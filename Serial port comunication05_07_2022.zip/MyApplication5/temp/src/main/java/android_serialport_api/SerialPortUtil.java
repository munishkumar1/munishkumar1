package android_serialport_api;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import callback.SerialPortCallBackUtils;
import util.ByteUtil;

/**
 * Created by Administrator on 2018/5/31.
 */

public class SerialPortUtil {

    public static String TAG = "SerialPortUtil";

    /**
     * Mark the current serial port status (true: open, false: closed)
     **/
    public static boolean isFlagSerial = false;

    public static SerialPort serialPort = null;
    public static InputStream inputStream = null;
    public static OutputStream outputStream = null;
    public static Thread receiveThread = null;
    public static String strData = "";

    /**
     * 打开串口
     */
    public static boolean open(String pathname, int baudrate, int flags) {
        boolean isopen = false;
        if (isFlagSerial) {
            return false;
        }
        try {
            serialPort = new SerialPort(new File(pathname), baudrate, flags);
            inputStream = serialPort.getInputStream();
            outputStream = serialPort.getOutputStream();
            receive();
            isopen = true;
            isFlagSerial = true;
        } catch (IOException e) {
            e.printStackTrace();
            isopen = false;
        }
        return isopen;
    }

    /**
     * 关闭串口
     */
    public static boolean close() {
        boolean isClose;
        try {
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
            if (serialPort != null) {
                serialPort.close();
            }
            isClose = true;
            isFlagSerial = false;//When the serial port is closed, the connection status is marked as false
        } catch (IOException e) {
            e.printStackTrace();
            Log.d("close:",e.getMessage().toString());
            isClose = false;
        }
        return isClose;
    }

    /**
     * Send serial commands
     */
    public static void sendString(String data) {
        if (!isFlagSerial) {
            return;
        }
        try {
            String aa = ByteUtil.strTo16(data);
            if (!aa.equals("2b2b2b"))
                aa = aa + "0a";

            Log.d("serialPortData","sendString:" + aa);
            byte[] sb = ByteUtil.hexStringToBytes(aa);
            outputStream.write(sb);
            outputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Send serial commands
     */
    public static void sendByte(byte[] bytes) {
        if (!isFlagSerial) {
            return;
        }
        try {
            Log.d("serialPortData","sendString:" + ByteUtil.bytesToHexString(bytes));
            outputStream.write(bytes);
            outputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * How to receive serial data
     */
    public static void receive() {
        if (receiveThread != null && !isFlagSerial) {
            return;
        }
        receiveThread = new Thread() {
            @Override
            public void run() {
                while (isFlagSerial) {
                    try {
                        byte[] readData = new byte[128];

                        if (inputStream == null) {
                            return;
                        }

                        int size = inputStream.read(readData);
                        if (size > 0 && isFlagSerial) {
                            byte[] newdata = new byte[size];
                            System.arraycopy(readData, 0, newdata, 0, size);
                           // strData = ByteUtil.toHexString(newdata);
                            strData = new String(newdata, 0, size);
                            Log.d("serialPortData","readData:" + strData);
//                            strData = ByteUtil.decode(strData);
//                            Log.d("serialPortData","readData:" + strData);
                            SerialPortCallBackUtils.doCallBackMethod(strData);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        receiveThread.start();
    }
}