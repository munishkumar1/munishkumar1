package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class LogListViewAdapter extends BaseAdapter {

	public ArrayList<ItemData> mData;

	public LogListViewAdapter() {
		mData = new ArrayList<>();
	}

	public void setData(ItemData data) {
		if (null != data) {
			mData.add(data);
			notifyDataSetChanged();
		}
	}

	@Override
	public int getCount() {
		return mData.size();
	}

	@Override
	public Object getItem(int position) {

		return mData.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (null == convertView) {
			View root = LayoutInflater.from(parent.getContext()).inflate(
					R.layout.list_view_item, parent, false);
			root.setTag(new ViewHolder(root));
			convertView = root;
		}
		ViewHolder holder = (ViewHolder) convertView.getTag();
		ItemData itemData = (ItemData) getItem(position);
		if (null != holder && null != itemData) {
			holder.cmd.setText(itemData.cmd == null ? "" : itemData.cmd);
			holder.data.setText(itemData.data == null ? "" : itemData.data);
		}
		return convertView;
	}

	static class ViewHolder {
		public TextView cmd;
		public TextView data;

		public ViewHolder(View root) {
			cmd = (TextView) root.findViewById(R.id.cmd);
			data = (TextView) root.findViewById(R.id.data);
		}
	}

	static class ItemData {
		public String cmd;
		public String data;
	}
}
