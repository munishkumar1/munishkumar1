package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import android_serialport_api.SerialPortFinder;
import android_serialport_api.SerialPortUtil;
import callback.SerialCallBack;
import callback.SerialPortCallBackUtils;

public class MainActivity extends AppCompatActivity implements SerialCallBack, View.OnClickListener {

    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MSG_EDITVIEW:
                    Bundle bundle = msg.getData();
                    LogListViewAdapter.ItemData itemData = new LogListViewAdapter.ItemData();
                    itemData.data = bundle.getString("data");
                    if (mListAdapter.mData.size() > 100) {
                        mListAdapter.mData.clear();
                    }
                    mListAdapter.setData(itemData);
                    mListView.setSelection(mListView.getBottom());
                    break;
                default:
                    break;
            }
        }
    };

    public void onSerialPortData(String serialPortData) {//串口数据回调
        Log.d("pbt","serialPortData :" + serialPortData);
        Message msg = new Message();
        msg.what = MSG_EDITVIEW;
        Bundle bundle = new Bundle();
        bundle.putString("data", serialPortData);
        msg.setData(bundle);
        mHandler.sendMessage(msg);
    }

    private final static String TAG = "UM4BD_Main";
    private Spinner mDevice_Spinner, mRate_Spinner;
    private boolean mOpen;
    private Button  mOpenUart, reset,send;

    private Context mContext;
    private final static int MSG_EDITVIEW = 1000;
    private ListView mListView;
    LogListViewAdapter mListAdapter;
    PowerManager pm;


/////////////////////////////////////////////////
//b5 62 06 8a 2c 00 00 01 00 00 c5 00 91 20 00 c7 00 91

// 20 00 c0 00 91 20 00 c2 00 91 20 00 ca 00 91 20 00

    // cc 00 91 20 00 ac 00 91 20 00 ae 00 91 20 00 43 36
    public static final byte[] SEND = new byte[] { (byte) 0xB5, 0x62, 0x06,
            (byte) 0x8A, 0x2C, 0x00,  0x00, 0x01, 0x00, 0x00, (byte) 0xC5, 0x00,
            (byte) 0x91, 0x20, 0x00, (byte) 0xC7,0x00, (byte) 0x91,
            0x20,0x00, (byte) 0xC0,0x00,(byte) 0x91,0x20,0x00, (byte) 0xC2,0x00,
            (byte) 0x91,0x20,0x00, (byte) 0xCA,0x00, (byte) 0x91,0x20,0x00,
            (byte) 0xcc,0x00, (byte) 0x91,0x20,0x00, (byte) 0xac,0x00,
            (byte) 0x91,0x20,0x00, (byte) 0xae,0x00, (byte) 0x91,0x20,0x00,0x43,0x36};

    /////////////////////////////////////////////////////
    public static final byte[] RESET = new byte[] { (byte) 0xB5, 0x62, 0x06,
            0x09, 0x0D, 0x00, (byte) 0xFF, (byte) 0xFF, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, (byte) 0xFF, (byte) 0xFF, 0x00, 0x00, 0x03, 0x1B,
            (byte) 0x9A };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        // 获取位置管理服务
        String serviceName = Context.LOCATION_SERVICE;
        InitView();
        pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
    }

    private void InitView() {

        mDevice_Spinner = findViewById(R.id.sp_uart);
        mRate_Spinner = findViewById(R.id.sp_baud_rate);
        mOpenUart = findViewById(R.id.bt_open_uart);
        mListView = findViewById(R.id.list);
        send = findViewById(R.id.bt_send);
        reset = findViewById(R.id.bt_reset);
        mListAdapter = new LogListViewAdapter();
        mListView.setAdapter(mListAdapter);
        mOpenUart.setOnClickListener(this);
        send.setOnClickListener(this);
        reset.setOnClickListener(this);
    }
    /**
     * 获取串口列表
     */
    private void initUartDevice() {
      //  SerialPortFinder mfinder = new SerialPortFinder();
      //  String device[] = mfinder.getAllDevices();
        List<String> list = new ArrayList<String>();

        ArrayAdapter adpter = new ArrayAdapter(mContext, android.R.layout.simple_spinner_item, android.R.id.text1, list);
        mDevice_Spinner.setAdapter(adpter);
        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.baudrates_value, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mRate_Spinner.setAdapter(adapter);
        mRate_Spinner.setSelection(16);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private String getResult(boolean result) {
        return (result ? getString(R.string.result_success) : getString(R.string.result_fail));
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.bt_open_uart:
                String device = mDevice_Spinner.getSelectedItem().toString();
                //device = "/dev/" + device.substring(0, device.indexOf("(")).trim();
                mOpen = SerialPortUtil.open(device,
                        Integer.parseInt(mRate_Spinner.getSelectedItem().toString().trim()), 0);
                if (mOpen) {
                    SerialPortCallBackUtils.setCallBack(this);
                    SerialPortUtil.receive();
                }
                Toast.makeText(mContext, "Open " + device + ",result:" + getResult(mOpen), Toast.LENGTH_SHORT).show();
                break;


            /////////////////////////////////////////
            case R.id.bt_reset:
                if (mOpen) {
                    SerialPortUtil.sendByte(RESET);
                } else {
                    Toast.makeText(mContext, getString(R.string.msg_toast), Toast.LENGTH_SHORT).show();
                }
                break;

                case R.id.bt_send:
               if (mOpen) {
                    SerialPortUtil.sendByte(SEND);
                } else {
                    Toast.makeText(mContext, getString(R.string.msg_toast), Toast.LENGTH_SHORT).show();
                }
                break;
            /////////////////////////////////////////


        }
    }
}