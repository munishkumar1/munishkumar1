package com.nextstack.chicken.customerapp.databases;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.nextstack.chicken.customerapp.models.cart_model.CartProduct;
import com.nextstack.chicken.customerapp.models.product_model.ProductDetails;
import com.nextstack.chicken.customerapp.utils.Utilities;

import java.util.ArrayList;


/**
 * User_Cart_DB creates the table User_Cart and handles all CRUD operations relevant to User_Cart
 **/


public class User_Cart_DB {

    SQLiteDatabase db;

    // Table Name
    public static final String TABLE_CART = "User_Cart";
    // Table Columns
    public static final String CART_ID                      = "cart_id";
    public static final String CART_PRODUCT_ID              = "products_id";
    public static final String CART_PRODUCT_NAME            = "products_name";
    public static final String CART_PRODUCT_IMAGE           = "products_image";
    public static final String CART_PRODUCT_WEIGHT          = "products_weight";
    public static final String CART_PRODUCT_WEIGHT_UNIT     = "products_weight_unit";
    public static final String CART_PRODUCT_STOCK           = "product_stock";
    public static final String CART_PRODUCT_QUANTITY        = "product_quantity";
    public static final String CART_PRODUCT_PRICE           = "product_price";
    public static final String CART_PRODUCT_TOTAL_PRICE     = "product_total_price";
    public static final String CART_PRODUCT_FINAL_PRICE     = "product_final_price";
    public static final String CART_CATEGORIES_NAME         = "categories_name";
    public static final String CART_DISTRIBUTOR_ID          = "distributor_id";
    public static final String CART_DATE_ADDED              = "cart_date_added";
    public static final String GST_TAX                      = "gst_tax";
    public static final String DELIVERY_CHARGE              = "delivery_charge";
    public static final String TAX_AMOUNT                   = "tax_amount";


    //*********** Returns the Query to Create TABLE_CART ********//

    public static String createTableCart() {

        return "CREATE TABLE "+ TABLE_CART +
                "(" +
                    CART_ID                         + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    CART_PRODUCT_ID                 + " INTEGER," +
                    CART_PRODUCT_NAME               + " TEXT," +
                    CART_PRODUCT_IMAGE              + " TEXT," +
                    CART_PRODUCT_WEIGHT             + " TEXT," +
                    CART_PRODUCT_WEIGHT_UNIT        + " TEXT," +
                    CART_PRODUCT_STOCK              + " INTEGER," +
                    CART_PRODUCT_QUANTITY           + " INTEGER," +
                    CART_PRODUCT_PRICE              + " TEXT," +
                    CART_PRODUCT_FINAL_PRICE        + " TEXT," +
                    CART_PRODUCT_TOTAL_PRICE        + " TEXT," +
                    CART_CATEGORIES_NAME            + " TEXT," +
                    CART_DISTRIBUTOR_ID             + " INTEGER," +
                    CART_DATE_ADDED                 + " TEXT," +
                    GST_TAX                         + " TEXT," +
                    DELIVERY_CHARGE                 + " TEXT," +
                    TAX_AMOUNT                      + " TEXT" +
                ")";
    }


    //*********** Fetch Last Inserted Cart_ID ********//

    public int getLastCartID() {
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        final String getCartID = "SELECT MAX("+ CART_ID +") FROM " + TABLE_CART;

        Cursor cur = db.rawQuery(getCartID, null);
        cur.moveToFirst();

        int cartID = cur.getInt(0);

        // close cursor and DB
        cur.close();
        DB_Manager.getInstance().closeDatabase();

        return cartID;
    }



    //*********** Insert New Cart Item ********//

    public void addCartItem(CartProduct cart) {
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        ContentValues productValues = new ContentValues();

        productValues.put(CART_PRODUCT_ID,                      cart.getCustomersBasketProduct().getProductsId());
        productValues.put(CART_PRODUCT_NAME,                    cart.getCustomersBasketProduct().getProductsName());
        productValues.put(CART_PRODUCT_IMAGE,                   cart.getCustomersBasketProduct().getProductsImage());
        productValues.put(CART_PRODUCT_WEIGHT,                  cart.getCustomersBasketProduct().getProductsWeight());
        productValues.put(CART_PRODUCT_WEIGHT_UNIT,             cart.getCustomersBasketProduct().getProductsWeightUnit());
        productValues.put(CART_PRODUCT_STOCK,                   cart.getCustomersBasketProduct().getCustomersBasketQuantity());
        productValues.put(CART_PRODUCT_QUANTITY,                cart.getCustomersBasketProduct().getProductsQuantity());
        productValues.put(CART_PRODUCT_PRICE,                   cart.getCustomersBasketProduct().getProductsPrice());
        productValues.put(CART_PRODUCT_FINAL_PRICE,             cart.getCustomersBasketProduct().getTotalPrice());
        //productValues.put(CART_PRODUCT_TOTAL_PRICE,             cart.getCustomersBasketProduct().getTotalPrice());
        productValues.put(CART_CATEGORIES_NAME,                 cart.getCustomersBasketProduct().getCategory_id());
        productValues.put(CART_DISTRIBUTOR_ID,                  String.valueOf(cart.getCustomersBasketProduct().getDistributorId()));
        productValues.put(CART_DATE_ADDED,                      Utilities.getDateTime());
        productValues.put(GST_TAX,                              cart.getGst_tax());
        productValues.put(DELIVERY_CHARGE,                      cart.getDelivery_charge());
        productValues.put(TAX_AMOUNT,                           cart.getCustomersBasketProduct().getTax_amount());

        db.insert(TABLE_CART, null, productValues);

        // close the Database
        DB_Manager.getInstance().closeDatabase();
    }



    //*********** Get all Cart Items ********//

    public ArrayList<CartProduct> getCartItems(String categoryId) {
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        Cursor cursor =  db.rawQuery( "SELECT * FROM "+ TABLE_CART, null);

        ArrayList<CartProduct> cartList = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                if (cursor.getString(11).equalsIgnoreCase(categoryId)) {
                    CartProduct cart = new CartProduct();
                    ProductDetails product = new ProductDetails();

                    product.setProductsId(cursor.getInt(1));
                    product.setProductsName(cursor.getString(2));
                    product.setProductsImage(cursor.getString(3));
                    product.setProductsWeight(cursor.getString(4));
                    product.setProductsWeightUnit(cursor.getString(5));
                    product.setCustomersBasketQuantity(cursor.getInt(6));
                    product.setProductsQuantity(cursor.getInt(7));
                    product.setProductsPrice(cursor.getString(8));
                    product.setTotalPrice(cursor.getString(9));
                    product.setCategory_id(cursor.getString(11));
                    product.setDistributorId(cursor.getInt(12));
                    product.setTax_amount(cursor.getString(16));


                    cart.setGst_tax(cursor.getString(14));
                    cart.setDelivery_charge(cursor.getString(15));


                    cart.setCustomersBasketId(cursor.getInt(0));
                    //cart.setCustomersBasketDateAdded(cursor.getString(24));

                    cart.setCustomersBasketProduct(product);


                    cartList.add(cart);
                }


            } while (cursor.moveToNext());
        }

        // close cursor and DB
        cursor.close();
        DB_Manager.getInstance().closeDatabase();

        return cartList;
    }



    //*********** Get all Cart Items ********//

    public CartProduct getCartProduct(int product_id) {
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CART + " WHERE " + CART_PRODUCT_ID + " = ?", new String[]{String.valueOf(product_id)});

        CartProduct cartProduct = new CartProduct();

        if (cursor != null) {
            cursor.moveToFirst();

            ProductDetails product = new ProductDetails();

            product.setProductsId(cursor.getInt(1));
            product.setProductsName(cursor.getString(2));
            product.setProductsImage(cursor.getString(3));
            product.setProductsWeight(cursor.getString(4));
            product.setProductsWeightUnit(cursor.getString(5));
            product.setCustomersBasketQuantity(cursor.getInt(6));
            product.setProductsQuantity(cursor.getInt(7));
            product.setProductsPrice(cursor.getString(8));
            product.setTotalPrice(cursor.getString(9));
            product.setCategory_id(cursor.getString(11));
            product.setTax_amount(cursor.getString(16));
            product.setDistributorId(Integer.parseInt(cursor.getString(12)));


            cartProduct.setGst_tax(cursor.getString(14));
            cartProduct.setDelivery_charge(cursor.getString(15));

            cartProduct.setCustomersBasketId(cursor.getInt(0));

            cartProduct.setCustomersBasketProduct(product);

        }

        // close cursor and DB
        cursor.close();
        DB_Manager.getInstance().closeDatabase();

        return cartProduct;
    }



    //*********** Fetch All Recent Items ********//

    public ArrayList<Integer> getCartItemsIDs() {
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        SQLiteDatabase db = DB_Manager.getInstance().openDatabase();

        ArrayList<Integer> cartIDs = new ArrayList<Integer>();

        Cursor cursor =  db.rawQuery( "SELECT "+ CART_PRODUCT_ID +" FROM "+ TABLE_CART , null);

        if (cursor.moveToFirst()) {
            do {
                cartIDs.add(cursor.getInt(0));

            } while (cursor.moveToNext());
        }


        // close the Database
        DB_Manager.getInstance().closeDatabase();

        return cartIDs;
    }



    //*********** Update Existing Cart Item ********//

    public void updateCart(CartProduct cart){
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        ContentValues productValues = new ContentValues();

        productValues.put(CART_PRODUCT_ID,                      cart.getCustomersBasketProduct().getProductsId());
        productValues.put(CART_PRODUCT_NAME,                    cart.getCustomersBasketProduct().getProductsName());
        productValues.put(CART_PRODUCT_IMAGE,                   cart.getCustomersBasketProduct().getProductsImage());
        productValues.put(CART_PRODUCT_WEIGHT,                  cart.getCustomersBasketProduct().getProductsWeight());
        productValues.put(CART_PRODUCT_WEIGHT_UNIT,             cart.getCustomersBasketProduct().getProductsWeightUnit());
        productValues.put(CART_PRODUCT_STOCK,                   cart.getCustomersBasketProduct().getProductsQuantity());
        productValues.put(CART_PRODUCT_QUANTITY,                cart.getCustomersBasketProduct().getCustomersBasketQuantity());
        productValues.put(CART_PRODUCT_PRICE,                   cart.getCustomersBasketProduct().getProductsPrice());
        productValues.put(CART_PRODUCT_FINAL_PRICE,             cart.getCustomersBasketProduct().getTotalPrice());
        //productValues.put(CART_PRODUCT_TOTAL_PRICE,             cart.getCustomersBasketProduct().getTotalPrice());
        productValues.put(CART_CATEGORIES_NAME,                 cart.getCustomersBasketProduct().getCategory_id());
        productValues.put(CART_DISTRIBUTOR_ID,                  cart.getCustomersBasketProduct().getDistributorId());
        productValues.put(TAX_AMOUNT,                           cart.getCustomersBasketProduct().getTax_amount());

        db.update(TABLE_CART, productValues, CART_ID +" = ?", new String[]{String.valueOf(cart.getCustomersBasketId())});

        // close the Database
        DB_Manager.getInstance().closeDatabase();
    }



    //*********** Update Price and Quantity of Existing Cart Item ********//

    public void updateCartItem(CartProduct cart) {
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        ContentValues values = new ContentValues();

        values.put(CART_PRODUCT_STOCK,                  cart.getCustomersBasketProduct().getCustomersBasketQuantity());
        values.put(CART_PRODUCT_FINAL_PRICE,            cart.getCustomersBasketProduct().getTotalPrice());
        values.put(TAX_AMOUNT,                          cart.getCustomersBasketProduct().getTax_amount());

        db.update(TABLE_CART, values, CART_ID +" = ?", new String[]{String.valueOf(cart.getCustomersBasketId())});

        // close the Database
        DB_Manager.getInstance().closeDatabase();
    }



    //*********** Delete specific Item from Cart ********//

    public void deleteCartItem(int cart_id) {
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        db.delete(TABLE_CART, CART_ID +" = ?", new String[]{String.valueOf(cart_id)});

        // close the Database
        DB_Manager.getInstance().closeDatabase();
    }



    //*********** Clear all User Cart ********//

    public void clearCart() {
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        db.delete(TABLE_CART, null, null);

        // close the Database
        DB_Manager.getInstance().closeDatabase();
    }
    
}

