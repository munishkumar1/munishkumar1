package com.nextstack.chicken.customerapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.CheckOutActivity;
import com.nextstack.chicken.customerapp.activity.DeliveryAddress;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.fragment.Add_Address;
import com.nextstack.chicken.customerapp.fragment.Addresses;
import com.nextstack.chicken.customerapp.location.GPSTracker;
import com.nextstack.chicken.customerapp.models.address_model.AddressDetails;
import com.nextstack.chicken.customerapp.utils.Utilities;

import java.io.IOException;
import java.util.List;
import java.util.Locale;


/**
 * AddressListAdapter is the adapter class of RecyclerView holding List of Addresses in My_Addresses
 **/

public class AddressListAdapter extends RecyclerView.Adapter<AddressListAdapter.MyViewHolder> {

    Context context;
    String customerID;
    List<AddressDetails> addressList;
    OnItemClickListener listener;

    CheckOutActivity activity;

    private static int selectedPosition;

    // To keep track of Checked Radio Button
    private RadioButton lastChecked_RB = null;



    public interface OnItemClickListener {
        void onItemClick(AddressDetails item);
    }

    public AddressListAdapter(Context context, String customerID, int defaultAddressPosition, List<AddressDetails> addressList, OnItemClickListener listener, CheckOutActivity activity) {
        this.context = context;
        this.customerID = customerID;
        this.addressList = addressList;
        this.selectedPosition = defaultAddressPosition;
        this.listener = listener;
        this.activity = activity;
    }

    public AddressListAdapter(Context context, String customerID, int defaultAddressPosition, List<AddressDetails> addressList) {
        this.context = context;
        this.customerID = customerID;
        this.addressList = addressList;
        this.selectedPosition = defaultAddressPosition;
    }


    //********** Called to Inflate a Layout from XML and then return the Holder *********//

    @Override
    public MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        // Inflate the custom layout
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_card_addresses, parent, false);

        return new MyViewHolder(itemView);
    }



    //********** Called by RecyclerView to display the data at the specified Position *********//

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        if (listener != null) {

                holder.bind(addressList, listener, context, position, activity, customerID);

        }
        else {

            // Get the data model based on Position
            final AddressDetails addressDetails = addressList.get(position);

            final String addressID = String.valueOf(addressDetails.getAddressId());

            holder.nickname.setText(addressDetails.getNickname());
            holder.address_title.setText(addressDetails.getFirstname() +" "+ addressDetails.getLastname());
            holder.address_details.setText(addressDetails.getStreet() +", "+ addressDetails.getCity() +", "+ addressDetails.getCountryName());


            // Toggle the Default Address RadioButton with Position
            if (position == selectedPosition) {
                holder.makeDefault_rb.setChecked(true);
                lastChecked_RB = holder.makeDefault_rb;
            } else {
                holder.makeDefault_rb.setChecked(false);
            }

            // Check the Clicked RadioButton
            holder.makeDefault_rb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (lastChecked_RB != null) {
                        lastChecked_RB.setChecked(false);
                    }

                    // Request the Server to Change Default Address
                    Addresses.MakeAddressDefault(customerID, addressID, context, view);

                    lastChecked_RB = holder.makeDefault_rb;
                    selectedPosition = position;

                    // Notify that items from specified position have changed.
                    notifyItemRangeChanged(holder.getAdapterPosition(), addressList.size());
                }
            });


            // Edit relevant Address
            holder.edit_address.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Set the current Address Info to Bundle
                    Bundle addressInfo = new Bundle();
                    addressInfo.putBoolean("isUpdate", true);
                    addressInfo.putString("addressID", addressID);
                    addressInfo.putString("addressFirstname", addressDetails.getFirstname());
                    addressInfo.putString("addressLastname", addressDetails.getLastname());
                    addressInfo.putString("addressCountryName", addressDetails.getCountryName());
                    addressInfo.putString("addressState", addressDetails.getState());
                    addressInfo.putString("addressCity", addressDetails.getCity());
                    addressInfo.putString("addressStreet", addressDetails.getStreet());
                    addressInfo.putString("addressPostCode", addressDetails.getPostcode());
                    addressInfo.putString("addressSuburb", addressDetails.getSuburb());
                    addressInfo.putString("addressLat", addressDetails.getLng());
                    addressInfo.putString("addressLng", addressDetails.getLng());
                    addressInfo.putString("nickname", addressDetails.getNickname());
                    addressInfo.putString("houseno", addressDetails.getHouse_no());
                    addressInfo.putString("landmark", addressDetails.getLandmark());


                    // Navigate to Add_Address Fragment with arguments to Edit Address

                    Intent intent = new Intent(context, DeliveryAddress.class);
                    intent.putExtra("addressInfo", addressInfo);
                    context.startActivity(intent);
                   /*
                    Fragment fragment = new Add_Address();
                    fragment.setArguments(addressInfo);
                    FragmentManager fragmentManager = ((MainActivity) context).getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.main_fragment, fragment)
                            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                            .addToBackStack(null).commit();*/
                }
            });


        }


    }



    //********** Returns the total number of items in the data set *********//

    @Override
    public int getItemCount() {
        if (listener!= null)
            return addressList.size()+1;
        else
            return addressList.size();
    }



    /********** Custom ViewHolder provides a direct reference to each of the Views within a Data_Item *********/

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageButton edit_address;
        RadioButton makeDefault_rb;
        TextView address_title, address_details, nickname;

        RadioButton lastChecked_RB = null;


        public MyViewHolder(final View itemView) {
            super(itemView);

            address_title = itemView.findViewById(R.id.address_title);
            address_details = itemView.findViewById(R.id.address_details);
            edit_address = itemView.findViewById(R.id.edit_address);
            nickname = itemView.findViewById(R.id.nickname);
            makeDefault_rb = itemView.findViewById(R.id.default_address_rb);
            }

        public void bind(final List<AddressDetails> addressDetails, final OnItemClickListener listener, final Context context, final int position, final CheckOutActivity activity, final String customerID) {

            GPSTracker gps;
            Location location;
            Geocoder geocoder;
            List<Address> addresses;

            MyAppPrefsManager myAppPrefsManager = new MyAppPrefsManager(context);

            if (position == 0) {
                geocoder = new Geocoder(context, Locale.getDefault());

                gps = new GPSTracker(context);

                if (Utilities.isNetworkAvailable(activity)) {

                    if (gps.canGetLocation()) {
                        location = gps.getLocation();
                        try {
                            addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);

                            nickname.setText("Current Location");
                            edit_address.setVisibility(View.GONE);
                            address_title.setText(myAppPrefsManager.getUserName());
                            address_details.setText(addresses.get(0).getSubAdminArea() + ", " + addresses.get(0).getLocality() + ", " + addresses.get(0).getCountryName());

                            final AddressDetails current = new AddressDetails();

                            current.setFirstname(myAppPrefsManager.getUserName().split(" ")[0]);
                            current.setLastname(myAppPrefsManager.getUserName().split(" ")[1]);
                            current.setStreet(addresses.get(0).getSubAdminArea());
                            current.setCity(addresses.get(0).getLocality());
                            current.setSuburb(addresses.get(0).getLocality());
                            current.setPostcode(addresses.get(0).getPostalCode());
                            current.setState(addresses.get(0).getAdminArea());
                            current.setCountryName(addresses.get(0).getCountryName());
                            current.setZoneId(183);

                            Add_Address addAddress = new Add_Address();

                            addAddress.addUserAddress
                                    (
                                            customerID,
                                            current.getFirstname(),
                                            current.getLastname(),
                                            current.getStreet(),
                                            current.getPostcode(),
                                            current.getCity(),
                                            current.getState(),
                                            "253",
                                            "",
                                            "",
                                            "",
                                            "",
                                            " ",
                                            "2",
                                            context,
                                            null
                                    );

                            itemView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    listener.onItemClick(current);
                                    activity.address.setText(current.getStreet() + ", " + current.getCity() + ", " + current.getCountryName());
                                }
                            });

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Toast.makeText(context, "Can not get Current Location", Toast.LENGTH_LONG).show();
                    }

                }
            } else {

                final AddressDetails addressList = addressDetails.get(position-1);

                nickname.setText(addressList.getNickname());
                edit_address.setVisibility(View.GONE);
                address_title.setText(addressList.getFirstname() + " " + addressList.getLastname());
                address_details.setText(addressList.getStreet() + ", " + addressList.getCity() + ", " + addressList.getCountryName());

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onItemClick(addressList);
                        activity.address.setText(addressList.getStreet() + ", " + addressList.getCity() + ", " + addressList.getCountryName());
                    }
                });

            }

            if (position == selectedPosition) {
                makeDefault_rb.setChecked(true);
                lastChecked_RB = makeDefault_rb;
            } else {
                makeDefault_rb.setChecked(false);
            }

            final String addressID = position == 0?"0":String.valueOf(addressDetails.get(position-1).getAddressId());


            // Check the Clicked RadioButton
            makeDefault_rb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (lastChecked_RB != null) {
                        lastChecked_RB.setChecked(false);
                    }

                    // Request the Server to Change Default Address
                    if (!addressID.equalsIgnoreCase("0")) {
                        Addresses.MakeAddressDefault(customerID, addressID, context, view);

                        lastChecked_RB = makeDefault_rb;

                        selectedPosition = position;
                        notifyItemRangeChanged(getAdapterPosition(), AddressListAdapter.this.addressList.size());
                    }
                }
            });

        }
    }
}

