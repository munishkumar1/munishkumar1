package com.nextstack.chicken.customerapp.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.models.faq_model.FaqData;
import com.nextstack.chicken.customerapp.network.APIClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BulkOrder extends Fragment {

    Button request_button;

    TextView request_status;

    EditText textView2;

    String email, mobile, body, subject, message;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_bulk_order, container, false);

        request_button = rootView.findViewById(R.id.request_button);
        request_status = rootView.findViewById(R.id.request_status);
        textView2 = rootView.findViewById(R.id.textView2);

        email = "himanginikar287@gmail.com";
        mobile = "9337279260";


        subject="Bulk Order Request";



        if (ConstantValues.IS_USER_LOGGED_IN)
        {
            request_button.setEnabled(true);


        }else
        {
            request_button.setEnabled(false);
            request_button.setBackgroundColor(getResources().getColor(R.color.colorAccentGrey));


        }

        request_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                message = body = textView2.getText().toString();

                Call<FaqData> call = APIClient.getNetInstance(true).sendEmail_Sms
                        (
                            email,
                            subject,
                            body,
                            mobile,
                            message
                        );

                call.enqueue(new Callback<FaqData>() {
                    @Override
                    public void onResponse(Call<FaqData> call, Response<FaqData> response) {

                        if (response.isSuccessful()) {

                            request_status.setVisibility(View.VISIBLE);
                            textView2.setText(message);

                            Toast.makeText(getContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();

                        } else {
                            // Show the Error Message
                            Toast.makeText(getContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                        }

                    }

                    @Override
                    public void onFailure(Call<FaqData> call, Throwable t) {

                        Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();

                    }
                });

            }
        });

        return rootView;
    }
}
