package com.nextstack.chicken.customerapp.models.order_model;

import java.util.List;

public class OrderDataPost {

    private PostOrder postOrder;
    private List<PostProducts> postProducts;

    public OrderDataPost(PostOrder postOrder, List<PostProducts> postProducts) {
        this.postOrder = postOrder;
        this.postProducts = postProducts;
    }

    public PostOrder getPostOrder() {
        return postOrder;
    }

    public void setPostOrder(PostOrder postOrder) {
        this.postOrder = postOrder;
    }

    public List<PostProducts> getPostProducts() {
        return postProducts;
    }

    public void setPostProducts(List<PostProducts> postProducts) {
        this.postProducts = postProducts;
    }
}
