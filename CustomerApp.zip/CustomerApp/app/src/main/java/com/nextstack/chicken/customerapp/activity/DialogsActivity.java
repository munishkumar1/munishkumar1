package com.nextstack.chicken.customerapp.activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.Toast;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.models.faq_model.FaqData;
import com.nextstack.chicken.customerapp.network.APIClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DialogsActivity extends AppCompatActivity {
    RatingBar mRate;
    Button mSubmitref;
    EditText mRefCode;
    String totalStars;
    int rating ;
    LinearLayout comment_layout;
    EditText mReview;
    Boolean val = true;
    MyAppPrefsManager myAppPrefsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialogs);
        myAppPrefsManager = new MyAppPrefsManager(DialogsActivity.this);
        initLayout();

    }
    private  void initLayout(){

    if(myAppPrefsManager.isUserLoggedIn())
    {
        if(myAppPrefsManager.isUserRated()) {
            openDialog();
        }else
        {
            //todo ad dialog
        }
    }
    else {
        openDialogRef();
    }
    }
    private void openDialog() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(DialogsActivity.this);
        View dialogView = getLayoutInflater().inflate(R.layout.rate_dialog, null);
        dialog.setView(dialogView);
        dialog.setCancelable(true);
             /* Intent i = new Intent(SplashActivity.this,My_Orders.class);
                 startActivity(i);*/
        mRate = dialogView.findViewById(R.id.reviewBar);
         Button mSubmit = dialogView.findViewById(R.id.id_submit);
        mReview = dialogView.findViewById(R.id.id_review);
        final AlertDialog alertDialog = dialog.create();
        alertDialog.show();
        mRate.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rate, boolean fromUser) {
                rating = (int) rate;
                //   session.setRatingCode(rating);
                System.out.println("Rate for Module is" + rating);
                mRate.setIsIndicator(true);
                mRate.setRating(rating);
                totalStars = String.valueOf(mRate.getNumStars());


            }
        });
        mSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Call<FaqData> call = APIClient.getNetInstance(false).rateDistributor
                        (
                                String.valueOf(myAppPrefsManager.getOrdersId()),
                                myAppPrefsManager.getcustomerID(),
                                rating,
                                String.valueOf(mReview.getText())
                        );
                call.enqueue(new Callback<FaqData>() {
                    @Override
                    public void onResponse(Call<FaqData> call, Response<FaqData> response) {
                        if (response.isSuccessful()) {
                            LayerDrawable stars = (LayerDrawable) mRate.getProgressDrawable();
                            stars.getDrawable(2).setColorFilter(ContextCompat.getColor(DialogsActivity.this, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
                            comment_layout.setVisibility(View.GONE);
                            comment_layout.setVisibility(View.VISIBLE);
                            //    comment_layout.setText(String.valueOf(holder.mReview.getText()));
                            startActivity(new Intent(DialogsActivity.this, HomeActivity.class));
                            finish();
                            Toast.makeText(DialogsActivity.this, "You rated the order " + rating, Toast.LENGTH_SHORT).show();

                        }

                        mRate.setNumStars(Integer.parseInt(totalStars));
                    }

                    @Override
                    public void onFailure(Call<FaqData> call, Throwable t) {
                        Toast.makeText(DialogsActivity.this, "NetworkCallFailure : " + t, Toast.LENGTH_LONG).show();
                        val = false;
                    }
                });
            }
        });

        alertDialog.show();
    }

    private void openDialogRef() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(DialogsActivity.this);
        View dialogView = getLayoutInflater().inflate(R.layout.submit_ref_code, null);
        dialog.setView(dialogView);
        dialog.setCancelable(true);

        //  mRate = dialogView.findViewById(R.id.reviewBar);
        mSubmitref = dialogView.findViewById(R.id.login);
        mRefCode = dialogView.findViewById(R.id.id_review);
        final AlertDialog alertDialog = dialog.create();
        alertDialog.show();
        mSubmitref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(DialogsActivity.this, LoginActivity.class);
                startActivity(i);

               /* Call<FaqData> call = APIClient.getNetInstance(false).rateDistributor
                        (
                                String.valueOf(myAppPrefsManager.getOrdersId()),
                                myAppPrefsManager.getcustomerID(),
                                rating,
                                String.valueOf(mReview.getText())
                        );
                call.enqueue(new Callback<FaqData>() {
                    @Override
                    public void onResponse(Call<FaqData> call, Response<FaqData> response) {
                        if (response.isSuccessful()) {

                            //    comment_layout.setText(String.valueOf(holder.mReview.getText()));
                            startActivity(new Intent(getBaseContext(), HomeActivity.class));
                            finish();
                            Toast.makeText(SplashActivity.this, "You rated the order " + rating, Toast.LENGTH_SHORT).show();

                        }


                    }

                    @Override
                    public void onFailure(Call<FaqData> call, Throwable t) {
                        Toast.makeText(SplashActivity.this, "NetworkCallFailure : " + t, Toast.LENGTH_LONG).show();

                    }
                });*/
            }
        });

        alertDialog.show();
    }
}
