package com.nextstack.chicken.customerapp.models.product_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;


public class ProductData {

    @SerializedName("Success")
    @Expose
    private int success;
    @SerializedName("data")
    @Expose
    private List<ProductDetails> productData = new ArrayList<>();
    @SerializedName("Message")
    @Expose
    private String message;

    /**
     *
     * @return
     * The success
     */
    public int getSuccess() {
        return success;
    }

    /**
     *
     * @param success
     * The success
     */
    public void setSuccess(int success) {
        this.success = success;
    }

    /**
     *
     * @return
     * The productData
     */
    public List<ProductDetails> getProductData() {
        return productData;
    }

    /**
     *
     * @param productData
     * The product_data
     */
    public void setProductData(List<ProductDetails> productData) {
        this.productData = productData;
    }

    /**
     *
     * @return
     * The message
     */
    public String getMessage() {
        return message;
    }

    /**
     *
     * @param message
     * The message
     */
    public void setMessage(String message) {
        this.message = message;
    }


}
