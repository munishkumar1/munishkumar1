package com.nextstack.chicken.customerapp.models.paytm_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PaytmDetails {

    @SerializedName("MID")
    @Expose
    private String mid;
    @SerializedName("ORDER_ID")
    @Expose
    private String orderId;
    @SerializedName("CUST_ID")
    @Expose
    private String customerId;
    @SerializedName("CHANNEL_ID")
    @Expose
    private String channelId;
    @SerializedName("TXN_AMOUNT")
    @Expose
    private String txnAmount;
    @SerializedName("WEBSITE")
    @Expose
    private String website;
    @SerializedName("INDUSTRY_TYPE_ID")
    @Expose
    private String industryTypeId;
    @SerializedName("CALLBACK_URL")
    @Expose
    private String callbackUrl;

    public PaytmDetails(String mid, String orderId, String customerId, String channelId, String txnAmount, String website, String industryTypeId, String callbackUrl) {
        this.mid = mid;
        this.orderId = orderId;
        this.customerId = customerId;
        this.channelId = channelId;
        this.txnAmount = txnAmount;
        this.website = website;
        this.industryTypeId = industryTypeId;
        this.callbackUrl = callbackUrl;


    }

    public String getMid() {
        return mid;
    }

    public String getOrderId() {
        return orderId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getChannelId() {
        return channelId;
    }

    public String getTxnAmount() {
        return txnAmount;
    }

    public String getWebsite() {
        return website;
    }

    public String getIndustryTypeId() {
        return industryTypeId;
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }


}
