package com.nextstack.chicken.customerapp.app;

import android.content.Context;
import android.content.SharedPreferences;


/**
 * MyAppPrefsManager handles some Prefs of AndroidShopApp Application
 **/


public  class MyAppPrefsManager {

    private static final String IS_USER_RATED ="isUserRated";
    private static final String ORDER_IDR = "OrdersId";
    private static final String CUSTOMER_ID = "customerID";
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor prefsEditor;
    
    private int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "AndroidShopApp_Prefs";


    private static final String USER_LANGUAGE_ID  = "language_ID";
    private static final String USER_ID  = "user_ID";
    private static final String USER_NAME = "user_Name";
    private static final String USER_PROFILE  = "user_Profile";
    private static final String USER_MOBILE  = "user_Mobile";
    private static final String USER_EMAIL  = "user_Email";
    private static final String USER_WALLET  = "user_Wallet";
    private static final String USER_WALLET_MOBILE  = "user_Wallet_mobile";
    private static final String DISTRIBUTOR_ID  = "distributor_ID";
    private static final String DEVICE_ID  = "device_id";
    private static final String DISTRIBUTOR_NAME  = "distributor_Name";
    private static final String USER_LANGUAGE_CODE  = "language_Code";
    private static final String IS_USER_LOGGED_IN = "isLogged_in";
    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";
    private static final String IS_PUSH_NOTIFICATIONS_ENABLED = "isPushNotificationsEnabled";
    private static final String IS_LOCAL_NOTIFICATIONS_ENABLED = "isLocalNotificationsEnabled";

    private static final String LOCAL_NOTIFICATIONS_TITLE = "localNotificationsTitle";
    private static final String LOCAL_NOTIFICATIONS_DURATION = "localNotificationsDuration";
    private static final String LOCAL_NOTIFICATIONS_DESCRIPTION = "localNotificationsDescription";


    private static final String APP_CATEGORY_ID = "appCategoryId";
    private static final String APP_CATEGORY_NAME = "appCategoryName";
    private static final String APP_CATEGORY_IMAGE = "appCategoryImage";
    private static final String ADDRESS_CART_COUNT = "addressCartCount";
    private static final String SHOP_STATUS = "shopStatus";
    private static final String REF_CODE= "refcode";
    private static final String RATING_CODE= "ratingcode";





    public MyAppPrefsManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        prefsEditor = sharedPreferences.edit();
    }

    public void setAddressCartCount(int addressCartCount) {
        prefsEditor.putInt(ADDRESS_CART_COUNT, addressCartCount);
        prefsEditor.commit();
    }

    public int getAddressCartCount() {
        return sharedPreferences.getInt(ADDRESS_CART_COUNT, 0);
    }

    public void setShopStatus(String shopStatus) {
        prefsEditor.putString(SHOP_STATUS, shopStatus);
        prefsEditor.commit();
    }

    public String getShopStatus() {
        return sharedPreferences.getString(SHOP_STATUS, null);
    }

    public void setUser_Email(String user_Email) {
        prefsEditor.putString(USER_EMAIL, user_Email);
        prefsEditor.commit();
    }

    public String getUser_Email() {
        return sharedPreferences.getString(USER_EMAIL,null);
    }

    public void setUser_Mobile(String user_Mobile) {
        prefsEditor.putString(USER_MOBILE, user_Mobile);
        prefsEditor.commit();
    }

    public String getUser_Mobile() {
        return sharedPreferences.getString(USER_MOBILE,null);
    }

public void setUserWalletMobile(String user_Wallet_mobile) {
        prefsEditor.putString(USER_WALLET_MOBILE, user_Wallet_mobile);
        prefsEditor.commit();
    }

    public String getUserWalletMobile() {
        return sharedPreferences.getString(USER_WALLET_MOBILE,null);
    }



    public void setUserWalletId(String user_Wallet) {
        prefsEditor.putString(USER_WALLET, user_Wallet);
        prefsEditor.commit();
    }

    public String getUserWalletId() {
        return sharedPreferences.getString(USER_WALLET, null);
    }



    public void setAppCategoryId(String appCategoryId) {
        prefsEditor.putString(APP_CATEGORY_ID, appCategoryId);
        prefsEditor.commit();
    }

    public String getAppCategoryId() {
        return sharedPreferences.getString(APP_CATEGORY_ID, null);
    }

    public void setAppCategoryName(String appCategoryName) {
        prefsEditor.putString(APP_CATEGORY_NAME, appCategoryName);
        prefsEditor.commit();
    }

    public String getAppCategoryName() {
        return sharedPreferences.getString(APP_CATEGORY_NAME, null);
    }

    public void setAppCategoryImage(String appCategoryImage) {
        prefsEditor.putString(APP_CATEGORY_IMAGE, appCategoryImage);
        prefsEditor.commit();
    }

    public String getAppCategoryImage() {
        return sharedPreferences.getString(APP_CATEGORY_IMAGE, null);
    }

    public void setDistributorId(String distID) {
        prefsEditor.putString(DISTRIBUTOR_ID, distID);
        prefsEditor.commit();
    }

    public String getDistributorId() {
        return sharedPreferences.getString(DISTRIBUTOR_ID, null);
    }
    public void setUserId(String userID) {
        prefsEditor.putString(USER_ID, userID);
        prefsEditor.commit();
    }

    public String getUserId() {
        return sharedPreferences.getString(USER_ID, null);
    }

    public void setUserName(String userName) {
        prefsEditor.putString(USER_NAME, userName);
        prefsEditor.commit();
    }

    public String getUserName() {
        return sharedPreferences.getString(USER_NAME, null);
    }

    public void setUserProfile(String userProfile) {
        prefsEditor.putString(USER_PROFILE, userProfile);
        prefsEditor.commit();
    }

    public String getUserProfile() {
        return sharedPreferences.getString(USER_PROFILE, null);
    }

    public void setDeviceId(String deviceID) {
        prefsEditor.putString(DEVICE_ID, deviceID);
        prefsEditor.commit();
    }

    public String getDeviceId() {
        return sharedPreferences.getString(DEVICE_ID, null);
    }

    public void setDistributorName(String distributorName) {
        prefsEditor.putString(DISTRIBUTOR_NAME, distributorName);
        prefsEditor.commit();
    }

    public String getDistributorName() {
        return sharedPreferences.getString(DISTRIBUTOR_NAME, null);
    }
    
    public void setUserLanguageId(int langID) {
        prefsEditor.putInt(USER_LANGUAGE_ID, langID);
        prefsEditor.commit();
    }
    
    public Integer getUserLanguageId() {
        return sharedPreferences.getInt(USER_LANGUAGE_ID, 1);
    }
    
    public void setUserLanguageCode(String langCode) {
        prefsEditor.putString(USER_LANGUAGE_CODE, langCode);
        prefsEditor.commit();
    }
    
    public String getUserLanguageCode() {
        return sharedPreferences.getString(USER_LANGUAGE_CODE, "en");
    }
    
    
    public void setUserLoggedIn(boolean isUserLoggedIn) {
        prefsEditor.putBoolean(IS_USER_LOGGED_IN, isUserLoggedIn);
        prefsEditor.commit();
    }

    public boolean isUserLoggedIn() {
        return sharedPreferences.getBoolean(IS_USER_LOGGED_IN, false);
    }


    public void setFirstTimeLaunch(boolean isFirstTimeLaunch) {
        prefsEditor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTimeLaunch);
        prefsEditor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return sharedPreferences.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    public void setPushNotificationsEnabled(boolean isPushNotificationsEnabled) {
        prefsEditor.putBoolean(IS_PUSH_NOTIFICATIONS_ENABLED, isPushNotificationsEnabled);
        prefsEditor.commit();
    }

    public boolean isPushNotificationsEnabled() {
        return sharedPreferences.getBoolean(IS_PUSH_NOTIFICATIONS_ENABLED, true);
    }

    public void setLocalNotificationsEnabled(boolean isLocalNotificationsEnabled) {
        prefsEditor.putBoolean(IS_LOCAL_NOTIFICATIONS_ENABLED, isLocalNotificationsEnabled);
        prefsEditor.commit();
    }

    public boolean isLocalNotificationsEnabled() {
        return sharedPreferences.getBoolean(IS_LOCAL_NOTIFICATIONS_ENABLED, true);
    }


    public void setLocalNotificationsTitle(String localNotificationsTitle) {
        prefsEditor.putString(LOCAL_NOTIFICATIONS_TITLE, localNotificationsTitle);
        prefsEditor.commit();
    }

    public String getLocalNotificationsTitle() {
        return sharedPreferences.getString(LOCAL_NOTIFICATIONS_TITLE, "Android Ecommerce");
    }

    public void setLocalNotificationsDuration(String localNotificationsDuration) {
        prefsEditor.putString(LOCAL_NOTIFICATIONS_DURATION, localNotificationsDuration);
        prefsEditor.commit();
    }

    public String getLocalNotificationsDuration() {
        return sharedPreferences.getString(LOCAL_NOTIFICATIONS_DURATION, "day");
    }

    public void setLocalNotificationsDescription(String localNotificationsDescription) {
        prefsEditor.putString(LOCAL_NOTIFICATIONS_DESCRIPTION, localNotificationsDescription);
        prefsEditor.commit();
    }

    public String getLocalNotificationsDescription() {
        return sharedPreferences.getString(LOCAL_NOTIFICATIONS_DESCRIPTION, "Check bundle of new Products");
    }

    public  String getRefCode() {
        return sharedPreferences.getString(REF_CODE,"refcode");
    }
    public void setRefCode(String refCode) {
        prefsEditor.putString(LOCAL_NOTIFICATIONS_DESCRIPTION, refCode);
        prefsEditor.commit();
    }
     public  void setRatingCode(int ratingCode){
        prefsEditor.putInt(RATING_CODE, ratingCode);
        prefsEditor.commit();
     }
    public float getRatingCode() {
        return sharedPreferences.getInt(RATING_CODE,1);
    }
    public void setUserRated(boolean isUserRated) {
        prefsEditor.putBoolean(IS_USER_RATED, isUserRated);
        prefsEditor.commit();
    }

    public boolean isUserRated() {
        return sharedPreferences.getBoolean(IS_USER_RATED, false);
    }
    public  void setOrdersId(int OrdersId){
        prefsEditor.putInt(ORDER_IDR, OrdersId);
        prefsEditor.commit();
    }
    public float getOrdersId() {
        return sharedPreferences.getInt(ORDER_IDR,1);
    }
    public  String getcustomerID() {
        return sharedPreferences.getString(CUSTOMER_ID,"customerID");
    }
    public void  setcustomerID(String customerID) {
        prefsEditor.putString(CUSTOMER_ID, customerID);
        prefsEditor.commit();
    }
}
