package com.nextstack.chicken.customerapp.fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.CheckOutActivity;
import com.nextstack.chicken.customerapp.activity.LoginActivity;
import com.nextstack.chicken.customerapp.activity.MainActivity;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.databases.User_Cart_DB;
import com.nextstack.chicken.customerapp.models.cart_model.CartProduct;
import com.nextstack.chicken.customerapp.models.product_model.ProductDetails;
import com.nextstack.chicken.customerapp.models.shop_model.ShopData;
import com.nextstack.chicken.customerapp.models.shop_model.ShopDetails;
import com.nextstack.chicken.customerapp.network.APIClient;
import com.nextstack.chicken.customerapp.utils.CartOperations;
import com.nextstack.chicken.customerapp.utils.Utilities;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchResult extends Fragment {


    View rootView;

    private ImageView shop_image, product_image;
    private TextView shop_name, distance, product_name, quantity, price, quantity_count, no_shops;

    private LinearLayout quantity_layout;
    private ConstraintLayout product;

    private ImageButton remove, add_more;

    private Button btn_add, checkout_button;

    private int productId, productQuantity, distributorId;
    private String productName, productImage, productWeight, productWeightUnit, productPrice, taxRate;

    ProductDetails productDetails = new ProductDetails();
    List<CartProduct> cartItemsList = new ArrayList<>();
    ArrayList<Integer> cartItemsID = new ArrayList<>();
    User_Cart_DB db;

    MyAppPrefsManager session;

    String gst_tax, delivery_charge;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public void onResume() {
        super.onResume();

        cartItemsList = db.getCartItems(session.getAppCategoryId());

        if (cartItemsList.size() > 0)
        {
            checkout_button.setVisibility(View.VISIBLE);
        }else
        {
            checkout_button.setVisibility(View.GONE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_search_result, container, false);

        shop_image = rootView.findViewById(R.id.shop_image);
        product_image = rootView.findViewById(R.id.product_image);
        shop_name = rootView.findViewById(R.id.shop_name);
        distance = rootView.findViewById(R.id.distance);
        product_name = rootView.findViewById(R.id.product_name);
        quantity = rootView.findViewById(R.id.quantity);
        price = rootView.findViewById(R.id.price);
        quantity_count = rootView.findViewById(R.id.quantity_count);
        quantity_layout = rootView.findViewById(R.id.quantity_layout);
        remove = rootView.findViewById(R.id.remove);
        add_more = rootView.findViewById(R.id.add_more);
        btn_add = rootView.findViewById(R.id.btn_add);
        checkout_button = rootView.findViewById(R.id.checkout_button);
        product = (ConstraintLayout) rootView.findViewById(R.id.product);
        no_shops = rootView.findViewById(R.id.no_shops);

        db = new User_Cart_DB();
        session = new MyAppPrefsManager(getContext());


        if (getArguments() != null)
        {
            productId = getArguments().getInt("product_id");
            productName = getArguments().getString("product_name");
            productImage = getArguments().getString("product_image");
            productWeight = getArguments().getString("product_weight");
            productWeightUnit = getArguments().getString("product_weight_unit");
            productQuantity = getArguments().getInt("product_quantity");
            productPrice = getArguments().getString("product_price");
            taxRate = getArguments().getString("tax_rate");
        }

        product_name.setText(productName);
        price.setText(productPrice);

        Glide
                .with(getContext())
                .load(productImage)
                .placeholder(R.drawable.profile)
                .into(product_image);

        quantity.setText(productWeight + " " + productWeightUnit);

        cartItemsID = db.getCartItemsIDs();

        if (cartItemsID.contains(productId) && ConstantValues.IS_USER_LOGGED_IN) {

            CartProduct cart;
            cart = db.getCartProduct(productId);
            if (cart.getCustomersBasketProduct().getDistributorId() == distributorId) {

                quantity_layout.setVisibility(View.VISIBLE);
                btn_add.setVisibility(View.GONE);
                quantity_count.setText(String.valueOf(cart.getCustomersBasketProduct().getCustomersBasketQuantity()));
                cartItemsID.clear();
            }

            else
            {
                quantity_layout.setVisibility(View.GONE);
                btn_add.setVisibility(View.VISIBLE);
            }
        }
        else {
            quantity_layout.setVisibility(View.GONE);
            btn_add.setVisibility(View.VISIBLE);
        }

        getDistributors(productId);

        cartItemsList = db.getCartItems(session.getAppCategoryId());

        if (cartItemsList.size() > 0)
        {
            checkout_button.setVisibility(View.VISIBLE);
        }

        checkout_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getContext(), CheckOutActivity.class);
                startActivity(i);

            }
        });



        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (ConstantValues.IS_USER_LOGGED_IN) {

                    cartItemsList = db.getCartItems(session.getAppCategoryId());

                    if (productQuantity > 0) {

                        if (cartItemsList.size() > 0 && cartItemsList.get(0).getCustomersBasketProduct().getDistributorId() == distributorId) {

                            setCartProduct();

                            quantity_layout.setVisibility(View.VISIBLE);
                            btn_add.setVisibility(View.GONE);
                            quantity_count.setText("1");

                            checkout_button.setVisibility(View.VISIBLE);

                            Snackbar.make(view, getContext().getString(R.string.item_added_to_cart), Snackbar.LENGTH_SHORT).show();
                        }else if (cartItemsList.size() == 0)
                        {
                            if (productQuantity > 0) {

                                setCartProduct();

                                quantity_layout.setVisibility(View.VISIBLE);
                                btn_add.setVisibility(View.GONE);
                                quantity_count.setText("1");

                                checkout_button.setVisibility(View.VISIBLE);

                                Snackbar.make(view, getContext().getString(R.string.item_added_to_cart), Snackbar.LENGTH_SHORT).show();
                            }
                        }
                        else
                        {

                            final AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
                            View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_clear_cart_alert, null);
                            dialog.setView(dialogView);
                            dialog.setCancelable(false);

                            Button dialog_button_cancel = dialogView.findViewById(R.id.dialog_button_cancel);
                            Button dialog_button_continue = dialogView.findViewById(R.id.dialog_button_continue);

                            final AlertDialog alertDialog = dialog.create();

                            dialog_button_cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                    alertDialog.dismiss();

                                }
                            });

                            dialog_button_continue.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                    CartOperations.ClearCart();

                                    if (productQuantity > 0) {

                                        setCartProduct();

                                        quantity_layout.setVisibility(View.VISIBLE);
                                        btn_add.setVisibility(View.GONE);
                                        quantity_count.setText("1");

                                        checkout_button.setVisibility(View.VISIBLE);


                                        alertDialog.dismiss();

                                        Snackbar.make(view, getContext().getString(R.string.item_added_to_cart), Snackbar.LENGTH_SHORT).show();
                                    }

                                }
                            });

                            alertDialog.show();
                        }
                    }
                    else
                    {

                    }
                }
                else {
                    Intent i = new Intent(getContext(), LoginActivity.class);
                    startActivity(i);
                }
            }

        });


        add_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setCartProduct();

                quantity_count.setText(String.valueOf(Integer.parseInt(quantity_count.getText().toString()) + 1));

                remove.setEnabled(true);
                remove.setColorFilter(getContext().getResources().getColor(R.color.colorPrimary));

            }
        });


        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                CartProduct cartProduct = new CartProduct();

                cartItemsID = db.getCartItemsIDs();

                if (cartItemsID.contains(productDetails.getProductsId())) {

                    CartProduct cart;
                    cart = db.getCartProduct(productDetails.getProductsId());

                    if (cart.getCustomersBasketProduct().getCustomersBasketQuantity() > 1) {

                        quantity_count.setText(String.valueOf(Integer.parseInt(quantity_count.getText().toString()) - 1));

                        remove.setEnabled(true);
                        remove.setColorFilter(getContext().getResources().getColor(R.color.colorPrimary));

                        double tax, taxPrice, basePrice;

                        tax = Double.parseDouble(taxRate);
                        basePrice = Double.parseDouble(productDetails.getProductsPrice());
                        taxPrice = (basePrice*tax)/100;

                        productDetails.setProductsId(productId);
                        productDetails.setProductsName(productName);
                        productDetails.setProductsImage(productImage);
                        productDetails.setProductsPrice(productPrice);
                        productDetails.setCategory_id(session.getAppCategoryId());
                        productDetails.setCustomersBasketQuantity(cart.getCustomersBasketProduct().getCustomersBasketQuantity() - 1);
                        productDetails.setTotalPrice(String.valueOf(Double.parseDouble(cart.getCustomersBasketProduct().getTotalPrice()) - Double.parseDouble(productPrice)  - taxPrice));
                        productDetails.setTax_amount(String.valueOf(Double.parseDouble(productDetails.getTax_amount()) - taxPrice));

                        cartProduct.setCustomersBasketId(cart.getCustomersBasketId());
                        cartProduct.setCustomersBasketProduct(productDetails);

                        CartOperations.UpdateCartItem
                                (
                                        cartProduct
                                );

                    }else
                    {
                        CartOperations.DeleteCartItem(cart.getCustomersBasketId());


                        cartItemsList = db.getCartItems(session.getAppCategoryId());

                        if (cartItemsList.size() == 0)
                        {
                            checkout_button.setVisibility(View.GONE);
                        }

                        quantity_layout.setVisibility(View.GONE);
                        btn_add.setVisibility(View.VISIBLE);
                    }
                }


            }
        });


        return rootView;
    }

    private void setCartProduct() {


        Utilities.animateCartMenuIcon(getContext(), (MainActivity) getContext());

        productDetails.setProductsId(productId);
        productDetails.setProductsName(productName);
        productDetails.setProductsImage(productImage);
        productDetails.setProductsPrice(productPrice);
        productDetails.setProductsQuantity(Integer.parseInt(productWeight));
        productDetails.setCategory_id(session.getAppCategoryId());
        productDetails.setDistributorId(distributorId);
        productDetails.setTax_rate(taxRate);
        // Add Product to User's Cart
        addProductToCart(productDetails);

    }

    private void getDistributors(int productId) {


        Call<ShopData> call = APIClient.getNetInstance(false).getDistributerByProduct
                (
                        productId,
                        "28.597",
                        "77.564"
                );

        call.enqueue(new Callback<ShopData>() {
            @Override
            public void onResponse(Call<ShopData> call, Response<ShopData> response) {

                if (response.isSuccessful())
                {
                    if (response.body().getSuccess() == 1)
                    {
                        List<ShopDetails> shopList = response.body().getData().getFix();

                        addShop(shopList);

                    }
                }
                else
                {
                    product.setVisibility(View.GONE);
                    shop_image.setVisibility(View.GONE);
                    shop_name.setVisibility(View.GONE);
                    distance.setVisibility(View.GONE);

                    no_shops.setVisibility(View.VISIBLE);

                }

            }

            @Override
            public void onFailure(Call<ShopData> call, Throwable t) {

            }
        });

    }

    private void addShop(List<ShopDetails> shopList) {


        no_shops.setVisibility(View.GONE);

        product.setVisibility(View.VISIBLE);
        shop_image.setVisibility(View.VISIBLE);
        shop_name.setVisibility(View.VISIBLE);
        distance.setVisibility(View.VISIBLE);

        gst_tax = shopList.get(0).getGst_tax();
        delivery_charge = shopList.get(0).getShipping_cost();

        distributorId = shopList.get(0).getShopId();

        shop_name.setText(shopList.get(0).getDistributorShop());
        distance.setText(shopList.get(0).getStoreAddress());

        Glide
                .with(getContext())
                .load(shopList.get(0).getDistributorPic())
                .placeholder(R.drawable.store)
                .into(shop_image);

        addProduct();

    }

    private void addProduct() {

        checkCart();

        product_name.setText(productName);
        quantity.setText(productWeight + " " + productWeightUnit);
        price.setText(productPrice);

        Glide
                .with(getContext())
                .load(productImage)
                .placeholder(R.drawable.profile)
                .into(product_image);

        btn_add.setVisibility(View.VISIBLE);
        quantity_layout.setVisibility(View.GONE);

    }

    private void checkCart() {

        cartItemsID = db.getCartItemsIDs();

        if (cartItemsID.contains(productId) && ConstantValues.IS_USER_LOGGED_IN) {

            CartProduct cart;
            cart = db.getCartProduct(productId);
            if (cart.getCustomersBasketProduct().getDistributorId() == distributorId) {

                quantity_layout.setVisibility(View.VISIBLE);
                btn_add.setVisibility(View.GONE);
                quantity_count.setText(String.valueOf(cart.getCustomersBasketProduct().getCustomersBasketQuantity()));
                cartItemsID.clear();
            }else
            {
                quantity_layout.setVisibility(View.GONE);
                btn_add.setVisibility(View.VISIBLE);
            }
        }
        else {
            quantity_layout.setVisibility(View.GONE);
            btn_add.setVisibility(View.VISIBLE);
        }
    }

    private void addProductToCart(ProductDetails product) {

        CartProduct cartProduct = new CartProduct();

        cartItemsID = db.getCartItemsIDs();

        if (cartItemsID.contains(product.getProductsId())) {

            CartProduct cart;
            cart = db.getCartProduct(product.getProductsId());

            double tax, taxPrice, basePrice;

            tax = Double.parseDouble(product.getTax_rate());
            basePrice = Double.parseDouble(product.getProductsPrice());
            taxPrice = (basePrice*tax)/100;

            product.setCustomersBasketQuantity(cart.getCustomersBasketProduct().getCustomersBasketQuantity()+1);
            product.setProductsPrice(product.getProductsPrice());
            product.setTotalPrice(String.valueOf(Double.parseDouble(cart.getCustomersBasketProduct().getTotalPrice()) + Double.parseDouble(product.getProductsPrice()) + taxPrice));
            product.setTax_amount(String.valueOf(taxPrice + Double.parseDouble(product.getTax_amount())));

            cartProduct.setCustomersBasketId(cart.getCustomersBasketId());
            cartProduct.setCustomersBasketProduct(product);

            CartOperations.UpdateCartItem
                    (
                            cartProduct
                    );

        }
        else
        {

            double productBasePrice, productFinalPrice, gstTax, gstTaxAmount;


        /*// Check Discount on Product with the help of static method of Helper class
        final String discount = Utilities.checkDiscount(product.getProductsPrice(), product.getDiscountPrice());

        // Get Product's Price based on Discount
        if (discount != null) {
            product.setIsSaleProduct("1");
            productBasePrice = Double.parseDouble(product.getDiscountPrice());
        } else {
            product.setIsSaleProduct("0");
            productBasePrice = Double.parseDouble(product.getProductsPrice());
        }*/

            gstTax = Double.parseDouble(product.getTax_rate());

            productBasePrice = Double.parseDouble(product.getProductsPrice());

            gstTaxAmount = (productBasePrice*gstTax)/100;

            // Add Attributes Price to Product's Final Price
            productFinalPrice = productBasePrice + gstTaxAmount;


            // Set Product's Price and Quantity
            product.setCustomersBasketQuantity(1);
            product.setProductsPrice(String.valueOf(productBasePrice));
            product.setTotalPrice(String.valueOf(productFinalPrice));
            product.setTax_amount(String.valueOf(gstTaxAmount));

            // Set Customer's Basket Product and selected Attributes Info
            cartProduct.setCustomersBasketProduct(product);
            cartProduct.setGst_tax(product.getTax_rate());
            cartProduct.setDelivery_charge(delivery_charge!=null?delivery_charge:"0");


            // Add the Product to User's Cart with the help of static method of My_Cart class
            CartOperations.AddCartItem
                    (
                            cartProduct
                    );

        }



        // Recreate the OptionsMenu
        ((MainActivity) getContext()).invalidateOptionsMenu();
    }

}
