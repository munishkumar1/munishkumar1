package com.nextstack.chicken.customerapp.fragment;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.MainActivity;
import com.nextstack.chicken.customerapp.activity.ShopMenuActivity;
import com.nextstack.chicken.customerapp.adapters.ShopListAdapter;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.location.GPSTracker;
import com.nextstack.chicken.customerapp.models.shop_model.ShopData;
import com.nextstack.chicken.customerapp.models.shop_model.ShopDetails;
import com.nextstack.chicken.customerapp.models.wallet_model.WalletData;
import com.nextstack.chicken.customerapp.network.APIClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HomeFragment extends Fragment{
    View rootView;
    ImageView home_image;
    RecyclerView shop_recycler;
    TextView textView, noResult;

    DialogLoader dialogLoader;
    ShopListAdapter shopListAdapter;

    public static List<ShopDetails> shopsList = new ArrayList<>();

    GPSTracker gps;
    Location location;
    Geocoder geocoder;
    List<Address> addresses;

    SwipeRefreshLayout swipeRefreshLayout;

    int category_id;

    int product_id = 0;
    MyAppPrefsManager myAppPrefsManager;

    String customerId;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_home, container, false);

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        MainActivity.actionBarDrawerToggle.setDrawerIndicatorEnabled(true);

        myAppPrefsManager = new MyAppPrefsManager(getContext());

        dialogLoader = new DialogLoader(getContext());

        home_image = rootView.findViewById(R.id.imageView5);
        textView = rootView.findViewById(R.id.textView);
        noResult = rootView.findViewById(R.id.noResult);
        shop_recycler = rootView.findViewById(R.id.shopRecycler);
        swipeRefreshLayout = rootView.findViewById(R.id.swipeRefreshLayout);

        category_id = Integer.parseInt(myAppPrefsManager.getAppCategoryId());

        if (myAppPrefsManager.isUserLoggedIn()) {

            customerId = myAppPrefsManager.getUserId();
            fetchWallet();
        }



        geocoder = new Geocoder(getContext(), Locale.getDefault());

        Glide
                .with(getContext())
                .load(myAppPrefsManager.getAppCategoryImage())
                .into(home_image);

        textView.setText(myAppPrefsManager.getAppCategoryName() +" "+ getString(R.string.stores_near_me));


        gps = new GPSTracker(getContext());
        if(gps.canGetLocation()){
            location = gps.getLocation();
            if(location != null) {
                try {
                    addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                    ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(addresses.get(0).getLocality());
                    ((AppCompatActivity) getActivity()).getSupportActionBar().setSubtitle(addresses.get(0).getAddressLine(0));


                    Log.d("Address: ", addresses.get(0).getAddressLine(0));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        else{

        }


        if (getArguments().get("product_id") != null)
        {
            product_id = (int) getArguments().get("product_id");
            RequstSearchResult();

        }
        else
        {
            RequestShopList();
        }


        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                gps = new GPSTracker(getContext());
                if(gps.canGetLocation()){
                    location = gps.getLocation();
                    try {
                        addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(),1);
                        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(addresses.get(0).getLocality());
                        ((AppCompatActivity) getActivity()).getSupportActionBar().setSubtitle(addresses.get(0).getAddressLine(0));

                        Log.d("Address: ", addresses.get(0).getAddressLine(0));
                    }catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                }

                if (getArguments().get("product_id") != null)
                {
                    product_id = (int) getArguments().get("product_id");
                    RequstSearchResult();

                }
                else
                {
                    RequestShopList();
                }

            }

        });

        return rootView;

    }




    private void RequstSearchResult() {


        dialogLoader.showProgressDialog();



        Call<ShopData> call = APIClient.getNetInstance(false)
                .getDistributerByProduct
                        (
                                product_id,
                                "",
                                ""
                        );

        call.enqueue(new Callback<ShopData>() {
            @Override
            public void onResponse(Call<ShopData> call, retrofit2.Response<ShopData> response) {

                dialogLoader.hideProgressDialog();

                // Check if the Response is successful
                if (response.isSuccessful()) {
                    if (response.body().getSuccess() == 1) {

                        // Orders have been returned. Add Orders to the ordersList
                        addShops(response.body());

                    }
                    else if (response.body().getSuccess() == 0) {
                        Snackbar.make(rootView, response.body().getMessage(), Snackbar.LENGTH_LONG).show();

                    }
                    else {
                        // Unable to get Success status
                        Snackbar.make(rootView, getString(R.string.unexpected_response), Snackbar.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ShopData> call, Throwable t) {
                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
                Log.d("Home Fragment :","NetworkCallFailure : ",t);
            }
        });

        swipeRefreshLayout.setRefreshing(false);


    }

    private void addShops(ShopData shopData) {

        // Add Orders to ordersList from the List of OrderData
            shopsList.clear();
            shopsList = shopData.getData().getFix();

        // Initialize the OrdersListAdapter for RecyclerView
        shopListAdapter = new ShopListAdapter(getContext(),location, shopsList, new ShopListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(ShopDetails item) {

                Intent i = new Intent(getContext(), ShopMenuActivity.class);
                i.putExtra("shopLat", item.getShopLat());
                i.putExtra("shopLng", item.getShopLng());
                i.putExtra("categoriesName", item.getCategoriesName());
                i.putExtra("shopName", item.getDistributorShop());
                i.putExtra("distributor_id", item.getShopId());
                i.putExtra("device_id", item.getFirebase_id());
                i.putExtra("delivery_charge", item.getShipping_cost());
                i.putExtra("gst_tax", item.getGst_tax());
                i.putExtra("shop_status", item.getShop_status());
                startActivity(i);

            }
        });

        // Set the Adapter and LayoutManager to the RecyclerView
        shop_recycler.setAdapter(shopListAdapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);

        shop_recycler.setLayoutManager(layoutManager);


        shopListAdapter.notifyDataSetChanged();

    }

    public void RequestShopList() {

        dialogLoader.showProgressDialog();



        Call<ShopData> call = APIClient.getNetInstance(false)
                .getDistributors
                        (
                                category_id
                        );

        call.enqueue(new Callback<ShopData>() {
            @Override
            public void onResponse(Call<ShopData> call, retrofit2.Response<ShopData> response) {

                dialogLoader.hideProgressDialog();

                // Check if the Response is successful
                if (response.isSuccessful()) {
                            if (response.body().getSuccess() == 1) {

                                // Orders have been returned. Add Orders to the ordersList
                                addShops(response.body());

                    }
                    else if (response.body().getSuccess() == 0) {
                        Snackbar.make(rootView, response.body().getMessage(), Snackbar.LENGTH_LONG).show();

                    }
                    else {
                        // Unable to get Success status
                        Snackbar.make(rootView, getString(R.string.unexpected_response), Snackbar.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ShopData> call, Throwable t) {
                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
                Log.d("Home Fragment :","NetworkCallFailure : ",t);
            }
        });

        swipeRefreshLayout.setRefreshing(false);
    }

    private void fetchWallet() {

        Call<WalletData> call = APIClient.getNetInstance(false)
                .viewWallet(customerId);

        call.enqueue(new Callback<WalletData>() {
            @Override
            public void onResponse(Call<WalletData> call, Response<WalletData> response) {

                if (response.isSuccessful())
                {
                    if (response.body().getSuccess() == 1)
                    {

                        myAppPrefsManager.setUserWalletId(String.valueOf(response.body().getData().getWallet_id()));
                        myAppPrefsManager.setUserWalletMobile(String.valueOf(response.body().getData().getMobile_no()));

                    }
                }
                else
                {
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onFailure(Call<WalletData> call, Throwable t) {

                Toast.makeText(getContext(), "NetworkCallFailure: "+t, Toast.LENGTH_SHORT).show();

            }
        });

    }
}
