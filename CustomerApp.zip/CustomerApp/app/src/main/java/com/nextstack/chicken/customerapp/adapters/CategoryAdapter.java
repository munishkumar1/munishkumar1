package com.nextstack.chicken.customerapp.adapters;

import android.content.Context;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.customs.CircularImageView;
import com.nextstack.chicken.customerapp.models.category_model.CategoryDetails;

import java.util.ArrayList;
import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyViewHolder> {

    List<CategoryDetails> categoryDetails = new ArrayList<>();
    Context context;
    OnItemClickListener listener;

    public interface OnItemClickListener
    {
        void onItemClick(CategoryDetails item);
    }

    public CategoryAdapter( Context context, List<CategoryDetails> categoryDetails, OnItemClickListener listener) {
        this.categoryDetails = categoryDetails;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView;

        itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_categoies_card, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.category_name.setText(categoryDetails.get(position).getCategoriesName());

        Glide
                .with(context)
                .load(categoryDetails.get(position).getCategoriesImage())
                .into(holder.category_image);

        holder.bind(context, categoryDetails.get(position));

        if (categoryDetails.get(position).getEnable().equalsIgnoreCase("0"))
        {
            setLocked(holder.category_image);
        }

    }

    @Override
    public int getItemCount() {
        return categoryDetails.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        CircularImageView category_image;
        TextView category_name;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            category_image = itemView.findViewById(R.id.category_image);
            category_name = itemView.findViewById(R.id.category_name);
        }


        public void bind(Context context, final CategoryDetails categoryDetails) {

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onItemClick(categoryDetails);
                }
            });
        }
    }

    public static void  setLocked(ImageView v)
    {
        ColorMatrix matrix = new ColorMatrix();
        matrix.setSaturation(0);  //0 means grayscale
        ColorMatrixColorFilter cf = new ColorMatrixColorFilter(matrix);
        v.setColorFilter(cf);
        v.setImageAlpha(128);   // 128 = 0.5
    }
}
