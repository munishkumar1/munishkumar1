package com.nextstack.chicken.customerapp.fragment;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.ScanActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class BarcodeFragment extends Fragment implements View.OnClickListener {
View rootView;
private Button mScan;

    public BarcodeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_barcode, container, false);
        initView();
        return rootView;
    }

    private void initView() {
        mScan =  rootView.findViewById(R.id.id_scan);
        mScan.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        openScanActivity();
    }

    private void openScanActivity() {
        Intent mIntent = new Intent(getActivity(), ScanActivity.class);
        startActivity(mIntent);
    }
}
