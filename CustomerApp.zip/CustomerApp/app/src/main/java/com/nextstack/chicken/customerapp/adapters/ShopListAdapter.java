package com.nextstack.chicken.customerapp.adapters;

import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.models.shop_model.ShopDetails;
import com.nextstack.chicken.customerapp.utils.Utilities;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ShopListAdapter extends RecyclerView.Adapter<ShopListAdapter.MyViewHolder> {

    Context context;
    List<ShopDetails> shopList;
    OnItemClickListener listener;
    Location customerLocation;
    float[] result = new float[100];
    int size;
    static Date currentTime, open, close;




    public interface OnItemClickListener {
        void onItemClick(ShopDetails item);
    }

    public ShopListAdapter(Context context, Location location, List<ShopDetails> shopList, OnItemClickListener listener) {
        this.context = context;
        this.shopList = shopList;
        this.listener = listener;
        customerLocation = location;
        size = shopList.size();


    }

    @Override
    public MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        // Inflate the custom layout
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_card_shoplist, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        if (shopList.get(position).getShopId() != 0) {
        if(show(shopList.get(position))) {

            holder.bind(shopList.get(position), listener, context, customerLocation);

        } else
                holder.shopCard.setVisibility(View.GONE);
        }
        else
            holder.shopCard.setVisibility(View.GONE);
    }

    private boolean show(ShopDetails shopLocation ) {

        float[] result2 = new float[100];

        Double distance = Utilities.getDistance(customerLocation, shopLocation, result2);

        if (distance <= shopLocation.getCatchmentArea()){

            return true;
        }
        else{

            //todo chnge after test
            return true;
        }
    }

    @Override
    public int getItemCount() {
        return size;
    }



    public static class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView shopName, shopAddresss, homedelivery, distance, shop_type;
        private ImageView shopImage, imgSuccess, imgChicken, imgGoat, imgFish, shop_status;

        ConstraintLayout shopCard;
        public MyViewHolder(final View itemView) {
            super(itemView);

            shopName = itemView.findViewById(R.id.shop_name);
            shopAddresss = itemView.findViewById(R.id.shop_address);
            homedelivery = itemView.findViewById(R.id.home_delivery);
            distance = itemView.findViewById(R.id.txt_distance);
            shop_status = itemView.findViewById(R.id.shop_status);
            shop_type = itemView.findViewById(R.id.shop_type);
            shopImage = itemView.findViewById(R.id.shop_image);
            imgSuccess = itemView.findViewById(R.id.img_sucess);
            imgChicken = itemView.findViewById(R.id.img_chicken);
            imgGoat = itemView.findViewById(R.id.img_goat);
            shopCard = itemView.findViewById(R.id.shop_card);
            imgFish = itemView.findViewById(R.id.img_fish);
        }

        public void bind(final ShopDetails shopDetails, final OnItemClickListener listener, Context context, Location location){

            MyAppPrefsManager appPrefsManager = new MyAppPrefsManager(context);

            float[] result = new float[100];
            String[] categoryList = shopDetails.getCategoriesName().split(",");

            Glide
                .with(context)
                .load(shopDetails.getDistributorPic())
                    .placeholder(R.drawable.store)
                .into(shopImage);

            shopName.setText(shopDetails.getDistributorShop());

            if (appPrefsManager.getAppCategoryId().equalsIgnoreCase("32") && shopDetails.getChickenType()!= null) {
                if (shopDetails.getChickenType().equalsIgnoreCase("1")) {
                    shop_type.setVisibility(View.VISIBLE);
                    shop_type.setTextColor(Color.RED);
                    shop_type.setText(R.string.jhatka);
                } else if (shopDetails.getChickenType().equalsIgnoreCase("2")) {
                    shop_type.setVisibility(View.VISIBLE);
                    shop_type.setTextColor(Color.GREEN);
                    shop_type.setText(R.string.halaal);
                } else {
                    shop_type.setVisibility(View.GONE);
                }
            }
            else {
                shop_type.setVisibility(View.GONE);
            }

        shopAddresss.setText(shopDetails.getStoreAddress());
        if (shopDetails.getDelivery().equalsIgnoreCase("Home Delivery"))
        {
            homedelivery.setText(shopDetails.getDelivery());
            imgSuccess.setVisibility(View.VISIBLE);
        }
        else {
            homedelivery.setText(" ");
            imgSuccess.setVisibility(View.GONE);

        }

            for (String item : categoryList) {

                switch (item) {

                    case "Chicken":
                        imgChicken.setVisibility(View.VISIBLE);
                        break;
                    case "Mutton":
                        imgGoat.setVisibility(View.VISIBLE);
                        break;
                    case "Fish":
                        imgFish.setVisibility(View.VISIBLE);
                        break;
                }
                }

            distance.setText(String.valueOf(Utilities.getDistance(location, shopDetails, result))+"Km");

            DateFormat formatter = new SimpleDateFormat("hh:mm aa", Locale.getDefault());
            DateFormat formatter2 = new SimpleDateFormat("hh:mm aa", Locale.getDefault());
            Date date = new Date();

            try {

                    currentTime = formatter.parse(formatter.format(date));
                    open = formatter2.parse(shopDetails.getOpeningTime());
                    close = formatter2.parse(shopDetails.getClosingTime());

                if (currentTime.after(open) && currentTime.before(close)) {
                    Glide
                            .with(context)
                            .load(R.drawable.ic_open)
                            .placeholder(R.drawable.ic_open)
                            .into(shop_status);
                    shopDetails.setShop_status("Open");

                }
                else
                {
                    Glide
                            .with(context)
                            .load(R.drawable.ic_closed)
                            .placeholder(R.drawable.ic_closed)
                            .into(shop_status);

                    shopDetails.setShop_status("Closed");
                }


            } catch (ParseException e) {
                e.printStackTrace();
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(shopDetails);
                }
            });
        }
    }

}
