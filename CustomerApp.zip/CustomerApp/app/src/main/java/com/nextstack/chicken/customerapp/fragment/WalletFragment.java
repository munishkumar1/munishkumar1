package com.nextstack.chicken.customerapp.fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.app.App;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.models.paytm_model.Checksum;
import com.nextstack.chicken.customerapp.models.paytm_model.PaytmDetails;
import com.nextstack.chicken.customerapp.models.wallet_model.WalletData;
import com.nextstack.chicken.customerapp.network.APIClient;
import com.nextstack.chicken.customerapp.utils.ValidateInputs;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WalletFragment extends Fragment {

    View rootView;

    private LinearLayout showWallet, topup_wallet;

    private TextView total_cash, total_points, wallet_status;

    private Button add_money, add_wallet, create, b100, b200, b500, top_up;

    private EditText mobile_no, amount;

    private int selectedAmount = 0;

    private double balance = 0.00;

    private String orderId, customerId, checksumHash, mobileNo, dateAdded;

    private MyAppPrefsManager session;

    App app;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_wallet, container, false);

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setSubtitle("");

        app = new App();

        session = new MyAppPrefsManager(getContext());

        customerId = session.getUserId();

        mobileNo = session.getUserWalletMobile();

        showWallet = rootView.findViewById(R.id.linearLayout12);
        /*input_layout = rootView.findViewById(R.id.input_layout);*/
        topup_wallet = rootView.findViewById(R.id.topup_wallet);

        total_cash = rootView.findViewById(R.id.total_cash);
        total_points = rootView.findViewById(R.id.total_points);
        wallet_status = rootView.findViewById(R.id.wallet_status);

        add_money = rootView.findViewById(R.id.add_money);
        /*add_wallet = rootView.findViewById(R.id.add_wallet);
        create = rootView.findViewById(R.id.create);*/
        b100 = rootView.findViewById(R.id.b100);
        b200 = rootView.findViewById(R.id.b200);
        b500 = rootView.findViewById(R.id.b500);
        top_up = rootView.findViewById(R.id.top_up);

        /*mobile_no = rootView.findViewById(R.id.mobile_no);*/
        amount = rootView.findViewById(R.id.amount);

        fetchWallet();

       /* add_wallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //add_wallet.setVisibility(View.VISIBLE);
               // input_layout.setVisibility(View.VISIBLE);

            }
        });*/

        /*create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!mobile_no.getText().toString().equalsIgnoreCase(""))
                {
                    if(ValidateInputs.isValidPhoneNo(mobile_no.getText().toString()))
                    {
                        topup_wallet.setVisibility(View.VISIBLE);
                        //input_layout.setVisibility(View.GONE);

                        mobileNo = mobile_no.getText().toString();

                        session.setUserWalletMobile(mobileNo);
                    }
                    else
                    mobile_no.setError(getString(R.string.invalid_mobile_no));
                }
                else
                    mobile_no.setError(getString(R.string.enter_your_mobile_no));

            }
        });*/

        b100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                selectedAmount = 100;

            }
        });

        b100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                selectedAmount = 100;

                b100.setBackgroundResource(R.drawable.square_border_card_accent);
                b500.setBackgroundResource(0);
                b200.setBackgroundResource(0);

                amount.setText(String.valueOf(selectedAmount));

            }
        });
                b200.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                selectedAmount = 200;

                b100.setBackgroundResource(0);
                b500.setBackgroundResource(0);
                b200.setBackgroundResource(R.drawable.square_border_card_accent);

                amount.setText(String.valueOf(selectedAmount));

            }
        });
                b500.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                selectedAmount = 500;

                b200.setBackgroundResource(0);
                b100.setBackgroundResource(0);
                b500.setBackgroundResource(R.drawable.square_border_card_accent);

                amount.setText(String.valueOf(selectedAmount));

            }
        });


                amount.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        selectedAmount = Integer.parseInt(amount.getText().toString());

                        b100.setBackgroundResource(0);
                        b500.setBackgroundResource(0);
                        b200.setBackgroundResource(0);

                    }

                    @Override
                    public void afterTextChanged(Editable editable) {

                    }
                });

                top_up.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (selectedAmount == 0)
                        {
                            amount.setError("Select or enter amount");
                        }else
                        {

                            Date date = new Date();
                            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());

                            dateAdded = format.format(date);

                            Call<WalletData> call = APIClient.getNetInstance(false)
                                    .addToWallet
                                            (
                                                    customerId,
                                                    mobileNo,
                                                    String.valueOf(selectedAmount),
                                                    dateAdded,
                                                    "1",
                                                    "0",
                                                    "gsdfgdskf",
                                                    "[TXN_SUCCESS]"

                                            );
                            call.enqueue(new Callback<WalletData>() {
                                @Override
                                public void onResponse(Call<WalletData> call, Response<WalletData> response) {

                                    if(response.isSuccessful())
                                    {
                                        if (response.body().getSuccess() == 1)
                                        {
                                            topup_wallet.setVisibility(View.GONE);
                                            showWallet.setVisibility(View.VISIBLE);

                                            fetchWallet();

                                            wallet_status.setVisibility(View.GONE);
                                            add_money.setVisibility(View.VISIBLE);
                                        }
                                        else 
                                            {
                                                Toast.makeText(getContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                    else
                                    {
                                        Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                                    }

                                }

                                @Override
                                public void onFailure(Call<WalletData> call, Throwable t) {

                                    Toast.makeText(getContext(), "NetworkCallFailure: "+t, Toast.LENGTH_SHORT).show();

                                }
                            });


                            /*orderId = Utilities.randomString();

                            String callbackUrl = ConstantValues.PAYTM_URL+"verifyChecksum.php";

                            PaytmDetails paytmDetails = new PaytmDetails
                                    (
                                            "shmwKe24105788853467",
                                            orderId,
                                            customerId,
                                            "WAP",
                                            "120.00",
                                            "WEBSTAGING",
                                            "Retail",
                                            callbackUrl
                                    );

                            generateChecksum(paytmDetails);*/

                        }

                    }
                });

                add_money.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        topup_wallet.setVisibility(View.VISIBLE);
                        add_money.setVisibility(View.GONE);
                        showWallet.setVisibility(View.GONE);

                    }
                });


        return rootView;
    }

    private void fetchWallet() {

        Call<WalletData> call = APIClient.getNetInstance(false)
                .viewWallet(customerId);

        call.enqueue(new Callback<WalletData>() {
            @Override
            public void onResponse(Call<WalletData> call, Response<WalletData> response) {

                if (response.isSuccessful())
                {
                    if (response.body().getSuccess() == 1)
                    {
                        showWallet.setVisibility(View.VISIBLE);
                        add_money.setVisibility(View.VISIBLE);

                        if (!response.body().getData().getTotal_cash().equalsIgnoreCase(""))
                        {
                            wallet_status.setVisibility(View.GONE);
                        }

                        total_cash.setText(response.body().getData().getTotal_cash());
                        total_points.setText(response.body().getData().getReferral_points());
                        session.setUserWalletId(String.valueOf(response.body().getData().getWallet_id()));
                        session.setUserWalletMobile(String.valueOf(response.body().getData().getMobile_no()));

                    }
                    else
                    {
                        add_wallet.setVisibility(View.VISIBLE);
                    }
                }
                else
                {
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onFailure(Call<WalletData> call, Throwable t) {

                Toast.makeText(getContext(), "NetworkCallFailure: "+t, Toast.LENGTH_SHORT).show();

            }
        });

    }


    private void generateChecksum(final PaytmDetails paytmDetails) {

        Call<Checksum> call = APIClient.getPaytmInstance()
                .generateChecksum
                        (
                                paytmDetails.getMid(),
                                paytmDetails.getOrderId(),
                                paytmDetails.getCustomerId(),
                                paytmDetails.getIndustryTypeId(),
                                paytmDetails.getChannelId(),
                                paytmDetails.getTxnAmount(),
                                paytmDetails.getWebsite()
                        );

        call.enqueue(new Callback<Checksum>() {
            @Override
            public void onResponse(Call<Checksum> call, Response<Checksum> response) {

                if (response.isSuccessful()) {
                    checksumHash = response.body().getChecksumHash();

                    processToPaytm(paytmDetails, checksumHash);


                }
                else
                {
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                    Log.d("Payment",  response.message());
                }

            }

            @Override
            public void onFailure(Call<Checksum> call, Throwable t) {

                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_SHORT).show();
                Log.d("Payment", "NetworkCallFailure : ", t);

            }
        });

    }

    private void processToPaytm(PaytmDetails paytmDetails, String checksumHash) {


        PaytmPGService Service = PaytmPGService.getStagingService();

        HashMap<String, String> paramMap = new HashMap<String,String>();
        paramMap.put( "MID" , "shmwKe24105788853467");
        paramMap.put( "ORDER_ID" ,paytmDetails.getOrderId());
        paramMap.put( "CUST_ID" , paytmDetails.getCustomerId());
        paramMap.put( "MOBILE_NO" , "7777777777");
        paramMap.put( "EMAIL" , "username@emailprovider.com");
        paramMap.put( "CHANNEL_ID" ,paytmDetails.getChannelId());
        paramMap.put( "TXN_AMOUNT" , paytmDetails.getTxnAmount());
        paramMap.put( "WEBSITE" , paytmDetails.getWebsite());
        paramMap.put( "INDUSTRY_TYPE_ID" , paytmDetails.getIndustryTypeId());
        paramMap.put( "CALLBACK_URL", paytmDetails.getCallbackUrl());
        paramMap.put( "CHECKSUMHASH" , checksumHash);

        PaytmOrder Order = new PaytmOrder(paramMap);

        Service.initialize(Order, null);

        Service.startPaymentTransaction(getContext(), true, true, new PaytmPaymentTransactionCallback() {
            /*Call Backs*/
            public void someUIErrorOccurred(String inErrorMessage) {

                Toast.makeText(app.getApplicationContext(), "UI Error " + inErrorMessage , Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : UI Error "+inErrorMessage);
            }
            public void onTransactionResponse(Bundle inResponse) {


                Toast.makeText(app.getApplicationContext(), "Payment Transaction response " + inResponse.toString(), Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Payment Transaction response "+inResponse.toString());



            }
            public void networkNotAvailable() {
                Toast.makeText(app.getApplicationContext(), "Network connection error: Check your internet connectivity", Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Network connection error: Check your internet connectivity");
            }
            public void clientAuthenticationFailed(String inErrorMessage) {
                Toast.makeText(app.getApplicationContext(), "Authentication failed: Server error" + inErrorMessage.toString(), Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Authentication failed: Server error" + inErrorMessage.toString());
            }
            public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {

                Toast.makeText(app.getApplicationContext(), "Unable to load webpage " + inErrorMessage.toString(), Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Unable to load webpage" + inErrorMessage.toString());
            }
            public void onBackPressedCancelTransaction()
            {
                Toast.makeText(app.getApplicationContext(), "Transaction cancelled" , Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Transaction cancelled" );
            }
            public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {

                Toast.makeText(app.getApplicationContext(), "Transaction cancelled" +inErrorMessage.toString() , Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Transaction cancelled" + inErrorMessage.toString());
            }
        });

    }

}
