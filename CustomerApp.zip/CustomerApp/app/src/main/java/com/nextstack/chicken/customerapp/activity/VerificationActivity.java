package com.nextstack.chicken.customerapp.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.nextstack.chicken.customerapp.R;

public class VerificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);
    }
}
