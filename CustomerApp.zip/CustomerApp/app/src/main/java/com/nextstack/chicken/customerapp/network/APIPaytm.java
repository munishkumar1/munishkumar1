package com.nextstack.chicken.customerapp.network;

import com.nextstack.chicken.customerapp.models.paytm_model.Checksum;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface APIPaytm {


    @FormUrlEncoded
    @POST("generateChecksum.php")
    Call<Checksum> generateChecksum(@Field("MID") String mid,
                                    @Field("ORDER_ID") String orderId,
                                    @Field("CUST_ID") String customerId,
                                    @Field("INDUSTRY_TYPE_ID") String industryTypeId,
                                    @Field("CHANNEL_ID") String channelId,
                                    @Field("TXN_AMOUNT") String txnAmount,
                                    @Field("WEBSITE") String website);
    @FormUrlEncoded
    @POST("verifyChecksum.php")
    Call<Checksum> verifyChecksum(@Field("MID") String mid,
                                    @Field("ORDER_ID") String orderId,
                                    @Field("CUST_ID") String customerId,
                                    @Field("INDUSTRY_TYPE_ID") String industryTypeId,
                                    @Field("CHANNEL_ID") String channelId,
                                    @Field("TXN_AMOUNT") String txnAmount,
                                    @Field("CHECKSUMHASH") String chechsumHash,
                                    @Field("WEBSITE") String website);
}
