package com.nextstack.chicken.customerapp.models.shop_model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ShopDetails implements Parcelable {

    @SerializedName("distributor_id")
    @Expose
    private int shopId;
    @SerializedName("distributor_name")
    @Expose
    private String distributorName;
    @SerializedName("distributor_shop")
    @Expose
    private String distributorShop;
    @SerializedName("store_address")
    @Expose
    private String storeAddress;
    @SerializedName("distributor_pic")
    @Expose
    private String distributorPic;
    @SerializedName("distributor_email")
    @Expose
    private String distributorEmail;
    @SerializedName("distributor_mobile")
    @Expose
    private String distributorMobile;
    @SerializedName("delivery")
    @Expose
    private String delivery;
    @SerializedName("shop_lat")
    @Expose
    private String shopLat;
    @SerializedName("shop_lng")
    @Expose
    private String shopLng;
    @SerializedName("device_id")
    @Expose
    private String deviceId;
    @SerializedName("categories_name")
    @Expose
    private String categoriesName;
    @SerializedName("minimum_order")
    @Expose
    private String minimumOrder;
    @SerializedName("chicken_type")
    @Expose
    private String chickenType;
    @SerializedName("catchment_area")
    @Expose
    private double catchmentArea;
    @SerializedName("open_timing")
    @Expose
    private String openingTime;
    @SerializedName("close_timing")
    @Expose
    private String closingTime;
    @SerializedName("days_off")
    @Expose
    private String daysOff;
    @SerializedName("gst_tax")
    @Expose
    private String gst_tax;
    @SerializedName("shipping_cost")
    @Expose
    private String shipping_cost;

    @SerializedName("firebase_id")
    @Expose
    private String firebase_id;
@SerializedName("temp_open_timing")
    @Expose
    private String temp_open_timing;
@SerializedName("temp_close_timing")
    @Expose
    private String temp_close_timing;

    private String shop_status;

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getShopLat() {
        return shopLat;
    }

    public void setShopLat(String shopLat) {
        this.shopLat = shopLat;
    }

    public String getShopLng() {
        return shopLng;
    }

    public void setShopLng(String shopLng) {
        this.shopLng = shopLng;
    }
    public String getMinimumOrder() {
        return minimumOrder;
    }

    public void setMinimumOrder(String minimumOrder) {
        this.minimumOrder = minimumOrder;
    }

    public String getDelivery() {
        return delivery;
    }

    public void setDelivery(String delivery) {
        this.delivery = delivery;
    }

    public String getDistributorPic() {
        return distributorPic;
    }

    public void setDistributorPic(String distributorPic) {
        this.distributorPic = distributorPic;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public String getDistributorName() {
        return distributorName;
    }

    public void setDistributorName(String distributorName) {
        this.distributorName = distributorName;
    }

    public String getDistributorShop() {
        return distributorShop;
    }

    public void setDistributorShop(String distributorShop) {
        this.distributorShop = distributorShop;
    }

    public String getStoreAddress() {
        return storeAddress;
    }

    public void setStoreAddress(String storeAddress) {
        this.storeAddress = storeAddress;

    }

    public String getDistributorEmail() {
        return distributorEmail;
    }

    public void setDistributorEmail(String distributorEmail) {
        this.distributorEmail = distributorEmail;
    }

    public String getDistributorMobile() {
        return distributorMobile;
    }

    public void setDistributorMobile(String distributorMobile) {
        this.distributorMobile = distributorMobile;
    }

    public String getCategoriesName() {
        return categoriesName;
    }

    public void setCategoriesName(String categoriesName) {
        this.categoriesName = categoriesName;
    }

    public void setChickenType(String chickenType) {
        this.chickenType = chickenType;
    }

    public String getChickenType() {
        return chickenType;
    }


     public double getCatchmentArea() {
        return catchmentArea;
    }

    public void setCatchmentArea(double catchmentArea) {
        this.catchmentArea = catchmentArea;
    }

    public String getOpeningTime() {
        return openingTime;
    }

    public void setOpeningTime(String openingTime) {
        this.openingTime = openingTime;
    }

    public String getClosingTime() {
        return closingTime;
    }

    public void setClosingTime(String closingTime) {
        this.closingTime = closingTime;
    }

    public String getDaysOff() {
        return daysOff;
    }

    public void setDaysOff(String daysOff) {
        this.daysOff = daysOff;
    }

    public String getGst_tax() {

        return gst_tax;
    }

    public void setGst_tax(String gst_tax) {
        this.gst_tax = gst_tax;
    }

    public String getShipping_cost() {
        return shipping_cost;
    }

    public void setShipping_cost(String shipping_cost) {
        this.shipping_cost = shipping_cost;
    }


    public String getFirebase_id() {
        return firebase_id;
    }

    public void setFirebase_id(String firebase_id) {
        this.firebase_id = firebase_id;
    }

    public String getShop_status() {
        return shop_status;
    }

    public void setShop_status(String shop_status) {
        this.shop_status = shop_status;
    }

    public String getTemp_open_timing() {
        return temp_open_timing;
    }

    public void setTemp_open_timing(String temp_open_timing) {
        this.temp_open_timing = temp_open_timing;
    }

    public String getTemp_close_timing() {
        return temp_close_timing;
    }

    public void setTemp_close_timing(String temp_close_timing) {
        this.temp_close_timing = temp_close_timing;
    }

    @Override
    public int describeContents() {
        return 0;
    }


    public static final Creator<ShopDetails> CREATOR = new Creator<ShopDetails>() {

        // Creates a new Instance of the Parcelable class, Instantiating it from the given Parcel
        @Override
        public ShopDetails createFromParcel(Parcel parcel_in) {
            return new ShopDetails(parcel_in);
        }

        // Creates a new array of the Parcelable class
        @Override
        public ShopDetails[] newArray(int size) {
            return new ShopDetails[size];
        }
    };


    protected ShopDetails(Parcel parcel_in) {

        this.shopId = parcel_in.readInt();
        this.distributorName = parcel_in.readString();
        this.distributorShop = parcel_in.readString();
        this.storeAddress = parcel_in.readString();
        this.distributorPic = parcel_in.readString();
        this.distributorEmail = parcel_in.readString();
        this.distributorMobile = parcel_in.readString();
        this.delivery = parcel_in.readString();
        this.shopLat = parcel_in.readString();
        this.shopLng = parcel_in.readString();
        this.categoriesName = parcel_in.readString();
        this.chickenType = parcel_in.readString();
        this.catchmentArea = parcel_in.readDouble();
        this.openingTime = parcel_in.readString();
        this.closingTime = parcel_in.readString();
        this.daysOff = parcel_in.readString();
        this.gst_tax = parcel_in.readString();
        this.shipping_cost = parcel_in.readString();
        this.firebase_id = parcel_in.readString();
        this.shop_status = parcel_in.readString();
        this.temp_close_timing = parcel_in.readString();
        this.temp_close_timing = parcel_in.readString();
    }

    @Override
    public void writeToParcel(Parcel parcel_out, int i) {

        parcel_out.writeValue(shopId);
        parcel_out.writeValue(distributorName);
        parcel_out.writeValue(distributorShop);
        parcel_out.writeValue(storeAddress);
        parcel_out.writeValue(distributorPic);
        parcel_out.writeValue(distributorEmail);
        parcel_out.writeValue(distributorMobile);
        parcel_out.writeValue(delivery);
        parcel_out.writeValue(shopLat);
        parcel_out.writeValue(shopLng);
        parcel_out.writeValue(categoriesName);
        parcel_out.writeValue(minimumOrder);
        parcel_out.writeValue(chickenType);
        parcel_out.writeValue(catchmentArea);
        parcel_out.writeValue(openingTime);
        parcel_out.writeValue(closingTime);
        parcel_out.writeValue(daysOff);
        parcel_out.writeValue(gst_tax);
        parcel_out.writeValue(shipping_cost);
        parcel_out.writeValue(firebase_id);
        parcel_out.writeValue(shop_status);
        parcel_out.writeValue(temp_close_timing);
        parcel_out.writeValue(temp_close_timing);

    }
}
