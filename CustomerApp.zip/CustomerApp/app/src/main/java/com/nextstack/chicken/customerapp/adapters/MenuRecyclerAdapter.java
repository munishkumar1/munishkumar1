package com.nextstack.chicken.customerapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.LoginActivity;
import com.nextstack.chicken.customerapp.activity.ShopMenuActivity;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.databases.User_Cart_DB;
import com.nextstack.chicken.customerapp.fragment.Tab_1;
import com.nextstack.chicken.customerapp.models.cart_model.CartProduct;
import com.nextstack.chicken.customerapp.models.product_model.ProductDetails;
import com.nextstack.chicken.customerapp.utils.CartOperations;
import com.nextstack.chicken.customerapp.utils.Utilities;

import java.util.ArrayList;
import java.util.List;

public class MenuRecyclerAdapter extends RecyclerView.Adapter<MenuRecyclerAdapter.MyViewHolder> {

    Context context;
    List<ProductDetails> productList;
    Tab_1 fragment;
    User_Cart_DB db;
    ArrayList<Integer> cartItemsID = new ArrayList<>();

    List<CartProduct> cartItemsList = new ArrayList<>();

    MyAppPrefsManager session;
    int distributorId;

    String gst_tax, delivery_charge, shopStatus;

    public MenuRecyclerAdapter(Context context, List<ProductDetails> productList, int distributorId, Tab_1 fragment, String gst_tax, String delivery_charge, String shopStatus) {
        this.context = context;
        this.productList = productList;
        this.fragment = fragment;
        this.distributorId = distributorId;
        this.delivery_charge = delivery_charge;
        this.gst_tax = gst_tax;
        this.shopStatus = shopStatus;

        db = new User_Cart_DB();
    }

    @Override
    public MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        // Inflate the custom layout
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.shop_menu_card, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final ProductDetails product = new ProductDetails();

        if (position < productList.size() && position != -1) {

            final ProductDetails productDetails = productList.get(position);

            holder.productName.setText(productDetails.getProductsName());
            holder.price.setText(productDetails.getProductsPrice());

            Glide
                    .with(context)
                    .load(productDetails.getProductsImage())
                    .placeholder(R.drawable.profile)
                    .into(holder.productImage);

            holder.quantity.setText(productDetails.getProductsWeight() + " " + productDetails.getProductsWeightUnit());

            cartItemsID = db.getCartItemsIDs();

            if (cartItemsID.contains(productDetails.getProductsId()) && ConstantValues.IS_USER_LOGGED_IN) {

                CartProduct cart;
                cart = db.getCartProduct(productDetails.getProductsId());
                if (cart.getCustomersBasketProduct().getDistributorId() == distributorId) {

                    holder.quantity_layout.setVisibility(View.VISIBLE);
                    holder.btnAdd.setVisibility(View.GONE);
                    holder.quantity_count.setText(String.valueOf(cart.getCustomersBasketProduct().getCustomersBasketQuantity()));
                    cartItemsID.clear();
                }

                else
                {
                    holder.quantity_layout.setVisibility(View.GONE);
                    holder.btnAdd.setVisibility(View.VISIBLE);
                }
            }
            else {
                holder.quantity_layout.setVisibility(View.GONE);
                holder.btnAdd.setVisibility(View.VISIBLE);
            }

            holder.btnAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    session = new MyAppPrefsManager(context);
                    if (ConstantValues.IS_USER_LOGGED_IN) {

                        cartItemsList = db.getCartItems(session.getAppCategoryId());

                        if (productDetails.getProductsQuantity() > 0) {

                            if (cartItemsList.size() > 0 && cartItemsList.get(0).getCustomersBasketProduct().getDistributorId() == distributorId) {

                                Utilities.animateCartMenuIcon(context, (ShopMenuActivity) context);

                                product.setProductsId(productDetails.getProductsId());
                                product.setProductsName(productDetails.getProductsName());
                                product.setProductsImage(productDetails.getProductsImage());
                                product.setProductsPrice(productDetails.getProductsPrice());
                                product.setProductsQuantity(Integer.parseInt(productDetails.getProductsWeight()));
                                product.setCategory_id(session.getAppCategoryId());
                                product.setDistributorId(distributorId);
                                product.setTax_rate(productDetails.getTax_rate());
                                // Add Product to User's Cart
                                addProductToCart(product);

                                holder.quantity_layout.setVisibility(View.VISIBLE);
                                holder.btnAdd.setVisibility(View.GONE);
                                holder.quantity_count.setText("1");

                                fragment.checkout_button.setVisibility(View.VISIBLE);

                                Snackbar.make(view, context.getString(R.string.item_added_to_cart), Snackbar.LENGTH_SHORT).show();
                            }else if (cartItemsList.size() == 0)
                            {
                                if (productDetails.getProductsQuantity() > 0) {

                                    Utilities.animateCartMenuIcon(context, (ShopMenuActivity) context);

                                    product.setProductsId(productDetails.getProductsId());
                                    product.setProductsName(productDetails.getProductsName());
                                    product.setProductsImage(productDetails.getProductsImage());
                                    product.setProductsPrice(productDetails.getProductsPrice());
                                    product.setProductsQuantity(Integer.parseInt(productDetails.getProductsWeight()));
                                    product.setCategory_id(session.getAppCategoryId());
                                    product.setDistributorId(distributorId);
                                    product.setTax_rate(productDetails.getTax_rate());
                                    // Add Product to User's Cart
                                    addProductToCart(product);

                                    holder.quantity_layout.setVisibility(View.VISIBLE);
                                    holder.btnAdd.setVisibility(View.GONE);
                                    holder.quantity_count.setText("1");

                                    fragment.checkout_button.setVisibility(View.VISIBLE);

                                    Snackbar.make(view, context.getString(R.string.item_added_to_cart), Snackbar.LENGTH_SHORT).show();
                                }
                            }
                            else
                            {

                                final AlertDialog.Builder dialog = new AlertDialog.Builder(context);
                                View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_clear_cart_alert, null);
                                dialog.setView(dialogView);
                                dialog.setCancelable(false);

                                Button dialog_button_cancel = dialogView.findViewById(R.id.dialog_button_cancel);
                                Button dialog_button_continue = dialogView.findViewById(R.id.dialog_button_continue);

                                final AlertDialog alertDialog = dialog.create();

                                dialog_button_cancel.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {

                                        alertDialog.dismiss();

                                    }
                                });

                                dialog_button_continue.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {

                                        CartOperations.ClearCart();

                                        if (productDetails.getProductsQuantity() > 0) {
                                            Utilities.animateCartMenuIcon(context, (ShopMenuActivity) context);

                                            product.setProductsId(productDetails.getProductsId());
                                            product.setProductsName(productDetails.getProductsName());
                                            product.setProductsImage(productDetails.getProductsImage());
                                            product.setProductsPrice(productDetails.getProductsPrice());
                                            product.setProductsQuantity(Integer.parseInt(productDetails.getProductsWeight()));
                                            product.setCategory_id(session.getAppCategoryId());
                                            product.setDistributorId(distributorId);
                                            product.setTax_rate(productDetails.getTax_rate());
                                            // Add Product to User's Cart
                                            addProductToCart(product);

                                            holder.quantity_layout.setVisibility(View.VISIBLE);
                                            holder.btnAdd.setVisibility(View.GONE);
                                            holder.quantity_count.setText("1");

                                            fragment.checkout_button.setVisibility(View.VISIBLE);


                                            alertDialog.dismiss();

                                            Snackbar.make(view, context.getString(R.string.item_added_to_cart), Snackbar.LENGTH_SHORT).show();
                                        }

                                    }
                                });

                                alertDialog.show();
                            }
                        }
                        else
                        {

                        }
                    }
                    else {
                        Intent i = new Intent(context, LoginActivity.class);
                        context.startActivity(i);
                    }
                }

            });


            holder.add_more.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    session = new MyAppPrefsManager(context);

                    Utilities.animateCartMenuIcon(context, (ShopMenuActivity) context);

                    product.setProductsId(productDetails.getProductsId());
                    product.setProductsName(productDetails.getProductsName());
                    product.setProductsImage(productDetails.getProductsImage());
                    product.setProductsPrice(productDetails.getProductsPrice());
                    product.setProductsQuantity(Integer.parseInt(productDetails.getProductsWeight()));
                    product.setCategory_id(session.getAppCategoryId());
                    product.setDistributorId(distributorId);
                    product.setTax_rate(productDetails.getTax_rate());
                    // Add Product to User's Cart
                    addProductToCart(product);

                    holder.quantity_count.setText(String.valueOf(Integer.parseInt(holder.quantity_count.getText().toString()) + 1));

                    holder.remove.setEnabled(true);
                    holder.remove.setColorFilter(context.getResources().getColor(R.color.colorPrimary));

                }
            });

            holder.remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    session = new MyAppPrefsManager(context);

                    CartProduct cartProduct = new CartProduct();

                    cartItemsID = db.getCartItemsIDs();

                    if (cartItemsID.contains(productDetails.getProductsId())) {

                        CartProduct cart;
                        cart = db.getCartProduct(productDetails.getProductsId());

                        if (cart.getCustomersBasketProduct().getCustomersBasketQuantity() > 1) {

                            holder.quantity_count.setText(String.valueOf(Integer.parseInt(holder.quantity_count.getText().toString()) - 1));

                            holder.remove.setEnabled(true);
                            holder.remove.setColorFilter(context.getResources().getColor(R.color.colorPrimary));

                            double tax, taxPrice, basePrice;

                            tax = Double.parseDouble(productDetails.getTax_rate());
                            basePrice = Double.parseDouble(productDetails.getProductsPrice());
                            taxPrice = (basePrice*tax)/100;

                            product.setProductsId(productDetails.getProductsId());
                            product.setProductsName(productDetails.getProductsName());
                            product.setProductsImage(productDetails.getProductsImage());
                            product.setProductsPrice(productDetails.getProductsPrice());
                            product.setCategory_id(session.getAppCategoryId());
                            product.setCustomersBasketQuantity(cart.getCustomersBasketProduct().getCustomersBasketQuantity() - 1);
                            product.setTotalPrice(String.valueOf(Double.parseDouble(cart.getCustomersBasketProduct().getTotalPrice()) - Double.parseDouble(productDetails.getProductsPrice()) - taxPrice));
                            product.setTax_amount(String.valueOf(Double.parseDouble(cart.getCustomersBasketProduct().getTax_amount()) - taxPrice));

                            cartProduct.setCustomersBasketId(cart.getCustomersBasketId());
                            cartProduct.setCustomersBasketProduct(product);

                            CartOperations.UpdateCartItem
                                    (
                                            cartProduct
                                    );

                        }else
                        {
                            CartOperations.DeleteCartItem(cart.getCustomersBasketId());


                            cartItemsList = db.getCartItems(session.getAppCategoryId());

                            if (cartItemsList.size() == 0)
                            {
                                fragment.checkout_button.setVisibility(View.GONE);
                            }

                            holder.quantity_layout.setVisibility(View.GONE);
                            holder.btnAdd.setVisibility(View.VISIBLE);
                        }
                    }


                }
            });
        }
    }

    @Override
    public int getItemCount() {

            return productList.size();
    }




    public static class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView productImage;
        TextView productName, price, quantity_count, quantity;
        Button btnAdd;
        ImageButton add_more, remove;

        LinearLayout quantity_layout;

        public MyViewHolder(final View itemView) {
            super(itemView);

            productImage = itemView.findViewById(R.id.product_image);
            productName = itemView.findViewById(R.id.product_name);
            price = itemView.findViewById(R.id.price);
            btnAdd = itemView.findViewById(R.id.btn_add);
            add_more = itemView.findViewById(R.id.add_more);
            remove = itemView.findViewById(R.id.remove);
            quantity_count = itemView.findViewById(R.id.quantity_count);

            quantity_layout = itemView.findViewById(R.id.quantity_layout);

            quantity = itemView.findViewById(R.id.quantity);

        }
    }

    private void addProductToCart(ProductDetails product) {

        CartProduct cartProduct = new CartProduct();

        cartItemsID = db.getCartItemsIDs();

        if (cartItemsID.contains(product.getProductsId())) {

            CartProduct cart;
            cart = db.getCartProduct(product.getProductsId());

            double tax, taxPrice, basePrice;

            tax = Double.parseDouble(product.getTax_rate());
            basePrice = Double.parseDouble(product.getProductsPrice());
            taxPrice = (basePrice*tax)/100;

            product.setCustomersBasketQuantity(cart.getCustomersBasketProduct().getCustomersBasketQuantity()+1);
            product.setProductsPrice(product.getProductsPrice());
            product.setTotalPrice(String.valueOf(Double.parseDouble(cart.getCustomersBasketProduct().getTotalPrice()) + Double.parseDouble(product.getProductsPrice()) + taxPrice));
            product.setTax_amount(String.valueOf(taxPrice + Double.parseDouble(cart.getCustomersBasketProduct().getTax_amount())));

            cartProduct.setCustomersBasketId(cart.getCustomersBasketId());
            cartProduct.setCustomersBasketProduct(product);

            CartOperations.UpdateCartItem
                    (
                            cartProduct
                    );

        }
        else
        {

            session.setShopStatus(shopStatus);

            double productBasePrice, productFinalPrice, gstTax, gstTaxAmount;


        /*// Check Discount on Product with the help of static method of Helper class
        final String discount = Utilities.checkDiscount(product.getProductsPrice(), product.getDiscountPrice());

        // Get Product's Price based on Discount
        if (discount != null) {
            product.setIsSaleProduct("1");
            productBasePrice = Double.parseDouble(product.getDiscountPrice());
        } else {
            product.setIsSaleProduct("0");
            productBasePrice = Double.parseDouble(product.getProductsPrice());
        }*/

            gstTax = Double.parseDouble(product.getTax_rate());

            productBasePrice = Double.parseDouble(product.getProductsPrice());

            gstTaxAmount = (productBasePrice*gstTax)/100;

            // Add Attributes Price to Product's Final Price
            productFinalPrice = productBasePrice + gstTaxAmount;


            // Set Product's Price and Quantity
            product.setCustomersBasketQuantity(1);
            product.setProductsPrice(String.valueOf(productBasePrice));
            product.setTotalPrice(String.valueOf(productFinalPrice));
            product.setTax_amount(String.valueOf(gstTaxAmount));

            // Set Customer's Basket Product and selected Attributes Info
            cartProduct.setCustomersBasketProduct(product);
            cartProduct.setGst_tax(product.getTax_rate());
            cartProduct.setDelivery_charge(delivery_charge!=null?delivery_charge:"0");


            // Add the Product to User's Cart with the help of static method of My_Cart class
            CartOperations.AddCartItem
                    (
                            cartProduct
                    );

        }



        // Recreate the OptionsMenu
        ((ShopMenuActivity) context).invalidateOptionsMenu();
    }
}
