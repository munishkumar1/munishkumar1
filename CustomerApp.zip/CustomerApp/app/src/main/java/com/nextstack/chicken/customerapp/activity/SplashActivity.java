package com.nextstack.chicken.customerapp.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.app.App;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.models.device_model.AppSettingsDetails;
import com.nextstack.chicken.customerapp.models.faq_model.FaqData;
import com.nextstack.chicken.customerapp.network.APIClient;
import com.nextstack.chicken.customerapp.network.StartAppRequests;
import com.nextstack.chicken.customerapp.utils.CheckPermissions;
import com.nextstack.chicken.customerapp.utils.Utilities;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.nextstack.chicken.customerapp.utils.CheckPermissions.PERMISSIONS_REQUEST_LOCATION;

public class SplashActivity extends AppCompatActivity {

    View rootView;
    ProgressBar progressBar;

    MyTask myTask;
    StartAppRequests startAppRequests;
    MyAppPrefsManager myAppPrefsManager;
    // float ans = (float) 0.0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_splash);

        progressBar = findViewById(R.id.splash_loadingBar);
        rootView = progressBar;



        startAppRequests = new StartAppRequests(this);
        myAppPrefsManager = new MyAppPrefsManager(this);
        //ConstantValues.LANGUAGE_ID = myAppPrefsManager.getUserLanguageId();
        //ConstantValues.LANGUAGE_CODE = myAppPrefsManager.getUserLanguageCode();
        ConstantValues.IS_USER_LOGGED_IN = myAppPrefsManager.isUserLoggedIn();
        //ConstantValues.IS_PUSH_NOTIFICATIONS_ENABLED = myAppPrefsManager.isPushNotificationsEnabled();
        //ConstantValues.IS_LOCAL_NOTIFICATIONS_ENABLED = myAppPrefsManager.isLocalNotificationsEnabled();

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    myTask = new MyTask();
                    myTask.execute();
                }
            }, 3000);
        } else {
            if (!CheckPermissions.is_LOCATION_PermissionGranted()  ||  !CheckPermissions.is_PHONE_STATE_PermissionGranted()
                    || !CheckPermissions.is_SMS_PermissionGranted()){
                ActivityCompat.requestPermissions
                        (
                                SplashActivity.this,
                                new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_PHONE_STATE,
                                        Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS},
                                PERMISSIONS_REQUEST_LOCATION
                        );
            }
        }



    }

    private void setAppConfig() {

        AppSettingsDetails appSettingsDetails = ((App) getApplicationContext()).getAppSettingsDetails();

        if (appSettingsDetails != null) {

            ConstantValues.APP_HEADER = getString(R.string.app_name);

            ConstantValues.CURRENCY_SYMBOL = appSettingsDetails.getCurrencySymbol();
            //ConstantValues.NEW_PRODUCT_DURATION = appSettingsDetails.getNewProductDuration();
            ConstantValues.IS_GOOGLE_LOGIN_ENABLED = (appSettingsDetails.getGoogleLogin().equalsIgnoreCase("1"));
            ConstantValues.IS_FACEBOOK_LOGIN_ENABLED = (appSettingsDetails.getFacebookLogin().equalsIgnoreCase("1"));
            ConstantValues.IS_ADD_TO_CART_BUTTON_ENABLED = (appSettingsDetails.getCartButton().equalsIgnoreCase("1"));

            //myAppPrefsManager.setLocalNotificationsTitle(appSettingsDetails.getNotificationTitle());
            //myAppPrefsManager.setLocalNotificationsDuration(appSettingsDetails.getNotificationDuration());
            //myAppPrefsManager.setLocalNotificationsDescription(appSettingsDetails.getNotificationText());

        }
        else {
            ConstantValues.APP_HEADER = getString(R.string.app_name);

            ConstantValues.CURRENCY_SYMBOL = "INR";
            ConstantValues.NEW_PRODUCT_DURATION = 30;
            ConstantValues.IS_ADMOBE_ENABLED = false;
            ConstantValues.IS_GOOGLE_LOGIN_ENABLED = true;
            ConstantValues.IS_FACEBOOK_LOGIN_ENABLED = true;
            ConstantValues.IS_ADD_TO_CART_BUTTON_ENABLED = true;

        }

    }

    private class MyTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {

            // Check for Internet Connection from the static method of Helper class
            if (Utilities.isNetworkAvailable(SplashActivity.this)) {



                // Call the method of StartAppRequests class to process App Startup Requests
               startAppRequests.StartRequests();


                return "1";
            } else {
                return "0";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            if (result.equalsIgnoreCase("0")) {

                progressBar.setVisibility(View.GONE);

                // No Internet Connection
                Snackbar.make(rootView, getString(R.string.no_internet), Snackbar.LENGTH_INDEFINITE)
                        .setAction(getString(R.string.retry), new View.OnClickListener() {

                            // Handle the Retry Button Click
                            @Override
                            public void onClick(View v) {

                                progressBar.setVisibility(View.VISIBLE);

                                // Restart MyTask after 3 seconds
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        myTask = new MyTask();
                                        myTask.execute();
                                    }
                                }, 3000);
                            }
                        })
                        .show();

            }
            else {
                setAppConfig();

                if (myAppPrefsManager.isFirstTimeLaunch()) {
                    // Navigate to IntroScreen
                    startActivity(new Intent(SplashActivity.this, IntroScreen.class));
                    finish();
                }


                else {
                    // Navigate to HomeActivity
                    startActivity(new Intent(SplashActivity.this, DialogsActivity.class));
                    finish();
                }
            }
        }

    }

    @Override
    protected void onStart() {
        super.onStart();



    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSIONS_REQUEST_LOCATION: {
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            myTask = new MyTask();
                            myTask.execute();
                        }
                    }, 3000);
                } else {
                    Log.i("Splash", "onRequestPermissionsResult: False");
                }
                return;
            }
        }

    }
}

