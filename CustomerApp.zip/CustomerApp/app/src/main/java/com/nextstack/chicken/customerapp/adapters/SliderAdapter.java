package com.nextstack.chicken.customerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.models.coupons_model.CouponsInfo;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.List;

public class SliderAdapter extends SliderViewAdapter<SliderAdapter.MyViewHolder> {

    private Context context;
    List<CouponsInfo> couponsInfos;

    public SliderAdapter(Context context, List<CouponsInfo> couponsInfos) {
        this.context = context;
        this.couponsInfos = couponsInfos;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_slider_layout_item, null);
        return new MyViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        CouponsInfo couponsInfo = couponsInfos.get(position);

        holder.textViewDescription.setText(couponsInfo.getDescription() + " Minimum Amount : " + couponsInfo.getMinimumAmount() + " Coupon Code : " + couponsInfo.getCode());

        Glide.with(context)
                .load(couponsInfo.getOffer_Image())
                .into(holder.imageViewBackground);


       /* switch (position) {
            case 0:
                Glide.with(context)
                        .load("https://images.pexels.com/photos/218983/pexels-photo-218983.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")
                        .into(holder.imageViewBackground);
                break;
            case 1:
                Glide.with(context)
                        .load("https://images.pexels.com/photos/747964/pexels-photo-747964.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260")
                        .into(holder.imageViewBackground);
                break;
            case 2:
                Glide.with(context)
                        .load("https://images.pexels.com/photos/929778/pexels-photo-929778.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")
                        .into(holder.imageViewBackground);
                break;
            default:
                Glide.with(context)
                        .load("https://images.pexels.com/photos/218983/pexels-photo-218983.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")
                        .into(holder.imageViewBackground);
                break;
        }*/

    }

    @Override
    public int getCount() {
        return couponsInfos.size();
    }

    class MyViewHolder extends SliderViewAdapter.ViewHolder {

        View itemView;
        ImageView imageViewBackground;
        TextView textViewDescription;

        public MyViewHolder(View itemView) {
            super(itemView);
            imageViewBackground = itemView.findViewById(R.id.iv_auto_image_slider);
            textViewDescription = itemView.findViewById(R.id.tv_auto_image_slider);
            this.itemView = itemView;
        }
    }
}
