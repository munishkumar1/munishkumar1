package com.nextstack.chicken.customerapp.models.category_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CategoryDetails {

    @SerializedName("categories_image")
    @Expose
    String categoriesImage;
    @SerializedName("categories_id")
    @Expose
    int categoriesId;
    @SerializedName("categories_name")
    @Expose
    String categoriesName;
    @SerializedName("enable")
    @Expose
    String enable;

    public String getCategoriesImage() {
        return categoriesImage;
    }

    public void setCategoriesImage(String categoriesImage) {
        this.categoriesImage = categoriesImage;
    }

    public int getCategoriesId() {
        return categoriesId;
    }

    public void setCategoriesId(int categoriesId) {
        this.categoriesId = categoriesId;
    }

    public String getCategoriesName() {
        return categoriesName;
    }

    public void setCategoriesName(String categoriesName) {
        this.categoriesName = categoriesName;
    }

    public String getEnable() {
        return enable;
    }

    public void setEnable(String enable) {
        this.enable = enable;
    }
}
