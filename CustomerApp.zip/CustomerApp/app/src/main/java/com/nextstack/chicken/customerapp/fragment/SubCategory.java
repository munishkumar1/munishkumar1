package com.nextstack.chicken.customerapp.fragment;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexWrap;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.android.flexbox.JustifyContent;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.ShopMenuActivity;
import com.nextstack.chicken.customerapp.adapters.SliderAdapter;
import com.nextstack.chicken.customerapp.adapters.SubCategoryAdapter;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.models.category_model.CategoriesData;
import com.nextstack.chicken.customerapp.models.category_model.CategoryDetails;
import com.nextstack.chicken.customerapp.models.coupons_model.CouponsData;
import com.nextstack.chicken.customerapp.models.coupons_model.CouponsInfo;
import com.nextstack.chicken.customerapp.network.APIClient;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SubCategory extends Fragment {

    View rootView;

    RecyclerView sub_category_recycler;

    List<CategoryDetails> categoriesList;
    List<CouponsInfo> couponsInfos;

    SubCategoryAdapter adapter;

    MyAppPrefsManager session;

    int distributor_id;

    SliderView sliderView;

    SliderAdapter sliderAdapter;

    String gst_tax, delivery_charge, shopStatus;

    @Override
    public void onResume() {
        super.onResume();


    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_sub_category, container, false);

        sub_category_recycler = rootView.findViewById(R.id.sub_category_recycler);
        FlexboxLayoutManager layoutManager = new FlexboxLayoutManager(getContext());
        layoutManager.setFlexDirection(FlexDirection.ROW);
        layoutManager.setFlexWrap(FlexWrap.WRAP);
        layoutManager.setJustifyContent(JustifyContent.SPACE_AROUND);
        sub_category_recycler.setLayoutManager(layoutManager);


        sliderView = rootView.findViewById(R.id.imageSlider);


       /* sliderView.setIndicatorAnimation(IndicatorAnimations.WORM); //set indicator animation by using SliderLayout.IndicatorAnimations. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        sliderView.setIndicatorSelectedColor(Color.WHITE);
        sliderView.setIndicatorUnselectedColor(Color.GRAY);
        sliderView.setScrollTimeInSec(4); //set scroll delay in seconds :
        sliderView.startAutoCycle();*/


        session = new MyAppPrefsManager(getContext());

        distributor_id = getArguments().getInt("distributor_id");
        gst_tax = getArguments().getString("gst_tax");
        delivery_charge = getArguments().getString("delivery_charge");
        shopStatus = getArguments().getString("shop_status");


        setSlider();


        requestSubCategories();

       /* offers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Fragment fragment = new DailyOffers();
                FragmentManager fragmentManager = ((ShopMenuActivity) getContext()).getSupportFragmentManager();
                fragmentManager.beginTransaction()
                        .replace(R.id.menu_fragment, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack("SubCategory")
                        .commit();

            }
        });*/

        return rootView;
    }

    private void setSlider()
    {

        Call<CouponsData> call = APIClient.getNetInstance(false)
                .getCoupon_distributor
                        (
                                String.valueOf(distributor_id)
                        );

        call.enqueue(new Callback<CouponsData>() {
            @Override
            public void onResponse(Call<CouponsData> call, Response<CouponsData> response) {

                if (response.isSuccessful()) {

                    if (response.body().getSuccess() == 1)
                    {
                        couponsInfos = response.body().getData();

                        sliderView.setIndicatorAnimation(IndicatorAnimations.SLIDE); //set indicator animation by using SliderLayout.IndicatorAnimations. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
                        sliderView.setSliderTransformAnimation(SliderAnimations.CUBEINROTATIONTRANSFORMATION);
                        sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
                        sliderView.setIndicatorSelectedColor(Color.WHITE);
                        sliderView.setIndicatorUnselectedColor(Color.GRAY);
                        sliderView.setScrollTimeInSec(4);
                        sliderView.startAutoCycle();

                        sliderAdapter = new SliderAdapter(getContext(), couponsInfos);

                        sliderView.setSliderAdapter(sliderAdapter);

                    }
                    else if (response.body().getSuccess() == 0)
                    {
                        // Get the Error Message from Response
                        String message = response.body().getMessage();
                    }
                    else {
                        Toast.makeText(getContext(), getString(R.string.unexpected_response), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    // Show the Error Message
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<CouponsData> call, Throwable t) {
                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });

    }

    private void requestSubCategories() {

        Call<CategoriesData> call = APIClient.getNetInstance(false)
                .getSubCategories
                        (
                                Integer.parseInt(session.getAppCategoryId()),
                                distributor_id
                        );

        call.enqueue(new Callback<CategoriesData>() {
            @Override
            public void onResponse(Call<CategoriesData> call, Response<CategoriesData> response) {

                if (response.isSuccessful()) {

                    if (response.body().getSuccess().equalsIgnoreCase("1") || response.body().getSuccess().equalsIgnoreCase("2"))
                    {
                        categoriesList = response.body().getData();

                        adapter = new SubCategoryAdapter(getContext(), categoriesList, new SubCategoryAdapter.OnItemClickListener() {
                            @Override
                            public void onItemClick(CategoryDetails item) {

                                Fragment fragment = new Tab_1();
                                Bundle bundle = new Bundle();
                                bundle.putInt("distributor_id", distributor_id);
                                bundle.putString("category_name", item.getCategoriesName());
                                bundle.putString("gst_tax", gst_tax);
                                bundle.putString("delivery_charge", delivery_charge);
                                bundle.putString("shop_status", shopStatus);
                                fragment.setArguments(bundle);
                                FragmentManager fragmentManager = ((ShopMenuActivity) getContext()).getSupportFragmentManager();
                                fragmentManager.beginTransaction()
                                        .replace(R.id.menu_fragment, fragment)
                                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                                        .addToBackStack("SubCategory")
                                        .commit();


                            }
                        });
                        sub_category_recycler.setAdapter(adapter);


                    }
                    else if (response.body().getSuccess().equalsIgnoreCase("0"))
                    {
                        // Get the Error Message from Response
                        String message = response.body().getMessage();
                    }
                    else {
                        Toast.makeText(getContext(), getString(R.string.unexpected_response), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    // Show the Error Message
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<CategoriesData> call, Throwable t) {
                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });
    }

}
