package com.nextstack.chicken.customerapp.activity;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.adapters.OrdersListAdapter;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.models.order_model.GetOrderData;
import com.nextstack.chicken.customerapp.models.order_model.OrderDetails;
import com.nextstack.chicken.customerapp.network.APIClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;


public class My_Orders extends AppCompatActivity {

    Toolbar toolbar;
    ActionBar actionBar;
    EditText searchBar;
    String customerID, categoryId;
    TextView emptyRecord;
    RecyclerView orders_recycler;
    DialogLoader dialogLoader;
    OrdersListAdapter ordersListAdapter;
    List<OrderDetails> ordersList = new ArrayList<>();
    List<GetOrderData.Data.Products> productsList = new ArrayList<>();
    MyAppPrefsManager prefsManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (ConstantValues.IS_USER_LOGGED_IN) {
            setContentView(R.layout.my_orders);
        }
        else {
            Intent i = new Intent(My_Orders.this, LoginActivity.class);
            startActivity(i);
        }

        toolbar = findViewById(R.id.mytoolbar);
        searchBar = findViewById(R.id.search_bar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        actionBar.setTitle(getString(R.string.actionOrders));
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        searchBar.setVisibility(View.GONE);

        // Get the CustomerID from SharedPreferences
        customerID = this.getSharedPreferences("UserInfo", MODE_PRIVATE).getString("userID", "");

        prefsManager = new MyAppPrefsManager(this);

        categoryId = prefsManager.getAppCategoryId();

        // Binding Layout Views
        emptyRecord = findViewById(R.id.empty_record);
        orders_recycler = findViewById(R.id.orders_recycler);

        // Hide some of the Views
        emptyRecord.setVisibility(View.GONE);


        dialogLoader = new DialogLoader(this);


        // Request for User's Orders
        RequestMyOrders();

    }



    //*********** Adds Orders returned from the Server to the OrdersList ********//

    private void addOrders(GetOrderData orderData) {

        // Add Orders to ordersList from the List of OrderData
        ordersList = orderData.getData().getOrderList();
        productsList = orderData.getData().getProductList();

        // Initialize the OrdersListAdapter for RecyclerView
        ordersListAdapter = new OrdersListAdapter(My_Orders.this, customerID, ordersList, productsList);

        // Set the Adapter and LayoutManager to the RecyclerView
        orders_recycler.setAdapter(ordersListAdapter);
        orders_recycler.setLayoutManager(new LinearLayoutManager(My_Orders.this, RecyclerView.VERTICAL, false));

        
        ordersListAdapter.notifyDataSetChanged();
    }



    //*********** Request User's Orders from the Server ********//

    public void RequestMyOrders() {

        dialogLoader.showProgressDialog();

        Call<GetOrderData> call = APIClient.getNetInstance(false)
                .getOrders
                        (
                                Integer.parseInt(customerID),
                                Integer.parseInt(categoryId)
                        );

        call.enqueue(new Callback<GetOrderData>() {
            @Override
            public void onResponse(Call<GetOrderData> call, retrofit2.Response<GetOrderData> response) {

                dialogLoader.hideProgressDialog();

                // Check if the Response is successful
                if (response.isSuccessful()) {
                    if (response.body().getSuccess() == 1) {
                        
                        // Orders have been returned. Add Orders to the ordersList
                        addOrders(response.body());
                        
                    }
                    else if (response.body().getSuccess() == 0) {
                        emptyRecord.setVisibility(View.VISIBLE);
                        //Snackbar.make(rootView, response.body().getMessage(), Snackbar.LENGTH_LONG).show();
    
                    }
                    else {
                        // Unable to get Success status
                        emptyRecord.setVisibility(View.VISIBLE);
                        //Snackbar.make(rootView, getString(R.string.unexpected_response), Snackbar.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(My_Orders.this, response.message(), Toast.LENGTH_SHORT).show();
                    Log.d("My_Orders", response.message());
                }
            }

            @Override
            public void onFailure(Call<GetOrderData> call, Throwable t) {
                Toast.makeText(My_Orders.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        finish();
        return true;
    }

}

