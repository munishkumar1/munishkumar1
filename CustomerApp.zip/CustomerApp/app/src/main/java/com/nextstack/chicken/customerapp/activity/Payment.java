package com.nextstack.chicken.customerapp.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.app.App;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.databases.User_Cart_DB;
import com.nextstack.chicken.customerapp.databases.User_Info_DB;
import com.nextstack.chicken.customerapp.models.cart_model.CartProduct;
import com.nextstack.chicken.customerapp.models.coupons_model.CouponsInfo;
import com.nextstack.chicken.customerapp.models.faq_model.FaqData;
import com.nextstack.chicken.customerapp.models.order_model.OrderData;
import com.nextstack.chicken.customerapp.models.order_model.OrderDataPost;
import com.nextstack.chicken.customerapp.models.order_model.PostOrder;
import com.nextstack.chicken.customerapp.models.order_model.PostProducts;
import com.nextstack.chicken.customerapp.models.order_model.ProcessOrderData;
import com.nextstack.chicken.customerapp.models.payment_model.PaymentMethodsData;
import com.nextstack.chicken.customerapp.models.payment_model.PaymentMethodsInfo;
import com.nextstack.chicken.customerapp.models.paytm_model.Checksum;
import com.nextstack.chicken.customerapp.models.paytm_model.PaytmDetails;
import com.nextstack.chicken.customerapp.models.shipping_model.ShippingService;
import com.nextstack.chicken.customerapp.models.user_model.UserDetails;
import com.nextstack.chicken.customerapp.models.wallet_model.WalletData;
import com.nextstack.chicken.customerapp.network.APIClient;
import com.nextstack.chicken.customerapp.utils.CartOperations;
import com.nextstack.chicken.customerapp.utils.NotificationHelper;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Payment extends AppCompatActivity {

    View View1;
    LinearLayout View2, wallet_layout;

    Toolbar toolbar;
    ActionBar actionBar;
    EditText searchBar;
    EditText coupon_code;

    String selectedPaymentMethod;
    String code;

    Button checkout_order_btn, checkout_paytm_btn, apply_coupon_button, add_message;

    ProgressDialog progressDialog;

    TextView payment_method, checkout_total, item_total, discount_amount, gift_message, wallet_amount;

    List<String> paymentMethodsList;
    List<CartProduct> checkoutItemsList;

    UserDetails userInfo;
    DialogLoader dialogLoader;
    ShippingService shippingMethod;

    User_Cart_DB user_cart_db = new User_Cart_DB();
    User_Info_DB user_info_db = new User_Info_DB();

    String customerId, firstName, lastName, street, postcode, suburb, city, zoneName, countryName, deliveryDate, start_time, end_time, shopStatus, addressId;
    int checkoutTotal;

    int zoneId, countryId;

    List<CouponsInfo> couponList;

    Double disountAmount;

    MyAppPrefsManager session;

    String orderId, checksumHash, walletAmount;

    double totalTax = 0;

    String prevString = " ";
    boolean isGiftOrder = false;

    private static boolean couponApplied = false;
    String dialog_name,dialog_type,dialog_msg;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_payment);

        toolbar = findViewById(R.id.mytoolbar);
        searchBar = findViewById(R.id.search_bar);

        session = new MyAppPrefsManager(this);

        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        getSupportActionBar().setTitle(getString(R.string.payment));
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        searchBar.setVisibility(View.GONE);

        firstName = getIntent().getStringExtra("firstName");
        lastName = getIntent().getStringExtra("lastName");
        street = getIntent().getStringExtra("street");
        postcode = getIntent().getStringExtra("postcode");
        suburb = getIntent().getStringExtra("suburb");
        city = getIntent().getStringExtra("city");
        zoneName = getIntent().getStringExtra("zoneName");
        countryName = getIntent().getStringExtra("countryName");
        zoneId = getIntent().getIntExtra("zoneId", 1);
        countryId = getIntent().getIntExtra("countryId", 1);
        deliveryDate = getIntent().getStringExtra("delivery_date");
        start_time = getIntent().getStringExtra("start_time");
        end_time = getIntent().getStringExtra("end_time");
        shopStatus = getIntent().getStringExtra("shop_status");
        addressId = String.valueOf(getIntent().getIntExtra("address_id",0));


        shippingMethod = ((App) getApplicationContext()).getShippingService();

        customerId = getSharedPreferences("UserInfo", MODE_PRIVATE).getString("userID", null);

        userInfo = user_info_db.getUserData(customerId);

        payment_method = findViewById(R.id.payment_method);

        checkout_paytm_btn = findViewById(R.id.checkout_paytm_btn);
        checkout_order_btn = findViewById(R.id.checkout_order_btn);
        apply_coupon_button = findViewById(R.id.apply_coupon_button);
        checkout_total = findViewById(R.id.checkout_total);
        item_total = findViewById(R.id.item_total);
        discount_amount = findViewById(R.id.discount_amount);
        coupon_code = findViewById(R.id.coupon_code);
        View1 = findViewById(R.id.View1);
        View2 = findViewById(R.id.View2);
        add_message = findViewById(R.id.add_message);
        gift_message = findViewById(R.id.gift_message);
        wallet_layout = findViewById(R.id.wallet_layout);
        wallet_amount = findViewById(R.id.wallet_amount);

        checkout_paytm_btn.setVisibility(View.GONE);

        checkoutTotal = (int) getIntent().getDoubleExtra("checkoutTotal", 0.00);
        /*totalTax = getIntent().getStringExtra("total_tax");*/

        item_total.setText(String.valueOf(checkoutTotal));
        checkout_total.setText(String.valueOf(checkoutTotal));

        dialogLoader = new DialogLoader(this);

        paymentMethodsList = new ArrayList<>();
        checkoutItemsList = new ArrayList<>();

        checkoutItemsList = user_cart_db.getCartItems(session.getAppCategoryId());

        //RequestPaymentMethods();

        paymentMethodsList.add("Cash On Delivery");
        paymentMethodsList.add("Paytm");
        if (session.getUserWalletId() != null) {
            paymentMethodsList.add("Wallet");
        }

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle(getString(R.string.processing));
        progressDialog.setMessage(getString(R.string.please_wait));
        progressDialog.setCancelable(false);

        coupon_code.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String string = s.toString();
                if (string.equals(prevString)) {
                    return;
                } else if (string.length() == 0)
                    return;
                    // 1st character
                else if (string.length() == 1) {
                    prevString = string.toUpperCase();
                    coupon_code.setText(string.toUpperCase());
                    coupon_code.setSelection(string.length());
                }
                // if the last entered character is after a space
                else if (string.length() > 0 && string.charAt(string.length() - 2) == ' ') {
                    string = string.substring(0, string.length() - 1) + Character.toUpperCase(string.charAt(string.length() - 1));
                    prevString = string;
                    coupon_code.setText(string);
                    coupon_code.setSelection(string.length());
                }
            }
        });


        apply_coupon_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkoutItemsList.size()>0) {
                    code = coupon_code.getText().toString();
                    applyCoupon(code, checkoutItemsList);
                }

            }
        });


        add_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder dialog = new AlertDialog.Builder(Payment.this);
                View dialogView = getLayoutInflater().inflate(R.layout.dialog_gift_message, null);
                dialog.setView(dialogView);
                dialog.setCancelable(true);

                Button add = dialogView.findViewById(R.id.dialog_button);
                final EditText add_name = dialogView.findViewById(R.id.dialog_name);
                final EditText add_type = dialogView.findViewById(R.id.dialog_type);
                final EditText add_message = dialogView.findViewById(R.id.dialog_message);
                final TextView message = dialogView.findViewById(R.id.dialog_input);

                final AlertDialog alertDialog = dialog.create();
                alertDialog.show();

                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        isGiftOrder = true;
                       // gift_message.setText(message.getText());
                        dialog_name = add_name.getText().toString();
                        dialog_type = add_type.getText().toString();
                        dialog_msg = add_message.getText().toString();
                        alertDialog.dismiss();
                        Toast.makeText(Payment.this,"Gift has ordered",Toast.LENGTH_SHORT).show();

                    }
                });

                alertDialog.show();

            }
        });


        payment_method.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final ArrayAdapter paymentAdapter = new ArrayAdapter<String>(Payment.this, android.R.layout.simple_list_item_1);
                paymentAdapter.addAll(paymentMethodsList);

                AlertDialog.Builder dialog = new AlertDialog.Builder(Payment.this);
                View dialogView = getLayoutInflater().inflate(R.layout.dialog_list, null);
                dialog.setView(dialogView);
                dialog.setCancelable(true);

                Button dialog_button = dialogView.findViewById(R.id.dialog_button);
                TextView dialog_title = dialogView.findViewById(R.id.dialog_title);
                ListView dialog_list = dialogView.findViewById(R.id.dialog_list);

                dialog_button.setVisibility(View.GONE);

                dialog_title.setText(getString(R.string.payment_method));
                dialog_list.setAdapter(paymentAdapter);


                final AlertDialog alertDialog = dialog.create();
                alertDialog.show();


                dialog_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        String userSelectedPaymentMethod = paymentAdapter.getItem(position).toString();

                        payment_method.setText(userSelectedPaymentMethod);

                        // Check the selected Payment Method
                        switch (userSelectedPaymentMethod) {

                            // Change the Visibility of some Views based on selected Payment Method
                            case "Cash On Delivery":
                                checkout_paytm_btn.setVisibility(View.GONE);
                                selectedPaymentMethod = "cash_on_delivery";
                                checkout_order_btn.setVisibility(View.VISIBLE);
                                checkout_order_btn.setBackgroundColor(ContextCompat.getColor(Payment.this, R.color.colorAccentGreen));
                                break;

                            case "Paytm":
                                checkout_paytm_btn.setVisibility(View.VISIBLE);
                                selectedPaymentMethod = "paytm";
                                checkout_order_btn.setVisibility(View.VISIBLE);
                                checkout_order_btn.setBackgroundColor(ContextCompat.getColor(Payment.this, R.color.colorAccentGreen));
                                break;

                            case "Wallet":

                                    checkout_paytm_btn.setVisibility(View.GONE);
                                    selectedPaymentMethod = "Wallet";
                                    showWallet();
                                    checkout_order_btn.setVisibility(View.VISIBLE);
                                    checkout_order_btn.setBackgroundColor(ContextCompat.getColor(Payment.this, R.color.colorAccentGreen));

                                break;

                            default:
                                checkout_paytm_btn.setVisibility(View.GONE);
                                selectedPaymentMethod = "cash_on_delivery";
                                break;
                        }

                        alertDialog.dismiss();
                    }
                });
            }
        });



        checkout_paytm_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                orderId = "order1";

                String callbackUrl = ConstantValues.PAYTM_URL+"verifyChecksum.php";
                //String callbackUrl = "https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID="+orderId;
                //String callbackUrl = "https://pguat.paytm.com/paytmchecksum/paytmCallback.jsp";

                PaytmDetails paytmDetails = new PaytmDetails
                                        (
                                                "shmwKe24105788853467",
                                                orderId,
                                                customerId,
                                                "WAP",
                                                "120.00",
                                                "WEBSTAGING",
                                                "Retail",
                                                callbackUrl
                                        );

                generateChecksum(paytmDetails);



            }
        });



        checkout_order_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {

                // Check if the selectedPaymentMethod is not "Cash_on_Delivery"
                if (!selectedPaymentMethod.equalsIgnoreCase("cash_on_delivery")) {

                    if (selectedPaymentMethod.equalsIgnoreCase("Wallet"))
                    {
                        if (checkoutTotal < Double.parseDouble(walletAmount)) {
                            payFromWallet();
                            progressDialog.show();
                        }
                        else
                            Toast.makeText(Payment.this, "Your wallet balance is insufficient for this order. Choose other payment method.", Toast.LENGTH_LONG).show();
                    }
                }
                else {
                    // Proceed Order
                    proceedOrder();
                    progressDialog.show();
                }


            }
        });

    }

    private void payFromWallet() {

        String amount = String.valueOf(checkoutTotal);

        Call<WalletData> call = APIClient.getNetInstance(false)
                .getFromWallet
                        (
                                customerId,
                                session.getUserWalletMobile(),
                                amount,
                                session.getUserWalletId()
                        );

        call.enqueue(new Callback<WalletData>() {
            @Override
            public void onResponse(Call<WalletData> call, Response<WalletData> response) {

                if (response.isSuccessful())

                {
                    if (response.body().getSuccess() == 1)
                    {
                        proceedOrder();
                        Toast.makeText(Payment.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(Payment.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    Toast.makeText(Payment.this, response.message(), Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onFailure(Call<WalletData> call, Throwable t) {

                Toast.makeText(Payment.this, "NetworkCallFailure: "+t, Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void showWallet() {


        Call<WalletData> call = APIClient.getNetInstance(false)
                .viewWallet(customerId);

        call.enqueue(new Callback<WalletData>() {
            @Override
            public void onResponse(Call<WalletData> call, Response<WalletData> response) {

                if (response.isSuccessful())
                {
                    if (response.body().getSuccess() == 1)
                    {
                        wallet_layout.setVisibility(View.VISIBLE);

                        wallet_amount.setText(response.body().getData().getTotal_cash());
                        walletAmount =response.body().getData().getTotal_cash();

                        session.setUserWalletId(String.valueOf(response.body().getData().getWallet_id()));
                        session.setUserWalletMobile(String.valueOf(response.body().getData().getMobile_no()));

                    }
                    else
                    {

                    }
                }
                else
                {
                    Toast.makeText(Payment.this, response.message(), Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onFailure(Call<WalletData> call, Throwable t) {

                Toast.makeText(Payment.this, "NetworkCallFailure: "+t, Toast.LENGTH_SHORT).show();

            }
        });


    }

    private void generateChecksum(final PaytmDetails paytmDetails) {

        Call<Checksum> call = APIClient.getPaytmInstance()
                .generateChecksum
                        (
                                paytmDetails.getMid(),
                                paytmDetails.getOrderId(),
                                paytmDetails.getCustomerId(),
                                paytmDetails.getIndustryTypeId(),
                                paytmDetails.getChannelId(),
                                paytmDetails.getTxnAmount(),
                                paytmDetails.getWebsite()
                        );

        call.enqueue(new Callback<Checksum>() {
            @Override
            public void onResponse(Call<Checksum> call, Response<Checksum> response) {

                if (response.isSuccessful()) {
                    checksumHash = response.body().getChecksumHash();
                    System.out.println("check:"+checksumHash);

                    processToPaytm(paytmDetails, checksumHash);


                }
                else
                {
                    Toast.makeText(Payment.this, response.message(), Toast.LENGTH_SHORT).show();
                    Log.d("Payment",  response.message());
                }

            }

            @Override
            public void onFailure(Call<Checksum> call, Throwable t) {

                Toast.makeText(Payment.this, "NetworkCallFailure : "+t, Toast.LENGTH_SHORT).show();
                Log.d("Payment", "NetworkCallFailure : ", t);

            }
        });

    }

    private void processToPaytm(PaytmDetails paytmDetails, String checksumHash) {


        PaytmPGService Service = PaytmPGService.getStagingService();

        HashMap<String, String> paramMap = new HashMap<String,String>();
        paramMap.put( "MID" , paytmDetails.getMid());       //shmwKe24105788853467
        paramMap.put( "ORDER_ID" ,paytmDetails.getOrderId());
        paramMap.put( "CUST_ID" , paytmDetails.getCustomerId());
        paramMap.put( "MOBILE_NO" , "7777777777");
        paramMap.put( "EMAIL" , "username@emailprovider.com");
        paramMap.put( "CHANNEL_ID" ,paytmDetails.getChannelId());
        paramMap.put( "TXN_AMOUNT" , paytmDetails.getTxnAmount());
        paramMap.put( "WEBSITE" , paytmDetails.getWebsite());
        paramMap.put( "INDUSTRY_TYPE_ID" , paytmDetails.getIndustryTypeId());
        paramMap.put( "CALLBACK_URL", paytmDetails.getCallbackUrl());
        paramMap.put( "CHECKSUMHASH" , checksumHash);
        PaytmOrder Order = new PaytmOrder(paramMap);

        Service.initialize(Order, null);

        Service.startPaymentTransaction(Payment.this, true, true, new PaytmPaymentTransactionCallback() {
            /*Call Backs*/
            public void someUIErrorOccurred(String inErrorMessage) {

                Toast.makeText(getApplicationContext(), "UI Error " + inErrorMessage , Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : UI Error "+inErrorMessage);
            }
            public void onTransactionResponse(Bundle inResponse) {


                 Toast.makeText(getApplicationContext(), "Payment Transaction response " + inResponse.toString(), Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Payment Transaction response "+inResponse.toString());
            }
            public void networkNotAvailable() {
                Toast.makeText(getApplicationContext(), "Network connection error: Check your internet connectivity", Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Network connection error: Check your internet connectivity");
            }
            public void clientAuthenticationFailed(String inErrorMessage) {
                Toast.makeText(getApplicationContext(), "Authentication failed: Server error" + inErrorMessage.toString(), Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Authentication failed: Server error" + inErrorMessage.toString());
            }
            public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {

                Toast.makeText(getApplicationContext(), "Unable to load webpage " + inErrorMessage.toString(), Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Unable to load webpage" + inErrorMessage.toString());
            }
            public void onBackPressedCancelTransaction()
            {
                Toast.makeText(getApplicationContext(), "Transaction cancelled" , Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Transaction cancelled" );
            }
            public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {

                Toast.makeText(getApplicationContext(), "Transaction cancelled" +inErrorMessage.toString() , Toast.LENGTH_LONG).show();
                Log.d("Payment", " Paytm Response : Transaction cancelled" + inErrorMessage.toString());
            }
        });

    }

    private void applyCoupon(String code, List<CartProduct> checkoutItemsList) {
        //List<ProcessOrderDetails> products = new ArrayList<>();

        String Products = "";

        for (int i = 0; i<checkoutItemsList.size(); i++)
        {
            Products = Products + "/" + checkoutItemsList.get(i).getCustomersBasketProduct().getProductsId() +
                    "-" + checkoutItemsList.get(i).getCustomersBasketProduct().getTotalPrice() +
                    "-" + 1;

        }

        Call<ProcessOrderData> call = APIClient.getNetInstance(false)
                .apply_coupons(
                        code,
                        customerId,
                        Products
                        );
        call.enqueue(new Callback<ProcessOrderData>() {
            @Override
            public void onResponse(Call<ProcessOrderData> call, retrofit2.Response<ProcessOrderData> response) {

                if (response.isSuccessful()) {
                    if (response.body().getSuccess() == 1) {


                        disountAmount = Double.valueOf(response.body().getDiscounted_price());

                        View2.setVisibility(View.VISIBLE);
                        View1.setVisibility(View.VISIBLE);
                        discount_amount.setText(response.body().getDiscounted_price());

                        checkout_total.setText(response.body().getTotal_amount());

                        checkoutTotal = (int) Double.parseDouble(response.body().getTotal_amount());


                        couponApplied = true;

                    }
                    else {
                        // Unexpected Response from Server
                        dialogLoader.hideProgressDialog();
                        //Snackbar.make(rootView, getString(R.string.cannot_get_payment_methods), Snackbar.LENGTH_LONG).show();
                        Toast.makeText(Payment.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        checkout_total.setText(String.valueOf(checkoutTotal));
                    }
                }
                else {
                    dialogLoader.hideProgressDialog();
                    Toast.makeText(Payment.this, getString(R.string.cannot_get_payment_methods), Toast.LENGTH_SHORT).show();
                    checkout_total.setText(String.valueOf(checkoutTotal));
                }
            }

            @Override
            public void onFailure(Call<ProcessOrderData> call, Throwable t) {
                dialogLoader.hideProgressDialog();
                Toast.makeText(Payment.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
                Log.d("Coupons","NetworkCallFailure : ", t);
                checkout_total.setText(String.valueOf(checkoutTotal));
            }
        });

    }


    private void RequestPaymentMethods() {

        dialogLoader.showProgressDialog();

        Call<PaymentMethodsData> call = APIClient.getNetInstance(false)
                .getPaymentMethods();


        call.enqueue(new Callback<PaymentMethodsData>() {
            @Override
            public void onResponse(Call<PaymentMethodsData> call, retrofit2.Response<PaymentMethodsData> response) {

                if (response.isSuccessful()) {
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {

                        for (int i=0;  i<response.body().getData().size();  i++) {

                            PaymentMethodsInfo paymentMethodsInfo = response.body().getData().get(i);

                            if (paymentMethodsInfo.getName().equalsIgnoreCase("Cash On Delivery")
                                    && paymentMethodsInfo.getActive().equalsIgnoreCase("1"))
                            {
                                paymentMethodsList.add("Cash On Delivery");
                            }

                            if (paymentMethodsInfo.getName().equalsIgnoreCase("Paytm")
                                    && paymentMethodsInfo.getActive().equalsIgnoreCase("1"))
                            {
                                paymentMethodsList.add("paytm");
                            }
                            else {
                                dialogLoader.hideProgressDialog();
                            }
                        }

                    }
                    else {
                        // Unexpected Response from Server
                        dialogLoader.hideProgressDialog();
                        //Snackbar.make(rootView, getString(R.string.cannot_get_payment_methods), Snackbar.LENGTH_LONG).show();
                        Toast.makeText(Payment.this, getString(R.string.cannot_get_payment_methods), Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    dialogLoader.hideProgressDialog();
                    Toast.makeText(Payment.this, getString(R.string.cannot_get_payment_methods), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PaymentMethodsData> call, Throwable t) {
                dialogLoader.hideProgressDialog();
                Toast.makeText(Payment.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });
    }
/*
    private boolean validatePaymentCard() {
        if (!ValidateInputs.isValidNumber(checkout_card_number.getText().toString().trim())) {
            checkout_card_number.setError(getString(R.string.invalid_credit_card));
            return false;
        } else if (!ValidateInputs.isValidNumber(checkout_card_cvv.getText().toString().trim())) {
            checkout_card_cvv.setError(getString(R.string.invalid_card_cvv));
            return false;
        } else if (checkout_card_expiry.getText().toString().trim().isEmpty()) {
            checkout_card_expiry.setError(getString(R.string.select_card_expiry));
            return false;
        } else {
            return true;
        }
    }*/

    private void proceedOrder() {

        PostOrder orderDetails = new PostOrder();
        List<PostProducts> orderProductList = new ArrayList<>();

        for (int i=0;  i<checkoutItemsList.size();  i++) {

            PostProducts orderProduct = new PostProducts();

            // Get current Product Details
            orderProduct.setProducts_id(checkoutItemsList.get(i).getCustomersBasketProduct().getProductsId());
            orderProduct.setProducts_name(checkoutItemsList.get(i).getCustomersBasketProduct().getProductsName());
            orderProduct.setProducts_quantity(String.valueOf(checkoutItemsList.get(i).getCustomersBasketProduct().getCustomersBasketQuantity()));
            orderProduct.setProducts_price(checkoutItemsList.get(i).getCustomersBasketProduct().getProductsPrice());
            orderProduct.setFinal_price(checkoutItemsList.get(i).getCustomersBasketProduct().getTotalPrice());
            totalTax += Double.parseDouble(checkoutItemsList.get(i).getCustomersBasketProduct().getTax_amount());
            orderDetails.setShippingCost(checkoutItemsList.get(i).getDelivery_charge());
            orderDetails.setDistributor_id(String.valueOf(checkoutItemsList.get(i).getCustomersBasketProduct().getDistributorId()));

            // Add current Product to orderProductList
            orderProductList.add(orderProduct);
        }

        orderDetails.setTotalTax(String.valueOf(totalTax));
        // Set Customer Info
        orderDetails.setCustomersId(userInfo.getCustomersId());
        orderDetails.setCustomersName(userInfo.getCustomersFirstname()+" "+ userInfo.getCustomersLastname());
        orderDetails.setCustomersTelephone(userInfo.getCustomersTelephone() != null?userInfo.getCustomersTelephone():session.getUserWalletMobile());
        orderDetails.setCustomersEmailAddress(userInfo.getCustomersEmailAddress());

        // Set PaymentNonceToken and PaymentMethod
        orderDetails.setPaymentMethod(selectedPaymentMethod);

        // Set Checkout Price and Products

        //orderDetails.setProducts(orderProductList);

        // Set Shipping  Info
        if (isGiftOrder)
        {
            orderDetails.setDelivery_name(dialog_name);
            orderDetails.setOrder_type("0");
        }else {
            orderDetails.setDelivery_name(firstName + " " + lastName);
            orderDetails.setOrder_type("1");
        }
        orderDetails.setDeliveryStreetAddress(street);
        orderDetails.setDeliveryPostcode(postcode);
        orderDetails.setDeliverySuburb(suburb);
        orderDetails.setDeliveryCity(city);
        orderDetails.setDeliveryState(zoneName);
        orderDetails.setDeliveryCountry("India");
        orderDetails.setDeliverySuburb(city);
        orderDetails.setDelivery_lat("28.77");
        orderDetails.setDelivery_lng("28.77");

        // Set Billing Info
        orderDetails.setBilling_name(firstName+" "+lastName);
        orderDetails.setBillingStreetAddress(street);
        orderDetails.setBillingPostcode(postcode);
        orderDetails.setBillingSuburb(suburb);
        orderDetails.setBillingCity(city);
        orderDetails.setBillingState(zoneName);
        orderDetails.setBillingCountry("India");
        orderDetails.setBillingSuburb(city);

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
        Date date = new Date();

        orderDetails.setDate_purchased(formatter.format(date));
        orderDetails.setOrder_price(String.valueOf(checkoutTotal));


        orderDetails.setShippingMethod(getIntent().getStringExtra("shipping_method"));

        if (couponApplied) {
            orderDetails.setCouponAmount(String.valueOf(disountAmount));
            orderDetails.setCoupon_code(code);
        }else {
            orderDetails.setCouponAmount("0.00");
            orderDetails.setCoupon_code(" ");
        }

        orderDetails.setSchedule_date(deliveryDate);
        orderDetails.setStart_time(start_time);
        orderDetails.setEnd_time(end_time);
        orderDetails.setCategory_id(session.getAppCategoryId());
        orderDetails.setAddress_id(addressId!=null?addressId:"0");
        //todo gift order
        orderDetails.setGift_type(dialog_type);
        orderDetails.setGift_message(dialog_msg);

        PlaceOrderNow(orderDetails, orderProductList);

    }

    private void PlaceOrderNow(PostOrder postOrder, List<PostProducts> postProducts) {

        OrderDataPost post = new OrderDataPost(postOrder,postProducts);

        /*try {
            JSONObject postorder = new JSONObject(post);
        } catch (JSONException e) {
            e.printStackTrace();
        }*/

        Call<OrderData> call = APIClient.getNetInstance(false)
                .addToOrder
                        (
                             post
                        );

        call.enqueue(new Callback<OrderData>() {
            @Override
            public void onResponse(Call<OrderData> call, retrofit2.Response<OrderData> response) {

                progressDialog.dismiss();

                // Check if the Response is successful
                if (response.isSuccessful()) {
                    if (response.body().getSuccess() == 1) {

                        String subject = "Order Placed";
                        String body, message;
                        if (shopStatus.equalsIgnoreCase("Closed"))
                        {
                            body = "Thank You. The shop is now closed. Your order will be processed by the next opening hour.";
                            message = "Thank You. The shop is now closed. Your order will be processed by the next opening hour.";
                            NotificationHelper.showNewNotification(Payment.this, null, getString(R.string.thank_you), response.body().getMessage() + getString(R.string.closed_shop_message));

                        }
                        else {
                            body = "Thank You. The shop is now closed. Your order will be processed by the next opening hour.";
                            message = "Thank You. The shop is now closed. Your order will be processed by the next opening hour.";

                            // Order has been placed Successfully
                            NotificationHelper.showNewNotification(Payment.this, null, getString(R.string.thank_you), response.body().getMessage());
                        }
                        Call<FaqData> call1 = APIClient.getNetInstance(true).sendEmail_Sms
                                (
                                        session.getUser_Email(),
                                        subject,
                                        body,
                                        session.getUser_Mobile(),
                                        message
                                );

                        call1.enqueue(new Callback<FaqData>() {
                            @Override
                            public void onResponse(Call<FaqData> call, Response<FaqData> response) {

                                if (response.isSuccessful()) {


                                    Toast.makeText(Payment.this, response.body().getMessage(), Toast.LENGTH_LONG).show();

                                } else {
                                    // Show the Error Message
                                    Toast.makeText(Payment.this, response.body().getMessage(), Toast.LENGTH_LONG).show();
                                }

                            }

                            @Override
                            public void onFailure(Call<FaqData> call, Throwable t) {

                                Toast.makeText(Payment.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();

                            }
                        });
                        // Clear User's Cart
                        CartOperations.ClearCart();


                        // Navigate to Thank_You Fragment
                        Intent i = new Intent(Payment.this, Thank_You.class);
                        startActivity(i);


                    }
                    else if (response.body().getSuccess() == 0) {
                        Toast.makeText(Payment.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                    }
                    else {
                        // Unable to get Success status
                        Toast.makeText(Payment.this, getString(R.string.unexpected_response), Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(Payment.this, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<OrderData> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(Payment.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }



    //*********** Receives the result from a previous call of startActivityForResult(Intent, int) ********//

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Payment.this.finish();
    }
}
