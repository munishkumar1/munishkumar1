package com.nextstack.chicken.customerapp.adapters;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.CheckOutActivity;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.databases.User_Cart_DB;
import com.nextstack.chicken.customerapp.models.cart_model.CartProduct;
import com.nextstack.chicken.customerapp.utils.CartOperations;

import java.util.List;


/**
 * CartItemsAdapter is the adapter class of RecyclerView holding List of Cart Items in My_Cart
 **/

public class CartItemsAdapter extends RecyclerView.Adapter<CartItemsAdapter.MyViewHolder> {

    private Context context;
    private CheckOutActivity cartFragment;
    private List<CartProduct> cartItemsList;

    private User_Cart_DB user_cart_db;

    MyAppPrefsManager session;

    //private ProductAttributeValuesAdapter attributesAdapter;


    public CartItemsAdapter(Context context, List<CartProduct> cartItemsList, CheckOutActivity cartFragment) {
        this.context = context;
        this.cartItemsList = cartItemsList;
        this.cartFragment = cartFragment;

        user_cart_db = new User_Cart_DB();

        session = new MyAppPrefsManager(context);
    }



    //********** Called to Inflate a Layout from XML and then return the Holder *********//

    @Override
    public MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
    
        View itemView;

            itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkout_items_card, parent, false);

        return new MyViewHolder(itemView);
    }



    //********** Called by RecyclerView to display the data at the specified Position *********//

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {

        if (position < cartItemsList.size() && position != -1) {
            // Get the data model based on Position
            final CartProduct cartProduct = cartItemsList.get(position);

            // Set Product Image on ImageView with Glide Library
            Glide.with(context).load(ConstantValues.ECOMMERCE_URL + cartProduct.getCustomersBasketProduct().getProductsImage()).into(holder.cart_item_cover);

            holder.cart_item_title.setText(cartProduct.getCustomersBasketProduct().getProductsName());
            holder.cart_item_quantity.setText(cartProduct.getCustomersBasketProduct().getProductsQuantity()+" x " + cartProduct.getCustomersBasketProduct().getCustomersBasketQuantity());
            holder.cart_item_base_price.setText(cartProduct.getCustomersBasketProduct().getTotalPrice());

            // Delete relevant Product from Cart
            holder.cart_item_removeBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    holder.cart_item_removeBtn.setClickable(false);

                    // Delete CartItem from Local Database using static method of My_Cart
                    CartOperations.DeleteCartItem
                            (
                                    cartProduct.getCustomersBasketId()
                            );


                    // Calculate Cart's Total Price Again
                    setCartTotal();

                    // Remove CartItem from Cart List
                    cartItemsList.remove(holder.getAdapterPosition());

                    // Notify that item at position has been removed
                    notifyItemRemoved(holder.getAdapterPosition());

                    // Update Cart View from Local Database using static method of My_Cart
                    cartFragment.updateCartView(getItemCount());

                }
            });

        }

        cartFragment.updateCartView(getItemCount());
    }




    //********** Returns the total number of items in the data set *********//

    @Override
    public int getItemCount() {
        return cartItemsList.size();
    }


    //*********** Calculate and Set the Cart's Total Price ********//

    public void setCartTotal() {

        double finalPrice = 0, deliveryPrice = 0, tax = 0, taxPrice = 0;
        List<CartProduct> cartItemsList = user_cart_db.getCartItems(session.getAppCategoryId());

        for (int i=0;  i<cartItemsList.size();  i++) {
            // Update the Cart's Total Price
            finalPrice += Double.parseDouble(cartItemsList.get(i).getCustomersBasketProduct().getTotalPrice());

            tax = Double.parseDouble(cartItemsList.get(0).getGst_tax());

            deliveryPrice = Double.parseDouble(cartItemsList.get(0).getDelivery_charge());
        }


        taxPrice += (finalPrice * tax)/100;

        cartFragment.itemTotal.setText( String.valueOf(finalPrice));

        cartFragment.deliveryCharge.setText(String.valueOf(deliveryPrice));
        cartFragment.totalPrice.setText(String.valueOf(finalPrice + deliveryPrice + taxPrice));
        cartFragment.total_tax.setText(String.valueOf(taxPrice)+ "("+String.valueOf(tax)+"%"+")");
    }



    /********** Custom ViewHolder provides a direct reference to each of the Views within a Data_Item *********/

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private ImageView cart_item_cover;
        private ImageButton cart_item_removeBtn;
        private TextView cart_item_title, cart_item_base_price,cart_item_unit, cart_item_quantity;


        public MyViewHolder(final View itemView) {
            super(itemView);
            
            cart_item_title = itemView.findViewById(R.id.cart_item_title);
            cart_item_base_price = itemView.findViewById(R.id.cart_item_base_price);
            cart_item_quantity = itemView.findViewById(R.id.cart_item_quantity);
            cart_item_cover = itemView.findViewById(R.id.cart_item_cover);
            cart_item_removeBtn = itemView.findViewById(R.id.cart_item_removeBtn);/*
            cart_item_unit = itemView.findViewById(R.id.cart_item_unit);*/

        }
        
    }

}

