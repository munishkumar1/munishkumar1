package com.nextstack.chicken.customerapp.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.adapters.OrderedProductsListAdapter;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.models.coupons_model.CouponsInfo;
import com.nextstack.chicken.customerapp.models.order_model.OrderProducts;
import com.nextstack.chicken.customerapp.models.order_model.ViewOrderData;
import com.nextstack.chicken.customerapp.models.order_model.ViewOrderDetails;
import com.nextstack.chicken.customerapp.network.APIClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class Order_Details extends Fragment {

    View rootView;
    
    ViewOrderDetails orderDetails;

    CardView buyer_comments_card, seller_comments_card;
    RecyclerView checkout_items_recycler, checkout_coupons_recycler;
    TextView checkout_subtotal, checkout_tax, checkout_shipping, checkout_discount, checkout_total;
    TextView billing_name, billing_street, billing_address, shipping_name, shipping_street, shipping_address;
    TextView order_price, order_products_count, order_status, order_date, shipping_method, payment_method, buyer_comments, seller_comments;

    List<CouponsInfo> couponsList;
    List<OrderProducts> orderProductsList;

    OrderedProductsListAdapter orderedProductsAdapter;

    String orderStatus, orderPrice, orderId;


    @Nullable
    @Override
    public View onCreateView(final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.order_details, container, false);

        orderStatus = getArguments().getString("order_status");
        orderPrice = getArguments().getString("order_price");
        orderId = getArguments().getString("order_id");

        RequestOrderDetails(Integer.parseInt(orderId));

        // Set the Title of Toolbar
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(getString(R.string.order_details));

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        

        // Binding Layout Views
        order_price = rootView.findViewById(R.id.order_price);
        order_products_count = rootView.findViewById(R.id.order_products_count);
        shipping_method = rootView.findViewById(R.id.shipping_method);
        payment_method = rootView.findViewById(R.id.payment_method);
        order_status = rootView.findViewById(R.id.order_status);
        order_date = rootView.findViewById(R.id.order_date);
        checkout_subtotal = rootView.findViewById(R.id.checkout_subtotal);
        checkout_tax = rootView.findViewById(R.id.checkout_tax);
        checkout_shipping = rootView.findViewById(R.id.checkout_shipping);
        checkout_discount = rootView.findViewById(R.id.checkout_discount);
        checkout_total = rootView.findViewById(R.id.checkout_total);
        billing_name = rootView.findViewById(R.id.billing_name);
        billing_address = rootView.findViewById(R.id.billing_address);
        billing_street = rootView.findViewById(R.id.billing_street);
        shipping_name = rootView.findViewById(R.id.shipping_name);
        shipping_address = rootView.findViewById(R.id.shipping_address);
        shipping_street = rootView.findViewById(R.id.shipping_street);
        checkout_items_recycler = rootView.findViewById(R.id.checkout_items_recycler);
        /*
        buyer_comments = (TextView) rootView.findViewById(R.id.buyer_comments);
        seller_comments = (TextView) rootView.findViewById(R.id.seller_comments);
        buyer_comments_card = (CardView) rootView.findViewById(R.id.buyer_comments_card);
        seller_comments_card = (CardView) rootView.findViewById(R.id.seller_comments_card);
        checkout_coupons_recycler = (RecyclerView) rootView.findViewById(R.id.checkout_coupons_recycler);*/


        checkout_items_recycler.setNestedScrollingEnabled(false);
        //checkout_coupons_recycler.setNestedScrollingEnabled(false);


        return rootView;

    }




    private void RequestOrderDetails(int ordersId) {

        Call<ViewOrderData> call = APIClient.getNetInstance(false)
                .viewOrders
                        (
                                ordersId
                        );

        call.enqueue(new Callback<ViewOrderData>() {
            @Override
            public void onResponse(Call<ViewOrderData> call, Response<ViewOrderData> response) {
                if (response.isSuccessful())
                {
                    if (response.body().getSuccess() == 1)
                    {
                        orderDetails = response.body().getData();

                        setOrderDetails(orderDetails);
                    }
                    if (response.body().getSuccess() == 0)
                    {
                        Toast.makeText(getContext(), "Order Details ; " +response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    Toast.makeText(getContext(), "No Order Data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ViewOrderData> call, Throwable t) {

                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_SHORT).show();
                Log.d("View Orders","NetworkCallFailure : ", t);

            }
        });
    }

    private void setOrderDetails(ViewOrderDetails orderDetails) {

        orderProductsList = orderDetails.getProducts();

        double subTotal = 0;
        int noOfProducts = 0;
        for (int i=0;  i<orderProductsList.size();  i++) {
            subTotal += Double.parseDouble(orderProductsList.get(i).getFinalPrice());
            noOfProducts += orderProductsList.get(i).getProductsQuantity();
        }


        order_products_count.setText(String.valueOf(noOfProducts));
        order_price.setText(ConstantValues.CURRENCY_SYMBOL + orderPrice);
        shipping_method.setText(orderDetails.getShipping_method());
        payment_method.setText(orderDetails.getPayment_method());
        order_status.setText(orderStatus);
        order_date.setText(orderDetails.getDate_purchased());

        checkout_subtotal.setText(ConstantValues.CURRENCY_SYMBOL + String.valueOf(subTotal));
        checkout_tax.setText(ConstantValues.CURRENCY_SYMBOL + orderDetails.getTotal_tax());
        checkout_shipping.setText(ConstantValues.CURRENCY_SYMBOL + orderDetails.getShipping_cost());
        checkout_total.setText(ConstantValues.CURRENCY_SYMBOL + orderPrice);

        billing_name.setText(orderDetails.getBilling_name());
        billing_address.setText(orderDetails.getBilling_city());
        billing_street.setText(orderDetails.getBilling_street_address());
        shipping_name.setText(orderDetails.getDelivery_name());
        shipping_address.setText(orderDetails.getDelivery_city());
        shipping_street.setText(orderDetails.getDelivery_street_address());
        checkout_discount.setText(ConstantValues.CURRENCY_SYMBOL +orderDetails.getCoupon_amount());


        /*if (!orderDetails.getCustomerComments().isEmpty()  &&  !orderDetails.getCustomerComments().equalsIgnoreCase("")) {
            buyer_comments_card.setVisibility(View.VISIBLE);
            buyer_comments.setText(orderDetails.getCustomerComments());
        } else {
            buyer_comments_card.setVisibility(View.GONE);
        }

        if (!orderDetails.getAdminComments().isEmpty()  &&  !orderDetails.getAdminComments().equalsIgnoreCase("")) {
            seller_comments_card.setVisibility(View.VISIBLE);
            seller_comments.setText(orderDetails.getAdminComments());
        } else {
            seller_comments_card.setVisibility(View.GONE);
        }*/

//todo Orders details
        /*couponsAdapter = new CouponsAdapter(getContext(), couponsList, false, null);

        checkout_coupons_recycler.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        checkout_coupons_recycler.setAdapter(couponsAdapter);*/


        orderedProductsAdapter = new OrderedProductsListAdapter(getContext(), orderProductsList);

        checkout_items_recycler.setAdapter(orderedProductsAdapter);
        checkout_items_recycler.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        checkout_items_recycler.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));


    }


}



