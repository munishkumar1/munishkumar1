package com.nextstack.chicken.customerapp.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.CheckOutActivity;
import com.nextstack.chicken.customerapp.adapters.MenuRecyclerAdapter;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.databases.User_Cart_DB;
import com.nextstack.chicken.customerapp.models.cart_model.CartProduct;
import com.nextstack.chicken.customerapp.models.product_model.ProductData;
import com.nextstack.chicken.customerapp.models.product_model.ProductDetails;
import com.nextstack.chicken.customerapp.network.APIClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

public class Tab_1 extends Fragment {
    View rootView;

    RecyclerView menuRecycler;
    TextView sub_category_name;
    public Button checkout_button;

    String category_name, delivery_charge, gst_tax, shopStatus;
    int distributor_id;

    DialogLoader dialogLoader;
    MenuRecyclerAdapter menuRecyclerAdapter;

    List<ProductDetails> productsList = new ArrayList<>();

    User_Cart_DB user_cart_db = new User_Cart_DB();

    List<CartProduct> cartItemsList = new ArrayList<>();

    MyAppPrefsManager session;

    @Override
    public void onResume() {
        super.onResume();

        RequestProducts();

        cartItemsList = user_cart_db.getCartItems(session.getAppCategoryId());

        if (cartItemsList.size() > 0)
        {
            checkout_button.setVisibility(View.VISIBLE);
        }else
        {
            checkout_button.setVisibility(View.GONE);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //Returning the layout file after inflating
        rootView = inflater.inflate(R.layout.tab_1, container, false);

        session = new MyAppPrefsManager(getContext());

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        if (getArguments() != null) {
            if (getArguments().containsKey("category_name") && getArguments().containsKey("distributor_id")) {
                category_name = getArguments().getString("category_name", "");
                distributor_id = getArguments().getInt("distributor_id", 0);
                delivery_charge = getArguments().getString("delivery_charge");
                gst_tax = getArguments().getString("gst_tax");
                shopStatus = getArguments().getString("shop_status");
            }
        }

        menuRecycler = rootView.findViewById(R.id.chicken_recyclerView);
        checkout_button = rootView.findViewById(R.id.checkout_button);
        sub_category_name = rootView.findViewById(R.id.sub_category_name);

        sub_category_name.setText(category_name);

        dialogLoader = new DialogLoader(getContext());

        cartItemsList = user_cart_db.getCartItems(session.getAppCategoryId());

        if (cartItemsList.size() > 0)
        {
            checkout_button.setVisibility(View.VISIBLE);
        }

        checkout_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getContext(), CheckOutActivity.class);
                i.putExtra("shop_status",shopStatus);
                startActivity(i);

            }
        });

        RequestProducts();


        return rootView;
    }

    public void addProducts(ProductData productData)
    {
        productsList.clear();
        for (int i = 0; i < productData.getProductData().size(); i++) {
            ProductDetails productDetails = productData.getProductData().get(i);
            productsList.add(productDetails);
        }


        Log.d("Tab_1", "addProducts: "  + productsList.size());

        menuRecycler.removeAllViews();
        menuRecyclerAdapter = new MenuRecyclerAdapter(getContext(), productsList, distributor_id, Tab_1.this, gst_tax, delivery_charge, shopStatus);
        menuRecycler.setAdapter(menuRecyclerAdapter);
        menuRecycler.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));

        menuRecyclerAdapter.notifyDataSetChanged();
    }

    public void RequestProducts() {

        Call<ProductData> call = APIClient.getNetInstance(false)
                .getProducts(

                        distributor_id,
                        category_name

                        );

       call.enqueue(new Callback<ProductData>() {
            @Override
            public void onResponse(Call<ProductData> call, retrofit2.Response<ProductData> response) {

                // Check if the Response is successful
                if (response.isSuccessful()) {
                    if (response.body().getSuccess() == 1) {

                        // Orders have been returned. Add Orders to the ordersList
                        ProductData productData = response.body();

                        addProducts(productData);

                    }
                    else if (response.body().getSuccess() == 0) {
                        Snackbar.make(rootView, response.body().getMessage(), Snackbar.LENGTH_LONG).show();
                        Log.d("ProductData: ", response.body().getMessage());

                    }
                    else {
                        // Unable to get Success status
                        Snackbar.make(rootView, getString(R.string.unexpected_response), Snackbar.LENGTH_SHORT).show();
                        Log.d("ProductData: ", getString(R.string.unexpected_response));
                    }
                }
                else {
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                    Log.d("ProductData: ", response.message());
                }
            }

            @Override
            public void onFailure(Call<ProductData> call, Throwable t) {
                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
                Log.d("ProductData: ", "NetworkCallFailure : ", t);
            }
        });
    }


    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        super.onPrepareOptionsMenu(menu);


    }
}
