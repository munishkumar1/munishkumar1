package com.nextstack.chicken.customerapp.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.adapters.OfferListAdapter;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.models.coupons_model.CouponsData;
import com.nextstack.chicken.customerapp.models.coupons_model.CouponsInfo;
import com.nextstack.chicken.customerapp.network.APIClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;


public class Offers extends AppCompatActivity {

    Toolbar toolbar;
    ActionBar actionBar;
    EditText searchBar;

    TextView emptyRecord;

    RecyclerView offer_recycler;
    DialogLoader dialogLoader;
    OfferListAdapter offerListAdapter;

    List<CouponsInfo> couponsList = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_offer);

        dialogLoader = new DialogLoader(this);

        toolbar = findViewById(R.id.mytoolbar);
        searchBar = findViewById(R.id.search_bar);

        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        getSupportActionBar().setTitle("Offers");
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        searchBar.setVisibility(View.GONE);

        emptyRecord = findViewById(R.id.no_offers);
        offer_recycler = findViewById(R.id.offer_recycler);

        emptyRecord.setVisibility(View.GONE);

        RequestMyOffers();

    }


    private void addCoupons(CouponsData couponsData) {

        // Add Orders to ordersList from the List of OrderData
        couponsList = couponsData.getData();


        // Initialize the OrdersListAdapter for RecyclerView
        offerListAdapter = new OfferListAdapter(Offers.this, couponsList);

        // Set the Adapter and LayoutManager to the RecyclerView
        offer_recycler.setAdapter(offerListAdapter);
        offer_recycler.setLayoutManager(new LinearLayoutManager(Offers.this, RecyclerView.VERTICAL, false));


        offerListAdapter.notifyDataSetChanged();
    }

    public void RequestMyOffers() {

        dialogLoader.showProgressDialog();

        Call<CouponsData> call = APIClient.getNetInstance(false).getOffers();

        call.enqueue(new Callback<CouponsData>() {
            @Override
            public void onResponse(Call<CouponsData> call, retrofit2.Response<CouponsData> response) {

                dialogLoader.hideProgressDialog();

                // Check if the Response is successful
                if (response.isSuccessful()) {
                    if (response.body().getSuccess() == 1) {

                        // Orders have been returned. Add Orders to the ordersList
                        addCoupons(response.body());

                    }
                    else if (response.body().getSuccess() == 0) {
                        emptyRecord.setVisibility(View.VISIBLE);
                        //Snackbar.make(rootView, response.body().getMessage(), Snackbar.LENGTH_LONG).show();

                    }
                    else {
                        // Unable to get Success status
                        emptyRecord.setVisibility(View.VISIBLE);
                        //Snackbar.make(rootView, getString(R.string.unexpected_response), Snackbar.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(Offers.this, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CouponsData> call, Throwable t) {
                Toast.makeText(Offers.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
