package com.nextstack.chicken.customerapp.models.wallet_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ViewWallet {

    @SerializedName("wallet_id")
    @Expose
    private int wallet_id;
    @SerializedName("total_cash")
    @Expose
    private String total_cash;
    @SerializedName("total_points")
    @Expose
    private String total_points;
    @SerializedName("referral_points")
    @Expose
    private String referral_points;
    @SerializedName("mobile_no")
    @Expose
    private String mobile_no;


    public int getWallet_id() {
        return wallet_id;
    }

    public void setWallet_id(int wallet_id) {
        this.wallet_id = wallet_id;
    }

    public String getTotal_cash() {
        return total_cash;
    }

    public void setTotal_cash(String total_cash) {
        this.total_cash = total_cash;
    }

    public String getTotal_points() {
        return total_points;
    }

    public void setTotal_points(String total_points) {
        this.total_points = total_points;
    }

    public String getReferral_points() {
        return referral_points;
    }

    public void setReferral_points(String referral_points) {
        this.referral_points = referral_points;
    }

    public String getMobile_no() {
        return mobile_no;
    }

    public void setMobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }
}
