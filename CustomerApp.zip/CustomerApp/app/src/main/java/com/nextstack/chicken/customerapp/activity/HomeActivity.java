package com.nextstack.chicken.customerapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexWrap;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.android.flexbox.JustifyContent;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.adapters.CategoryAdapter;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.models.category_model.CategoriesData;
import com.nextstack.chicken.customerapp.models.category_model.CategoryDetails;
import com.nextstack.chicken.customerapp.network.APIClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HomeActivity extends AppCompatActivity {

    RecyclerView category_recycler;
    CategoryAdapter adapter;

    DialogLoader dialogLoader;

    List<CategoryDetails > categoriesList = new ArrayList<>();

    MyAppPrefsManager session;

    int postcode = 110019;

    String customerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        session = new MyAppPrefsManager(this);

        if (session.isFirstTimeLaunch()) {

            session.setFirstTimeLaunch(false);
            Intent i = new Intent(HomeActivity.this, DeliveryAddress.class);
            i.putExtra("activity", "Home");
            startActivity(i);

            super.onStart();
        }

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        category_recycler = findViewById(R.id.category_recycler);
        FlexboxLayoutManager layoutManager = new FlexboxLayoutManager(this);
        layoutManager.setFlexDirection(FlexDirection.ROW);
        layoutManager.setFlexWrap(FlexWrap.WRAP);
        layoutManager.setJustifyContent(JustifyContent.SPACE_AROUND);
        category_recycler.setLayoutManager(layoutManager);

        dialogLoader = new DialogLoader(HomeActivity.this);


        requestCategories();


    }

    @Override
    protected void onResume() {
        super.onResume();

        requestCategories();
    }

    public Context getContext()
    {
        return HomeActivity.this;
    }

    private void requestCategories() {

        dialogLoader.showProgressDialog();

        Call<CategoriesData> call = APIClient.getNetInstance(false)
                .getDistributorCategory
                        (
                                1,
                                postcode
                        );

        call.enqueue(new Callback<CategoriesData>() {
            @Override
            public void onResponse(Call<CategoriesData> call, Response<CategoriesData> response) {

                dialogLoader.hideProgressDialog();

                if (response.isSuccessful()) {

                    if (response.body().getSuccess().equalsIgnoreCase("1") || response.body().getSuccess().equalsIgnoreCase("2"))
                    {
                        // Get the User Details from Response
                        categoriesList = response.body().getData();

                        adapter = new CategoryAdapter(HomeActivity.this, categoriesList, new CategoryAdapter.OnItemClickListener() {
                            @Override
                            public void onItemClick(CategoryDetails item) {

                                Intent i = new Intent(HomeActivity.this, MainActivity.class);
                                session.setAppCategoryId(String.valueOf(item.getCategoriesId()));
                                session.setAppCategoryName(item.getCategoriesName());
                                session.setAppCategoryImage(item.getCategoriesImage());
                                i.putExtra("fragment", getString(R.string.home));
                                startActivity(i);
                            }
                        });
                        category_recycler.setAdapter(adapter);


                    }
                    else if (response.body().getSuccess().equalsIgnoreCase("0"))
                    {
                        // Get the Error Message from Response
                        String message = response.body().getMessage();
                    }
                    else {
                        Toast.makeText(HomeActivity.this, getString(R.string.unexpected_response), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    // Show the Error Message
                    Toast.makeText(HomeActivity.this, response.message(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<CategoriesData> call, Throwable t) {
                dialogLoader.hideProgressDialog();
                Toast.makeText(HomeActivity.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });
    }
}
