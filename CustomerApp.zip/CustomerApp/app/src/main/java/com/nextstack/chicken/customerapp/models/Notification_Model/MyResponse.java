package com.nextstack.chicken.customerapp.models.Notification_Model;


public class MyResponse {
        public int success;
    }

