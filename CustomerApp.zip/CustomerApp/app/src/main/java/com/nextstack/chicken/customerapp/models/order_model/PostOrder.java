package com.nextstack.chicken.customerapp.models.order_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class PostOrder {

    @SerializedName("customers_id")
    @Expose
    private int customersId;
    @SerializedName("customers_name")
    @Expose
    private String customersName;
    @SerializedName("customers_telephone")
    @Expose
    private String customersTelephone;
    @SerializedName("customers_email_address")
    @Expose
    private String customersEmailAddress;

    @SerializedName("delivery_name")
    @Expose
    private String delivery_name;
    @SerializedName("delivery_street_address")
    @Expose
    private String deliveryStreetAddress;
    @SerializedName("delivery_suburb")
    @Expose
    private String deliverySuburb;
    @SerializedName("delivery_postcode")
    @Expose
    private String deliveryPostcode;
    @SerializedName("delivery_city")
    @Expose
    private String deliveryCity;
    @SerializedName("delivery_state")
    @Expose
    private String deliveryState;
    @SerializedName("delivery_country")
    @Expose
    private String deliveryCountry;
    @SerializedName("billing_name")
    @Expose
    private String billing_name;
    @SerializedName("billing_street_address")
    @Expose
    private String billingStreetAddress;
    @SerializedName("billing_suburb")
    @Expose
    private String billingSuburb;
    @SerializedName("billing_postcode")
    @Expose
    private String billingPostcode;
    @SerializedName("billing_city")
    @Expose
    private String billingCity;
    @SerializedName("billing_state")
    @Expose
    private String billingState;
    @SerializedName("billing_country")
    @Expose
    private String billingCountry;
    @SerializedName("delivery_lat")
    @Expose
    private String delivery_lat;
    @SerializedName("delivery_lng")
    @Expose
    private String delivery_lng;
    @SerializedName("total_tax")
    @Expose
    private String totalTax;
    @SerializedName("shipping_method")
    @Expose
    private String shippingMethod;
    @SerializedName("payment_method")
    @Expose
    private String paymentMethod;
    @SerializedName("shipping_cost")
    @Expose
    private String shippingCost;
    @SerializedName("coupon_code")
    @Expose
    private String coupon_code;
    @SerializedName("address_id")
    @Expose
    private String address_id;
    @SerializedName("coupon_amount")
    @Expose
    private String couponAmount;
    @SerializedName("schedule_date")
    @Expose
    private String schedule_date;
    @SerializedName("start_time")
    @Expose
    private String start_time;
    @SerializedName("end_time")
    @Expose
    private String end_time ;
    @SerializedName("date_purchased")
    @Expose
    private String date_purchased;
    @SerializedName("order_price")
    @Expose
    private String order_price;
    @SerializedName("category_id")
    @Expose
    private String category_id;
    @SerializedName("distributor_id")
    @Expose
    private String distributor_id;
    @SerializedName("gift_type")
    @Expose
    private String gift_type;
    @SerializedName("gift_message")
    @Expose
    private String gift_message;
    @SerializedName("order_type")
    @Expose
    private String order_type;

    /*@SerializedName("products")
    @Expose
    private List<PostProducts> products = new ArrayList<>();*/
    
    
    
    public int getCustomersId() {
        return customersId;
    }
    
    public void setCustomersId(int customersId) {
        this.customersId = customersId;
    }
    
    public String getCustomersName() {
        return customersName;
    }
    
    public void setCustomersName(String customersName) {
        this.customersName = customersName;
    }
    
    public String getCustomersTelephone() {
        return customersTelephone;
    }
    
    public void setCustomersTelephone(String customersTelephone) {
        this.customersTelephone = customersTelephone;
    }
    
    public String getCustomersEmailAddress() {
        return customersEmailAddress;
    }
    
    public void setCustomersEmailAddress(String customersEmailAddress) {
        this.customersEmailAddress = customersEmailAddress;
    }
    public String getDeliveryStreetAddress() {
        return deliveryStreetAddress;
    }
    
    public void setDeliveryStreetAddress(String deliveryStreetAddress) {
        this.deliveryStreetAddress = deliveryStreetAddress;
    }
    
    public String getDeliverySuburb() {
        return deliverySuburb;
    }
    
    public void setDeliverySuburb(String deliverySuburb) {
        this.deliverySuburb = deliverySuburb;
    }
    
    public String getDeliveryPostcode() {
        return deliveryPostcode;
    }
    
    public void setDeliveryPostcode(String deliveryPostcode) {
        this.deliveryPostcode = deliveryPostcode;
    }
    
    public String getDeliveryCity() {
        return deliveryCity;
    }
    
    public void setDeliveryCity(String deliveryCity) {
        this.deliveryCity = deliveryCity;
    }

    public String getDeliveryState() {
        return deliveryState;
    }
    
    public void setDeliveryState(String deliveryState) {
        this.deliveryState = deliveryState;
    }
    
    public String getDeliveryCountry() {
        return deliveryCountry;
    }
    
    public void setDeliveryCountry(String deliveryCountry) {
        this.deliveryCountry = deliveryCountry;
    }
    
    public String getBillingStreetAddress() {
        return billingStreetAddress;
    }
    
    public void setBillingStreetAddress(String billingStreetAddress) {
        this.billingStreetAddress = billingStreetAddress;
    }
    
    public String getBillingSuburb() {
        return billingSuburb;
    }
    
    public void setBillingSuburb(String billingSuburb) {
        this.billingSuburb = billingSuburb;
    }
    
    public String getBillingPostcode() {
        return billingPostcode;
    }
    
    public void setBillingPostcode(String billingPostcode) {
        this.billingPostcode = billingPostcode;
    }
    
    public String getBillingCity() {
        return billingCity;
    }
    
    public void setBillingCity(String billingCity) {
        this.billingCity = billingCity;
    }

    public String getBillingState() {
        return billingState;
    }
    
    public void setBillingState(String billingState) {
        this.billingState = billingState;
    }
    
    public String getBillingCountry() {
        return billingCountry;
    }

    public void setBillingCountry(String billingCountry) {
        this.billingCountry = billingCountry;
    }

    public String getTotalTax() {
        return totalTax;
    }
    
    public void setTotalTax(String totalTax) {
        this.totalTax = totalTax;
    }
    
    public String getShippingCost() {
        return shippingCost;
    }
    
    public void setShippingCost(String shippingCost) {
        this.shippingCost = shippingCost;
    }
    
    public String getShippingMethod() {
        return shippingMethod;
    }
    
    public void setShippingMethod(String shippingMethod) {
        this.shippingMethod = shippingMethod;
    }

    public String getCouponAmount() {
        return couponAmount;
    }
    
    public void setCouponAmount(String couponAmount) {
        this.couponAmount = couponAmount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }
    
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
/*
    public List<PostProducts> getProducts() {
        return products;
    }
    
    public void setProducts(List<PostProducts> products) {
        this.products = products;
    }*/

    public String getDelivery_name() {
        return delivery_name;
    }

    public void setDelivery_name(String delivery_name) {
        this.delivery_name = delivery_name;
    }

    public String getBilling_name() {
        return billing_name;
    }

    public void setBilling_name(String billing_name) {
        this.billing_name = billing_name;
    }

    public String getCoupon_code() {
        return coupon_code;
    }

    public void setCoupon_code(String coupon_code) {
        this.coupon_code = coupon_code;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getSchedule_date() {
        return schedule_date;
    }

    public void setSchedule_date(String schedule_date) {
        this.schedule_date = schedule_date;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public String getDate_purchased() {
        return date_purchased;
    }

    public void setDate_purchased(String date_purchased) {
        this.date_purchased = date_purchased;
    }

    public String getOrder_price() {
        return order_price;
    }

    public void setOrder_price(String order_price) {
        this.order_price = order_price;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getDistributor_id() {
        return distributor_id;
    }

    public void setDistributor_id(String distributor_id) {
        this.distributor_id = distributor_id;
    }

    public String getDelivery_lat() {
        return delivery_lat;
    }

    public void setDelivery_lat(String delivery_lat) {
        this.delivery_lat = delivery_lat;
    }

    public String getDelivery_lng() {
        return delivery_lng;
    }

    public void setDelivery_lng(String delivery_lng) {
        this.delivery_lng = delivery_lng;
    }

    public String getGift_type() {
        return gift_type;
    }

    public void setGift_type(String gift_type) {
        this.gift_type = gift_type;
    }

    public String getGift_message() {
        return gift_message;
    }

    public void setGift_message(String gift_message) {
        this.gift_message = gift_message;
    }

    public String getOrder_type() {
        return order_type;
    }

    public void setOrder_type(String order_type) {
        this.order_type = order_type;
    }
}
