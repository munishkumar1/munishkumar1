package com.nextstack.chicken.customerapp.adapters;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.nextstack.chicken.customerapp.customs.CustomViewPager;

import java.util.ArrayList;
import java.util.List;

public class MenuPageAdapter extends FragmentStatePagerAdapter {
    private int mCurrentPosition = -1;
    private final List<Fragment> fragmentList = new ArrayList<>();
    private final List<String> fragmentTitleList = new ArrayList<>();

    public MenuPageAdapter(@NonNull FragmentManager fragmentManager) {
        super(fragmentManager);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentList.size();

    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return fragmentTitleList.get(position);
    }

    @Override
    public void setPrimaryItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        super.setPrimaryItem(container, position, object);

        if (position != mCurrentPosition)
        {
            Fragment fragment = (Fragment) object;

            CustomViewPager pager = (CustomViewPager) container;

            if (fragment != null && fragment.getView()!= null) {
                mCurrentPosition = position;

                // Set the measured View to CustomViewPager
                pager.setCurrentView(fragment.getView());
            }
        }
    }

    public void addFragment(Fragment fragment, String title) {
        // Add the given Fragment to FragmentList
        fragmentList.add(fragment);

        // Add the Title of a given Fragment to FragmentTitleList
        fragmentTitleList.add(title);
    }
}
