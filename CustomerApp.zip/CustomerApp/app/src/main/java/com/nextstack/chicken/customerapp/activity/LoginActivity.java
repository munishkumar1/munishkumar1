package com.nextstack.chicken.customerapp.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.databases.User_Address;
import com.nextstack.chicken.customerapp.databases.User_Info_DB;
import com.nextstack.chicken.customerapp.fragment.Add_Address;
import com.nextstack.chicken.customerapp.models.address_model.AddressDetails;
import com.nextstack.chicken.customerapp.models.user_model.UserData;
import com.nextstack.chicken.customerapp.models.user_model.UserDetails;
import com.nextstack.chicken.customerapp.models.wallet_model.WalletData;
import com.nextstack.chicken.customerapp.network.APIClient;
import com.nextstack.chicken.customerapp.services.MyFirebaseMessagingService;
import com.nextstack.chicken.customerapp.utils.ValidateInputs;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    View parentView;

    EditText user_email, user_password;
    TextView signUpText;
    Button loginBtn;
    LoginButton facebookLoginBtn;
    SignInButton googleLoginBtn;


    DialogLoader dialogLoader;
    User_Info_DB userInfoDB;


    SharedPreferences.Editor editor;
    SharedPreferences sharedPreferences;

    GoogleApiClient mGoogleApiClient;
    GoogleSignInAccount account;

    FirebaseAuth mAuth;
    private CallbackManager callbackManager;

    private final static int RC_SIGN_IN = 100;

    MyAppPrefsManager myAppPrefsManager;

    String last_name, first_name, email, id, image;

    User_Address userAddressDb = new User_Address();

    List<AddressDetails> addressDetails = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        myAppPrefsManager = new MyAppPrefsManager(LoginActivity.this);

        user_email = findViewById(R.id.login_email);
        user_password = findViewById(R.id.login_password);
        loginBtn = findViewById(R.id.btn_login);
        signUpText = findViewById(R.id.sign_up_text);
        facebookLoginBtn = findViewById(R.id.facebookLoginBtn);
        facebookLoginBtn.setPermissions(Arrays.asList("email", "public_profile"));
        googleLoginBtn = findViewById(R.id.googleLoginBtn);
        googleLoginBtn.setSize(SignInButton.SIZE_STANDARD);

        mAuth = FirebaseAuth.getInstance();


        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();


        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                        Toast.makeText(LoginActivity.this, "Something went wrong!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();




        googleLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignIn();
            }
        });


        parentView = signUpText;

        dialogLoader = new DialogLoader(LoginActivity.this);
        sharedPreferences = getSharedPreferences("UserInfo", MODE_PRIVATE);


        signUpText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to SignUp Activity
                startActivity(new Intent(LoginActivity.this, SignupActivity.class));
                overridePendingTransition(R.anim.enter_from_left, R.anim.exit_out_left);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Validate Login Form Inputs
                boolean isValidData = validateLogin();

                if (isValidData) {

                    // Proceed User Login
                    processLogin(user_email.getText().toString().trim(), "", user_password.getText().toString().trim(), LoginActivity.this, "1");
                }
            }
        });

        facebookLoginBtn.setVisibility(View.VISIBLE);
        callbackManager = CallbackManager.Factory.create();
        facebookLoginBtn.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {

                GraphRequest request = GraphRequest.newMeRequest(
                        loginResult.getAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject object, GraphResponse response) {
                                Log.v("LoginActivity", response.toString());

                                try {

                                    Log.d("Facebook Login  :", object.toString() );
                                    Log.d("Facebook Login  :", response.toString() );

                                   last_name = object.getString("last_name");
                                   first_name = object.getString("first_name");
                                   id = object.getString("id");
                                   image = "https://graph.facebook.com/" + id + "/picture?type=normal";

                                    processFacebookRegistration
                                            (
                                                    first_name,
                                                    last_name,
                                                    id,
                                                    email,
                                                    image,
                                                    ""

                                            );

                                } catch (JSONException e) {
                                    e.printStackTrace();


                                }
                            }
                        });
                Log.d("Facebook Login  :", loginResult.getAccessToken().getToken() );
                Log.d("Facebook Login  :", loginResult.getAccessToken().getUserId());

                Bundle parameters = new Bundle();
                parameters.putString("fields", "first_name,last_name,email,id");
                request.setParameters(parameters);
                request.executeAsync();

            }

            @Override
            public void onCancel() {
                Toast.makeText(LoginActivity.this, "FacebookException : ", Toast.LENGTH_LONG).show();

            }

            @Override
            public void onError(FacebookException exception) {


                Toast.makeText(LoginActivity.this, "FacebookException : "+exception, Toast.LENGTH_LONG).show();

            }
        });

    }
    private void SignIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }

    private void updateUI(FirebaseUser currentUser) {
    }

    private boolean validateLogin() {
        if (!ValidateInputs.isValidEmail(user_email.getText().toString().trim())) {
            user_email.setError(getString(R.string.invalid_email));
            return false;
        }
        else if (!ValidateInputs.isValidPassword(user_password.getText().toString().trim())) {
            user_password.setError(getString(R.string.invalid_password));
            return false;
        }
        else {
            return true;
        }
    }

    public void processLogin(String customers_email_address, final String mobile_no, String customers_password, final Context context, final String type) {

//        dialogLoader = new DialogLoader(context);
        //dialogLoader.showProgressDialog();

        Call<UserData> call = APIClient.getNetInstance(false)
                .processLogin
                        (
                                customers_email_address,
                                customers_password
                        );

        call.enqueue(new Callback<UserData>() {
            @Override
            public void onResponse(Call<UserData> call, Response<UserData> response) {

               // dialogLoader.hideProgressDialog();

                if (response.isSuccessful()) {

                    if (response.body().getSuccess() == 1 || response.body().getSuccess() == 2)
                    {

                        if (response.body().getMessage().equalsIgnoreCase("Authenticated")) {
                            // Get the User Details from Response
                            UserDetails userDetails = response.body().getData();

                            userInfoDB = new User_Info_DB();

                            // Save User data to Local Databases
                            if (userInfoDB.getUserData(String.valueOf(userDetails.getCustomersId())) != null) {
                                // User already exists
                                userInfoDB.updateUserData(userDetails);
                            } else {
                                // Insert Details of New User
                                userInfoDB.insertUserData(userDetails);
                            }


                            sharedPreferences = context.getSharedPreferences("UserInfo", context.MODE_PRIVATE);

                            // Save necessary details in SharedPrefs
                            editor = sharedPreferences.edit();
                            editor.putString("userID", String.valueOf(userDetails.getCustomersId()));
                            editor.putString("userEmail", userDetails.getCustomersEmailAddress());
                            editor.putString("userName", userDetails.getCustomersFirstname() + " " + userDetails.getCustomersLastname());
                            editor.putString("userProfile", userDetails.getCustomersPicture());
                            editor.putString("userDefaultAddressID", userDetails.getCustomersDefaultAddressId());
                            editor.putBoolean("isLogged_in", true);
                            editor.apply();


                            myAppPrefsManager = new MyAppPrefsManager(context);
                            // Set UserLoggedIn in MyAppPrefsManager
                            myAppPrefsManager.setUserLoggedIn(true);
                            myAppPrefsManager.setUserId(String.valueOf(userDetails.getCustomersId()));
                            myAppPrefsManager.setUserName(userDetails.getCustomersFirstname() + " " + userDetails.getCustomersLastname());
                            myAppPrefsManager.setUserProfile(userDetails.getCustomersPicture());
                            myAppPrefsManager.setRefCode(userDetails.getReferral_Code());
                            myAppPrefsManager.setUser_Mobile(userDetails.getCustomersTelephone());
                            myAppPrefsManager.setUser_Email(userDetails.getCustomersEmailAddress());

                            // Set isLogged_in of ConstantValues
                            ConstantValues.IS_USER_LOGGED_IN = myAppPrefsManager.isUserLoggedIn();


                            FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(LoginActivity.this, new OnSuccessListener<InstanceIdResult>() {
                                @Override
                                public void onSuccess(InstanceIdResult instanceIdResult) {
                                    String newToken = instanceIdResult.getToken();
                                    Log.e("newToken", newToken);

                                    editor = sharedPreferences.edit();
                                    editor.putString("FCM_Token", newToken);
                                    editor.apply();

                                    MyFirebaseMessagingService.updateToken(newToken);

                                    MyFirebaseMessagingService.RegisterDeviceForFCM(context);

                                }
                            });

                            fetchWallet(String.valueOf(userDetails.getCustomersId()));

                            addressDetails = userAddressDb.getAddressData();

                            if (addressDetails != null && myAppPrefsManager.getAddressCartCount()<addressDetails.size())
                            {
                                myAppPrefsManager.setAddressCartCount(addressDetails.size());

                                Add_Address addAddress = new Add_Address();

                                for (int i = 0; i<addressDetails.size();i++) {

                                    addAddress.addUserAddress
                                            (
                                                    String.valueOf(userDetails.getCustomersId()),
                                                    userDetails.getCustomersFirstname(),
                                                    userDetails.getCustomersLastname(),
                                                    addressDetails.get(i).getStreet(),
                                                    addressDetails.get(i).getPostcode(),
                                                    addressDetails.get(i).getCity(),
                                                    addressDetails.get(i).getState(),
                                                    "253",
                                                    addressDetails.get(i).getLat(),
                                                    addressDetails.get(i).getLng(),
                                                    addressDetails.get(i).getNickname(),
                                                    addressDetails.get(i).getLandmark(),
                                                    addressDetails.get(i).getHouse_no(),
                                                    "3",
                                                    LoginActivity.this,
                                                    null
                                            );
                                }
                            }


                            // Navigate back to MainActivity
                            /*Intent i = new Intent(getApplicationContext(), MainActivity.class);
                            i.putExtra("fragment", "home");
                            startActivity(i);*/
                            finish();
                            //overridePendingTransition(R.anim.enter_from_right, R.anim.exit_out_right);
                        }
                        else {



                            }

                    }
                    else if (response.body().getSuccess() == 0)
                    {

                        if (type.equalsIgnoreCase("2")) {
                            String photoURL = account.getPhotoUrl() != null ? account.getPhotoUrl().toString() : "";

                            SignupActivity signup = new SignupActivity();
                            signup.registerToFCM
                                    (
                                            LoginActivity.this,
                                            account.getGivenName(),
                                            account.getFamilyName(),
                                            account.getEmail(),
                                            " ",
                                            account.getId(),
                                            account.getDisplayName(),
                                            mobile_no,
                                            "",
                                            photoURL,
                                            "2",
                                            "",
                                            account.getId()
                                    );

                        }else if(type.equalsIgnoreCase("3"))
                        {

                            SignupActivity signup = new SignupActivity();
                            signup.registerToFCM
                                    (
                                            LoginActivity.this,
                                            first_name,
                                            last_name,
                                            email,
                                            " ",
                                            id,
                                            first_name+" "+last_name,
                                            mobile_no,
                                            "",
                                            image,
                                            "3",
                                            id,
                                            ""
                                    );
                        }
                        // Get the Error Message from Response
                        String message = response.body().getMessage();
                   //     Snackbar.make(parentView, message, Snackbar.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(LoginActivity.this, getString(R.string.unexpected_response), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    // Show the Error Message
                    Toast.makeText(LoginActivity.this, response.message(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<UserData> call, Throwable t) {
              //  dialogLoader.hideProgressDialog();
                Toast.makeText(LoginActivity.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });


    }

    private void processFacebookRegistration(String first_name, String last_name, final String id, final String email, String image, String mobile) {

        if (email != null)
        {
            processLogin(email, mobile, id, this, "3");

        }
        else
        {
            openDialog(id, first_name, 2);
        }

    }

    private void openDialog(final String id, String first_name, final int type) {

        final AlertDialog.Builder dialog = new AlertDialog.Builder(LoginActivity.this);
        View dialogView = LoginActivity.this.getLayoutInflater().inflate(R.layout.dialog_email, null);
        dialog.setView(dialogView);
        dialog.setCancelable(false);

        TextView dialog_title = dialogView.findViewById(R.id.dialog_title);
        final EditText email_address = dialogView.findViewById(R.id.email);
        final EditText mobile_no = dialogView.findViewById(R.id.mobile);
        Button dialog_button = dialogView.findViewById(R.id.dialog_button);

        dialog_title.setText(getString(R.string.Hii) + first_name+",");

        final AlertDialog alertDialog = dialog.create();

        dialog_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email_addr,mobile;

                if(!ValidateInputs.isValidEmail( email_address.getText().toString()))
                {
                    email_address.setText(" ");
                    email_address.setHint(R.string.invalid_email);
                }
                if(!ValidateInputs.isValidPhoneNo( mobile_no.getText().toString()))
                {
                    mobile_no.setText(" ");
                    mobile_no.setHint(R.string.invalid_mobile_no);
                }
                else
                {
                    email_addr = email_address.getText().toString();
                    mobile = mobile_no.getText().toString();
                    if (type==2) {
                        processLogin(email_addr, mobile, id, LoginActivity.this, "3");
                    }
                    else {
                        processGoogleRegistration(account,mobile);
                    }
                    LoginActivity.this.email = email_addr;
                    alertDialog.dismiss();
                }

            }
        });
        alertDialog.show();

    }



    @Override
    public void onBackPressed() {

        // Navigate back to MainActivity
        startActivity(new Intent(LoginActivity.this, MainActivity.class));
        finish();
        overridePendingTransition(R.anim.enter_from_right, R.anim.exit_out_right);
    }


    private void fetchWallet(String customerId) {

        Call<WalletData> call = APIClient.getNetInstance(false)
                .viewWallet(customerId);

        call.enqueue(new Callback<WalletData>() {
            @Override
            public void onResponse(Call<WalletData> call, Response<WalletData> response) {

                if (response.isSuccessful())
                {
                    if (response.body().getSuccess() == 1)
                    {

                        myAppPrefsManager.setUserWalletId(String.valueOf(response.body().getData().getWallet_id()));
                        myAppPrefsManager.setUserWalletMobile(String.valueOf(response.body().getData().getMobile_no()));

                    }
                }
                else
                {
                    Toast.makeText(LoginActivity.this, response.message(), Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onFailure(Call<WalletData> call, Throwable t) {

                Toast.makeText(LoginActivity.this, "NetworkCallFailure: "+t, Toast.LENGTH_SHORT).show();

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == RC_SIGN_IN) {
            switch (requestCode){
                case  0:
                    try {
                        // The Task returned from this call is always completed, no need to attach
                        // a listener.
                        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                        GoogleSignInAccount account = task.getResult(ApiException.class);
                        onLoggedIn(account);
                    } catch (ApiException e) {
                        // The ApiException status code indicates the detailed failure reason.
                        //Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
                    }
                    break;


            }
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if (result.isSuccess())
            {
                account = result.getSignInAccount();
                openDialog(account.getId(),account.getDisplayName(),1);




            } else {
                Toast.makeText(LoginActivity.this, "Something went wrong!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void onLoggedIn(GoogleSignInAccount account) {
        Intent intent = new Intent(this, HomeActivity.class);
       // intent.putExtra(ProfileActivity.GOOGLE_ACCOUNT, googleSignInAccount);
        startActivity(intent);
        finish();
    }


    private void processGoogleRegistration(GoogleSignInAccount account, String mobile) {

        processLogin(account.getEmail(), mobile, account.getId(), this, "2");

    }

    private class FacebookSdk {
    }


    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        Log.d("Login Activity", "firebaseAuthWithGoogle:" + acct.getId());

        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("Login Activity", "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("Login Activity", "signInWithCredential:failure", task.getException());
                            Toast.makeText(LoginActivity.this, "Authentication Failed.", Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }

                        // ...
                    }
                });
    }


}
