package com.nextstack.chicken.customerapp.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.graphics.drawable.DrawableWrapper;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.customs.NotificationBadger;
import com.nextstack.chicken.customerapp.fragment.BulkOrder;
import com.nextstack.chicken.customerapp.fragment.SubCategory;
import com.nextstack.chicken.customerapp.utils.CartOperations;
import com.nextstack.chicken.customerapp.utils.Utilities;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class ShopMenuActivity extends AppCompatActivity  {


    Toolbar toolbar;
    EditText searchBar;
    Button chatButton, bulk_order;

    Geocoder geocoder;
    List<Address> addresses;

    String shopLat, shopLng, shopName;

    int distributor_id;

    String categoriesName, deviceID, deliveryCharge,gstTax, shopStatus;

    MyAppPrefsManager session;

    @Override
    protected void onResume() {
        super.onResume();

        geocoder = new Geocoder(this, Locale.getDefault());
        if (shopLat != null && shopLng != null) {

            try {
                addresses = geocoder.getFromLocation(Double.parseDouble(shopLat), Double.parseDouble(shopLng), 1);
                getSupportActionBar().setSubtitle(addresses.get(0).getAddressLine(0));

                Log.d("Shop Address: ", addresses.get(0).getAddressLine(0));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (ConstantValues.IS_USER_LOGGED_IN)
        {
            chatButton.setClickable(true);
            chatButton.setEnabled(true);
            chatButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
        }
        else
        {
            chatButton.setClickable(false);
            chatButton.setEnabled(false);
            chatButton.setBackgroundColor(getResources().getColor(R.color.colorAccentGrey));
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_menu);


    if (getIntent().getStringExtra("shopLat")!= null && getIntent().getStringExtra("shopLng")!= null) {
        shopLat = getIntent().getStringExtra("shopLat");
        shopLng = getIntent().getStringExtra("shopLng");
    }
        shopName = getIntent().getStringExtra("shopName");
        distributor_id = getIntent().getIntExtra("distributor_id", 0);
        categoriesName = getIntent().getStringExtra("categoriesName");
        deviceID = getIntent().getStringExtra("device_id");
        deliveryCharge = getIntent().getStringExtra("delivery_charge");
        gstTax = getIntent().getStringExtra("gst_tax");
        shopStatus = getIntent().getStringExtra("shop_status");

        toolbar = findViewById(R.id.mytoolbar);
        toolbar.setTitle("Menu");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        searchBar = findViewById(R.id.search_bar);
        chatButton = findViewById(R.id.chat);
        bulk_order = findViewById(R.id.bulk_order);

        searchBar.setVisibility(View.GONE);

        getSupportActionBar().setTitle(shopName);

        geocoder = new Geocoder(this, Locale.getDefault());
        if (shopLat != null && shopLng != null) {

            try {
                addresses = geocoder.getFromLocation(Double.parseDouble(shopLat), Double.parseDouble(shopLng), 1);
                getSupportActionBar().setSubtitle(addresses.get(0).getAddressLine(0));

                Log.d("Shop Address: ", addresses.get(0).getAddressLine(0));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        final Fragment fragment = new SubCategory();
        Bundle bundle = new Bundle();
        bundle.putInt("distributor_id", distributor_id);
        bundle.putString("delivery_charge", deliveryCharge);
        bundle.putString("gst_tax", gstTax);
        bundle.putString("shop_status", shopStatus);
        fragment.setArguments(bundle);
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.menu_fragment, fragment)
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                .commit();


        if (ConstantValues.IS_USER_LOGGED_IN)
        {
            chatButton.setClickable(true);
            chatButton.setEnabled(true);
            chatButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
        }
        else
        {
            chatButton.setClickable(false);
            chatButton.setEnabled(false);
            chatButton.setBackgroundColor(getResources().getColor(R.color.colorAccentGrey));
        }

        session = new MyAppPrefsManager(ShopMenuActivity.this);

        chatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                session.setDistributorName(shopName);
                session.setDeviceId(deviceID);

                Intent i = new Intent(ShopMenuActivity.this, ChatActivity.class);
                startActivity(i);

            }
        });

        bulk_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Fragment fragment = new BulkOrder();
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction()
                        .replace(R.id.menu_fragment, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack("SubCategory")
                        .commit();

            }
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.toolbar_menu, menu);

        MenuItem cartItem = menu.findItem(R.id.toolbar_ic_cart);
        MenuItem profileItem = menu.findItem(R.id.toolbar_ic_profile);

        Utilities.tintMenuIcon(ShopMenuActivity.this, profileItem, R.color.white);

        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ImageView image = (ImageView) inflater.inflate(R.layout.layout_animated_ic_cart, null);

        Drawable itemIcon = cartItem.getIcon().getCurrent();
        image.setImageDrawable(itemIcon);

        cartItem.setActionView(image);

        cartItem.getActionView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(ShopMenuActivity.this, CheckOutActivity.class);
                startActivity(i);

            }
        });

        Utilities.tintMenuIcon(ShopMenuActivity.this, cartItem, R.color.white);

        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        MenuItem cartItem = menu.findItem(R.id.toolbar_ic_cart);

        // Get No. of Cart Items with the static method of My_Cart Fragment
        int cartSize = CartOperations.getCartSize();


        // if Cart has some Items
        if (cartSize > 0) {

            // Animation for cart_menuItem
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake_icon);
            animation.setRepeatMode(Animation.REVERSE);
            animation.setRepeatCount(1);

            cartItem.getActionView().startAnimation(animation);
            cartItem.getActionView().setAnimation(null);


            LayerDrawable icon = null;
            Drawable drawable = cartItem.getIcon();

            if (drawable instanceof DrawableWrapper) {
                drawable = ((DrawableWrapper)drawable).getWrappedDrawable();
            }
            icon =  new LayerDrawable(new Drawable[]{drawable});


            // Set BadgeCount on Cart_Icon with the static method of NotificationBadger class
            NotificationBadger.setBadgeCount(this, icon, String.valueOf(cartSize));

        } else {
            // Set the Icon for Empty Cart
            cartItem.setIcon(R.drawable.ic_cart_empty);
        }

        return super.onPrepareOptionsMenu(menu);
    }

}
