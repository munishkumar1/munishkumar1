package com.nextstack.chicken.customerapp.network;

import com.nextstack.chicken.customerapp.constant.ConstantValues;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MapApi {

    private Retrofit retrofit;

    public Retrofit getRetrofit() {
        retrofit = new Retrofit.Builder()
                .baseUrl(ConstantValues.GOOGLE_MAP_URL)
                .client(getRequestHeader())
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit;
    }

    private OkHttpClient getRequestHeader() {
        return new OkHttpClient.Builder()
                .readTimeout(30, TimeUnit.SECONDS)
                .connectTimeout(30, TimeUnit.SECONDS)
                .build();
    }
}
