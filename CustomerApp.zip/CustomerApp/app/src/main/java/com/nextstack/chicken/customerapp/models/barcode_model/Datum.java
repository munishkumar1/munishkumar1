
package com.nextstack.chicken.customerapp.models.barcode_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datum {

    @SerializedName("barcode_id")
    @Expose
    private Integer barcodeId;
    @SerializedName("products_id")
    @Expose
    private String productsId;
    @SerializedName("barcode")
    @Expose
    private String barcode;
    @SerializedName("quantity")
    @Expose
    private Object quantity;
    @SerializedName("isActive")
    @Expose
    private String isActive;

    public Integer getBarcodeId() {
        return barcodeId;
    }

    public void setBarcodeId(Integer barcodeId) {
        this.barcodeId = barcodeId;
    }

    public String getProductsId() {
        return productsId;
    }

    public void setProductsId(String productsId) {
        this.productsId = productsId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Object getQuantity() {
        return quantity;
    }

    public void setQuantity(Object quantity) {
        this.quantity = quantity;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

}
