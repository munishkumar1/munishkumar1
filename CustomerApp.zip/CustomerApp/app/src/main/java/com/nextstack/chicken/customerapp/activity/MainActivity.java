package com.nextstack.chicken.customerapp.activity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.graphics.drawable.DrawableWrapper;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;
import com.facebook.login.LoginManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.dynamiclinks.DynamicLink;
import com.google.firebase.dynamiclinks.FirebaseDynamicLinks;
import com.google.firebase.dynamiclinks.ShortDynamicLink;
import com.nextstack.chicken.customerapp.BuildConfig;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.adapters.DrawerExpandableListAdapter;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.app.SharedHelper;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.customs.CircularImageView;
import com.nextstack.chicken.customerapp.customs.NotificationBadger;
import com.nextstack.chicken.customerapp.databases.User_Info_DB;
import com.nextstack.chicken.customerapp.fragment.AccountSettings;
import com.nextstack.chicken.customerapp.fragment.Addresses;
import com.nextstack.chicken.customerapp.fragment.BarcodeFragment;
import com.nextstack.chicken.customerapp.fragment.ChatBox;
import com.nextstack.chicken.customerapp.fragment.FaqsFragment;
import com.nextstack.chicken.customerapp.fragment.HomeFragment;
import com.nextstack.chicken.customerapp.fragment.Order_Details;
import com.nextstack.chicken.customerapp.fragment.SearchFragment;
import com.nextstack.chicken.customerapp.fragment.SettingsFragment;
import com.nextstack.chicken.customerapp.fragment.Tab_1;
import com.nextstack.chicken.customerapp.fragment.WalletFragment;
import com.nextstack.chicken.customerapp.location.GPSTracker;
import com.nextstack.chicken.customerapp.models.drawer_model.Drawer_Items;
import com.nextstack.chicken.customerapp.models.user_model.UserDetails;
import com.nextstack.chicken.customerapp.utils.CartOperations;
import com.nextstack.chicken.customerapp.utils.Utilities;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
    ActionBar actionBar;
    EditText searchBar;
    BottomNavigationView bottomNavigationView;

    LinearLayout drawer_header;
    DrawerLayout drawerLayout;
    NavigationView navigationDrawer;
    RelativeLayout bottomSocail;

    SharedPreferences sharedPreferences;
    MyAppPrefsManager myAppPrefsManager;

    ExpandableListView main_drawer_list;
    DrawerExpandableListAdapter drawerExpandableAdapter;

    private static String mSelectedItem;
    private static final String SELECTED_ITEM_ID = "selected";
    public static ActionBarDrawerToggle actionBarDrawerToggle;

    List<Drawer_Items> listDataHeader = new ArrayList<>();
    Map<Drawer_Items, List<Drawer_Items>> listDataChild = new HashMap<>();

    GPSTracker gps;
    Location location;
    Geocoder geocoder;
    List<Address> addresses;
    Context context;

    Task1 task;
    int rating;

    boolean doublePressedBackToExit = false;

    @Override
    protected void onResume() {
        super.onResume();

        searchBar.setVisibility(View.VISIBLE);

        main_drawer_list.smoothScrollToPosition(0);

        setupExpandableDrawerHeader();

        setupExpandableDrawerList();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkRatingBar();

        //getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        myAppPrefsManager = new MyAppPrefsManager(MainActivity.this);
        sharedPreferences = getSharedPreferences("UserInfo", MODE_PRIVATE);
        toolbar = findViewById(R.id.mytoolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationDrawer = findViewById(R.id.main_drawer);

        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        actionBar.setTitle(getString(R.string.home));
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        searchBar = findViewById(R.id.search_bar);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomSocail = findViewById(R.id.bottomSocail);




        geocoder = new Geocoder(this, Locale.getDefault());


        setupExpandableDrawerList();

        setupExpandableDrawerHeader();

        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.drawerOpen, R.string.drawerClose) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                // Hide OptionsMenu
                invalidateOptionsMenu();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                // Recreate the OptionsMenu
                invalidateOptionsMenu();
            }
        };

        drawerLayout.addDrawerListener(actionBarDrawerToggle);

        actionBarDrawerToggle.syncState();

        final View.OnClickListener toggleNavigationClickListener = actionBarDrawerToggle.getToolbarNavigationClickListener();


        getSupportFragmentManager().addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @Override
            public void onBackStackChanged() {

                // Check BackStackEntryCount of FragmentManager
                if (getSupportFragmentManager().getBackStackEntryCount() > 0) {

                    // Set new ToolbarNavigationClickListener
                    actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // Close the Drawer if Opened
                            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                                drawerLayout.closeDrawers();
                            } else {
                                // Pop previous Fragment from BackStack
                                getSupportFragmentManager().popBackStack();
                            }
                        }
                    });


                } else {
                    // Set DrawerToggle Indicator and default ToolbarNavigationClickListener
                    actionBar.setTitle(ConstantValues.APP_HEADER);
                    actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
                    actionBarDrawerToggle.setToolbarNavigationClickListener(toggleNavigationClickListener);
                }
            }
        });

        mSelectedItem = getIntent().getStringExtra("fragment")!= null ? getIntent().getStringExtra("fragment") : getString(R.string.home);

        drawerSelectedItemNavigation(mSelectedItem);

        main_drawer_list.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {

                drawerSelectedItemNavigation(listDataHeader.get(groupPosition).getTitle());
                return true;
            }
        });

        drawer_header.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Check if the User is Authenticated
                if (ConstantValues.IS_USER_LOGGED_IN) {
                  //  rating = SharedHelper.getKey(context,"");

                    // Navigate to Update_Account Fragment
                    Fragment fragment = new AccountSettings();
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.main_fragment, fragment)
                            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                            .addToBackStack(getString(R.string.home)).commit();

                    // Close NavigationDrawer
                    drawerLayout.closeDrawers();

                } else {
                    // Navigate to Login Activity
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                    overridePendingTransition(R.anim.enter_from_left, R.anim.exit_out_left);
                }
            }
        });


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                Fragment fragment;
                FragmentManager fragmentManager = getSupportFragmentManager();
                String mSelectedItem = menuItem.getTitle().toString();

                if (mSelectedItem == getString(R.string.home))
                {
                    Bundle bundle = new Bundle();
                    bundle.putString("category_id", " ");

                    fragment = new HomeFragment();
                    fragment.setArguments(bundle);
                    fragmentManager.beginTransaction()
                            .replace(R.id.main_fragment, fragment)
                            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                            .commit();

                    return true;
                }
                else if (mSelectedItem == getString(R.string.offer))
                {
                    Intent i = new Intent(MainActivity.this, Offers.class);
                    startActivity(i);

                    return true;
                }
                else if (mSelectedItem == getString(R.string.list))
                {

                    return true;
                }
                else
                    return false;
            }
        });


        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                String itemToolbar = String.valueOf(item.getTitle());

                switch (itemToolbar)
                {
                    case "PROFILE" :
                        drawerLayout.closeDrawers();

                        Fragment fragment = new AccountSettings();
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction()
                                .replace(R.id.main_fragment, fragment)
                                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                                .addToBackStack(getString(R.string.home)).commit();

                        searchBar.setVisibility(View.GONE);
                        break;

                    case "MY CART" :
                        drawerLayout.closeDrawers();

                        Intent i = new Intent(MainActivity.this, CheckOutActivity.class);
                        startActivity(i);
                        MainActivity.this.finish();
                        MainActivity.this.overridePendingTransition(R.anim.enter_from_left, R.anim.exit_out_left);

                        searchBar.setVisibility(View.GONE);
                        break;
                }


                return false;
            }
        });

        gps = new GPSTracker(MainActivity.this);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                task = new Task1();
                task.execute();
            }
        },  1000);

        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                Bundle searchInfo = new Bundle();
                searchInfo.putString("searchText",searchBar.getText().toString());

                Fragment fragment = new SearchFragment();
                fragment.setArguments(searchInfo);
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction()
                        .replace(R.id.main_fragment, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack(getString(R.string.home)).commit();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        bottomSocail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {

                    /*DynamicLink dynamicLink = FirebaseDynamicLinks.getInstance().createDynamicLink()
                            .setLink(Uri.parse("https://www.example.com/"))
                            .setDomainUriPrefix("https://bouto.page.link")
                            // Open links with this app on Android
                            .setAndroidParameters(new DynamicLink.AndroidParameters.Builder().build())
                            .buildDynamicLink();

                    Uri dynamicLinkUri = dynamicLink.getUri();*/

                    //Log.e("firebase", "dynamicLink"  + dynamicLinkUri.toString());

                    String link = "https://play.google.com/store/apps/details?id="+MainActivity.this.getPackageName();
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Bouto");
                    String shareMessage= "\nLet me recommend you this application\n\n" + link + "\nUse Refferal Code" +myAppPrefsManager.getRefCode();
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));



                    /*Task<ShortDynamicLink> shortLinkTask = FirebaseDynamicLinks.getInstance().createDynamicLink()
                            .setLongLink(Uri.parse(link))
                            .buildShortDynamicLink()
                            .addOnCompleteListener(MainActivity.this, new OnCompleteListener<ShortDynamicLink>() {
                                @Override
                                public void onComplete(@NonNull com.google.android.gms.tasks.Task<ShortDynamicLink> task) {
                                    if (task.isSuccessful()) {
                                        // Short link created
                                        Uri shortLink = task.getResult().getShortLink();
                                        Uri flowchartLink = task.getResult().getPreviewLink();

                                        Log.e("firebase", "shortLink"  + shortLink);


                                    } else {
                                        // Error
                                        // ...
                                        Log.e("firebase", "error");
                                    }
                                }
                            });
*/

                } catch(Exception e) {
                    Log.e("Error Sharing App :", e.toString());
                }
            }
        });
    }

    private void checkRatingBar() {

    }


    public void setupExpandableDrawerList() {
        listDataHeader = new ArrayList<>();
        listDataChild = new HashMap<>();

        listDataHeader.add(new Drawer_Items(R.drawable.ic_home, getString(R.string.home)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_categories, getString(R.string.app_dashboard)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_settings, getString(R.string.actionAccountSettings)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_vendors, getString(R.string.actionMovingVendors)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_order, getString(R.string.actionOrders)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_location, getString(R.string.actionAddresses)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_wallet, getString(R.string.actionWallet)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_intro, getString(R.string.actionIntro)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_preferrences, getString(R.string.actionPreferrence)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_faq, getString(R.string.actionFaq)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_star, getString(R.string.actionRateApp)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_logout, getString(R.string.actionLogout)));
        listDataHeader.add(new Drawer_Items(R.drawable.ic_cart,"Barcode"));


        drawerExpandableAdapter = new DrawerExpandableListAdapter(this, listDataHeader, listDataChild);

        main_drawer_list = findViewById(R.id.main_drawer_list);
        main_drawer_list.setAdapter(drawerExpandableAdapter);

        main_drawer_list.smoothScrollToPosition(0);

        drawerExpandableAdapter.notifyDataSetChanged();
    }

    public void setupExpandableDrawerHeader() {
        drawer_header = findViewById(R.id.drawer_header);
        CircularImageView drawer_profile_image = findViewById(R.id.drawer_profile_image);
        TextView drawer_profile_name = findViewById(R.id.drawer_profile_name);
        TextView drawer_profile_email = findViewById(R.id.drawer_profile_email);

        if (ConstantValues.IS_USER_LOGGED_IN) {
            // Check User's Info from SharedPreferences
            if (sharedPreferences.getString("userEmail", null) != null) {


                // Get User's Info from Local Database User_Info_DB
                User_Info_DB userInfoDB = new User_Info_DB();
                UserDetails userInfo = userInfoDB.getUserData(sharedPreferences.getString("userID", null));

                // Set User's Name, Email and Photo
                drawer_profile_email.setText(userInfo.getCustomersEmailAddress());
                drawer_profile_name.setText(userInfo.getCustomersFirstname() + " " + userInfo.getCustomersLastname());
                Glide.with(this)
                        .load( userInfo.getCustomersPicture()).asBitmap()
                        .placeholder(R.drawable.profile)
                        .error(R.drawable.profile)
                        .into(drawer_profile_image);

            } else {
                // Set Default Name, Email and Photo
                drawer_profile_image.setImageResource(R.drawable.profile);
                drawer_profile_name.setText(getString(R.string.login_or_signup));
                drawer_profile_email.setText(getString(R.string.login_or_create_account));
            }

        } else {
            // Set Default Name, Email and Photo
            drawer_profile_image.setImageResource(R.drawable.profile);
            drawer_profile_name.setText(getString(R.string.login_or_signup));
            drawer_profile_email.setText(getString(R.string.login_or_create_account));
        }


        // Handle DrawerHeader Click Listener
        drawer_header.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Check if the User is Authenticated
                if (ConstantValues.IS_USER_LOGGED_IN) {

                    // Navigate to Update_Account Fragment
                    Fragment fragment = new AccountSettings();
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.main_fragment, fragment)
                            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                            .addToBackStack(getString(R.string.home)).commit();

                    searchBar.setVisibility(View.GONE);

                    // Close NavigationDrawer
                    drawerLayout.closeDrawers();

                } else {
                    // Navigate to Login Activity
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                    overridePendingTransition(R.anim.enter_from_left, R.anim.exit_out_left);
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.toolbar_menu, menu);

        MenuItem cartItem = menu.findItem(R.id.toolbar_ic_cart);
        MenuItem profileItem = menu.findItem(R.id.toolbar_ic_profile);

        Utilities.tintMenuIcon(MainActivity.this, profileItem, R.color.white);

        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ImageView image = (ImageView) inflater.inflate(R.layout.layout_animated_ic_cart, null);

        Drawable itemIcon = cartItem.getIcon().getCurrent();
        image.setImageDrawable(itemIcon);

        cartItem.setActionView(image);

        cartItem.getActionView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this, CheckOutActivity.class);
                startActivity(i);

            }
        });

        Utilities.tintMenuIcon(MainActivity.this, cartItem, R.color.white);

        return true;
    }

    private void drawerSelectedItemNavigation(String selectedItem) {


        MyAppPrefsManager session = new MyAppPrefsManager(MainActivity.this);

        Fragment fragment;
        FragmentManager fragmentManager = getSupportFragmentManager();
        Bundle bundle = new Bundle();

        if (selectedItem.equalsIgnoreCase(getString(R.string.home))) {
            mSelectedItem = selectedItem;

            bundle.clear();
            bundle.putString("category_id", " ");
            fragment = new HomeFragment();
            fragment.setArguments(bundle);
            fragmentManager.beginTransaction()
                    .replace(R.id.main_fragment, fragment)
                    .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                    .commit();
                toolbar.setTitle(selectedItem);

            drawerLayout.closeDrawers();

        }  else if(selectedItem.equalsIgnoreCase("Barcode")) {
            mSelectedItem = selectedItem;
            //barcode fragment
            fragment = new BarcodeFragment();
            fragmentManager.beginTransaction()
                    .replace(R.id.main_fragment, fragment)
                    .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                    .addToBackStack("Dashboard")
                    .commit();

            drawerLayout.closeDrawers();

        }else if (selectedItem.equalsIgnoreCase(getString(R.string.actionIntro))) {
            mSelectedItem = selectedItem;

            // Navigate to IntroScreen
            startActivity(new Intent(getBaseContext(), IntroScreen.class));

        }else if (selectedItem.equalsIgnoreCase(getString(R.string.actionPreferrence))) {
            mSelectedItem = selectedItem;

            /*fragment = new SettingsFragment();
            fragmentManager.beginTransaction()
                    .replace(R.id.main_fragment, fragment)
                    .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                    .addToBackStack(getString(R.string.home)).commit();

            searchBar.setVisibility(View.GONE);
            toolbar.setTitle(selectedItem);*/
            drawerLayout.closeDrawers();

        }
        else if (selectedItem.equalsIgnoreCase(getString(R.string.actionRateApp))) {
            mSelectedItem = selectedItem;

            // Rate App with the help of static method of Utilities class
            rateApp();

            drawerLayout.closeDrawers();

        }
        else if (selectedItem.equalsIgnoreCase(getString(R.string.app_dashboard))) {
            mSelectedItem = selectedItem;

            // Navigate to IntroScreen
            startActivity(new Intent(getBaseContext(), HomeActivity.class));

        }else if (ConstantValues.IS_USER_LOGGED_IN) {
            if (selectedItem.equalsIgnoreCase(getString(R.string.actionAccountSettings))) {
                mSelectedItem = selectedItem;

                // Navigate to SettingsFragment Fragment
                fragment = new AccountSettings();
                fragmentManager.beginTransaction()
                        .replace(R.id.main_fragment, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack(getString(R.string.home)).commit();

                searchBar.setVisibility(View.GONE);
                toolbar.setTitle(selectedItem);

                drawerLayout.closeDrawers();
            }else if (selectedItem.equalsIgnoreCase(getString(R.string.actionWallet))) {
                mSelectedItem = selectedItem;

                // Navigate to SettingsFragment Fragment
                fragment = new WalletFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.main_fragment, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack(getString(R.string.home)).commit();

                drawerLayout.closeDrawers();
                toolbar.setTitle(selectedItem);

            } else if (selectedItem.equalsIgnoreCase("Tab_1")) {
                mSelectedItem = getIntent().getStringExtra("category_name") ;

                // Navigate to SettingsFragment Fragment
                fragment = new Tab_1();
                Bundle menuData = new Bundle();
                menuData.putString("category_name", getIntent().getStringExtra("category_name"));
                menuData.putInt("distributor_id", getIntent().getIntExtra("distributor_id", 0));
                fragment.setArguments(menuData);
                fragmentManager.beginTransaction()
                        .replace(R.id.main_fragment, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack(getString(R.string.home)).commit();

                drawerLayout.closeDrawers();
                toolbar.setTitle(selectedItem);

            } else if (selectedItem.equalsIgnoreCase(getString(R.string.actionFaq))) {
                mSelectedItem = selectedItem;

                // Navigate to SettingsFragment Fragment
                fragment = new FaqsFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.main_fragment, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack(getString(R.string.home)).commit();

                drawerLayout.closeDrawers();
                toolbar.setTitle(selectedItem);

            }
            else if (selectedItem.equalsIgnoreCase(getString(R.string.actionOrders))) {

                Intent i = new Intent(MainActivity.this, My_Orders.class);
                i.putExtra("ratedata", SharedHelper.getKey(getBaseContext(),"rating"));
                startActivity(i);
                searchBar.setVisibility(View.GONE);

                drawerLayout.closeDrawers();
                toolbar.setTitle(selectedItem);

            }
            else if (selectedItem.equalsIgnoreCase("ViewOrders")) {
            // Get Order Info
                Bundle itemInfo = new Bundle();
                itemInfo.putString("order_id", getIntent().getStringExtra("order_id"));
                itemInfo.putString("order_status", getIntent().getStringExtra("order_status"));
                itemInfo.putString("order_price", getIntent().getStringExtra("order_price"));

                // Navigate to Order_Details Fragment
                fragment = new Order_Details();
                fragment.setArguments(itemInfo);
                MainActivity.actionBarDrawerToggle.setDrawerIndicatorEnabled(false);
                fragmentManager.beginTransaction()
                        .replace(R.id.main_fragment, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack(getString(R.string.actionOrders)).commit();
                searchBar.setVisibility(View.GONE);

                drawerLayout.closeDrawers();
                toolbar.setTitle(selectedItem);

            }
            else if (selectedItem.equalsIgnoreCase(getString(R.string.actionAddresses))) {
                mSelectedItem = selectedItem;

                // Navigate to SettingsFragment Fragment
                fragment = new Addresses();
                fragmentManager.beginTransaction()
                        .replace(R.id.main_fragment, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                        .addToBackStack(getString(R.string.home)).commit();

                drawerLayout.closeDrawers();
                toolbar.setTitle(selectedItem);
                searchBar.setVisibility(View.GONE);
                bottomNavigationView.setVisibility(View.GONE);

            }

            else if (selectedItem.equalsIgnoreCase(getString(R.string.actionLogout))) {
                if (ConstantValues.IS_USER_LOGGED_IN) {
                    mSelectedItem = selectedItem;

                    if (LoginManager.getInstance()!= null)
                    {
                        LoginManager.getInstance().logOut();
                    }

                    // Edit UserID in SharedPreferences
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("userID", "");
                    editor.apply();

                    // Set UserLoggedIn in MyAppPrefsManager
                    MyAppPrefsManager myAppPrefsManager = new MyAppPrefsManager(this);
                    myAppPrefsManager.setUserLoggedIn(false);

                    // Set isLogged_in of ConstantValues
                    ConstantValues.IS_USER_LOGGED_IN = myAppPrefsManager.isUserLoggedIn();


                    // Navigate to Login Activity
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                    overridePendingTransition(R.anim.enter_from_right, R.anim.exit_out_right);
                } else {
                    Toast.makeText(this, "You need to login to logout!", Toast.LENGTH_LONG).show();
                    drawerLayout.closeDrawers();
                }

                toolbar.setTitle(selectedItem);
            } else if (selectedItem.equalsIgnoreCase(getString(R.string.actionMovingVendors))) {
                mSelectedItem = selectedItem;



                        // Navigate to SettingsFragment Fragment
                Intent i = new Intent(MainActivity.this, MovingVendorsActivity.class);
                startActivity(i);

                drawerLayout.closeDrawers();
                toolbar.setTitle(selectedItem);

            }else if (selectedItem.equalsIgnoreCase("ChatSupport")) {
                mSelectedItem = selectedItem;

                bundle.clear();
                bundle.putString("title", "Chat Support");

                fragment = new ChatBox();
                fragment.setArguments(bundle);
                fragmentManager.beginTransaction()
                        .replace(R.id.main_fragment, fragment)
                        .commit();
                overridePendingTransition(R.anim.enter_from_right, R.anim.exit_out_right);

                drawerLayout.closeDrawers();
                toolbar.setTitle(selectedItem);
                searchBar.setVisibility(View.GONE);
                bottomNavigationView.setVisibility(View.GONE);

            }else if (selectedItem.equalsIgnoreCase("retailer") && session.getDeviceId() == null) {
                mSelectedItem = selectedItem;


                    bundle.clear();
                    bundle.putString("title", session.getDistributorName());
                    bundle.putString("userid", session.getDeviceId());
                    fragment = new ChatBox();
                    fragment.setArguments(bundle);
                    fragmentManager.beginTransaction()
                            .replace(R.id.main_fragment, fragment)
                            .commit();
                    overridePendingTransition(R.anim.enter_from_right, R.anim.exit_out_right);

                    drawerLayout.closeDrawers();
                    searchBar.setVisibility(View.GONE);
                    bottomNavigationView.setVisibility(View.GONE);
            }

        }else {
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
            finish();
            overridePendingTransition(R.anim.enter_from_left, R.anim.exit_out_left);

            toolbar.setTitle(selectedItem);
        }
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // Save the Selected NavigationDrawer Item
        outState.putString(SELECTED_ITEM_ID, mSelectedItem);
    }


    public void rateApp()
    {
        try
        {
            Intent rateIntent = rateIntentForUrl("market://details");
            startActivity(rateIntent);
        }
        catch (ActivityNotFoundException e)
        {
            Intent rateIntent = rateIntentForUrl("https://play.google.com/store/apps/details");
            startActivity(rateIntent);
        }
    }

    private Intent rateIntentForUrl(String url)
    {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format("%s?id=%s", url, getPackageName())));
        int flags = Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_MULTIPLE_TASK;
        if (Build.VERSION.SDK_INT >= 21)
        {
            flags |= Intent.FLAG_ACTIVITY_NEW_DOCUMENT;
        }
        else
        {
            //noinspection deprecation
            flags |= Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET;
        }
        intent.addFlags(flags);
        return intent;
    }


    private class Task1 extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {

            // Check for Internet Connection from the static method of Helper class
            if (Utilities.isNetworkAvailable(MainActivity.this)) {

                if(gps.canGetLocation()){
                    location = gps.getLocation();
                    try {
                        addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(),1);

                        Log.d("Address: ", addresses.get(0).getAddressLine(0));
                    }catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                }
                else{
                    Toast.makeText(MainActivity.this, "Can not get Location", Toast.LENGTH_LONG).show();
                }


                return "1";
            } else {
                return "0";
            }
        }
    }


    @Override
    public void onBackPressed() {

        // Get FragmentManager
        FragmentManager fm = getSupportFragmentManager();


        // Check if NavigationDrawer is Opened
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawers();

        }
        // Check if BackStack has some Fragments
        else  if (fm.getBackStackEntryCount() > 0) {

            // Pop previous Fragment
            fm.popBackStackImmediate();

        }
        else {
            super.onBackPressed();
        }
       /* // Check if doubleBackToExitPressed is true
        else if (doublePressedBackToExit) {


        }
        else {
            this.doublePressedBackToExit = true;
            Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show();

            // Delay of 2 seconds
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    // Set doublePressedBackToExit false after 2 seconds
                    doublePressedBackToExit = false;
                }
            }, 2000);
        }*/
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        MenuItem cartItem = menu.findItem(R.id.toolbar_ic_cart);

        // Get No. of Cart Items with the static method of My_Cart Fragment
        int cartSize = CartOperations.getCartSize();


        // if Cart has some Items
        if (cartSize > 0) {

            // Animation for cart_menuItem
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake_icon);
            animation.setRepeatMode(Animation.REVERSE);
            animation.setRepeatCount(1);

            cartItem.getActionView().startAnimation(animation);
            cartItem.getActionView().setAnimation(null);


            LayerDrawable icon = null;
            Drawable drawable = cartItem.getIcon();

            if (drawable instanceof DrawableWrapper) {
                drawable = ((DrawableWrapper)drawable).getWrappedDrawable();
            }
            icon = new LayerDrawable(new Drawable[]{drawable});


            // Set BadgeCount on Cart_Icon with the static method of NotificationBadger class
            NotificationBadger.setBadgeCount(this, icon, String.valueOf(cartSize));

        } else {
            // Set the Icon for Empty Cart
            cartItem.setIcon(R.drawable.ic_cart_empty);
        }

        return super.onPrepareOptionsMenu(menu);
    }
}