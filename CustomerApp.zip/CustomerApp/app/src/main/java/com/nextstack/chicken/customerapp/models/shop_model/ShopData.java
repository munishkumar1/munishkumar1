package com.nextstack.chicken.customerapp.models.shop_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ShopData {

    @SerializedName("Success")
    @Expose
    private int success;
    @SerializedName("data")
    @Expose
    private Data data = null;
    @SerializedName("Message")
    @Expose
    private String message;



    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public class Data
    {
        @SerializedName("movable")
        @Expose
        List <ShopDetails> movable = new ArrayList <ShopDetails> ();
        @SerializedName("fix")
        @Expose
        List<ShopDetails> fix = new ArrayList<ShopDetails>();


        public List<ShopDetails> getMovable() {
            return movable;
        }

        public void setMovable(List<ShopDetails> movable) {
            this.movable = movable;
        }

        public List<ShopDetails> getFix() {
            return fix;
        }

        public void setFix(List<ShopDetails> fix) {
            this.fix = fix;
        }
    }
}
