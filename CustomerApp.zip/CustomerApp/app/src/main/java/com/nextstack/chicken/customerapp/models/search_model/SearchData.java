package com.nextstack.chicken.customerapp.models.search_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.nextstack.chicken.customerapp.models.product_model.ProductDetails;

import java.util.List;

public class SearchData {

    @SerializedName("Success")
    @Expose
    private int success;
    @SerializedName("data")
    @Expose
    private List<ProductDetails> productData;
    @SerializedName("Message")
    @Expose
    private String message;

    /**
     * 
     * @return
     *     The success
     */
    public int getSuccess() {
        return success;
    }

    /**
     * 
     * @param success
     *     The success
     */
    public void setSuccess(int success) {
        this.success = success;
    }

    public List<ProductDetails> getProductData() {
        return productData;
    }

    public void setProductData(List<ProductDetails> productData) {
        this.productData = productData;
    }

    /**
     * 
     * @return
     *     The message
     */
    public String getMessage() {
        return message;
    }

    /**
     * 
     * @param message
     *     The message
     */
    public void setMessage(String message) {
        this.message = message;
    }

}
