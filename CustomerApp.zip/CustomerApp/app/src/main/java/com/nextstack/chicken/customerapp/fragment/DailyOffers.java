package com.nextstack.chicken.customerapp.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.adapters.DailyOffersAdapter;

public class DailyOffers extends Fragment {

    View rootView;

    RecyclerView daily_offer_recycler;
    DailyOffersAdapter dailyOffersAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_daily_offers, container, false);

        daily_offer_recycler = rootView.findViewById(R.id.daily_offer_recycler);

        dailyOffersAdapter = new DailyOffersAdapter();

        daily_offer_recycler.setLayoutManager( new GridLayoutManager(getContext(), 2));
        daily_offer_recycler.setItemAnimator(new DefaultItemAnimator());
        daily_offer_recycler.setAdapter(dailyOffersAdapter);

        return rootView;
    }
}
