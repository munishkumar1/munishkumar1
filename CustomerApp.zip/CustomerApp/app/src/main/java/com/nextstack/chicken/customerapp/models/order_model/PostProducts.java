package com.nextstack.chicken.customerapp.models.order_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class PostProducts {

    @SerializedName("products_id")
    @Expose
    private int products_id;
    @SerializedName("products_name")
    @Expose
    private String products_name;
    @SerializedName("products_quantity")
    @Expose
    private String products_quantity;
    @SerializedName("products_price")
    @Expose
    private String products_price;
    @SerializedName("final_price")
    @Expose
    private String final_price;


    public int getProducts_id() {
        return products_id;
    }

    public void setProducts_id(int products_id) {
        this.products_id = products_id;
    }

    public String getProducts_name() {
        return products_name;
    }

    public void setProducts_name(String products_name) {
        this.products_name = products_name;
    }

    public String getProducts_quantity() {
        return products_quantity;
    }

    public void setProducts_quantity(String products_quantity) {
        this.products_quantity = products_quantity;
    }

    public String getProducts_price() {
        return products_price;
    }

    public void setProducts_price(String products_price) {
        this.products_price = products_price;
    }

    public String getFinal_price() {
        return final_price;
    }

    public void setFinal_price(String final_price) {
        this.final_price = final_price;
    }
}
