package com.nextstack.chicken.customerapp.network;


import com.nextstack.chicken.customerapp.constant.ConstantValues;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * APIClient handles all the Network API Requests using Retrofit Library
 **/

public class APIClient {
    
    
    // Base URL for API Requests
    private static final String BASE_URL = ConstantValues.NEW_URL_2;
    private static final String NEW_URL = ConstantValues.NEW_URL;
    private static final String FIREBASE_URL = ConstantValues.FIREBASE_URL;
    private static final String PAYTM_URL = ConstantValues.PAYTM_URL;

    private static APIRequestsNet apiRequestsNet;
    private static APIPaytm apiRequestsPaytm;

    private static FirebaseAPI firebaseAPI;

    public static APIPaytm getPaytmInstance() {
        if (apiRequestsPaytm == null) {

            OkHttpClient okHttpClient = new OkHttpClient().newBuilder()
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS)
                    .build();


            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(PAYTM_URL)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();


            apiRequestsPaytm = retrofit.create(APIPaytm.class);

            return apiRequestsPaytm;
        }
        else {
            return apiRequestsPaytm;
        }
    }

    public static APIRequestsNet getNetInstance(boolean isSms) {
        if (apiRequestsNet == null) {

            OkHttpClient okHttpClient = new OkHttpClient().newBuilder()
                    .connectTimeout(100, TimeUnit.SECONDS)
                    .readTimeout(100, TimeUnit.SECONDS)
                    .writeTimeout(100, TimeUnit.SECONDS)
                    .build();
            if (isSms) {

                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl(BASE_URL)
                        .client(okHttpClient)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();


                apiRequestsNet = retrofit.create(APIRequestsNet.class);
            }else {
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl(NEW_URL)
                        .client(okHttpClient)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();


                apiRequestsNet = retrofit.create(APIRequestsNet.class);
            }

            return apiRequestsNet;
        }
        else {
            return apiRequestsNet;
        }
    }


    public  static FirebaseAPI getFirebaseInstance() {

        if (firebaseAPI == null) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.level(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
            httpClient.addInterceptor(new Interceptor() {
                @Override
                public okhttp3.Response intercept(Chain chain) throws IOException {
                    Request original = chain.request();

                    // Request customization: add request headers
                    Request.Builder requestBuilder = original.newBuilder()
                            .header("Authorization", "key=AIzaSyAs8XvN8uNuXjVUYLdoSE3rhF-oRIFtnyE"); // <-- this is the important line
                    Request request = requestBuilder.build();
                    return chain.proceed(request);
                }
            });

            httpClient.addInterceptor(logging);
            OkHttpClient client = httpClient.build();

            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(FIREBASE_URL)//url of FCM message server
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())//use for convert JSON file into object
                    .build();

            firebaseAPI = retrofit.create(FirebaseAPI.class);

            return firebaseAPI;
        }

        else
            return firebaseAPI;
    }

}


