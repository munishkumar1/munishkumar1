package com.nextstack.chicken.customerapp.models.wallet_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class WalletData {

    @SerializedName("Success")
    @Expose
    private int success;
    @SerializedName("data")
    @Expose
    private ViewWallet data = null;
    @SerializedName("Message")
    @Expose
    private String message;

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public ViewWallet getData() {
        return data;
    }

    public void setData(ViewWallet data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
