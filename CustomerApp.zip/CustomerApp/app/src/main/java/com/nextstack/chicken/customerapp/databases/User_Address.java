package com.nextstack.chicken.customerapp.databases;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.nextstack.chicken.customerapp.models.address_model.AddressDetails;

import java.util.ArrayList;
import java.util.List;

public class User_Address {

    SQLiteDatabase db;

    // Table Name
    public static final String TABLE_ADDRESS_INFO = "User_Address_Record";
    // Table Columns
    public static final String STREET                      = "street";
    public static final String POSTCODE                    = "postcode";
    public static final String CITY                        = "city";
    public static final String STATE                       = "state";
    public static final String LAT                         = "lat";
    public static final String LNG                         = "lng";
    public static final String NICKNAME                    = "nickname";


    public static String createTableAddresses() {

        return "CREATE TABLE "+ TABLE_ADDRESS_INFO +
                "(" +
                STREET               +" TEXT," +
                POSTCODE             +" TEXT," +
                CITY                 +" INTEGER, " +
                STATE                +" TEXT," +
                LAT                  +" TEXT," +
                LNG                  +" TEXT," +
                NICKNAME             +" TEXT" +
                ")";
    }

    public void insertAddressData(AddressDetails address){
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        ContentValues values = new ContentValues();

        values.put(STREET,              address.getStreet());
        values.put(POSTCODE,            address.getPostcode());
        values.put(CITY,                address.getCity());
        values.put(STATE,               address.getState());
        values.put(LAT,                 address.getLat());
        values.put(LNG,                 address.getLng());
        values.put(NICKNAME,            address.getNickname());

        db.insert(TABLE_ADDRESS_INFO, null, values);

        // close the Database
        DB_Manager.getInstance().closeDatabase();
    }

    public List<AddressDetails> getAddressData(){
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        Cursor cursor =  db.rawQuery( "SELECT * FROM "+ TABLE_ADDRESS_INFO , null);

        List<AddressDetails> addresses = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {

                AddressDetails address = new AddressDetails();
                address.setStreet(cursor.getString(0));
                address.setPostcode(cursor.getString(1));
                address.setCity(cursor.getString(2));
                address.setState(cursor.getString(3));
                address.setLat(cursor.getString(4));
                address.setLng(cursor.getString(5));
                address.setNickname(cursor.getString(6));
                addresses.add(address);

            } while (cursor.moveToNext());


            // close the Database
            DB_Manager.getInstance().closeDatabase();

            return addresses;
        }

        return null;
    }

    public void clearAddresses() {
        // get and open SQLiteDatabase Instance from static method of DB_Manager class
        db = DB_Manager.getInstance().openDatabase();

        db.delete(TABLE_ADDRESS_INFO, null, null);

        // close the Database
        DB_Manager.getInstance().closeDatabase();
    }


}
