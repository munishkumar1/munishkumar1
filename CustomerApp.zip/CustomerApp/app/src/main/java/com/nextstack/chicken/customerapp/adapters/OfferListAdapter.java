package com.nextstack.chicken.customerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.models.coupons_model.CouponsInfo;

import java.util.List;

public class OfferListAdapter extends RecyclerView.Adapter<OfferListAdapter.MyViewHolder> {
    Context context;
    String customerID;
    List<CouponsInfo> couponsList;

    public OfferListAdapter(Context context, List<CouponsInfo> couponsList) {
        this.context = context;
        this.couponsList = couponsList;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_offer_card, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        final CouponsInfo coupon = couponsList.get(position);

            holder.offer_description.setText(String.valueOf(coupon.getDescription()));
            holder.coupon_code.setText(coupon.getCode());
            holder.minimumOrder.setText(coupon.getMinimumAmount());

    }

    @Override
    public int getItemCount() {
        return couponsList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        private TextView offer_description, coupon_code, minimumOrder;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            offer_description = itemView.findViewById(R.id.offer_description);
            coupon_code = itemView.findViewById(R.id.coupon_code);
            minimumOrder = itemView.findViewById(R.id.minimumOrder);
        }
    }
}
