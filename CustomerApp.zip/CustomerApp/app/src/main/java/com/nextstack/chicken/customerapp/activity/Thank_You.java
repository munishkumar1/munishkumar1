package com.nextstack.chicken.customerapp.activity;


import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;

import com.nextstack.chicken.customerapp.R;


public class Thank_You extends AppCompatActivity {


    Toolbar toolbar;
    ActionBar actionBar;
    EditText searchBar;

    FrameLayout banner_adView;
    Button order_status_btn, continue_shopping_btn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thank_you);


        toolbar = findViewById(R.id.mytoolbar);
        searchBar = findViewById(R.id.search_bar);

        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        getSupportActionBar().setTitle(getString(R.string.order_confirmed));
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        searchBar.setVisibility(View.GONE);


        // Binding Layout Views
        order_status_btn = findViewById(R.id.order_status_btn);
        continue_shopping_btn = findViewById(R.id.continue_shopping_btn);

        // Binding Layout Views
        order_status_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(Thank_You.this, My_Orders.class);
                startActivity(i);

            }
        });


        // Binding Layout Views
        continue_shopping_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to HomePage Fragment
                Intent i = new Intent(Thank_You.this, MainActivity.class);
                i.putExtra("fragment", getString(R.string.home));
                startActivity(i);
                Thank_You.this.finish();
                Thank_You.this.overridePendingTransition(R.anim.enter_from_left, R.anim.exit_out_left);
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        
        if (item.getItemId() == android.R.id.home) {
            getFragmentManager().popBackStack(getString(R.string.home), FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(Thank_You.this, CheckOutActivity.class);
        Thank_You.this.finish();
        startActivity(i);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
    
}

