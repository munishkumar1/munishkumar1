package com.nextstack.chicken.customerapp.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.MainActivity;
import com.nextstack.chicken.customerapp.adapters.FaqListAdapter;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.models.faq_model.FaqData;
import com.nextstack.chicken.customerapp.models.faq_model.FaqDetails;

import java.util.ArrayList;
import java.util.List;

public class FaqsFragment extends Fragment {

    View rootView;
    RecyclerView faq_recycler;

    DialogLoader dialogLoader;
    FaqListAdapter faqListAdapter;

    List<FaqDetails> faqList = new ArrayList<>();

    public FaqsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_faqs, container, false);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setSubtitle("");

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        MainActivity.actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(getString(R.string.actionFaq));

        faq_recycler = rootView.findViewById(R.id.faq_recycler);

        dialogLoader = new DialogLoader(getContext());
        addFaqs();

        //RequestFaqs();

        return rootView;
    }

    private void addFaqs()
    {
        faqListAdapter = new FaqListAdapter(getContext());
        faq_recycler.setAdapter(faqListAdapter);
        faq_recycler.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));

        faqListAdapter.notifyDataSetChanged();
    }

    private void addFaqs(FaqData faqData) {

        // Add Orders to ordersList from the List of OrderData
        faqList = faqData.getData();


        // Initialize the OrdersListAdapter for RecyclerView
        faqListAdapter = new FaqListAdapter(getContext(), faqList);

        // Set the Adapter and LayoutManager to the RecyclerView
        faq_recycler.setAdapter(faqListAdapter);
        faq_recycler.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));


        faqListAdapter.notifyDataSetChanged();
    }
    /*public void RequestFaqs() {

        dialogLoader.showProgressDialog();

        Call<FaqData> call = APIClient.getInstance()
                .getFaqs();

        call.enqueue(new Callback<FaqData>() {
            @Override
            public void onResponse(Call<FaqData> call, retrofit2.Response<FaqData> response) {

                dialogLoader.hideProgressDialog();

                // Check if the Response is successful
                if (response.isSuccessful()) {
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {

                        // Orders have been returned. Add Orders to the ordersList
                        //addOrders(response.body());

                    }
                    else if (response.body().getSuccess().equalsIgnoreCase("0")) {
                        Snackbar.make(rootView, response.body().getMessage(), Snackbar.LENGTH_LONG).show();

                    }
                    else {
                        // Unable to get Success status
                        Snackbar.make(rootView, getString(R.string.unexpected_response), Snackbar.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<FaqData> call, Throwable t) {
                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });
    }*/
}
