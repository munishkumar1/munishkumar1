package com.nextstack.chicken.customerapp.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.databases.User_Address;
import com.nextstack.chicken.customerapp.fragment.Add_Address;
import com.nextstack.chicken.customerapp.location.GPSTracker;
import com.nextstack.chicken.customerapp.models.address_model.AddressDetails;
import com.nextstack.chicken.customerapp.utils.Utilities;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class DeliveryAddress extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener, GoogleMap.OnMarkerDragListener {

    SupportMapFragment mapFragment;
    GoogleMap mMap;

    GPSTracker gps;
    Location location;

    Geocoder geocoder;
    List<Address> addresses;

    EditText address, add_nickname, houseno, landmark;
    Button add_address, add_details, home, work, others, cancel, btn_skip, save_address;

    LinearLayout details, choose_btn, address_nickname, add_nickname_layout;

    String street, postcode, city, state, lat, lng, nickname,Landmark, house_no, addressID, activity;

    User_Address dbUserAddress = new User_Address();
    AddressDetails addressDetails = new AddressDetails();

    List<AddressDetails> addressDetailsList = new ArrayList<>();

    private int PLACE_AUTOCOMPLETE_REQUEST_CODE = 1;
    private boolean isUpdate = false;
    List<Place.Field> fields = Arrays.asList
            (
                    Place.Field.ID,
                    Place.Field.NAME,
                    Place.Field.LAT_LNG,
                    Place.Field.ADDRESS,
                    Place.Field.ADDRESS_COMPONENTS
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_address);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        Places.initialize(getApplicationContext(), getString(R.string.google_maps_key));

        address = findViewById(R.id.address);
        add_address = findViewById(R.id.add_address);
        add_details = findViewById(R.id.add_details);
        choose_btn = findViewById(R.id.choose_btn);
        details = findViewById(R.id.details);
        home = findViewById(R.id.home);
        work = findViewById(R.id.work);
        others = findViewById(R.id.others);
        address_nickname = findViewById(R.id.address_nickname);
        add_nickname_layout = findViewById(R.id.add_nickname_layout);
        add_nickname = findViewById(R.id.add_nickname);
        btn_skip = findViewById(R.id.btn_skip);
        cancel = findViewById(R.id.cancel);
        save_address = findViewById(R.id.save_address);
        houseno = findViewById(R.id.house_no);
        landmark = findViewById(R.id.landmark);

        if (getIntent().hasExtra("addressInfo"))
        {
            Bundle addressInfo = getIntent().getBundleExtra("addressInfo");
            isUpdate = addressInfo.getBoolean("isUpdate");
            addressID = addressInfo.getString("addressID");
            city = addressInfo.getString("addressCity");
            street = addressInfo.getString("addressStreet");
            postcode = addressInfo.getString("addressPostCode");
            state = addressInfo.getString("addressState");
            lat = addressInfo.getString("addressLat");
            lng = addressInfo.getString("addressLng");
            nickname = addressInfo.getString("nickname");
            house_no = addressInfo.getString("houseno");
            Landmark = addressInfo.getString("landmark");
        }


        if (getIntent().hasExtra("activity"))
        {
            activity = getIntent().getStringExtra("activity");
        }


        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        geocoder = new Geocoder(this, Locale.getDefault());

        add_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                MyAppPrefsManager myAppPrefsManager = new MyAppPrefsManager(DeliveryAddress.this);

                if (isUpdate)
                {
                    Add_Address addAddress = new Add_Address();


                    addAddress.updateUserAddress
                            (
                                    addressID,
                                    String.valueOf(myAppPrefsManager.getUserId()),
                                    myAppPrefsManager.getUserName().split(" ")[0],
                                    myAppPrefsManager.getUserName().split(" ")[1],
                                    street,
                                    postcode,
                                    city,
                                    state,
                                    "253",
                                    lat,
                                    lng,
                                    nickname,
                                    Landmark,
                                    house_no,
                                    "3",
                                    DeliveryAddress.this,
                                    null
                            );
                    finish();
                }
                else {
                    addressDetailsList = dbUserAddress.getAddressData();
                    int count1 = 0;
                    int count2 = 0;

                    if (addressDetailsList != null) {
                        for (int i = 0; i < addressDetailsList.size(); i++) {
                            if (addressDetailsList.get(0).getNickname().equalsIgnoreCase("Home")) {
                                count1++;
                            } else if (addressDetailsList.get(0).getNickname().equalsIgnoreCase("Work")) {
                                count2++;
                            }
                        }

                    }


                    if (count1 == 0) {
                        nickname = "Home";
                    } else if (count2 == 0) {
                        nickname = "Work";
                    } else {
                        nickname = "Others";
                    }

                    addressDetails.setNickname(nickname);
                    addressDetails.setLng(lng);
                    addressDetails.setLat(lat);
                    addressDetails.setState(state);
                    addressDetails.setCity(city);
                    addressDetails.setPostcode(postcode);
                    addressDetails.setStreet(street);

                    dbUserAddress.insertAddressData(addressDetails);

                    if (ConstantValues.IS_USER_LOGGED_IN) {
                        addressDetailsList = dbUserAddress.getAddressData();

                        myAppPrefsManager.setAddressCartCount(addressDetailsList.size());

                        Add_Address addAddress = new Add_Address();


                        addAddress.addUserAddress
                                (
                                        String.valueOf(myAppPrefsManager.getUserId()),
                                        myAppPrefsManager.getUserName().split(" ")[0],
                                        myAppPrefsManager.getUserName().split(" ")[1],
                                        street,
                                        postcode,
                                        city,
                                        state,
                                        "253",
                                        lat,
                                        lng,
                                        nickname,
                                        Landmark,
                                        house_no,
                                        "3",
                                        DeliveryAddress.this,
                                        null
                                );
                    }

                    if (activity!=null)
                    {
                        Intent i = new Intent(DeliveryAddress.this, HomeActivity.class);
                        startActivity(i);
                    }else {
                        finish();
                    }

                }



            }
        });

        address.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
                            .setCountry("IN")
                            .build(DeliveryAddress.this);
                    startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);

                }

                return false;
            }
        });


        add_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                choose_btn.setVisibility(View.GONE);
                details.setVisibility(View.VISIBLE);

            }
        });

        btn_skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (activity!=null)
                {
                    Intent i = new Intent(DeliveryAddress.this, HomeActivity.class);
                    startActivity(i);
                }else {
                    finish();
                }

            }
        });
        if (isUpdate)
        {

            address.setText(street+", "+", "+city+", "+state+" "+postcode+", India");

            if (Landmark!=null|| house_no!=null)
            {
                choose_btn.setVisibility(View.GONE);
                details.setVisibility(View.VISIBLE);

                landmark.setText(Landmark);
                houseno.setText(house_no);

                if (nickname!=null)
                {
                    if (nickname.equalsIgnoreCase("Home"))
                    {
                        home.setBackgroundResource(R.drawable.square_border_card_accent);
                        work.setBackgroundResource(0);
                        others.setBackgroundResource(0);
                    }else if (nickname.equalsIgnoreCase("Work"))
                    {
                        home.setBackgroundResource(0);
                        work.setBackgroundResource(R.drawable.square_border_card_accent);
                        others.setBackgroundResource(0);
                    }else
                    {
                        address_nickname.setVisibility(View.GONE);
                        add_nickname_layout.setVisibility(View.VISIBLE);
                        add_nickname.setText(nickname);
                        home.setBackgroundResource(0);
                        work.setBackgroundResource(0);
                        others.setBackgroundResource(R.drawable.square_border_card_accent);
                    }
                }


            }


        }else {
            gps = new GPSTracker(this);
            if (gps.canGetLocation()) {
                location = gps.getLocation();

                if (location != null) {
                    LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());

                    getLocation(latLng);
                }

            } else {
                Toast.makeText(this, "Can not get Location", Toast.LENGTH_LONG).show();
            }
        }

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                nickname = "Home";
                home.setBackgroundResource(R.drawable.square_border_card_accent);
                work.setBackgroundResource(0);
                others.setBackgroundResource(0);

            }
        });

        work.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                nickname = "Work";
                home.setBackgroundResource(0);
                work.setBackgroundResource(R.drawable.square_border_card_accent);
                others.setBackgroundResource(0);


            }
        });

        others.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                nickname = "Others";

                address_nickname.setVisibility(View.GONE);
                add_nickname_layout.setVisibility(View.VISIBLE);
                home.setBackgroundResource(0);
                work.setBackgroundResource(0);
                others.setBackgroundResource(R.drawable.square_border_card_accent);

            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                address_nickname.setVisibility(View.VISIBLE);
                add_nickname_layout.setVisibility(View.GONE);

            }
        });



        save_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                MyAppPrefsManager myAppPrefsManager = new MyAppPrefsManager(DeliveryAddress.this);

                if (isUpdate)
                {
                    Add_Address addAddress = new Add_Address();


                    addAddress.updateUserAddress
                            (
                                    addressID,
                                    String.valueOf(myAppPrefsManager.getUserId()),
                                    myAppPrefsManager.getUserName().split(" ")[0],
                                    myAppPrefsManager.getUserName().split(" ")[1],
                                    street,
                                    postcode,
                                    city,
                                    state,
                                    "253",
                                    lat,
                                    lng,
                                    nickname,
                                    Landmark,
                                    house_no,
                                    "3",
                                    DeliveryAddress.this,
                                    null
                            );
                }else {

                    addressDetails.setNickname(nickname);
                    addressDetails.setLng(lng);
                    addressDetails.setLat(lat);
                    addressDetails.setState(state);
                    addressDetails.setCity(city);
                    addressDetails.setPostcode(postcode);
                    addressDetails.setStreet(street);

                    house_no = houseno.getText().toString();
                    Landmark = landmark.getText().toString();

                    dbUserAddress.insertAddressData(addressDetails);

                    if (ConstantValues.IS_USER_LOGGED_IN) {
                        addressDetailsList = dbUserAddress.getAddressData();


                        myAppPrefsManager.setAddressCartCount(addressDetailsList.size());

                        Add_Address addAddress = new Add_Address();


                        addAddress.addUserAddress
                                (
                                        String.valueOf(myAppPrefsManager.getUserId()),
                                        myAppPrefsManager.getUserName().split(" ")[0],
                                        myAppPrefsManager.getUserName().split(" ")[1],
                                        street,
                                        postcode,
                                        city,
                                        state,
                                        "253",
                                        lat,
                                        lng,
                                        nickname,
                                        Landmark,
                                        house_no,
                                        "3",
                                        DeliveryAddress.this,
                                        null
                                );
                    }
                }
                if (activity!=null)
                {
                    Intent i = new Intent(DeliveryAddress.this, HomeActivity.class);
                    startActivity(i);
                }else {
                    finish();
                }


            }
        });
    }



    @Override
    public boolean onMarkerClick(Marker marker) {

        return false;
    }

    protected Marker createMarker(double latitude, double longitude, String title, String snippet, int iconResID) {

        return mMap.addMarker(new MarkerOptions()
                .position(new LatLng(latitude, longitude))
                .anchor(0.5f, 0.5f)
                .snippet(snippet)
                .title(title)
                .icon(Utilities.bitmapDescriptorFromVector(this, R.drawable.ic_location))
                .draggable(true));

    }

    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;

        if (isUpdate)
        {
            if (lat!=null|| lng!=null) {
                LatLng address = new LatLng(Double.parseDouble(lat),Double.parseDouble(lng));
                placeMarker(address);
            }
        }else {

            Log.d("GPS", "onMapReady: " + gps.getLocation().getLatitude() + ", " +
                    gps.getLocation().getLongitude());

            LatLng yourLocation = new LatLng(gps.getLocation().getLatitude(), gps.getLocation().getLongitude());
            placeMarker(yourLocation);
        }

    }

    @Override
    public void onMarkerDragStart(Marker marker) {

    }

    @Override
    public void onMarkerDrag(Marker marker) {

    }

    @Override
    public void onMarkerDragEnd(Marker marker) {

        LatLng location = new LatLng(marker.getPosition().latitude, marker.getPosition().longitude);

        getLocation(location);

    }


    private void placeMarker(LatLng location) {

        mMap.addMarker(new MarkerOptions().position(location).title("Drag to Adjust").draggable(true)).setDraggable(true);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(location));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));

        mMap.setOnMarkerClickListener(this);
        mMap.setOnMarkerDragListener(this);

    }



    public void getLocation(LatLng location)
    {
        try {

            addresses = geocoder.getFromLocation(location.latitude, location.longitude,1);

            address.setText(addresses.get(0).getAddressLine(0));

            street = addresses.get(0).getSubAdminArea();
            postcode = addresses.get(0).getPostalCode();
            city = addresses.get(0).getLocality();
            state = addresses.get(0).getAdminArea();
            lat = String.valueOf(location.latitude);
            lng = String.valueOf(location.latitude);


        } catch (IOException e) {

            e.printStackTrace();

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Place place = Autocomplete.getPlaceFromIntent(data);
                Log.i("Searched Place", "Place: " + place.toString() + ", " + place.getId());
                getLocation(place.getLatLng());
                address.setText(place.getAddress());

                placeMarker(place.getLatLng());

            } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
                // TODO: Handle the error.
                Status status = Autocomplete.getStatusFromIntent(data);
                Log.i("Searched Place", status.getStatusMessage());
            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
