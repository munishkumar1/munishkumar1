package com.nextstack.chicken.customerapp.models.search_model;

public class SearchDetails {


    private Product products;

    /**
     * @return The products
     */
    public Product getProducts() {
        return products;
    }

    /*

      @param products
          The products
     */
    public void setProducts(Product products) {
        this.products = products;
    }

}
