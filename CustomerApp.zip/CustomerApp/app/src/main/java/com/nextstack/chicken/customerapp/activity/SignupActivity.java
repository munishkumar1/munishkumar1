package com.nextstack.chicken.customerapp.activity;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.customs.CircularImageView;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.models.user_model.UserData;
import com.nextstack.chicken.customerapp.network.APIClient;
import com.nextstack.chicken.customerapp.services.MyFirebaseMessagingService;
import com.nextstack.chicken.customerapp.utils.CheckPermissions;
import com.nextstack.chicken.customerapp.utils.ImagePicker;
import com.nextstack.chicken.customerapp.utils.Utilities;
import com.nextstack.chicken.customerapp.utils.ValidateInputs;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;

public class SignupActivity extends AppCompatActivity {

    View parentView;
    String profileImage;
    private static final int PICK_IMAGE_ID = 360;
    DialogLoader dialogLoader;

    FirebaseAuth auth;
    DatabaseReference reference;
    String userid;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    Button signupBtn;
    CircularImageView user_photo;
    FloatingActionButton user_photo_edit_fab;
    EditText user_firstname, user_lastname, user_dob, user_email, user_password, user_mobile, searchBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        auth = FirebaseAuth.getInstance();

        user_photo = findViewById(R.id.user_photo);
        user_firstname = findViewById(R.id.user_firstname);
        user_lastname = findViewById(R.id.user_lastname);
        user_dob = findViewById(R.id.user_dob);
        user_email = findViewById(R.id.user_email);
        user_password = findViewById(R.id.user_password);
        user_mobile = findViewById(R.id.user_contactno);
        signupBtn = findViewById(R.id.btn_sign_up);
        user_photo_edit_fab = findViewById(R.id.user_photo_edit_fab);searchBar = findViewById(R.id.search_bar);

        searchBar.setVisibility(View.GONE);

       dialogLoader = new DialogLoader(SignupActivity.this);

        user_photo_edit_fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CheckPermissions.is_CAMERA_PermissionGranted()  &&  CheckPermissions.is_STORAGE_PermissionGranted()) {
                    pickImage();
                }
                else {
                    ActivityCompat.requestPermissions
                            (
                                    SignupActivity.this,
                                    new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                    CheckPermissions.PERMISSIONS_REQUEST_CAMERA
                            );
                }
            }
        });

        user_dob.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    // Get Calendar instance
                    final Calendar calendar = Calendar.getInstance();

                    // Initialize DateSetListener of DatePickerDialog
                    DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                            // Set the selected Date Info to Calendar instance
                            calendar.set(Calendar.YEAR, year);
                            calendar.set(Calendar.MONTH, monthOfYear);
                            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                            // Set Date Format
                            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

                            // Set Date in input_dob EditText
                            user_dob.setText(dateFormat.format(calendar.getTime()));
                        }
                    };


                    // Initialize DatePickerDialog
                    DatePickerDialog datePicker = new DatePickerDialog
                            (
                                    SignupActivity.this,
                                    date,
                                    calendar.get(Calendar.YEAR),
                                    calendar.get(Calendar.MONTH),
                                    calendar.get(Calendar.DAY_OF_MONTH)
                            );

                    // Show datePicker Dialog
                    datePicker.show();
                }

                return false;
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Validate Login Form Inputs


              /*  processRegistration
                        (
                                SignupActivity.this,
                                user_firstname.getText().toString().trim(),
                                user_lastname.getText().toString().trim(),
                                user_email.getText().toString().trim(),
                                user_dob.getText().toString().trim(),
                                user_password.getText().toString().trim(),
                                user_mobile.getText().toString().trim(),
                                profileImage,
                                "1",
                                "",
                                ""
                        );*/

                registerToFCM
                        (
                                SignupActivity.this,
                                user_firstname.getText().toString().trim(),
                                user_lastname.getText().toString().trim(),
                                user_email.getText().toString().trim(),
                                user_dob.getText().toString().trim(),
                                user_password.getText().toString().trim(),
                                (user_firstname.getText().toString().trim()+" "+user_lastname.getText().toString().trim()),
                                user_mobile.getText().toString().trim(),
                                profileImage,
                                "",
                                "",
                                "",
                                ""
                        );

            }
        });
    }


    public void processRegistration
            (
                    final Context context,
                    final String customers_firstname,
                    final String customers_lastname,
                    final String customers_email_address,
                    String customers_dob,
                    final String customers_password,
                    final String customers_telephone,
                    final String customers_picture,
                    final String customers_old_picture,
                    final String type,
                    String fb_id,
                    String google_id
            )
    {

//        dialogLoader = new DialogLoader(context);
//        dialogLoader.showProgressDialog();


            Call<UserData> call = APIClient.getNetInstance(true)
                    .processRegistration
                            (
                                    customers_firstname,
                                    customers_lastname,
                                    customers_email_address,
                                    customers_dob,
                                    customers_password,
                                    customers_telephone,
                                    customers_picture,
                                    customers_old_picture,
                                    fb_id,
                                    google_id,
                                    userid!=null?userid:"NA"
                            );


            call.enqueue(new Callback<UserData>() {
                @Override
                public void onResponse(Call<UserData> call, retrofit2.Response<UserData> response) {

                  //  dialogLoader.hideProgressDialog();

                    // Check if the Response is successful
                    if (response.isSuccessful()) {
                        if (response.body().getSuccess() == 1) {

                            if (type.equalsIgnoreCase("1")) {
                                // Finish SignUpActivity to goto the LoginActivity
                                finish();
                                overridePendingTransition(R.anim.enter_from_left, R.anim.exit_out_left);
                            } else if (type.equalsIgnoreCase("2")) {

                                LoginActivity login = new LoginActivity();
                                login.processLogin(customers_email_address, customers_telephone, customers_password, context, "2");
                            } else if (type.equalsIgnoreCase("3")) {

                                LoginActivity login = new LoginActivity();
                                login.processLogin(customers_email_address, customers_telephone, customers_password, context, "3");
                            }

                            sharedPreferences = context.getSharedPreferences("UserInfo", context.MODE_PRIVATE);


                            FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(SignupActivity.this, new OnSuccessListener<InstanceIdResult>() {
                                @Override
                                public void onSuccess(InstanceIdResult instanceIdResult) {
                                    String newToken = instanceIdResult.getToken();
                                    Log.e("newToken", newToken);

                                    editor = sharedPreferences.edit();
                                    editor.putString("FCM_Token", newToken);
                                    editor.apply();

                                    MyFirebaseMessagingService.updateToken(newToken);

                                    MyFirebaseMessagingService.RegisterDeviceForFCM(context);

                                }
                            });

                        } else if (response.body().getSuccess() == 0) {
                            // Get the Error Message from Response
                            String message = response.body().getMessage();
                            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
                          //  Snackbar.make(parentView, message, Snackbar.LENGTH_SHORT).show();

                        } else {
                            // Unable to get Success status
                            Toast.makeText(context, getString(R.string.unexpected_response), Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        // Show the Error Message
                        Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<UserData> call, Throwable t) {
                    dialogLoader.hideProgressDialog();
                    Toast.makeText(context, "NetworkCallFailure : " + t, Toast.LENGTH_LONG).show();
                }
            });


    }

    public void registerToFCM
            (
                    final Context context,
                    final String first_name,
                    final String last_name,
                    final String email,
                    final String dob,
                    final String password,
                    final String username,
                    final String mobile,
                    final String imageURL,
                    final String altImageURL,
                    final String type,
                    final String fb_id,
                    final String google_id
            )
    {
        auth = FirebaseAuth.getInstance();
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(!task.isComplete()){
                            Toast.makeText(SignupActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        if (task.isSuccessful()) {
                            FirebaseUser firebaseUser = auth.getCurrentUser();
                            assert firebaseUser != null;
                            userid = firebaseUser.getUid();

                            reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);

                            HashMap<String, String> hashMap = new HashMap<>();
                            hashMap.put("id", userid);
                            hashMap.put("username", username);
                            hashMap.put("imageURL", imageURL);

                            reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()) {

                                        boolean isValidData = validateForm();

                                        if (isValidData) {

                                            // Proceed User Registration
                                            if (type=="1") {
                                                processRegistration
                                                        (
                                                                context,
                                                                first_name,
                                                                last_name,
                                                                email,
                                                                dob,
                                                                password,
                                                                mobile,
                                                                profileImage,
                                                                "",
                                                                type,
                                                                fb_id,
                                                                google_id
                                                        );
                                            }
                                            else
                                            {
                                                processRegistration
                                                        (
                                                                context,
                                                                first_name,
                                                                last_name,
                                                                email,
                                                                dob,
                                                                password,
                                                                mobile,
                                                                "",
                                                                profileImage,
                                                                type,
                                                                fb_id,
                                                                google_id
                                                        );
                                            }
                                        }

                                    }
                                }
                            });
                        } else {
                            Toast.makeText(SignupActivity.this, "You can't register with this email or password", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void pickImage() {
        // Get Intent with Options of Image Picker Apps from the static method of ImagePicker class
        Intent chooseImageIntent = ImagePicker.getImagePickerIntent(SignupActivity.this);

        if(Build.VERSION.SDK_INT>=24){
            try{
                Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                m.invoke(null);
                // Start Activity with Image Picker Intent
                startActivityForResult(chooseImageIntent, PICK_IMAGE_ID);
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            // Handle Activity Result
            if (requestCode == PICK_IMAGE_ID) {



                // Get the User Selected Image as Bitmap from the static method of ImagePicker class
                Bitmap bitmap = ImagePicker.getImageFromResult(SignupActivity.this, resultCode, data);

                // Upload the Bitmap to ImageView
                user_photo.setImageBitmap(bitmap);

                // Get the converted Bitmap as Base64ImageString from the static method of Helper class
                profileImage = Utilities.getBase64ImageStringFromBitmap(bitmap);

            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CheckPermissions.PERMISSIONS_REQUEST_CAMERA) {
            if (grantResults.length > 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                // The Camera and Storage Permission is granted
                pickImage();
            }
            else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(SignupActivity.this, Manifest.permission.CAMERA)) {
                    // Show Information about why you need the permission
                    AlertDialog.Builder builder = new AlertDialog.Builder(SignupActivity.this);
                    builder.setTitle(getString(R.string.permission_camera_storage));
                    builder.setMessage(getString(R.string.permission_camera_storage_needed));
                    builder.setPositiveButton(getString(R.string.grant), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            ActivityCompat.requestPermissions
                                    (
                                            SignupActivity.this,
                                            new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                            CheckPermissions.PERMISSIONS_REQUEST_CAMERA
                                    );
                        }
                    });
                    builder.setNegativeButton(getString(R.string.not_now), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    builder.show();
                }
                else {
                    Toast.makeText(SignupActivity.this,getString(R.string.permission_rejected), Toast.LENGTH_LONG).show();
                }
            }
        }
    }


    private boolean validateForm() {
        if (!ValidateInputs.isValidName(user_firstname.getText().toString().trim())) {
            user_firstname.setError(getString(R.string.invalid_first_name));
            return false;
        } else if (!ValidateInputs.isValidName(user_lastname.getText().toString().trim())) {
            user_lastname.setError(getString(R.string.invalid_last_name));
            return false;
        } else if (!ValidateInputs.isValidEmail(user_email.getText().toString().trim())) {
            user_email.setError(getString(R.string.invalid_email));
            return false;
        } else if (!ValidateInputs.isValidPassword(user_password.getText().toString().trim())) {
            user_password.setError(getString(R.string.invalid_password));
            return false;
        } else if (!ValidateInputs.isValidNumber(user_mobile.getText().toString().trim())) {
            user_mobile.setError(getString(R.string.invalid_contact));
            return false;
        } else {
            return true;
        }
    }
    //*********** Called when the Activity has detected the User pressed the Back key ********//

    @Override
    public void onBackPressed() {
        // Finish SignUpActivity to goto the LoginActivity
        finish();
        overridePendingTransition(R.anim.enter_from_right, R.anim.exit_out_right);
    }

}
