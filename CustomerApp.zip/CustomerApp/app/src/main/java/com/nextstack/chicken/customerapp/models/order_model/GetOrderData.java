package com.nextstack.chicken.customerapp.models.order_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class GetOrderData {

    @SerializedName("Success")
    @Expose
    private int success;
    @SerializedName("data")
    @Expose
    private Data data;
    @SerializedName("Message")
    @Expose
    private String message;


    public class Data
    {
        @SerializedName("OrderList")
        @Expose
        List <OrderDetails> orderList = new ArrayList <OrderDetails> ();
        @SerializedName("ProductList")
        @Expose
        List<Products> productList = new ArrayList <Products>();


        public class Products
        {
            @SerializedName("products_name")
            @Expose
            String products_name;
            @SerializedName("orders_id")
            @Expose
            int orders_id;
            @SerializedName("products_quantity")
            @Expose
            int products_quantity;

            public String getProducts_name() {
                return products_name;
            }

            public void setProducts_name(String products_name) {
                this.products_name = products_name;
            }

            public int getOrders_id() {
                return orders_id;
            }

            public void setOrders_id(int orders_id) {
                this.orders_id = orders_id;
            }


            public int getProducts_quantity() {
                return products_quantity;
            }

            public void setProducts_quantity(int products_quantity) {
                this.products_quantity = products_quantity;
            }
        }

        public List<OrderDetails> getOrderList() {
            return orderList;
        }

        public void setOrderList(List<OrderDetails> orderList) {
            this.orderList = orderList;
        }

        public List<Products> getProductList() {
            return productList;
        }

        public void setProductList(List<Products> productList) {
            this.productList = productList;
        }
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
