package com.nextstack.chicken.customerapp.models.device_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;


public class AppSettingsData {

    @SerializedName("Success")
    @Expose
    private int success;
    @SerializedName("data")
    @Expose
    private List<AppSettingsDetails> appDetails = null;
    @SerializedName("Message")
    @Expose
    private String message;

    
    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public List<AppSettingsDetails> getProductData() {
        return appDetails;
    }

    public void setProductData(List<AppSettingsDetails> appDetails) {
        this.appDetails = appDetails;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
