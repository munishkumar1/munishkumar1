package com.nextstack.chicken.customerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.models.category_model.CategoryDetails;

import java.util.ArrayList;
import java.util.List;

public class SubCategoryAdapter extends RecyclerView.Adapter<SubCategoryAdapter.MyViewHolder> {

    List<CategoryDetails> categoryDetails = new ArrayList<>();
    Context context;
    OnItemClickListener listener;

    public interface OnItemClickListener
    {
        void onItemClick(CategoryDetails item);
    }

    public SubCategoryAdapter(Context context, List<CategoryDetails> categoryDetails, OnItemClickListener listener) {
        this.categoryDetails = categoryDetails;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView;

        itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_sub_categories_card, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.sub_category_name.setText(categoryDetails.get(position).getCategoriesName());

        Glide
                .with(context)
                .load(categoryDetails.get(position).getCategoriesImage())
                .into(holder.sub_category_image);

        holder.bind(context, categoryDetails.get(position));

    }

    @Override
    public int getItemCount() {
        return categoryDetails.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        ImageView sub_category_image;
        TextView sub_category_name;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            sub_category_image = itemView.findViewById(R.id.sub_category_image);
            sub_category_name = itemView.findViewById(R.id.sub_category_name);
        }


        public void bind(Context context, final CategoryDetails categoryDetails) {

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onItemClick(categoryDetails);
                }
            });
        }
    }
}
