package com.nextstack.chicken.customerapp.models.order_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ViewOrderData {

    @SerializedName("Success")
    @Expose
    private int success;
    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private ViewOrderDetails data = null;


    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ViewOrderDetails getData() {
        return data;
    }

    public void setData(ViewOrderDetails data) {
        this.data = data;
    }
}
