package com.nextstack.chicken.customerapp.network;

import com.nextstack.chicken.customerapp.models.Notification_Model.MyResponse;
import com.nextstack.chicken.customerapp.models.Notification_Model.Sender;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface FirebaseAPI {

    @Headers(
            {
                    "Content-Type:application/json",
                    "Authorization:key=AAAAEulZoXQ:APA91bGSgaTbyX5gQ0Wy8QAez9sKigPuAVlR5YxGv_aJfv_YbfdwHJ-eR1tpCl9Vd_gpdG7Bn33jVycEmkfXReGx-ySUUqoDgEJZRKIa84un-A9pYheEGMp4GEGXBJzDP8T2enMMkCwm"
            }
    )

    @POST("fcm/send")
    Call<MyResponse> sendNotification(@Body Sender body);
}
