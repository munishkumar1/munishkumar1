package com.nextstack.chicken.customerapp.models.user_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class UserData {


    @SerializedName("Success")
    @Expose
    private int success;
    @SerializedName("data")
    @Expose
    private UserDetails data = null;
    @SerializedName("Message")
    @Expose
    private String message;



    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public UserDetails getData() {
        return data;
    }

    public void setData(UserDetails data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
