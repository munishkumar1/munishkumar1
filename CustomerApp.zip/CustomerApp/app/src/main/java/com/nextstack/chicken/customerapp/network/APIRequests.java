package com.nextstack.chicken.customerapp.network;


import com.nextstack.chicken.customerapp.models.order_model.OrderData;
import com.nextstack.chicken.customerapp.models.order_model.PostOrder;
import com.nextstack.chicken.customerapp.models.user_model.UserData;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * APIRequests contains all the Network Request Methods with relevant API Endpoints
 **/

public interface APIRequests {


    //******************** User data ********************//

    @FormUrlEncoded
    @POST("facebookRegistration")
    Call<UserData> facebookRegistration(@Field("access_token") String access_token);

    @POST("addToOrder")
    Call<OrderData> addToOrder(@Body PostOrder postOrder);

}

