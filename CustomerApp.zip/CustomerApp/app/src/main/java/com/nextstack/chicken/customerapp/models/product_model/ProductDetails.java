package com.nextstack.chicken.customerapp.models.product_model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class ProductDetails implements Parcelable {


    @SerializedName("products_id")
    @Expose
    private int productsId;
    @SerializedName("products_quantity")
    @Expose
    private int productsQuantity;
    @SerializedName("products_image")
    @Expose
    private String productsImage;
    @SerializedName("products_price")
    @Expose
    private String productsPrice;
    @SerializedName("products_weight")
    @Expose
    private String productsWeight;
    @SerializedName("products_weight_unit")
    @Expose
    private String productsWeightUnit;
    @SerializedName("products_name")
    @Expose
    private String productsName;
    @SerializedName("distributor_id")
    @Expose
    private int distributorId;
    @SerializedName("total_price")
    @Expose
    private String totalPrice;
    @SerializedName("customers_basket_quantity")
    @Expose
    private int customersBasketQuantity;
    @SerializedName("tax_amt")
    @Expose
    private String tax_amount;
    @SerializedName("tax_rate")
    @Expose
    private String tax_rate;

    private String category_id;

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public int getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(int distributorId) {
        this.distributorId = distributorId;
    }

    public ProductDetails() {
    }

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getCustomersBasketQuantity() {
        return customersBasketQuantity;
    }

    public void setCustomersBasketQuantity(int customersBasketQuantity) {
        this.customersBasketQuantity = customersBasketQuantity;
    }

    public int getProductsId() {
        return productsId;
    }

    public void setProductsId(int productsId) {
        this.productsId = productsId;
    }

    public int getProductsQuantity() {
        return productsQuantity;
    }

    public void setProductsQuantity(int productsQuantity) {
        this.productsQuantity = productsQuantity;
    }
    public String getProductsImage() {
        return productsImage;
    }

    public void setProductsImage(String productsImage) {
        this.productsImage = productsImage;
    }

    public String getProductsPrice() {
        return productsPrice;
    }

    public void setProductsPrice(String productsPrice) {
        this.productsPrice = productsPrice;
    }
    public String getProductsWeight() {
        return productsWeight;
    }

    public void setProductsWeight(String productsWeight) {
        this.productsWeight = productsWeight;
    }

    public String getProductsWeightUnit() {
        return productsWeightUnit;
    }

    public void setProductsWeightUnit(String productsWeightUnit) {
        this.productsWeightUnit = productsWeightUnit;
    }

    public String getProductsName() {
        return productsName;
    }

    public void setProductsName(String productsName) {
        this.productsName = productsName;
    }

    public String getTax_amount() {
        return tax_amount;
    }

    public void setTax_amount(String tax_amount) {
        this.tax_amount = tax_amount;
    }

    public String getTax_rate() {
        return tax_rate;
    }

    public void setTax_rate(String tax_rate) {
        this.tax_rate = tax_rate;
    }

    //********** Describes the kinds of Special Objects contained in this Parcelable Instance's marshaled representation *********//

    @Override
    public int describeContents() {
        return 0;
    }



    //********** Writes the values to the Parcel *********//

    @Override
    public void writeToParcel(Parcel parcel_out, int flags) {
        parcel_out.writeInt(productsId);
        parcel_out.writeInt(productsQuantity);
        parcel_out.writeString(productsName);
        parcel_out.writeString(productsImage);
        parcel_out.writeString(productsWeight);
        parcel_out.writeString(productsWeightUnit);
        parcel_out.writeString(productsName);
        parcel_out.writeString(tax_amount);
        parcel_out.writeInt(distributorId);
        parcel_out.writeString(tax_rate);
    }



    //********** Generates Instances of Parcelable class from a Parcel *********//

    public static final Creator<ProductDetails> CREATOR = new Creator<ProductDetails>() {
        
        // Creates a new Instance of the Parcelable class, Instantiating it from the given Parcel
        @Override
        public ProductDetails createFromParcel(Parcel parcel_in) {
            return new ProductDetails(parcel_in);
        }

        // Creates a new array of the Parcelable class
        @Override
        public ProductDetails[] newArray(int size) {
            return new ProductDetails[size];
        }
    };



    //********** Retrieves the values from the Parcel *********//

    protected ProductDetails(Parcel parcel_in) {
        this.productsId = parcel_in.readInt();
        this.productsQuantity = parcel_in.readInt();
        this.productsName = parcel_in.readString();
        this.productsImage = parcel_in.readString();
        this.productsWeight = parcel_in.readString();
        this.productsWeightUnit = parcel_in.readString();
        this.productsName = parcel_in.readString();
        this.tax_amount = parcel_in.readString();
        this.distributorId = parcel_in.readInt();
        this.tax_rate = parcel_in.readString();
    }

}
