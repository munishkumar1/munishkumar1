package com.nextstack.chicken.customerapp.network;

import com.nextstack.chicken.customerapp.models.address_model.AddressData;
import com.nextstack.chicken.customerapp.models.address_model.Zones;
import com.nextstack.chicken.customerapp.models.banner_model.BannerData;
import com.nextstack.chicken.customerapp.models.barcode_model.Barcode;
import com.nextstack.chicken.customerapp.models.category_model.CategoriesData;
import com.nextstack.chicken.customerapp.models.coupons_model.CouponsData;
import com.nextstack.chicken.customerapp.models.device_model.AppSettingsData;
import com.nextstack.chicken.customerapp.models.device_model.DeviceData;
import com.nextstack.chicken.customerapp.models.faq_model.FaqData;
import com.nextstack.chicken.customerapp.models.language_model.LanguageData;
import com.nextstack.chicken.customerapp.models.order_model.GetOrderData;
import com.nextstack.chicken.customerapp.models.order_model.OrderData;
import com.nextstack.chicken.customerapp.models.order_model.OrderDataPost;
import com.nextstack.chicken.customerapp.models.order_model.ProcessOrderData;
import com.nextstack.chicken.customerapp.models.order_model.ViewOrderData;
import com.nextstack.chicken.customerapp.models.payment_model.PaymentMethodsData;
import com.nextstack.chicken.customerapp.models.product_model.ProductData;
import com.nextstack.chicken.customerapp.models.search_model.SearchData;
import com.nextstack.chicken.customerapp.models.shop_model.ShopData;
import com.nextstack.chicken.customerapp.models.user_model.UserData;
import com.nextstack.chicken.customerapp.models.wallet_model.WalletData;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface APIRequestsNet {


    @GET("categories/distributer_categories")
    Call<CategoriesData> getDistributorCategory
            (
                    @Query("language_id") int language_id,
                    @Query("postcode") int postcode
            );


    @GET("categories/sub_categories")
    Call<CategoriesData> getSubCategories(@Query("category_id") int category_id,
                                          @Query("distributor_id") int distributor_id);


    @FormUrlEncoded
    @POST("Auth/processLogin")
    Call<UserData> processLogin(@Field("customers_email_address") String customers_email_address,
                                 @Field("customers_password") String customers_password);


    @FormUrlEncoded
    @POST("Auth/processRegistration")
    Call<UserData> processRegistration(@Field("customers_firstname") String customers_firstname,
                                       @Field("customers_lastname") String customers_lastname,
                                       @Field("customers_email_address") String customers_email_address,
                                       @Field("customers_dob") String customers_dob,
                                       @Field("customers_password") String customers_password,
                                       @Field("customers_telephone") String customers_telephone,
                                       @Field("customers_picture") String customers_picture,
                                       @Field("customers_old_picture") String customers_old_picture,
                                       @Field("fb_id") String fb_id,
                                       @Field("google_id") String google_id,
                                       @Field("firebase_id") String firebase_id);

    @FormUrlEncoded
    @POST("Auth/updateCustomerInfo")
    Call<UserData> updateCustomerInfo(@Field("customers_id") String customers_id,
                                      @Field("customers_firstname") String customers_firstname,
                                      @Field("customers_lastname") String customers_lastname,
                                      @Field("customers_telephone") String customers_telephone,
                                      @Field("customers_dob") String customers_dob,
                                      @Field("customers_picture") String customers_picture,
                                      @Field("customers_old_picture") String customers_old_picture,
                                      @Field("customers_password") String customers_password);

    @GET("coupons/getCoupon")
    Call<CouponsData> getCoupon(@Query("code") String code);

    @GET("coupons/getCoupon_distributor")
    Call<CouponsData> getCoupon_distributor(@Query("distributor_id") String distributor_id);

    @FormUrlEncoded
    @POST("Orders/apply_coupons")
    Call<ProcessOrderData> apply_coupons(@Field("coupon_code") String code,
                                         @Field("customer_id") String customer_id,
                                         @Field("products") String products_list);

    @GET("products/getDistributor")
    Call<ShopData> getDistributors(@Query("sell_type") int sell_type);

    @GET("products/getDistributorByProduct")
    Call<ShopData> getDistributorByProduct(@Query("product_id") int product_id);

    @GET("products/Distributer_by_Product")
    Call<ShopData> getDistributerByProduct
            (
                    @Query("_products_id") int product_id,
                    @Query("latitude") String latitude,
                    @Query("longitude") String longitude
            );

    @GET("products/getProduct")
    Call<ProductData> getProducts(@Query("distributor_id") int distributor_id,
                                  @Query("category_name") String category_name);

    @FormUrlEncoded
    @POST("Location/getState")
    Call<Zones> getZones(@Field("zone_country_id") int zone_country_id);


    @FormUrlEncoded
    @POST("Location/getAllAddress")
    Call<AddressData> getAllAddress(@Field("customers_id") int customers_id);

    @FormUrlEncoded
    @POST("Location/addShippingAddress")
    Call<AddressData> addShippingAddress(@Field("customers_id") String customers_id,
                                        @Field("firstname") String firstname,
                                        @Field("lastname") String lastname,
                                        @Field("street") String street,
                                        @Field("postcode") String postcode,
                                        @Field("city") String city,
                                        @Field("state") String state,
                                        @Field("entry_country_id") String entry_country_id,
                                        @Field("lat") String lat,
                                        @Field("lng") String lng,
                                        @Field("nickname") String nickname,
                                        @Field("Landmark") String Landmark,
                                        @Field("house_no") String house_no);


    @FormUrlEncoded
    @POST("Location/updateShippingAddress")
    Call<AddressData> updateShippingAddress(@Field("customers_id") String customers_id,
                                        @Field("address_id") String address_id,
                                        @Field("firstname") String firstname,
                                        @Field("lastname") String lastname,
                                        @Field("street") String street,
                                        @Field("postcode") String postcode,
                                        @Field("city") String city,
                                        @Field("state") String state,
                                        @Field("entry_country_id") String entry_country_id,
                                        @Field("lat") String lat,
                                        @Field("lng") String lng,
                                        @Field("nickname") String nickname,
                                        @Field("Landmark") String Landmark,
                                        @Field("house_no") String house_no);


    @GET("Location/updateDefaultAddress")
    Call<AddressData> updateDefaultAddress(@Query("customers_id") int customers_id,

                                        @Query("address_book_id") int address_book_id);
    @GET("Location/delete_address")
    Call<AddressData> deleteUserAddress(@Query("customers_id") int customers_id,
                                        @Query("address_book_id") int address_book_id);


    @FormUrlEncoded
    @POST("Auth/registerDeviceToFCM")
    Call<DeviceData> registerDeviceToFCM(@Field("device_id") String device_id,
                                         @Field("device_type") String device_type,
                                         @Field("ram") String ram,
                                         @Field("processor") String processor,
                                         @Field("device_os") String device_os,
                                         @Field("location") String location,
                                         @Field("device_model") String device_model,
                                         @Field("manufacturer") String manufacturer,
                                         @Field("id") String customers_id,
                                         @Field("type") int type);


    @GET("Orders/viewOrders")
    Call<ViewOrderData> viewOrders(@Query("order_id") int order_id);


    @GET("products/getOrders")
    Call<GetOrderData> getOrders(@Query("customer_id") int customer_id,
                                 @Query("categories_id") int categories_id);


    @GET("banners/getbanners")
    Call<BannerData> getBanners();


    @GET("banners/getsettings")
    Call<AppSettingsData> getAppSetting();


    @GET("banners/getOffers")
    Call<CouponsData> getOffers();


    @GET("products/getSearchData")
    Call<SearchData> getSearchData(@Query("name") String searchValue,
                                   @Query("categories_id") int categories_id);

    @GET("banners/getPaymentMethods")
    Call<PaymentMethodsData> getPaymentMethods();

    @FormUrlEncoded
    @POST("categories/capture_customer")
    Call<FaqData> saveSearch
            (
                    @Field("search_query") String search_query
            );

    @POST("Orders/addToOrder")
    Call<OrderData> addToOrder(@Body OrderDataPost postOrder);

    @FormUrlEncoded
    @POST("wallet/Addtowallet")
    Call<WalletData> addToWallet
            (
                    @Field("customer_id") String customer_id,
                    @Field("mobile_no") String mobile_no,
                    @Field("transaction_amount") String transaction_amount,
                    @Field("date_added") String date_added,
                    @Field("is_active") String is_active,
                    @Field("is_referral") String is_referral,
                    @Field("payment_token") String payment_token,
                    @Field("payment_status") String payment_status
            );


    @GET("wallet/viewwallet")
    Call<WalletData> viewWallet
            ( @Query("customer_id") String customer_id);

    @FormUrlEncoded
    @POST("wallet/getfromwallet")
    Call<WalletData> getFromWallet
            (
                    @Field("customer_id") String customer_id,
                    @Field("mobile_no") String mobile_no,
                    @Field("transaction_amount") String transaction_amount,
                    @Field("wallet_id") String wallet_id
            );

    @GET("getLanguages")
    Call<LanguageData> getLanguages();

    @GET("msg_email/msg")
    Call sendMessage
            (
                 @Query("mobile") String mobile,
                 @Query("message") String message
            );

    @GET("msg_email/email")
    Call sendEmail
            (
                 @Query("email") String email,
                 @Query("subject") String subject,
                 @Query("body") String body
            );
    @GET("msg_email/both")
    Call<FaqData> sendEmail_Sms
            (
                 @Query("email") String email,
                 @Query("subject") String subject,
                 @Query("body") String body,
                 @Query("mobile") String mobile,
                 @Query("message") String message
            );

@GET("products/rating")
    Call<FaqData> rateDistributor
            (
                 @Query("order_id") String order_id,
                 @Query("customers_id") String customers_id,
                 @Query("reviews_rating") int reviews_rating,
                 @Query("message") String message
            );

    @GET("api/distributer_product/Product_barcode")
    Call<Barcode> barcodePost(@Query("barcode") String barcode);

}
