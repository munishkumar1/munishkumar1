package com.nextstack.chicken.customerapp.models.order_model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ViewOrderDetails implements Parcelable{

    @SerializedName("delivery_name")
    @Expose
    private String delivery_name;
    @SerializedName("delivery_street_address")
    @Expose
    private String delivery_street_address;
    @SerializedName("delivery_suburb")
    @Expose
    private String delivery_suburb = null;
    @SerializedName("delivery_postcode")
    @Expose
    private String delivery_postcode;
    @SerializedName("delivery_locality")
    @Expose
    private String delivery_locality = null;
    @SerializedName("delivery_city")
    @Expose
    private String delivery_city;
    @SerializedName("shipping_cost")
    @Expose
    private String shipping_cost;
    @SerializedName("address_book_id")
    @Expose
    private String address_book_id;
    @SerializedName("date_purchased")
    @Expose
    private String date_purchased;
    @SerializedName("start_time")
    @Expose
    private String start_time;
    @SerializedName("end_time")
    @Expose
    private String end_time;
    @SerializedName("schedule_date")
    @Expose
    private String schedule_date;
    @SerializedName("billing_name")
    @Expose
    private String billing_name;
    @SerializedName("billing_street_address")
    @Expose
    private String billing_street_address;
    @SerializedName("billing_suburb")
    @Expose
    private String billing_suburb = null;
    @SerializedName("billing_city")
    @Expose
    private String billing_city;
    @SerializedName("billing_postcode")
    @Expose
    private String billing_postcode;
    @SerializedName("billing_state")
    @Expose
    private String billing_state;
    @SerializedName("billing_country")
    @Expose
    private String billing_country;
    @SerializedName("payment_method")
    @Expose
    private String payment_method;
    @SerializedName("shipping_method")
    @Expose
    private String shipping_method;
    @SerializedName("total_tax")
    @Expose
    private String total_tax;
    @SerializedName("coupon_amount")
    @Expose
    private String coupon_amount;
    @SerializedName("product_list")
    @Expose
    private List<OrderProducts> products = new ArrayList<>();


    public String getDelivery_name() {
        return delivery_name;
    }

    public void setDelivery_name(String delivery_name) {
        this.delivery_name = delivery_name;
    }

    public String getDelivery_street_address() {
        return delivery_street_address;
    }

    public void setDelivery_street_address(String delivery_street_address) {
        this.delivery_street_address = delivery_street_address;
    }

    public String getDelivery_suburb() {
        return delivery_suburb;
    }

    public void setDelivery_suburb(String delivery_suburb) {
        this.delivery_suburb = delivery_suburb;
    }

    public String getDelivery_postcode() {
        return delivery_postcode;
    }

    public void setDelivery_postcode(String delivery_postcode) {
        this.delivery_postcode = delivery_postcode;
    }

    public String getDelivery_locality() {
        return delivery_locality;
    }

    public void setDelivery_locality(String delivery_locality) {
        this.delivery_locality = delivery_locality;
    }

    public String getDelivery_city() {
        return delivery_city;
    }

    public void setDelivery_city(String delivery_city) {
        this.delivery_city = delivery_city;
    }

    public String getShipping_cost() {
        return shipping_cost;
    }

    public void setShipping_cost(String shipping_cost) {
        this.shipping_cost = shipping_cost;
    }

    public String getAddress_book_id() {
        return address_book_id;
    }

    public void setAddress_book_id(String address_book_id) {
        this.address_book_id = address_book_id;
    }

    public String getDate_purchased() {
        return date_purchased;
    }

    public void setDate_purchased(String date_purchased) {
        this.date_purchased = date_purchased;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public String getSchedule_date() {
        return schedule_date;
    }

    public void setSchedule_date(String schedule_date) {
        this.schedule_date = schedule_date;
    }

    public String getBilling_name() {
        return billing_name;
    }

    public void setBilling_name(String billing_name) {
        this.billing_name = billing_name;
    }

    public String getBilling_street_address() {
        return billing_street_address;
    }

    public void setBilling_street_address(String billing_street_address) {
        this.billing_street_address = billing_street_address;
    }

    public String getBilling_suburb() {
        return billing_suburb;
    }

    public void setBilling_suburb(String billing_suburb) {
        this.billing_suburb = billing_suburb;
    }

    public String getBilling_city() {
        return billing_city;
    }

    public void setBilling_city(String billing_city) {
        this.billing_city = billing_city;
    }

    public String getBilling_postcode() {
        return billing_postcode;
    }

    public void setBilling_postcode(String billing_postcode) {
        this.billing_postcode = billing_postcode;
    }

    public String getBilling_state() {
        return billing_state;
    }

    public void setBilling_state(String billing_state) {
        this.billing_state = billing_state;
    }

    public String getBilling_country() {
        return billing_country;
    }

    public void setBilling_country(String billing_country) {
        this.billing_country = billing_country;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public String getShipping_method() {
        return shipping_method;
    }

    public void setShipping_method(String shipping_method) {
        this.shipping_method = shipping_method;
    }

    public List<OrderProducts> getProducts() {
        return products;
    }

    public void setProducts(List<OrderProducts> products) {
        this.products = products;
    }

    public String getTotal_tax() {
        return total_tax;
    }

    public void setTotal_tax(String total_tax) {
        this.total_tax = total_tax;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public String getCoupon_amount() {
        return coupon_amount;
    }

    public void setCoupon_amount(String coupon_amount) {
        this.coupon_amount = coupon_amount;
    }

    //********** Writes the values to the Parcel *********//

    public void writeToParcel(Parcel parcel_out, int flags) {

        parcel_out.writeValue(delivery_name);
        parcel_out.writeValue(delivery_street_address);
        parcel_out.writeValue(delivery_suburb);
        parcel_out.writeValue(delivery_city);
        parcel_out.writeValue(delivery_postcode);
        parcel_out.writeValue(delivery_locality);
        parcel_out.writeValue(address_book_id);
        parcel_out.writeValue(billing_name);
        parcel_out.writeValue(billing_street_address);
        parcel_out.writeValue(billing_suburb);
        parcel_out.writeValue(billing_city);
        parcel_out.writeValue(billing_postcode);
        parcel_out.writeValue(billing_state);
        parcel_out.writeValue(billing_country);
        parcel_out.writeValue(payment_method);
        parcel_out.writeValue(shipping_method);
        parcel_out.writeValue(date_purchased);
        parcel_out.writeValue(start_time);
        parcel_out.writeValue(end_time);
        parcel_out.writeValue(schedule_date);
        parcel_out.writeValue(shipping_cost);
        parcel_out.writeValue(total_tax);
        parcel_out.writeValue(coupon_amount);
        parcel_out.writeList(products);
    }



    //********** Generates Instances of Parcelable class from a Parcel *********//

    public static final Parcelable.Creator<ViewOrderDetails> CREATOR = new Parcelable.Creator<ViewOrderDetails>() {

        // Creates a new Instance of the Parcelable class, Instantiating it from the given Parcel
        @Override
        public ViewOrderDetails createFromParcel(Parcel parcel_in) {
            return new ViewOrderDetails(parcel_in);
        }

        // Creates a new array of the Parcelable class
        @Override
        public ViewOrderDetails[] newArray(int size) {
            return new ViewOrderDetails[size];
        }
    };



    //********** Retrieves the values from the Parcel *********//

    protected ViewOrderDetails(Parcel parcel_in) {
        this.delivery_name = parcel_in.readString();
        this.delivery_street_address = parcel_in.readString();
        this.delivery_suburb = parcel_in.readString();
        this.delivery_city = parcel_in.readString();
        this.delivery_postcode = parcel_in.readString();
        this.delivery_locality = parcel_in.readString();
        this.address_book_id = parcel_in.readString();
        this.billing_name = parcel_in.readString();
        this.billing_street_address = parcel_in.readString();
        this.billing_suburb = parcel_in.readString();
        this.billing_postcode = parcel_in.readString();
        this.billing_state = parcel_in.readString();
        this.billing_country = parcel_in.readString();
        this.payment_method = parcel_in.readString();
        this.shipping_method = parcel_in.readString();
        this.date_purchased = parcel_in.readString();
        this.start_time = parcel_in.readString();
        this.end_time = parcel_in.readString();
        this.schedule_date = parcel_in.readString();
        this.shipping_cost = parcel_in.readString();
        this.total_tax = parcel_in.readString();
        this.coupon_amount = parcel_in.readString();
        this.products = new ArrayList<OrderProducts>();
        parcel_in.readList(products, OrderProducts.class.getClassLoader());
    }
}
