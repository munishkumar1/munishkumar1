package com.nextstack.chicken.customerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.models.chat_model.Chat;

import java.util.List;

public class MessageListAdapter extends RecyclerView.Adapter<MessageListAdapter.MyViewHolder> {


    public static final int MSG_TYPE_LEFT = 0;
    public static final int MSG_TYPE_RIGHT = 1;
    public static final int MSG_TYPE_IMG_LEFT = 2;
    public static final int MSG_TYPE_IMG_RIGHT = 3;

    private Context mContext;
    private List<Chat> mChat;

    FirebaseUser firebaseUser;

    public MessageListAdapter(Context mContext, List<Chat> mChat) {
        this.mContext = mContext;
        this.mChat = mChat;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        if (viewType == MSG_TYPE_RIGHT) {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_right, parent, false);
            return new MessageListAdapter.MyViewHolder(view);
        } else if(viewType == MSG_TYPE_LEFT) {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_left, parent, false);
            return new MessageListAdapter.MyViewHolder(view);
        } else if(viewType == MSG_TYPE_IMG_RIGHT) {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_right_img, parent, false);
            return new MessageListAdapter.MyViewHolder(view);
        } else {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_left_img, parent, false);
            return new MessageListAdapter.MyViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Chat chat = mChat.get(position);
        if (!chat.getMessage().equals("")) {
            holder.show_message.setText(chat.getMessage());
        } else {
            Glide.with(mContext)
                    .load(chat.getImage())
                    .override(100, 100)
                    .fitCenter()
                    .into(holder.show_image);
        }

    }


    @Override
    public int getItemCount() {
        return mChat.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        public TextView show_message;
        public ImageView show_image;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            show_message = itemView.findViewById(R.id.show_message);
            show_image = itemView.findViewById(R.id.show_image);
        }
    }

    @Override
    public int getItemViewType(int position) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        if(!mChat.get(position).getMessage().equals("")) {
            if(mChat.get(position).getSender().equals(firebaseUser.getUid())) {
                return MSG_TYPE_RIGHT;
            } else {
                return MSG_TYPE_LEFT;
            }
        } else {
            if(mChat.get(position).getSender().equals(firebaseUser.getUid())) {
                return MSG_TYPE_IMG_RIGHT;
            } else {
                return MSG_TYPE_IMG_LEFT;
            }
        }
    }
}
