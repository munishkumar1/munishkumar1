package com.nextstack.chicken.customerapp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.fragment.ChatBox;
import com.nextstack.chicken.customerapp.utils.Utilities;

public class ChatActivity extends AppCompatActivity {

    TextView chat_retailer, chat_support;

    Toolbar toolbar;
    EditText searchBar;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

       getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        chat_retailer = findViewById(R.id.chat_box_retailer);
        chat_support = findViewById(R.id.chat_box_support);

        final Intent i = new Intent(ChatActivity.this, MainActivity.class);

        final Fragment fragment = new ChatBox();
        final FragmentManager fragmentManager = getSupportFragmentManager();

        toolbar = findViewById(R.id.mytoolbar);
        toolbar.setTitle(getString(R.string.chat));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        searchBar = findViewById(R.id.search_bar);

        searchBar.setVisibility(View.GONE);

        chat_support.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i.putExtra("fragment", "ChatSupport");
                startActivity(i);

            }

        });
        chat_retailer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i.putExtra("fragment", "retailer");
                startActivity(i);

            }

        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.toolbar_menu, menu);

        MenuItem cartItem = menu.findItem(R.id.toolbar_ic_cart);
        MenuItem profileItem = menu.findItem(R.id.toolbar_ic_profile);

        Utilities.tintMenuIcon(ChatActivity.this, cartItem, R.color.white);
        Utilities.tintMenuIcon(ChatActivity.this, profileItem, R.color.white);


        return true;
    }
}
