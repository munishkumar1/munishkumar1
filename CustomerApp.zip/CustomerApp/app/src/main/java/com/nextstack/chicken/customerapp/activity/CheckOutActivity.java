package com.nextstack.chicken.customerapp.activity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.adapters.AddressListAdapter;
import com.nextstack.chicken.customerapp.adapters.CartItemsAdapter;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.constant.ConstantValues;
import com.nextstack.chicken.customerapp.customs.DialogLoader;
import com.nextstack.chicken.customerapp.databases.User_Cart_DB;
import com.nextstack.chicken.customerapp.fragment.Addresses;
import com.nextstack.chicken.customerapp.models.address_model.AddressData;
import com.nextstack.chicken.customerapp.models.address_model.AddressDetails;
import com.nextstack.chicken.customerapp.models.address_model.CountryDetails;
import com.nextstack.chicken.customerapp.models.address_model.ZoneDetails;
import com.nextstack.chicken.customerapp.models.address_model.Zones;
import com.nextstack.chicken.customerapp.models.cart_model.CartProduct;
import com.nextstack.chicken.customerapp.network.APIClient;
import com.nextstack.chicken.customerapp.utils.Utilities;
import com.nextstack.chicken.customerapp.utils.ValidateInputs;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckOutActivity extends AppCompatActivity {

    View view;

    String customerID;
    String defaultAddressID;

    public EditText address;
    EditText DeliveryDate, fromTime, toTime;
    TextView address_text;
    public TextView delivery, min_order,itemTotal, deliveryCharge, totalPrice,total_tax;

    RecyclerView cart_items_recycler;
    DialogLoader dialogLoader;

    LinearLayout cart_view, cart_view_empty, delivery_options;
    Button cart_payment_btn, continue_shopping_btn, self_pick_up, home_delivery;

    Toolbar toolbar;
    ActionBar actionBar;

    CartItemsAdapter cartItemsAdapter;
    User_Cart_DB user_cart_db = new User_Cart_DB();

    List<CartProduct> cartItemsList = new ArrayList<>();
    List<AddressDetails> addressList = new ArrayList<>();
    AddressListAdapter addressAdapter;

    private int mHour, mMinute;
    private boolean addressSellected = false;
    String selectedShipping = " ";

    List<String> zoneNames, countryNames;
    List<ZoneDetails> zoneList = new ArrayList<>();
    List<CountryDetails> countryList = new ArrayList<>();

    String selectedZone, selectedCountryID, shopStatus;


    ArrayAdapter<String> zoneAdapter;
    ArrayAdapter<String> countryAdapter;

    boolean isAddessAdded = false;

    int defaultAddressPosition = -1;

    SharedPreferences sharedPreferences;

    MyAppPrefsManager session;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (ConstantValues.IS_USER_LOGGED_IN) {
            setContentView(R.layout.activity_check_out);

            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

            session = new MyAppPrefsManager(this);

            shopStatus = session.getShopStatus();

            cartItemsList = user_cart_db.getCartItems(session.getAppCategoryId());

            cart_items_recycler = findViewById(R.id.cart_item_recycler);
            DeliveryDate = findViewById(R.id.date);
            fromTime = findViewById(R.id.fromTime);
            toTime = findViewById(R.id.toTime);
            delivery = findViewById(R.id.delivery);
            min_order = findViewById(R.id.min_order);
            toolbar = findViewById(R.id.mytoolbar);
            cart_view = findViewById(R.id.cart_view);
            cart_view_empty = findViewById(R.id.cart_view_empty);
            continue_shopping_btn = findViewById(R.id.continue_shopping_btn);
            cart_payment_btn = findViewById(R.id.paymentButton);
            address = findViewById(R.id.address);
            itemTotal = findViewById(R.id.item_total);
            totalPrice = findViewById(R.id.total);
            deliveryCharge = findViewById(R.id.delivery_charge);
            address_text = findViewById(R.id.address_text);
            delivery_options = findViewById(R.id.delivery_options);
            self_pick_up = findViewById(R.id.self_pick_up);
            home_delivery = findViewById(R.id.home_delivery);
            total_tax = findViewById(R.id.total_tax);

            dialogLoader = new DialogLoader(this);

            setSupportActionBar(toolbar);
            actionBar = getSupportActionBar();
            actionBar.setTitle(getString(R.string.checkout));
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);

            if (cartItemsList.size() != 0) {
                cart_view.setVisibility(View.VISIBLE);
                cart_view_empty.setVisibility(View.GONE);
            } else {
                cart_view.setVisibility(View.GONE);
                cart_view_empty.setVisibility(View.VISIBLE);
            }

            DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
            DateFormat formatter1 = new SimpleDateFormat("hh:mm aa", Locale.getDefault());
            Date date = new Date();
            Date time1 = new Date();
            Date time2 = new Date(time1.getTime() + (3600 * 1000));

            try {
                DeliveryDate.setText(formatter.format(date));
                fromTime.setText(formatter1.format(time1));
                toTime.setText(formatter1.format(time2));
            } catch (Exception e) {
                e.printStackTrace();
            }

            customerID = this.getSharedPreferences("UserInfo", MODE_PRIVATE).getString("userID", "");
            defaultAddressID = this.getSharedPreferences("UserInfo", MODE_PRIVATE).getString("userDefaultAddressID", "0");


            DeliveryDate.setKeyListener(null);

            RequestAllAddresses();

            if (defaultAddressPosition >= 0)
            address.setText(addressList.get(defaultAddressPosition -1).getStreet()+","+addressList.get(defaultAddressPosition -1).getCity()+","+addressList.get(defaultAddressPosition -1).getCountryName());

            final Intent i = new Intent(CheckOutActivity.this, Payment.class);

            DeliveryDate.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent event) {

                    if (event.getAction() == MotionEvent.ACTION_UP) {
                        // Get Calendar instance
                        final Calendar calendar = Calendar.getInstance();

                        // Initialize DateSetListener of DatePickerDialog
                        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                                // Set the selected Date Info to Calendar instance
                                calendar.set(Calendar.YEAR, year);
                                calendar.set(Calendar.MONTH, monthOfYear);
                                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                                // Set Date Format
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

                                // Set Date in input_dob EditText
                                DeliveryDate.setText(dateFormat.format(calendar.getTime()));
                            }
                        };


                        // Initialize DatePickerDialog
                        DatePickerDialog datePicker = new DatePickerDialog
                                (
                                        CheckOutActivity.this,
                                        date,
                                        calendar.get(Calendar.YEAR),
                                        calendar.get(Calendar.MONTH),
                                        calendar.get(Calendar.DAY_OF_MONTH)
                                );

                        // Show datePicker Dialog
                        datePicker.show();
                    }

                    return false;
                }
            });


            Calendar calendar = Calendar.getInstance();


            mHour = calendar.get(Calendar.HOUR_OF_DAY);
            mMinute = calendar.get(Calendar.MINUTE);

            fromTime.setOnTouchListener(new View.OnTouchListener() {

                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {

                    final boolean ret = address.onTouchEvent(motionEvent);
                    final InputMethodManager imm = ((InputMethodManager) CheckOutActivity.this
                            .getSystemService(Context.INPUT_METHOD_SERVICE));
                    try{
                        imm.hideSoftInputFromWindow(address.getApplicationWindowToken(), 0);
                    }catch(Exception e){
                        e.printStackTrace();
                    }

                    if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                        TimePickerDialog timePickerDialog = new TimePickerDialog(CheckOutActivity.this, new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker timePicker, int hour, int minute) {

                                String am_pm = "";

                                Calendar datetime = Calendar.getInstance();
                                datetime.set(Calendar.HOUR_OF_DAY, hour);
                                datetime.set(Calendar.MINUTE, minute);

                                if (datetime.get(Calendar.AM_PM) == Calendar.AM)
                                    am_pm = "AM";
                                else if (datetime.get(Calendar.AM_PM) == Calendar.PM)
                                    am_pm = "PM";

                                String strHrsToShow = (datetime.get(Calendar.HOUR) == 0) ?"12":datetime.get(Calendar.HOUR)+"";
                                String strMinToShow = (datetime.get(Calendar.MINUTE) == 0) ? "00":datetime.get(Calendar.MINUTE)+"";
                                fromTime.setText(strHrsToShow+":"+strMinToShow+" " +am_pm);
                            }
                        }, mHour, mMinute, false);

                        timePickerDialog.show();

                    }
                    return ret;
                }
            });

            toTime.setOnTouchListener(new View.OnTouchListener() {

                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {

                    final boolean ret = address.onTouchEvent(motionEvent);
                    final InputMethodManager imm = ((InputMethodManager) CheckOutActivity.this
                            .getSystemService(Context.INPUT_METHOD_SERVICE));
                    try{
                        imm.hideSoftInputFromWindow(address.getApplicationWindowToken(), 0);
                    }catch(Exception e){
                        e.printStackTrace();
                    }

                    if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                        TimePickerDialog timePickerDialog = new TimePickerDialog(CheckOutActivity.this, new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker timePicker, int hour, int minute) {

                                String am_pm = "";

                                Calendar datetime = Calendar.getInstance();
                                datetime.set(Calendar.HOUR_OF_DAY, hour);
                                datetime.set(Calendar.MINUTE, minute);

                                if (datetime.get(Calendar.AM_PM) == Calendar.AM)
                                    am_pm = "AM";
                                else if (datetime.get(Calendar.AM_PM) == Calendar.PM)
                                    am_pm = "PM";

                                String strHrsToShow = (datetime.get(Calendar.HOUR) == 0) ?"12":datetime.get(Calendar.HOUR)+"";
                                String strMinToShow = (datetime.get(Calendar.MINUTE) == 0) ? "00":datetime.get(Calendar.MINUTE)+"";
                                toTime.setText(strHrsToShow+":"+strMinToShow+" " +am_pm);
                            }
                        }, mHour, mMinute, false);

                        timePickerDialog.show();

                    }
                    return ret;
                }
            });

            min_order.setText("Minimum Order : 200");
            delivery.setText("Free Delivery");


            // Initialize the AddressListAdapter for RecyclerView
            cartItemsAdapter = new CartItemsAdapter(CheckOutActivity.this, cartItemsList, CheckOutActivity.this);

            // Set the Adapter and LayoutManager to the RecyclerView
            cart_items_recycler.setAdapter(cartItemsAdapter);
            cart_items_recycler.setLayoutManager(new LinearLayoutManager(CheckOutActivity.this, RecyclerView.VERTICAL, false));


            // Show the Cart's Total Price with the help of static method of CartItemsAdapter
            cartItemsAdapter.setCartTotal();


            cartItemsAdapter.notifyDataSetChanged();

            // Handle Click event of continue_shopping_btn Button
            continue_shopping_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent i = new Intent(CheckOutActivity.this, MainActivity.class);
                    i.putExtra("fragment", getString(R.string.home));
                    startActivity(i);
                    CheckOutActivity.this.finish();
                    CheckOutActivity.this.overridePendingTransition(R.anim.enter_from_left, R.anim.exit_out_left);

                }
            });

            sharedPreferences = getSharedPreferences("UserInfo", MODE_PRIVATE);
            address.setVisibility(View.GONE);
            address_text.setVisibility(View.GONE);

            self_pick_up.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    address.setVisibility(View.GONE);

                    address_text.setVisibility(View.VISIBLE);
                    address_text.setText(getString(R.string.self_pickup));

                    selectedShipping = "Self Pickup";

                    /*i.putExtra("firstName", " ");
                    i.putExtra("lastName", " ");
                    i.putExtra("street", " ");
                    i.putExtra("city", " ");
                    i.putExtra("suburb", " ");
                    i.putExtra("postcode", " ");
                    i.putExtra("zoneName", " ");*/

                }
            });

            home_delivery.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    selectedShipping = "Home Delivery";


                    address_text.setVisibility(View.VISIBLE);
                    address_text.setText(getString(R.string.address));

                    address.setVisibility(View.VISIBLE);

                }
            });

            RequestAllAddresses();

            address.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {

                    final boolean ret = address.onTouchEvent(motionEvent);
                    final InputMethodManager imm = ((InputMethodManager) CheckOutActivity.this
                            .getSystemService(Context.INPUT_METHOD_SERVICE));
                    try{
                        imm.hideSoftInputFromWindow(address.getApplicationWindowToken(), 0);
                    }catch(Exception e){
                        e.printStackTrace();
                    }

                    if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {

                        final AlertDialog.Builder dialog = new AlertDialog.Builder(CheckOutActivity.this);
                        View dialogView = CheckOutActivity.this.getLayoutInflater().inflate(R.layout.dialog_recycler, null);
                        dialog.setView(dialogView);
                        dialog.setCancelable(false);

                        Button dialog_button = dialogView.findViewById(R.id.dialog_button);
                        TextView dialog_title = dialogView.findViewById(R.id.dialog_title);
                        RecyclerView addresses_recycler = dialogView.findViewById(R.id.addresses_recycler);
                        TextView add_address = dialogView.findViewById(R.id.add_address);

                        dialog_title.setText(getString(R.string.selectAddress));


                        final AlertDialog alertDialog = dialog.create();

                        add_address.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                alertDialog.dismiss();

                                Intent i = new Intent(CheckOutActivity.this, MainActivity.class);
                                i.putExtra("fragment", getString(R.string.actionAddresses));
                                startActivity(i);

                                dialog.show();

                            }
                        });

                        addressAdapter = new AddressListAdapter(CheckOutActivity.this, customerID, defaultAddressPosition, addressList, new AddressListAdapter.OnItemClickListener() {
                            @Override
                            public void onItemClick(AddressDetails item) {

                                alertDialog.dismiss();
                                i.putExtra("firstName", item.getFirstname());
                                i.putExtra("lastName", item.getLastname());
                                i.putExtra("street", item.getStreet());
                                i.putExtra("city", item.getCity());
                                i.putExtra("suburb", item.getSuburb());
                                i.putExtra("postcode", item.getPostcode());
                                i.putExtra("zoneName", item.getState());
                                i.putExtra("address_id", item.getAddressId());

                                //i.putExtra("countryName", item.getCountryName());
                                //i.putExtra("zoneId", item.getZoneId());
                                //i.putExtra("countryId", item.getCountriesId());

                                addressSellected = true;

                            }
                        }, CheckOutActivity.this);

                        addresses_recycler.setLayoutManager(new LinearLayoutManager(CheckOutActivity.this, RecyclerView.VERTICAL, false));
                        addresses_recycler.setVerticalScrollBarEnabled(true);
                        addresses_recycler.setAdapter(addressAdapter);

                        addressAdapter.notifyDataSetChanged();

                        dialog_button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                alertDialog.dismiss();
                            }
                        });

                        alertDialog.show();



                    }


                    return ret;
                }

            });


            // Handle Click event of cart_checkout_btn Button
            cart_payment_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    // Check if cartItemsList isn't empty
                    if (cartItemsList.size() != 0) {

                        // Check if User is Logged-In
                        if (ConstantValues.IS_USER_LOGGED_IN) {


                            if (addressSellected == false)
                            {
                                for (AddressDetails item : addressList)
                                {
                                    if (item.getAddressId() == Integer.parseInt(sharedPreferences.getString("userDefaultAddressID", "0")))
                                    {
                                        address.setText(item.getStreet()+ " ," + item.getCity() + " ," + item.getCountryName());

                                        i.putExtra("firstName", item.getFirstname());
                                        i.putExtra("lastName", item.getLastname());
                                        i.putExtra("street", item.getStreet());
                                        i.putExtra("city", item.getCity());
                                        i.putExtra("suburb", item.getSuburb());
                                        i.putExtra("postcode", item.getPostcode());
                                        i.putExtra("zoneName", item.getState());
                                      //  i.putExtra("address_id", item.getAddressId());

                                    }
                                }
                            }



                            i.putExtra("delivery_date", DeliveryDate.getText().toString());
                            i.putExtra("start_time", fromTime.getText().toString());
                            i.putExtra("checkoutTotal", Double.parseDouble(totalPrice.getText().toString()));
                            i.putExtra("total_tax", total_tax.getText().toString());
                            i.putExtra("end_time", toTime.getText().toString());
                            i.putExtra("shipping_method", selectedShipping);
                            i.putExtra("shop_status", shopStatus);
                            CheckOutActivity.this.finish();
                            startActivity(i);


                        } else {
                            // Navigate to Login Activity
                            Intent i = new Intent(CheckOutActivity.this, LoginActivity.class);
                            CheckOutActivity.this.startActivity(i);
                            CheckOutActivity.this.finish();
                            CheckOutActivity.this.overridePendingTransition(R.anim.enter_from_left, R.anim.exit_out_left);
                        }
                    }
                }
            });

        }
        else {
            Intent i = new Intent(CheckOutActivity.this, LoginActivity.class);
            startActivity(i);
        }

    }


    //*********** Change the Layout View of My_Cart Fragment based on Cart Items ********//

    public void updateCartView(int cartListSize) {

        // Check if Cart has some Items
        if (cartListSize != 0) {
            cart_view.setVisibility(View.VISIBLE);
            cart_view_empty.setVisibility(View.GONE);
        } else {
            cart_view.setVisibility(View.GONE);
            cart_view_empty.setVisibility(View.VISIBLE);
        }
    }

    public void RequestAllAddresses() {

        dialogLoader.showProgressDialog();

        Call<AddressData> call = APIClient.getNetInstance(false)
                .getAllAddress
                        (
                                Integer.parseInt(customerID)
                        );

        call.enqueue(new Callback<AddressData>() {
            @Override
            public void onResponse(Call<AddressData> call, retrofit2.Response<AddressData> response) {

                dialogLoader.hideProgressDialog();

                // Check if the Response is successful
                if (response.isSuccessful()) {
                    if (response.body().getSuccess() == 1) {

                        // Addresses have been returned. Add Addresses to the addressesList
                        addressList = response.body().getData();



                        for (int i=0;  i<addressList.size();  i++) {
                            if (addressList.get(i).getAddressId() == Integer.parseInt(defaultAddressID)) {
                                defaultAddressPosition = i;
                            }
                        }

                        if (addressList.size() == 1) {
                            defaultAddressPosition = 1;
                            Addresses.MakeAddressDefault(customerID, String.valueOf(addressList.get(0).getAddressId()), CheckOutActivity.this, null  );

                        }


                        for (AddressDetails item : addressList)
                        {
                            if (item.getAddressId() == Integer.parseInt(sharedPreferences.getString("userDefaultAddressID", "0")))
                            {
                                address.setText(item.getStreet()+ " ," + item.getCity() + " ," + item.getCountryName());
                            }
                        }


                    }
                    else if (response.body().getSuccess() == 0) {
                        // Addresses haven't been returned. Show the Message to the User
                        Toast.makeText(CheckOutActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                    }
                    else {
                        // Unable to get Success status
                        Toast.makeText(CheckOutActivity.this, getString(R.string.unexpected_response), Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(CheckOutActivity.this, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AddressData> call, Throwable t) {
                Toast.makeText(CheckOutActivity.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.toolbar_menu, menu);

        MenuItem cartItem = menu.findItem(R.id.toolbar_ic_cart);
        MenuItem profileItem = menu.findItem(R.id.toolbar_ic_profile);

        Utilities.tintMenuIcon(CheckOutActivity.this, cartItem, R.color.white);
        Utilities.tintMenuIcon(CheckOutActivity.this, profileItem, R.color.white);

        cartItem.setVisible(false);
        profileItem.setVisible(true);

        return true;
    }
}
