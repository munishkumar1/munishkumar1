package com.nextstack.chicken.customerapp.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.adapters.ShopListAdapter;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.location.GPSTracker;
import com.nextstack.chicken.customerapp.models.shop_model.ShopData;
import com.nextstack.chicken.customerapp.models.shop_model.ShopDetails;
import com.nextstack.chicken.customerapp.network.APIClient;
import com.nextstack.chicken.customerapp.utils.Utilities;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

public class MovingVendorsActivity extends AppCompatActivity implements OnMapReadyCallback {

    SupportMapFragment mapFragment;
    GoogleMap mMap;

    Toolbar toolbar;
    EditText searchBar;

    RecyclerView vendor_recyclerView;
    ShopListAdapter shopListAdapter;

    GPSTracker gps;
    Location location;

    int category_id;

    List<ShopDetails> shopsList = new ArrayList<ShopDetails>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moving_vendors);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        searchBar = findViewById(R.id.search_bar);
        vendor_recyclerView = findViewById(R.id.vendor_recyclerView);

        toolbar = findViewById(R.id.mytoolbar);
        toolbar.setTitle(getString(R.string.actionMovingVendors));
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        MyAppPrefsManager myAppPrefsManager = new MyAppPrefsManager(this);
        category_id = Integer.parseInt(myAppPrefsManager.getAppCategoryId());



        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        gps = new GPSTracker(this);
        if(gps.canGetLocation()){
            location = gps.getLocation();
        }
        else{
            Toast.makeText(this, "Can not get Location", Toast.LENGTH_LONG).show();
        }



    }

    protected Marker createMarker(double latitude, double longitude, String title, String snippet, int iconResID) {

        return mMap.addMarker(new MarkerOptions()
                .position(new LatLng(latitude, longitude))
                .anchor(0.5f, 0.5f)
                .title(title)
                .snippet(snippet)
                .icon(Utilities.bitmapDescriptorFromVector(this, R.drawable.ic_location)));
    }



    public void RequestShopList() {

        Call<ShopData> call = APIClient.getNetInstance(false)
                .getDistributors
                        (
                                category_id
                        );

        call.enqueue(new Callback<ShopData>() {
            @Override
            public void onResponse(Call<ShopData> call, retrofit2.Response<ShopData> response) {

                // Check if the Response is successful
                if (response.isSuccessful()) {
                    if (response.body().getSuccess() == 1) {

                        // Orders have been returned. Add Orders to the ordersList
                        addShops(response.body());

                        if (response.body().getData().getMovable() != null) {

                            for (int i = 0; i < response.body().getData().getMovable().size(); i++) {
                                createMarker(Double.parseDouble(response.body().getData().getMovable().get(i).getShopLat()),
                                        Double.parseDouble(response.body().getData().getMovable().get(i).getShopLng()),
                                        response.body().getData().getMovable().get(i).getDistributorShop(),
                                        response.body().getData().getMovable().get(i).getStoreAddress(),
                                        R.drawable.ic_location);
                            }

                        }
                    }
                    else if (response.body().getSuccess() == 0) {
                        Toast.makeText(MovingVendorsActivity.this, response.body().getMessage(), Toast.LENGTH_LONG).show();

                    }
                    else {
                        // Unable to get Success status
                        Toast.makeText(MovingVendorsActivity.this, getString(R.string.unexpected_response), Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(MovingVendorsActivity.this, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ShopData> call, Throwable t) {
                Toast.makeText(MovingVendorsActivity.this, "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
                Log.d("Home Fragment :","NetworkCallFailure : ",t);
            }
        });
    }


    private void addShops(ShopData shopData) {

        // Add Orders to ordersList from the List of OrderData
        shopsList.clear();
        if (shopData.getData().getMovable()!=null) {
            shopsList = shopData.getData().getMovable();

            // Initialize the OrdersListAdapter for RecyclerView
            shopListAdapter = new ShopListAdapter(MovingVendorsActivity.this, location, shopsList, new ShopListAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(ShopDetails item) {

                    Intent i = new Intent(MovingVendorsActivity.this, ShopMenuActivity.class);
                    i.putExtra("shopLat", item.getShopLat());
                    i.putExtra("shopLng", item.getShopLng());
                    i.putExtra("categoriesName", item.getCategoriesName());
                    i.putExtra("shopName", item.getDistributorShop());
                    i.putExtra("distributor_id", item.getShopId());
                    i.putExtra("device_id", item.getFirebase_id());
                    i.putExtra("delivery_charge", item.getShipping_cost());
                    i.putExtra("gst_tax", item.getGst_tax());
                    i.putExtra("shop_status", item.getShop_status());
                    startActivity(i);

                }
            });

            // Set the Adapter and LayoutManager to the RecyclerView
            vendor_recyclerView.setAdapter(shopListAdapter);

            LinearLayoutManager layoutManager = new LinearLayoutManager(MovingVendorsActivity.this, RecyclerView.VERTICAL, false);

            vendor_recyclerView.setLayoutManager(layoutManager);


            shopListAdapter.notifyDataSetChanged();
        }

    }


    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        Log.d("GPS", "onMapReady: " + gps.getLocation().getLatitude() + ", " +
                gps.getLocation().getLongitude());
        mMap = googleMap;

        LatLng yourLocation = new LatLng(gps.getLocation().getLatitude(), gps.getLocation().getLongitude());
        mMap.addMarker(new MarkerOptions().position(yourLocation).title("My Current Location")).setDraggable(true);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(yourLocation));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));

        RequestShopList();

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.toolbar_menu, menu);

        MenuItem cartItem = menu.findItem(R.id.toolbar_ic_cart);
        MenuItem profileItem = menu.findItem(R.id.toolbar_ic_profile);

        Utilities.tintMenuIcon(MovingVendorsActivity.this, cartItem, R.color.white);
        Utilities.tintMenuIcon(MovingVendorsActivity.this, profileItem, R.color.white);


        return true;
    }
}
