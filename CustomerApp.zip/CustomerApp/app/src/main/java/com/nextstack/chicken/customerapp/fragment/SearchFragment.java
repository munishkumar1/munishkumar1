package com.nextstack.chicken.customerapp.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.MainActivity;
import com.nextstack.chicken.customerapp.activity.Payment;
import com.nextstack.chicken.customerapp.adapters.SearchResultsAdapter;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.models.faq_model.FaqData;
import com.nextstack.chicken.customerapp.models.product_model.ProductDetails;
import com.nextstack.chicken.customerapp.models.search_model.SearchData;
import com.nextstack.chicken.customerapp.models.search_model.SearchResults;
import com.nextstack.chicken.customerapp.network.APIClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SearchFragment extends Fragment {

    View rootView;

    RecyclerView products_recycler;
    TextView resultCount;

    List<SearchResults> resultsList;
    ArrayList<Integer> distributor_ids = new ArrayList<>();

    SearchResultsAdapter searchProductsAdapter;

    String searchText;
    
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.search_fragment, container, false);

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        setHasOptionsMenu(true);

        MainActivity.actionBarDrawerToggle.setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(getString(R.string.actionSearch));

        if (getArguments() != null) {
            if (getArguments().containsKey("searchText")) {
                searchText = getArguments().getString("searchText", "");

                saveSearch(searchText);
            }
        }


        //search_editText
        products_recycler = rootView.findViewById(R.id.products_recycler);
        resultCount = rootView.findViewById(R.id.resultText);


        products_recycler.setNestedScrollingEnabled(false);

        // Hide some of the Views
        products_recycler.setVisibility(View.GONE);

        resultsList = new ArrayList<>();

        if (searchText != null) {
            RequestSearchData(searchText);
        }


        return rootView;
    }

    private void saveSearch(String searchText) {

        Call<FaqData> call1 = APIClient.getNetInstance(false).saveSearch
                (
                        searchText
                );

        call1.enqueue(new Callback<FaqData>() {
            @Override
            public void onResponse(Call<FaqData> call, Response<FaqData> response) {

                if (response.isSuccessful()) {


                    Toast.makeText(getContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();

                } else {
                    // Show the Error Message
                    Toast.makeText(getContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<FaqData> call, Throwable t) {

                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();

            }
        });


    }

    //*********** Adds SearchResults returned from the Server to the resultsList ********//

    private void addResults(SearchData searchData) {

        // Get the model SearchDetails from SearchData
        List<ProductDetails> searchResults = searchData.getProductData();


        if (searchResults.size() > 0) {

            // Make CategoriesList Visible
            products_recycler.setVisibility(View.VISIBLE);


            resultCount.setText("Showing " + searchResults.size() + " Products");

            // Initialize the SearchResultsAdapter for RecyclerView
            searchProductsAdapter = new SearchResultsAdapter(getContext(), searchResults, distributor_ids);

            // Set the Adapter, LayoutManager and ItemDecoration to the RecyclerView
            products_recycler.setAdapter(searchProductsAdapter);
            products_recycler.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
            products_recycler.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));

            searchProductsAdapter.notifyDataSetChanged();

        }
        else {

            resultCount.setText(getString(R.string.no_products_found));

        }

    }



    //*********** Request Search Results from the Server based on the given Query ********//

    public void RequestSearchData(String searchValue) {

        MyAppPrefsManager myAppPrefsManager = new MyAppPrefsManager(getContext());
        
        Call<SearchData> call = APIClient.getNetInstance(false)
                .getSearchData
                        (
                                searchValue,
                                Integer.parseInt(myAppPrefsManager.getAppCategoryId())
                        );

        call.enqueue(new Callback<SearchData>() {
            @Override
            public void onResponse(Call<SearchData> call, retrofit2.Response<SearchData> response) {
                
                if (response.isSuccessful()) {
                    if (response.body().getSuccess() == 1) {

                        // Search Results have been returned. Add Results to the resultsList
                        addResults(response.body());

                    }
                    else if (response.body().getSuccess() == 0) {
                        Snackbar.make(rootView, response.body().getMessage(), Snackbar.LENGTH_LONG).show();
    
                    }

                    else {
                        // Unable to get Success status
                        Snackbar.make(rootView, getContext().getString(R.string.unexpected_response), Snackbar.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<SearchData> call, Throwable t) {
                Toast.makeText(getContext(), "NetworkCallFailure : "+t, Toast.LENGTH_LONG).show();
            }
        });
    }
}



