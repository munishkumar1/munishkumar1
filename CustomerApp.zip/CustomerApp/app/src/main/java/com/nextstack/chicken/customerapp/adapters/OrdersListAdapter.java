package com.nextstack.chicken.customerapp.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.activity.MainActivity;
import com.nextstack.chicken.customerapp.app.MyAppPrefsManager;
import com.nextstack.chicken.customerapp.app.SharedHelper;
import com.nextstack.chicken.customerapp.models.faq_model.FaqData;
import com.nextstack.chicken.customerapp.models.order_model.GetOrderData;
import com.nextstack.chicken.customerapp.models.order_model.OrderDetails;
import com.nextstack.chicken.customerapp.models.order_model.ViewOrderDetails;
import com.nextstack.chicken.customerapp.network.APIClient;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * OrdersListAdapter is the adapter class of RecyclerView holding List of Orders in My_Orders
 **/

public class OrdersListAdapter extends RecyclerView.Adapter<OrdersListAdapter.MyViewHolder> {

Context context;
    String customerID;
    String message ="done";
    List<OrderDetails> ordersList;
    ViewOrderDetails orderDetails;
    List<GetOrderData.Data.Products> productsList;
    MyAppPrefsManager session;
    Boolean val = true;
    String totalStars;
    // float ans = (float) 0.0;
   int rating ;

    Intent i;

    ArrayAdapter<String> adapter;


    public OrdersListAdapter(Context context, String customerID, List<OrderDetails> ordersList, List<GetOrderData.Data.Products> productsList) {
     this.context = context;
        this.customerID = customerID;
        this.ordersList = ordersList;
        this.productsList = productsList;
        i = new Intent(context, MainActivity.class);
        session = new MyAppPrefsManager(context);
    }


    //********** Called to Inflate a Layout from XML and then return the Holder *********//

    @Override
    public MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        // Inflate the custom layout
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_card_orders, parent, false);

        return new MyViewHolder(itemView);
    }


    //********** Called by RecyclerView to display the data at the specified Position *********//

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {


        // Get the data model based on Position
        final OrderDetails orderDetails = ordersList.get(position);
        List<GetOrderData.Data.Products> products = new ArrayList<>();
        List<String> productNames = new ArrayList<>();
        for (int i = 0; i < productsList.size(); i++) {

            if (productsList.get(i).getOrders_id() == orderDetails.getOrdersId()) {
                products.add(productsList.get(i));
                productNames.add(productsList.get(i).getProducts_name());
            }

        }
        orderDetails.setProductsList(products);

        int noOfProducts = 0;
        for (int i = 0; i < orderDetails.getProductsList().size(); i++) {
            // Count no of Products
            noOfProducts += orderDetails.getProductsList().get(i).getProducts_quantity();
        }

        holder.order_id.setText(String.valueOf(orderDetails.getOrdersId()));
        holder.order_status.setText(orderDetails.getOrders_status_name());
        holder.order_price.setText("Rs" + orderDetails.getOrder_price());
        holder.order_date.setText(orderDetails.getDate_purchased());
        holder.order_product_count.setText(String.valueOf(noOfProducts));


        adapter = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, productNames);
        holder.order_name_list.setAdapter(adapter);


        // Check Order's status
        if (orderDetails.getOrders_status_name().equalsIgnoreCase("Cancel")) {
            holder.order_status.setTextColor(Color.RED);
            holder.rate_layout.setVisibility(View.GONE);

        } else if (orderDetails.getOrders_status_name().equalsIgnoreCase("Completed")) {
            holder.rate_layout.setVisibility(View.VISIBLE);
            holder.order_status.setTextColor(Color.GREEN);

        } else {
            holder.order_status.setTextColor(Color.BLUE);
            holder.rate_layout.setVisibility(View.GONE);
        }


        holder.view_orders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                i.putExtra("order_status", orderDetails.getOrders_status_name());
                i.putExtra("order_price", orderDetails.getOrder_price());
                i.putExtra("order_id", String.valueOf(orderDetails.getOrdersId()));
                i.putExtra("fragment", "ViewOrders");
                context.startActivity(i);
            }
        });

        if (orderDetails.getIsRated())

        {
            holder.comment.setVisibility(View.VISIBLE);
            holder.reviewBar.setIsIndicator(true);
            holder.comment.setText(orderDetails.getReviews());
            holder.reviewBar.setRating(Float.parseFloat(orderDetails.getReviews_rating()));
            holder.comment_layout.setVisibility(View.GONE);
            session.setUserRated(orderDetails.getIsRated());
        }
        else
        {
            holder.comment_layout.setVisibility(View.VISIBLE);
        }
if (!orderDetails.getIsRated()) {
    holder.comment_layout.setVisibility(View.VISIBLE);
    holder.reviewBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
        @Override
        public void onRatingChanged(RatingBar ratingBar, float rate, boolean fromUser) {
            rating = (int) rate;
            session.setRatingCode(rating);
            System.out.println("Rate for Module is" + rating);
            holder.reviewBar.setIsIndicator(true);
            holder.reviewBar.setRating(rating);
            totalStars = String.valueOf(holder.reviewBar.getNumStars());


        }
    });

    holder.mSubmit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Call<FaqData> call = APIClient.getNetInstance(false).rateDistributor
                    (
                            String.valueOf(orderDetails.getOrdersId()),
                            customerID,
                            rating,
                            String.valueOf(holder.mReview.getText())
                    );
            call.enqueue(new Callback<FaqData>() {
                @Override
                public void onResponse(Call<FaqData> call, Response<FaqData> response) {
                    if (response.isSuccessful()) {
                        LayerDrawable stars = (LayerDrawable) holder.reviewBar.getProgressDrawable();
                        stars.getDrawable(2).setColorFilter(ContextCompat.getColor(context, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
                        holder.comment_layout.setVisibility(View.GONE);
                        holder.comment.setVisibility(View.VISIBLE);
                        holder.comment.setText(String.valueOf(holder.mReview.getText()));
                        Toast.makeText(context, "You rated the order " + rating, Toast.LENGTH_SHORT).show();
                        session.setOrdersId(orderDetails.getOrdersId());
                        session.setcustomerID(customerID);
                    }

                    holder.reviewBar.setNumStars(Integer.parseInt(totalStars));
                }

                @Override
                public void onFailure(Call<FaqData> call, Throwable t) {
                    Toast.makeText(context, "NetworkCallFailure : " + t, Toast.LENGTH_LONG).show();
                    val = false;
                }
            });
        }
    });
}
      // holder.reviewBar.setRating(Float.parseFloat(SharedHelper.getKey(context,"rating")));

       /* holder.reviewBar.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {

                    final String totalStars = String.valueOf(holder.reviewBar.getNumStars());
                    final int rating = (int) holder.reviewBar.getRating();
                    holder.reviewBar.setIsIndicator(true);
                    holder.reviewBar.setFocusable(false);
                    Call<FaqData> call = APIClient.getInstance().rateDistributor
                            (
                                    orderDetails.getDistributor_id(),
                                    customerID,
                                    rating
                            );
                    call.enqueue(new Callback<FaqData>() {
                        @Override
                        public void onResponse(Call<FaqData> call, Response<FaqData> response) {
                            if (response.isSuccessful()) {

                                LayerDrawable stars = (LayerDrawable) holder.reviewBar.getProgressDrawable();
                                stars.getDrawable(2).setColorFilter(ContextCompat.getColor(context, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);

                                Toast.makeText(context, "You rated the order " + rating, Toast.LENGTH_SHORT).show();
                            }

                            holder.reviewBar.setNumStars(Integer.parseInt(totalStars));
                        }

                        @Override
                        public void onFailure(Call<FaqData> call, Throwable t) {
                            Toast.makeText(context, "NetworkCallFailure : " + t, Toast.LENGTH_LONG).show();
                        }
                    });

                }
                return true;
            }
        });*/
    }

    //********** Returns the total number of items in the data set *********//

    @Override
    public int getItemCount() {
        return ordersList.size();
    }


    /********** Custom ViewHolder provides a direct reference to each of the Views within a Data_Item *********/

    public static class MyViewHolder extends RecyclerView.ViewHolder  {
      //  Context context;
        private TextView order_id, order_product_count, order_status, order_price, order_date, comment;

        LinearLayout rate_layout, comment_layout;

        ListView order_name_list;

        RatingBar reviewBar;
        EditText mReview;

        Button view_orders,mSubmit;
        int count = 0;
        float currenRating = 0;
        Context mContext;

        public MyViewHolder(final View itemView) {
            super(itemView);

            order_id = itemView.findViewById(R.id.order_id);
            order_name_list = itemView.findViewById(R.id.order_name_list);
            order_product_count = itemView.findViewById(R.id.order_products_count);
            order_status = itemView.findViewById(R.id.order_status);
            order_price = itemView.findViewById(R.id.order_price);
            order_date = itemView.findViewById(R.id.order_date);
            view_orders = itemView.findViewById(R.id.view_orders);
            reviewBar = itemView.findViewById(R.id.reviewBar);
            rate_layout = itemView.findViewById(R.id.rate_layout);
            mReview = itemView.findViewById(R.id.id_review);
            mSubmit = itemView.findViewById(R.id.id_submit);
            comment_layout = itemView.findViewById(R.id.comment_layout);
            comment = itemView.findViewById(R.id.comment);

          //  reviewBar.setRating(Float.parseFloat(SharedHelper.getKey(mContext,"rating")));
           // reviewBar.setOnRatingBarChangeListener(this);

        }


        }
    }


