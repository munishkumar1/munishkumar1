package com.nextstack.chicken.customerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;
import com.nextstack.chicken.customerapp.models.faq_model.FaqDetails;

import java.util.List;

public class FaqListAdapter extends RecyclerView.Adapter<FaqListAdapter.MyViewHolder> {

    Context context;
    List<FaqDetails> faqsList;

    public FaqListAdapter(Context context, List<FaqDetails> faqsList) {
        this.context = context;
        this.faqsList = faqsList;
    }

    public FaqListAdapter(Context context) {
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        // Inflate the custom layout
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_faqs_card, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        if (faqsList == null){

            holder.question.setText(R.string.question);
            holder.answer.setText(R.string.answer);
        }

    }

    @Override
    public int getItemCount() {
        if (faqsList == null)
            return 1;
        else
            return faqsList.size();
    }




    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView question;
        EditText answer;

        public MyViewHolder(final View itemView) {

            super(itemView);

            question = itemView.findViewById(R.id.question);
            answer = itemView.findViewById(R.id.answer);
        }
    }
}
