package com.nextstack.chicken.customerapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.nextstack.chicken.customerapp.R;

public class DailyOffersAdapter extends RecyclerView.Adapter<DailyOffersAdapter.MyViewHolder> {

    public DailyOffersAdapter() {
    }

    @NonNull
    @Override
    public DailyOffersAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_daily_offers, parent, false);
        GridLayoutManager.LayoutParams lp = (GridLayoutManager.LayoutParams) itemView.getLayoutParams();
        lp.width = parent.getMeasuredWidth() / 2;
        itemView.setLayoutParams(lp);
        return new DailyOffersAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {


    }

    @Override
    public int getItemCount() {
        return 4;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView category_name, offer_amount, coupon_code;

        ImageView offer_image;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            offer_image = itemView.findViewById(R.id.offer_image);
            category_name = itemView.findViewById(R.id.category_name);
            offer_amount = itemView.findViewById(R.id.offer_amount);
            coupon_code = itemView.findViewById(R.id.coupon_code);

        }


    }
}
