package com.mbinfo.medico.ui.sms;

import android.Manifest;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.SpinnerItem;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.otp.OtpActivity;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.PermissionUtil;
import com.mbinfo.medico.utils.Utility;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

public class SmsFragment extends Fragment implements SmsContract.View{
    private static final String TAG = "SmsFragment";
    Spinner spinner;
    // Declaring the String Array with the Text Data for the Spinners
    public static final String[] titles = {"Register As", "Customer", "Dealer"};
    public List<SpinnerItem> rowItems;
    // Button submit;
    EditText mMobile;
    String mobile;
    ProgressDialog progressDialog;
    SmsContract.Presenter presenter;
    View submit;
    RelativeLayout relativeLayout;
    int duration = 5000;
    PermissionUtil permissionUtil;
    Utility utility;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.sms, null);
        presenter = new SmsPresenter(this);
        utility = new Utility(getActivity());
       // initLoadData();
        initView();
        return view;
    }

    @Override
    public void showSubmitProgress() {
        progressDialog = CommonUtils.showLoadingDialog(getActivity());
    }

    @Override
    public void showSubmitSuccess(String message) {
        dismissDialog();
        SharedHelper.putKey(getActivity(),"mobile",mobile);
        // utility.setLogin();
        OtpActivity.start(getActivity());
        //overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        getActivity().finish();

    }

    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    @Override
    public void showSubmitError(String message) {
        dismissDialog();
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void showNetworkNotAvailableError() {
        Snackbar snackbar = Snackbar
                .make(relativeLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)

                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);

        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    @Override
    public void initView() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            checkAndRequestPermission();
        }
        relativeLayout = view.findViewById(R.id.relative);
        mMobile = view.findViewById(R.id.editText);
        submit = view.findViewById(R.id.button);
        event();

    }

    private void event() {
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // mobile = mMobile.getText().toString();
                if(validate()) {
                   login();

                }
            }
        });
    }
    private void login() {

        presenter.onSubmit(mobile);
    }
    private boolean validate() {
        //  password = mPassword.getText().toString().trim();
        mobile = mMobile.getText().toString().trim();

        mMobile.setError(null);
        //  mPassword.setError(null);
        if (mMobile.getText().toString().equals("") || (mobile.length()!=10) ) {
            mMobile.setError(getString(R.string.empty_field_msg));
            mMobile.setError("Enter 10 digit Mobile Number");
            return false;
        }
      /*  else if (mobile.length()!=10) {
            mMobile.setError("Enter 10 digit Mobile Number");
            return false;

        }*/
        return true;
    }
    private void checkAndRequestPermission() {
        permissionUtil = new PermissionUtil();
        permissionUtil.checkAndRequestPermissions(getActivity(),
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA,
                Manifest.permission.READ_SMS,
                Manifest.permission.RECEIVE_SMS);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        permissionUtil.onRequestPermissionsResult(getActivity(), requestCode, permissions, grantResults);
    }
}
