package com.mbinfo.medico.ui.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.ProductAdapter;
import com.mbinfo.medico.adapter.ProductListAdapter;
import com.mbinfo.medico.data.model.product.Product;
import com.mbinfo.medico.data.model.product.ProductList;
import com.mbinfo.medico.data.model.retailer.RetailerDetail;
import com.mbinfo.medico.data.model.retailer.RetailerModel;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.retailerdetail.RetailerActivity_Detail;
import com.mbinfo.medico.ui.category.Categtory;
import com.mbinfo.medico.ui.product.ProudctActivity;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.RecyclerItemClickListener;

import java.util.List;


public class ByRetailer extends Fragment {
    RecyclerView recyclerView;
    View view;
    NetWorkInfoUtility netWorkInfoUtility;
    Context context;
    ProgressDialog progressDialog;
    ConstraintLayout constraintLayout;
    int duration = 5000;
    String authkey;
    int tab = 2, cat = 1;
    ProductAdapter adapter;
    SwipeRefreshLayout swipeRefreshLayout;

    public ByRetailer() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.retail_fragment, null);
        netWorkInfoUtility = new NetWorkInfoUtility();
        recyclerView = view.findViewById(R.id.recltwo);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);
        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent
                , R.color.colorPrimaryDark);
        initLoadData();
        // initView();
        return view;
    }

    private void initLoadData() {
        authkey = SharedHelper.getKey( getActivity(), "authkey");
        if (netWorkInfoUtility.isNetWorkAvailableNow(getActivity())) {
            progressDialog = CommonUtils.showLoadingDialog(getActivity());
            Call<RetailerModel> call = APIClient.getNetInstance().productGetTab(authkey, tab, cat);
            call.enqueue(new Callback<RetailerModel>() {
                @Override
                public void onResponse(Call<RetailerModel> call, Response<RetailerModel> response) {
                    if (response.isSuccessful()) {
                        dismissDialog();
                        if (response.body().getStatus() == 1) {
                            adapter = new ProductAdapter(getActivity(), response.body().getMessage());
                            recyclerView.setAdapter(adapter);
                            adapter.notifyDataSetChanged();
                            swiipeData(response.body().getMessage());
                        } else {
                            // Toast.makeText(getActivity(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<RetailerModel> call, Throwable t) {

                }
            });
        } else {
            showNetworkError();
        }
    }
        private void showNetworkError () {
            Snackbar snackbar = Snackbar
                    .make(constraintLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)
                    .setAction("RETRY", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                        }
                    });

            // Changing message text color
            snackbar.setActionTextColor(Color.WHITE);
            // Changing action button text color
            View sbView = snackbar.getView();
            sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
            TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
            textView.setTextColor(Color.YELLOW);
            snackbar.show();
        }

        private void dismissDialog () {
            if (progressDialog != null && progressDialog.isShowing())
                progressDialog.dismiss();
        }
    private void swiipeData(List<RetailerDetail> message) {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                suffle(message);
                swipeRefreshLayout.setRefreshing(false);
            }

            private void suffle(List<RetailerDetail> message) {
                adapter = new ProductAdapter(getActivity(),message);
                recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
        });
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(),
                new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        Intent i = new Intent(getActivity(), RetailerActivity_Detail.class);
                        getActivity().overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                        startActivity(i);
                       getActivity().finish();
                    }
                }));
    }
    }