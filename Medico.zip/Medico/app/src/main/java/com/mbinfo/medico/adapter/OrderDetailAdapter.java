package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.ordermodel.OrderDetailData;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class OrderDetailAdapter extends RecyclerView.Adapter<OrderDetailAdapter.MyViewHolder> {
    public Context context;
    public List<OrderDetailData> mData;

    public OrderDetailAdapter(Context context, List<OrderDetailData> mData) {
        this.context = context;
        this.mData = mData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_card_order, parent, false);
        OrderDetailAdapter.MyViewHolder viewHolder = new OrderDetailAdapter.MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.orderid.setText(mData.get(position).getOrderId());
        holder.quantitiy.setText(String.valueOf(mData.get(position).getQuantity()));
        System.out.println(mData.get(position).getQuantity());
        holder.price.setText(mData.get(position).getPrice());
        holder.discount.setText(String.valueOf(mData.get(position).getDiscount()));
        holder.payableamount.setText(mData.get(position).getPaybleAmt());
        holder.datetime.setText(mData.get(position).getOrderDatetime());
        holder.paymode.setText(mData.get(position).getPaymentMode());
        holder.mobile.setText(mData.get(position).getAltMobile());
        holder.confrimation.setText(mData.get(position).getPaymentConfirmation());

    }


    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView orderid, quantitiy, price, discount, payableamount, datetime, paymode, mobile, confrimation;
        //  ImageView product_image;
        CardView cardView;

        public MyViewHolder(View view) {
            super(view);
            orderid = view.findViewById(R.id.order_id);
            quantitiy = view.findViewById(R.id.order_products_count);
            price = view.findViewById(R.id.order_price);
            discount = view.findViewById(R.id.order_status);
            payableamount = view.findViewById(R.id.order_payable);
            datetime = view.findViewById(R.id.order_date);
            paymode = view.findViewById(R.id.order_paymode);
            mobile = view.findViewById(R.id.order_mobile);
            confrimation = view.findViewById(R.id.order_confirmation);
        }
    }
}

