package com.mbinfo.medico

import androidx.appcompat.app.AppCompatActivity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import com.mbinfo.medico.ui.sms.SmsActivity

class MainActivity : AppCompatActivity() {
    private val SPLASH_DISPLAY_LENGTH = 3000
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initView()
    }

    private fun initView() {
        Handler().postDelayed({
            /* Create an Intent that will start the Menu-Activity. */
            val mainIntent = Intent(this@MainActivity, SmsActivity::class.java)
            this@MainActivity.startActivity(mainIntent)
            this@MainActivity.finish()
        }, SPLASH_DISPLAY_LENGTH.toLong())
    }
}
