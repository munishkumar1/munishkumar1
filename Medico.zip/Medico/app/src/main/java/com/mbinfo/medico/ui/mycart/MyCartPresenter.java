package com.mbinfo.medico.ui.mycart;

import android.widget.Toast;

import com.mbinfo.medico.data.model.cartmodel.CartDataModel;
import com.mbinfo.medico.data.model.cartmodel.CartModel;
import com.mbinfo.medico.data.model.catmodel.CatModel;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.category.CatContractor;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.Utility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyCartPresenter implements MyCartContractor.Presenter {
    MyCartContractor.View view;
    NetWorkInfoUtility netWorkInfoUtility;
    String authkey,message;
    int status;


    public MyCartPresenter(MyCartContractor.View view) {
        this.view = view;
        netWorkInfoUtility = new NetWorkInfoUtility();
    }

    @Override
    public void onSubmit() {
        authkey = SharedHelper.getKey(view.getContext(),"authkey");
        if (netWorkInfoUtility.isNetWorkAvailableNow(view.getContext())) {
            view.showSubmitProgress();
            Call<CartDataModel> call = APIClient.getNetInstance().getCartData(authkey);
            call.enqueue(new Callback<CartDataModel>() {
                @Override
                public void onResponse(Call<CartDataModel> call, Response<CartDataModel> response) {
                    if (response.isSuccessful()) {
                        try {
                            if (response.body().getStatus() == 1) {
                                status = response.body().getStatus();
                                message = String.valueOf(response.body().getMessage());
                                view.showSubmitSuccess(response.body().getMessage(), status);

                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        view.showSubmitError("error");
                    }
                }


                @Override
                public void onFailure(Call<CartDataModel> call, Throwable t) {
                    view.showEmptySuccess(message, status);
            Toast.makeText(view.getContext(),message,Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            view.showNetworkNotAvailableError();
            // Toast.makeText(view.getContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }
}
