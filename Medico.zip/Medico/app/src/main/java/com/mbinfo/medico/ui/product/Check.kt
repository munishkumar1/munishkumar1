package com.mbinfo.medico.ui.product

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabItem
import com.google.android.material.tabs.TabLayout
import com.mbinfo.medico.R
import com.mbinfo.medico.adapter.PageAdapter
import com.mbinfo.medico.data.model.tabmodel.TabProduct
import com.mbinfo.medico.data.network.APIClient
import com.mbinfo.medico.ui.category.Categtory
import com.mbinfo.medico.ui.fragment.BlankFragment
import com.mbinfo.medico.utils.NetWorkInfoUtility
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class Check : AppCompatActivity() {
    var toolbar: Toolbar? = null
    var tabLayout: TabLayout? = null
    var viewPager: ViewPager? = null
    var pageAdapter: PageAdapter? = null
    var tabChats: TabItem? = null
    var tabCalls: TabItem? = null
    var netWorkInfoUtility: NetWorkInfoUtility? = null

    //Fragment List
    private val mFragmentList: MutableList<Fragment> = ArrayList()

    //Title List
    private val mFragmentTitleList: MutableList<String> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_proudct)
        netWorkInfoUtility = NetWorkInfoUtility()
        initView()
    }

    private fun initView() {
        toolbar = findViewById(R.id.toolbar)
        toolbar?.setTitle(resources.getString(R.string.app_name))
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        tabLayout = findViewById(R.id.tablayout)
        /*  tabChats = findViewById(R.id.tabChats);
        tabCalls = findViewById(R.id.tabCalls);*/viewPager = findViewById(R.id.viewPager)
        tabLayout?.setTabMode(TabLayout.MODE_FIXED)
        tabLayout?.setupWithViewPager(viewPager)
        setupViewPager(viewPager)

        // loadTableData();
    }

    /* private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new ByProduct(), "BYPRODUCT");
        adapter.addFragment(new ByRetailer(), "BYRETAILER");
        viewPager.setAdapter(adapter);
    }*/
    private fun loadTableData() {
        if (netWorkInfoUtility!!.isNetWorkAvailableNow(this@Check)) {
            val call = APIClient.getNetInstance().loadTabpinner()
            call.enqueue(object : Callback<TabProduct> {
                override fun onResponse(call: Call<TabProduct>, response: Response<TabProduct>) {
                    if (response.isSuccessful) {
                        if (response.body()!!.status == 1) {
                            val mValue = response.body()!!.message
                            for (i in mValue.indices) {
                                mFragmentTitleList.add(mValue[i].title.toString())
                            }
                            for (i in mFragmentTitleList.indices) {
                                mFragmentList.add(BlankFragment())
                            }
                            setupViewPager(viewPager)
                            tabLayout!!.setupWithViewPager(viewPager)
                            // Tab ViewPager setting
                            viewPager!!.offscreenPageLimit = mFragmentList.size
                            tabLayout!!.setupWithViewPager(viewPager)
                        } else {
                        }
                    }
                }

                override fun onFailure(call: Call<TabProduct>, t: Throwable) {}
            })
        } else {

            // Toast.makeText(view.getContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }
    }

    private fun setupViewPager(viewPager: ViewPager?) {
        pageAdapter = PageAdapter(supportFragmentManager, mFragmentList, mFragmentTitleList)
        viewPager!!.adapter = pageAdapter
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val i = Intent(applicationContext, Categtory::class.java)
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left)
        startActivity(i)
        finish()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        val searchItem = menu.findItem(R.id.action_search)
        val searchManager = this@Check.getSystemService(Context.SEARCH_SERVICE) as SearchManager
        var searchView: SearchView? = null
        if (searchItem != null) {
            searchView = searchItem.actionView as SearchView
        }
        searchView?.setSearchableInfo(searchManager.getSearchableInfo(this@Check.componentName))
        return true
    }
}