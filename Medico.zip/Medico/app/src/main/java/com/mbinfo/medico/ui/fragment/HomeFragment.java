package com.mbinfo.medico.ui.fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;

import com.mbinfo.medico.adapter.ManufacturerAdapter;
import com.mbinfo.medico.adapter.RecyclerViewAdapter;
import com.mbinfo.medico.adapter.RetailListAdapter;
import com.mbinfo.medico.data.model.ManModel;
import com.mbinfo.medico.data.model.Manufacture;
import com.mbinfo.medico.data.model.catmodel.CatList;
import com.mbinfo.medico.data.model.retail.Retail;
import com.mbinfo.medico.data.model.retail.RetailData;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.retailerdetail.RetailerActivity_Detail;
import com.mbinfo.medico.ui.category.CatContractor;
import com.mbinfo.medico.ui.category.CatPresenter;
import com.mbinfo.medico.ui.home.SearchActivity;
import com.mbinfo.medico.ui.manufacture.ManufactureActivity;
import com.mbinfo.medico.ui.mycart.MyCart;
import com.mbinfo.medico.ui.product.ByProductActivity;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.RecyclerItemClickListener;
import com.mbinfo.medico.utils.Utility;

import java.io.Serializable;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment implements CatContractor.View {
    View view;
    RecyclerView recyclerView;
    RecyclerView recyclerViewOne;
    RecyclerView recyclerViewManf;
    // View recyclerViewTag;
    ProgressDialog progressDialog;
    CatContractor.Presenter presenter;
    ConstraintLayout constraintLayout;
    int duration = 5000;
    RecyclerViewAdapter adapter;
    RetailListAdapter retailListAdapter;
    ManufacturerAdapter manufacturerAdapter;
    SwipeRefreshLayout swipeRefreshLayout;
    public List<CatList> message;
    public List<RetailData> datamessage;
    List<ManModel> datamanf;
    TextView seeall;
    ImageView cartimage;
    NetWorkInfoUtility netWorkInfoUtility;
    EditText editTextSearch;
    String query;
    private ShimmerFrameLayout mShimmerViewContainer, mShimerViewOne;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.content_main, null);
        netWorkInfoUtility = new NetWorkInfoUtility();
        presenter = new CatPresenter(this);
        presenter.onSubmit();
        initView();
        return view;

    }

    @Override
    public void showNetworkNotAvailableError() {/*
        Snackbar snackbar = Snackbar
                .make(constraintLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);
        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();*/
    }

    public void initView() {
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerViewOne = view.findViewById(R.id.recyclerViewone);
        recyclerViewManf = view.findViewById(R.id.recyclerViewTag);
        constraintLayout = view.findViewById(R.id.homefragment);
        seeall = view.findViewById(R.id.see_all);
        cartimage = view.findViewById(R.id.cartimage);
        mShimmerViewContainer = view.findViewById(R.id.id_shimmer);
        editTextSearch = view.findViewById(R.id.edittext_search);
        System.out.println("text1: " + editTextSearch.toString());
        editTextSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                query = editTextSearch.getText().toString();
                System.out.println("Query: " + query);
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    System.out.println("true");
                    performSearch();
                    return true;
                }
                return false;
            }
        });


        // mShimmerViewContainer = view.findViewById(R.id.id_shimmer1);
        cartimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), MyCart.class);
                getActivity().overridePendingTransition(R.anim.slide_in_left, R.anim.slide_in_right);
                startActivity(i);
                getActivity().finish();

            }
        });
        getCatgoryData();
        getManufacture();

    }

    private void performSearch() {
        Intent i = new Intent(getActivity(), SearchActivity.class);
        i.putExtra("search_text",query);
        startActivity(i);
    }

    private void getManufacture() {
        if (netWorkInfoUtility.isNetWorkAvailableNow(getActivity())) {
            //    progressDialog = CommonUtils.showLoadingDialog(getActivity());
            Call<Manufacture> call = APIClient.getNetInstance().loadManfacture();
            call.enqueue(new Callback<Manufacture>() {
                @Override
                public void onResponse(Call<Manufacture> call, Response<Manufacture> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            Log.v("netresponse:", String.valueOf(response.body().getMessage()));
                            datamanf = response.body().getMessage();
                            // convert the Array to List
                            manufacturerAdapter = new ManufacturerAdapter(getActivity(), response.body().getMessage());
                            recyclerViewManf.setLayoutManager(new GridLayoutManager(getActivity(), 3));
                            recyclerViewManf.setAdapter(manufacturerAdapter);
                            manufacturerAdapter.notifyDataSetChanged();

                        } else if (response.body().getStatus() == 0) {

                            Toast.makeText(getActivity(), (CharSequence) response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        } else {
                            // Toast.makeText(getActivity(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Manufacture> call, Throwable t) {
                    dismissDialog();
                    Toast.makeText(getActivity(), "no data", Toast.LENGTH_SHORT).show();

                }
            });
        } else {
            showNetworkNotAvailableError();
        }
        recyclerViewManf.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(),
                new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        String mnftxt = datamanf.get(position).getName();
                        System.out.println(mnftxt);
                        // Utility.setCatid(catid);
                        Intent i = new Intent(getActivity(), ManufactureActivity.class);
                        i.putExtra("catid", mnftxt);
                        getActivity().overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                        startActivity(i);
                        getActivity().finish();
                    }
                }));
    }

    private void getCatgoryData() {
        if (netWorkInfoUtility.isNetWorkAvailableNow(getActivity())) {
            //    progressDialog = CommonUtils.showLoadingDialog(getActivity());
            Call<Retail> call = APIClient.getNetInstance().loadRetail();
            call.enqueue(new Callback<Retail>() {
                @Override
                public void onResponse(Call<Retail> call, Response<Retail> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            datamessage = response.body().getMessage();
                            retailListAdapter = new RetailListAdapter(getActivity(), response.body().getMessage());
                            recyclerViewOne.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
                            recyclerViewOne.setAdapter(retailListAdapter);
                            retailListAdapter.notifyDataSetChanged();

                        } else if (response.body().getStatus() == 0) {

                            Toast.makeText(getActivity(), (CharSequence) response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        } else {
                            // Toast.makeText(getActivity(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Retail> call, Throwable t) {
                    dismissDialog();
                    Toast.makeText(getActivity(), "no data", Toast.LENGTH_SHORT).show();

                }
            });
        } else {
            showNetworkNotAvailableError();
        }
        recyclerViewOne.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(),
                new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        int rid = datamessage.get(position).getId();
                        System.out.println(rid);
                        Log.v("rid",String.valueOf(rid));
                        Intent i = new Intent(getActivity(), RetailerActivity_Detail.class);
                        i.putExtra("rid", rid);
                        getActivity().overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                        startActivity(i);
                        getActivity().finish();
                    }
                }));
    }

    @Override
    public void showSubmitProgress() {
        // progressDialog = CommonUtils.showLoadingDialog(getActivity());
    }

    @Override
    public void showSubmitSuccess(List<CatList> message, int status) {
        mShimmerViewContainer.stopShimmerAnimation();
        mShimmerViewContainer.setVisibility(View.GONE);
  /*      List<CategoryModel> al = new ArrayList<>();
        CategoryModel categoryModel = new CategoryModel();
        categoryModel.setId(message.get(0).getId());
        categoryModel.setTitle(message.get(0).getTitle());
        categoryModel.setDescription(message.get(0).getDescription());
        categoryModel.setImage(message.get(0).getImage());
        al.add(categoryModel);
        CategoryModel categoryModel1 = new CategoryModel();
        categoryModel1.setId(message.get(1).getId());
        categoryModel1.setTitle(message.get(1).getTitle());
        categoryModel1.setDescription(message.get(1).getDescription());
        categoryModel1.setImage(message.get(1).getImage());
        al.add(categoryModel1);
        CategoryModel categoryModel2 = new CategoryModel();
        categoryModel2.setId(message.get(2).getId());
        categoryModel2.setTitle(message.get(2).getTitle());
        categoryModel2.setDescription(message.get(2).getDescription());
        categoryModel2.setImage(message.get(2).getImage());
        al.add(categoryModel2);
        CategoryModel categoryModel3 = new CategoryModel();
        categoryModel3.setId(message.get(3).getId());
        categoryModel3.setTitle(message.get(3).getTitle());
        categoryModel3.setDescription(message.get(3).getDescription());
        categoryModel3.setImage(message.get(3).getImage());
        al.add(categoryModel3);
        progressDialog = CommonUtils.showLoadingDialog(getActivity());*/
        adapter = new RecyclerViewAdapter(getActivity(), message);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        dismissDialog();
      /*  seeall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), DetailShow.class);
                i.putExtra("data", (Serializable) message);
                startActivity(i);
            }
        });*/
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(),
                new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        int catid = message.get(position).getId();
                        System.out.println(catid);
                        Utility.setCatid(catid);
                        Intent i = new Intent(getActivity(), ByProductActivity.class);
                        i.putExtra("catid", catid);
                        getActivity().overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                        startActivity(i);
                        getActivity().finish();
                    }
                }));
    }

    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    @Override
    public void showEmptySuccess(String message, int status) {
        if (status == 0) {
            Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void showSubmitError(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResume() {
        super.onResume();
        mShimmerViewContainer.startShimmerAnimation();
        //  mShimerViewOne.startShimmerAnimation();
    }

    @Override
    public void onPause() {
        mShimmerViewContainer.stopShimmerAnimation();
        //mShimerViewOne.stopShimmerAnimation();
        super.onPause();
    }
}
