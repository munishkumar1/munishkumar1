package com.mbinfo.medico.utils;

import android.text.TextUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validte {
    public final static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }
    public static boolean isMobileValid(String mobile) {
        Pattern pattern;
        Matcher matcher;

        final String MOBILE_PATTERN =
                "\"(0/91)?[7-9][0-9]{9}\"";
        pattern = Pattern.compile(MOBILE_PATTERN);
        matcher = pattern.matcher(mobile);
        return matcher.matches();
    }
    public static boolean isValidPhoneNumber(String target) {
        if (target.length() != 10 ) {
            return true;

        } else {
            return android.util.Patterns.PHONE.matcher(target).matches();
        }
    }

}
