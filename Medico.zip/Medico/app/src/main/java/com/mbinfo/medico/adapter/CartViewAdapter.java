package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.cartmodel.CartShowData;
import com.mbinfo.medico.data.model.dataremove.RemoveItem;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.utils.Utility;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartViewAdapter extends RecyclerView.Adapter<CartViewAdapter.MyViewHolder> {
    public Context context;
    public List<CartShowData> mData;
    double mPrice,cast,quant;
    String authkey;
    int pid;

    public CartViewAdapter(Context context, List<CartShowData> mData) {
        this.context = context;
        this.mData = mData;
    }

    @NonNull
    @Override
    public CartViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        view = layoutInflater.inflate(R.layout.cart_list,parent,false);
        return new CartViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewAdapter.MyViewHolder holder, int position) {
        pid = mData.get(position).getPid();
        holder.name.setText(mData.get(position).getName());
           holder.price.setText("CalculatedPrice" +":"+"Rs." + mData.get(position).getPrice());
           mPrice = Double.parseDouble(mData.get(position).getPrice());
           quant = mData.get(position).getQuantity();
           cast =  mPrice/quant;
          holder.calculatedprice.setText("SinglePrice"+":"+"Rs." + String.valueOf(cast));
          System.out.println(cast);
          holder.quantity.setText("quantity:"+ Integer.toString(mData.get(position).getQuantity()));
          String imgurl = mData.get(position).getImage();
        if(imgurl!=null) {
       /*    Glide.with(context).load(imgurl).
       into(holder.medicineview);*/
            Glide.with(context)
                    .load(imgurl)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.medimage);
        }else {
            Glide.with(context)
                    .load(R.drawable.med)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.medimage);
        }

       holder.remove.setOnClickListener((View v) -> {
            // do something here
           authkey = SharedHelper.getKey(context,"authkey");
           //pid = Integer.parseInt(Utility.getPID());
           //pid = Integer.parseInt(getIntent().getStringExtra("pid"));
           Call<RemoveItem> call = APIClient.getNetInstance().removeCartItem(authkey,pid);
           call.enqueue(new Callback<RemoveItem>() {
               @Override
               public void onResponse(Call<RemoveItem> call, Response<RemoveItem> response) {
                   if (response.isSuccessful()) {
                       if(response.body().getStatus() == 1) {
                           int newPosition = holder.getAdapterPosition();
                           mData.remove(newPosition);
                           notifyItemRemoved(newPosition);
                           notifyItemRangeChanged(newPosition, mData.size());
                           holder.itemView.setVisibility(View.GONE);
                           Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                       }if(mData.size() == 0){

                       }

                       else {
                           // Toast.makeText(getActivity(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                       }
                   }
               }

               @Override
               public void onFailure(Call<RemoveItem> call, Throwable t) {
                   Toast.makeText(context,"error",Toast.LENGTH_SHORT).show();
               }
           });
        });


    }



    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name,price,quantity,totalprice,date,calculatedprice;
        ImageView medimage,remove;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.cart_name);
            date = itemView.findViewById(R.id.id_date);
            price = itemView.findViewById(R.id.id_price);
            quantity = itemView.findViewById(R.id.qauantity);
            totalprice = itemView.findViewById(R.id.text_action1);
            medimage = itemView.findViewById(R.id.image_cartlist);
            calculatedprice = itemView.findViewById(R.id.delfree);
            remove = itemView.findViewById(R.id.ic_wishlist);


        }
    }


        }



