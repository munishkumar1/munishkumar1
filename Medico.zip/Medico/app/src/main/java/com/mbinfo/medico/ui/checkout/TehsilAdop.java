package com.mbinfo.medico.ui.checkout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.TehsilAdapter;
import com.mbinfo.medico.data.model.tehsil.TehsilData;
import com.mbinfo.medico.ui.register.RegisterActivity;

import java.util.List;

public class TehsilAdop extends ArrayAdapter<TehsilData> {
    LayoutInflater layoutInflater;
    public String cityid;
    View view;
    Context context;

    public TehsilAdop(CheckOut context, int spinner_item, int title, List<TehsilData> message) {
        super(context, spinner_item, title, message);
        layoutInflater = context.getLayoutInflater();

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return rowview(convertView, position);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return rowview(convertView, position);
    }

    private View rowview(View convertView, int position) {

        TehsilData rowItem = getItem(position);
        TehsilAdop.viewHolder holder;
        View rowview = convertView;
        if (rowview == null) {

            holder = new TehsilAdop.viewHolder();
            layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowview = layoutInflater.inflate(R.layout.spinner_item, null, false);

            holder.txtTitle = rowview.findViewById(R.id.title);
            //  holder.imageView = (ImageView) rowview.findViewById(R.id.icon);
            rowview.setTag(holder);
        } else {
            holder = (TehsilAdop.viewHolder) rowview.getTag();
        }
        // holder.imageView.setImageResource(rowItem.getImageId());
        holder.txtTitle.setText(rowItem.getTehsil());
       /* cityid = String.valueOf(rowItem.getId());
        Utility.setCityid(cityid);*/
        // SharedHelper.putKey(getContext(), "id", id);
        return rowview;
    }

    private class viewHolder {
        TextView txtTitle;
        ImageView imageView;
    }

    {
    }
}
