package com.mbinfo.medico.ui.sms;

import android.content.Context;
import android.provider.Telephony;
import android.view.View;
import android.widget.Toast;

import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.model.SmsModel;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SessionManager;
import com.mbinfo.medico.utils.NetWorkInfoUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import static com.mbinfo.medico.utils.CommonUtils.isNetworkAvailable;

public class SmsPresenter implements SmsContract.Presenter {
    SmsContract.View view;
    NetWorkInfoUtility netWorkInfoUtility;
    Context context;
    SessionManager sessionManager;
    String message;
    public SmsPresenter(SmsContract.View view) {
        this.view = view;
        netWorkInfoUtility = new NetWorkInfoUtility();
    }

    @Override
    public void onSubmit(String mobile) {
        if (netWorkInfoUtility.isNetWorkAvailableNow(view.getContext())) {
            view.showSubmitProgress();
            Call<Sms> call = APIClient.getNetInstance().processOtp(mobile);
            call.enqueue(new Callback<Sms>() {
                @Override
                public void onResponse(Call<Sms> call, Response<Sms> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            message = response.body().getMessage();
                            view.showSubmitSuccess(response.body().getMessage());

                        } else {
                            view.showSubmitError(response.body().getMessage());
                        }
                    }
                }

                @Override
                public void onFailure(Call<Sms> call, Throwable t) {
                    view.showSubmitError(message);
                }
            });
        } else {
            view.showNetworkNotAvailableError();
           // Toast.makeText(view.getContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }


    }


    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }
}
