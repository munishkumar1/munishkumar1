package com.mbinfo.medico.ui.orderdetail;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.OrderDetailAdapter;
import com.mbinfo.medico.adapter.ProductListAdapter;
import com.mbinfo.medico.data.model.ordermodel.OrderDetail;
import com.mbinfo.medico.data.model.ordermodel.OrderDetailData;
import com.mbinfo.medico.data.model.product.Product;
import com.mbinfo.medico.data.model.product.ProductList;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.category.Categtory;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.Utility;

import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrderDetailActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    View view;
    NetWorkInfoUtility netWorkInfoUtility;
    Context context;
    ProgressDialog progressDialog;
    ConstraintLayout constraintLayout;
    LinearLayout NoItemLayout;
    int duration = 5000;
    String authkey, pid;
    int tab = 1, cat;
    ImageView profile_image;
    OrderDetailAdapter adapter;
    SwipeRefreshLayout swipeRefreshLayout;
    public List<OrderDetailData> message;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        initlayout();

    }

    private void initlayout() {
        netWorkInfoUtility = new NetWorkInfoUtility();
        recyclerView = findViewById(R.id.reclsummary);
        constraintLayout = findViewById(R.id.order_summary);
        profile_image = findViewById(R.id.profile_image);
        recyclerView.setLayoutManager(new LinearLayoutManager(OrderDetailActivity.this));
        recyclerView.setHasFixedSize(true);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent
                , R.color.colorPrimaryDark);
        profile_image.setOnClickListener((View v) -> {
            Intent i = new Intent(getApplicationContext(), HomeActivity.class);
            overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
            startActivity(i);
            finish();
        });
        initLoadData();
    }

    private void initLoadData() {
        authkey = SharedHelper.getKey(this, "authkey");
        if (netWorkInfoUtility.isNetWorkAvailableNow(OrderDetailActivity.this)) {
            progressDialog = CommonUtils.showLoadingDialog(OrderDetailActivity.this);
            Call<OrderDetail> call = APIClient.getNetInstance().OrderGet(authkey);
            call.enqueue(new Callback<OrderDetail>() {
                @Override
                public void onResponse(Call<OrderDetail> call, Response<OrderDetail> response) {
                    if (response.isSuccessful()) {
                        dismissDialog();
                        if (response.body().getStatus() == 1) {
                            adapter = new OrderDetailAdapter(OrderDetailActivity.this, response.body().getMessage());
                            recyclerView.setAdapter(adapter);
                            // adapter.notifyDataSetChanged();
                            message = response.body().getMessage();
                            swiipeData(response.body().getMessage());
                        } else if (response.body().getStatus() == 0) {
                            dismissDialog();
                            Toast.makeText(getApplicationContext(), (CharSequence) response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    }
                }

                @Override
                public void onFailure(Call<OrderDetail> call, Throwable t) {
                    dismissDialog();
                    Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_SHORT).show();

                }
            });
        } else {

            showNetworkError();
        }

    }

    private void showNetworkError() {
        Snackbar snackbar = Snackbar
                .make(constraintLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);
        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    private void swiipeData(List<OrderDetailData> message) {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                suffle(message);
                swipeRefreshLayout.setRefreshing(false);
            }

            private void suffle(List<OrderDetailData> message) {
                adapter = new OrderDetailAdapter(OrderDetailActivity.this, message);
                recyclerView.setLayoutManager(new LinearLayoutManager(OrderDetailActivity.this));
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(), HomeActivity.class);
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        startActivity(i);
        finish();
    }
}

