package com.mbinfo.medico.ui.otp;

import com.mbinfo.medico.ui.base.BasePresenter;
import com.mbinfo.medico.ui.base.BaseView;

public class OtpContract {
    interface View extends BaseView<Presenter> {
        void showSubmitProgress();

        void showSubmitSuccess(String message, String utype);

        void showSubmitError(String message);
    }

    interface Presenter extends BasePresenter {
        void onVerify(String mobile, String otp);
    }
}
