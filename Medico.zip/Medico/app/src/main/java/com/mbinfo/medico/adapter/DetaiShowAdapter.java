package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.catmodel.CatList;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class DetaiShowAdapter extends RecyclerView.Adapter<DetaiShowAdapter.MyViewHolder> {
    public Context context;
    public List<CatList> mData;

    public DetaiShowAdapter(Context context, List<CatList> mData) {
        this.context = context;
        this.mData = mData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        view = layoutInflater.inflate(R.layout.card_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.medicine_title.setText(mData.get(position).getTitle());
//        int catid = mData.get(position).getId();
//        Utility.setCatid(catid);
        String imgurl = mData.get(position).getImage();
        if (imgurl != null) {
       /*    Glide.with(context).load(imgurl).
       into(holder.medicineview);*/
            Glide.with(context)
                    .load(imgurl)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.medicineview);
        } else {
            Glide.with(context)
                    .load(R.drawable.med)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.medicineview);
        }
    }


    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView medicine_title;
        ImageView medicineview;
        CardView cardView;

        public MyViewHolder(View view) {
            super(view);
            medicine_title = view.findViewById(R.id.med_title);
            medicineview = view.findViewById(R.id.med);
            cardView = view.findViewById(R.id.card);
        }
    }
}
