package com.mbinfo.medico.ui.thnaks;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;
import com.mbinfo.medico.R;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.ui.mycart.MyCart;

import java.lang.invoke.LambdaConversionException;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ThankYou extends AppCompatActivity {
    MaterialButton contionueshopping;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thank_you);
        initLayout();
    }

    private void initLayout() {
        contionueshopping = findViewById(R.id.continue_shopping_btn);
        contionueshopping.setOnClickListener((View v) ->{
            Intent in = new Intent(getApplicationContext(), HomeActivity.class);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_in_left);
            startActivity(in);
            finish();
        });
    }
}
