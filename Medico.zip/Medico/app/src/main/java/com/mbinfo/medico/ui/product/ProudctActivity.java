package com.mbinfo.medico.ui.product;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;
import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.PageAdapter;
import com.mbinfo.medico.adapter.ViewPagerAdapter;
import com.mbinfo.medico.data.model.catmodel.CatModel;
import com.mbinfo.medico.data.model.profilemodel.ProfileData;
import com.mbinfo.medico.data.model.tabmodel.ProductMessage;
import com.mbinfo.medico.data.model.tabmodel.TabProduct;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.ui.category.Categtory;
import com.mbinfo.medico.ui.fragment.BlankFragment;
import com.mbinfo.medico.ui.fragment.ByProduct;
import com.mbinfo.medico.ui.fragment.ByRetailer;
import com.mbinfo.medico.ui.fragment.FirstTab;
import com.mbinfo.medico.utils.NetWorkInfoUtility;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class ProudctActivity extends AppCompatActivity {
    Toolbar toolbar;
    TabLayout tabLayout;
    ViewPager viewPager;
    PageAdapter pageAdapter;
    TabItem tabChats;
    TabItem tabCalls;
    NetWorkInfoUtility netWorkInfoUtility;
    //Fragment List
    private final List<Fragment> mFragmentList = new ArrayList<>();
    //Title List
    private final List<String> mFragmentTitleList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proudct);
        netWorkInfoUtility = new NetWorkInfoUtility();
        initView();

    }

    private void initView() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getResources().getString(R.string.app_name));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        tabLayout = findViewById(R.id.tablayout);
      /*  tabChats = findViewById(R.id.tabChats);
        tabCalls = findViewById(R.id.tabCalls);*/
        viewPager = findViewById(R.id.viewPager);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
        tabLayout.setupWithViewPager(viewPager);
          setupViewPager(viewPager);

       // loadTableData();
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new ByProduct(), "BYPRODUCT");
        adapter.addFragment(new ByRetailer(), "BYRETAILER");
        viewPager.setAdapter(adapter);
    }
/*    private void loadTableData() {
        if (netWorkInfoUtility.isNetWorkAvailableNow(ProudctActivity.this)) {
            Call<TabProduct> call = APIClient.getNetInstance().loadTabpinner();
            call.enqueue(new Callback<TabProduct>() {
                @Override
                public void onResponse(Call<TabProduct> call, Response<TabProduct> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            List<ProductMessage> mValue= response.body().getMessage();
                            for(int i =0; i<mValue.size();i++){
                                mFragmentTitleList.add(String.valueOf(mValue.get(i).getTitle()));
                            }
                            for(int i = 0; i < mFragmentTitleList.size(); i++) {
                                mFragmentList.add(new BlankFragment());
                            }
                            setupViewPager(viewPager);
                            tabLayout.setupWithViewPager(viewPager);
                            // Tab ViewPager setting
                            viewPager.setOffscreenPageLimit(mFragmentList.size());
                            tabLayout.setupWithViewPager(viewPager);
                        } else {

                        }
                    }
                }

                @Override
                public void onFailure(Call<TabProduct> call, Throwable t) {

                }
            });
        } else {

            // Toast.makeText(view.getContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }
    }

    private void setupViewPager(ViewPager viewPager) {
        pageAdapter = new PageAdapter(getSupportFragmentManager(), mFragmentList, mFragmentTitleList);
        viewPager.setAdapter(pageAdapter);
    }*/

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(), Categtory.class);
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        startActivity(i);
        finish();
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchManager searchManager = (SearchManager) ProudctActivity.this.getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(ProudctActivity.this.getComponentName()));
        }
        return true;

    }
}

