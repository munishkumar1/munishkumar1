package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.mbinfo.medico.R;
import com.mbinfo.medico.productdetail.ProductDetail;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class SlidingImage_Adapter extends PagerAdapter {
    private List<String> imagesArray;
    // private ArrayList<String> imagesArray;
    private LayoutInflater inflater;
    private Context context;
    public SlidingImage_Adapter(Context context, ArrayList<String> imagesArray) {
        this.context = context;
        this.imagesArray=imagesArray;
        // inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return imagesArray.size();
    }
    @Override
    public int getItemPosition(@NonNull Object object) {
        return PagerAdapter.POSITION_NONE;


    }
    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }

    @Override
    public Object instantiateItem(ViewGroup view, int position) {
        View imageLayout = inflater.inflate(R.layout.slidingimages_layout, view, false);

        assert imageLayout != null;

        final ImageView imageView =  imageLayout
                .findViewById(R.id.slide_image);
        String arrData = imagesArray.get(position);
        for(int i=0;i==imagesArray.size();i++)
            System.out.println(i);

        System.out.println("data: " + arrData);
        Glide.with(context)
                .load(arrData)
                .apply(new RequestOptions()
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true))
                .into(imageView);

        System.out.println("Size: " + getCount());
        //imageView.setImageResource(Integer.parseInt(arrData));

        view.addView(imageLayout, 0);

        return imageLayout;
    }
    @Override
    public void destroyItem(View container, int position, Object object) {
        ((ViewPager) container).removeView((View) object);
    }
}

