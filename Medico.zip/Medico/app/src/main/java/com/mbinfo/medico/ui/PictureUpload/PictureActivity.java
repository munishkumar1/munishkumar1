package com.mbinfo.medico.ui.PictureUpload;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.retailerdetail.SupplierActivity;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.ui.register.RegisterActivity;
import com.mbinfo.medico.utils.CameraUtil;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.Utility;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class PictureActivity extends AppCompatActivity implements View.OnClickListener {
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private Button upload;
    private TextView skip;
    private CircleImageView mProfilePic;
    AppCompatImageView camera;
    String userChoosenTask, filepath;
    Bitmap thumbnail;
    Context context;
    String picturePath;
    File destination,finalFile;
    NetWorkInfoUtility netWorkInfoUtility;
    String authkey,msg;
    int utype;

    public static void start(Context context) {
        Intent i = new Intent(context, PictureActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture);
    /*    ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);*/
                initView();
    }

    private void initView() {
       // utype = SharedHelper.getKey(PictureActivity.this, "id");
        utype = Utility.getUype();
        System.out.println(utype);
        authkey = SharedHelper.getKey(PictureActivity.this,"authkey");
        netWorkInfoUtility = new NetWorkInfoUtility();
        mProfilePic = findViewById(R.id.profile_image);
        camera = findViewById(R.id.camera);
        upload = findViewById(R.id.upload);
        skip = findViewById(R.id.skip);
        mProfilePic.setOnClickListener(this);
        camera.setOnClickListener(this);
        upload.setOnClickListener(this);
        skip.setOnClickListener(this);

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent i = new Intent(this, RegisterActivity.class);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_in_left);
                startActivity(i);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.profile_image:
                selectImage();
                break;
            case R.id.camera:
                selectImage();
                break;
            case R.id.upload:
                uploadPic();
                break;
            case R.id.skip:
                if(utype == 1) {
                    Toast.makeText(getApplicationContext(), "show", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(PictureActivity.this, HomeActivity.class);
                    overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                    startActivity(i);
                    finish();
                }if(utype == 2){
                Toast.makeText(getApplicationContext(), "show", Toast.LENGTH_LONG).show();
                Intent i = new Intent(PictureActivity.this, SupplierActivity.class);
                overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                startActivity(i);
                finish();
            }
                break;

        }
    }

    private void uploadPic() {
      /*  // Create a request body with file and image media type
        RequestBody fileReqBody = RequestBody.create(MediaType.parse("multipart/form-data"), finalFile);
        // Create MultipartBody.Part using file request-body,file name and part name
        MultipartBody.Part part = MultipartBody.Part.createFormData("pic", finalFile.getName(), fileReqBody);
        //Create request body with text description and text media type
        RequestBody description = RequestBody.create(MediaType.parse("multipart/form-data"), "image-type");*/
        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), finalFile);
        // MultipartBody.Part is used to send also the actual filename
        MultipartBody.Part body = MultipartBody.Part.createFormData("pic", finalFile.getName(), requestFile);
        // adds another part within the multipart request
        String descriptionString = "Sample description";
        RequestBody description = RequestBody.create(MediaType.parse("text/plain"), descriptionString);
        try {
            if (netWorkInfoUtility.isNetWorkAvailableNow(PictureActivity.this)) {
                Call<Sms> call = APIClient.getNetInstance().
                        uploadImage(authkey,body,description);
                call.enqueue(new Callback<Sms>() {
                    @Override
                    public void onResponse(Call<Sms> call, Response<Sms> response) {
                        if (response.isSuccessful()) {
                            if (response.body().getStatus() == 1) {
                                msg = response.body().getMessage();
                                Toast.makeText(PictureActivity.this,msg,
                                        Toast.LENGTH_SHORT).show();
                                mProfilePic.setImageBitmap(null);
                                mProfilePic.destroyDrawingCache();
                                Intent i = new Intent(PictureActivity.this, HomeActivity.class);
                                overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                                startActivity(i);
                                finish();
                            } else {
                                Toast.makeText(PictureActivity.this,response.body().getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<Sms> call, Throwable t) {

                    }
                });
            } else {
                Toast.makeText(PictureActivity.this,"Network error",
                        Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Gallery",
                "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(PictureActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result = CameraUtil.checkPermission(PictureActivity.this);

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    if (result)
                        cameraIntent();

                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask = "Choose from Gallery";
                    if (result)
                        galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void cameraIntent() {
        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA);
        }
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, REQUEST_CAMERA);


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);

        }
    }

    private void onCaptureImageResult(Intent data) {
        thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 20, bytes);

       /*  destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        mProfilePic.setImageBitmap(thumbnail);

        // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
        Uri tempUri = getImageUri(getApplicationContext(), thumbnail);

        // CALL THIS METHOD TO GET THE ACTUAL PATH
         finalFile = new File(getRealPathFromURI(tempUri));
    }

    private String getRealPathFromURI(Uri tempUri) {
        String path = "";
        if (getContentResolver() != null) {
            Cursor cursor = getContentResolver().query(tempUri, null, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                path = cursor.getString(idx);
                cursor.close();
            }
        }
        return path;
    }

    private Uri getImageUri(Context applicationContext, Bitmap thumbnail) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(applicationContext.getContentResolver(), thumbnail, "Title", null);
        return Uri.parse(path);
    }

    private void onSelectFromGalleryResult(Intent data) {

        thumbnail = null;
        if (data != null) {
            try {
                thumbnail = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
                Uri selectedImage = data.getData();
                String[] filePathColumn = { MediaStore.Images.Media.DATA };

                Cursor cursor = getContentResolver().query(selectedImage,
                        filePathColumn, null, null, null);
                cursor.moveToFirst();

                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                picturePath = cursor.getString(columnIndex);
                cursor.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        mProfilePic.setImageBitmap(thumbnail);
        // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
        Uri tempUri = getImageUri(getApplicationContext(), thumbnail);

        // CALL THIS METHOD TO GET THE ACTUAL PATH
        finalFile = new File(getRealPathFromURI(tempUri));
    }

    public byte[] getFileDataFromDrawable(Bitmap thumbnail) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.PNG, 50, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    @Override

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CAMERA) {

            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();

            } else {

                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();

            }
        }
    }

}