package com.mbinfo.medico.ui.home;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.CartViewAdapter;
import com.mbinfo.medico.adapter.SearchAdapter;
import com.mbinfo.medico.data.model.cartmodel.CartShowData;
import com.mbinfo.medico.data.model.product.Product;
import com.mbinfo.medico.data.model.search.Search;
import com.mbinfo.medico.data.model.search.SearchData;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.productdetail.ProductDetail;
import com.mbinfo.medico.retailerdetail.RetailAdapter;
import com.mbinfo.medico.retailerdetail.RetailerActivity_Detail;
import com.mbinfo.medico.ui.manufacture.ManufactureActivity;
import com.mbinfo.medico.ui.mycart.MyCart;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.RecyclerTouchListener;

import java.util.List;

import static androidx.constraintlayout.widget.Constraints.TAG;

public class SearchActivity extends AppCompatActivity {
    private ProgressBar mProgressBar;
    LinearLayout ll;
    ConstraintLayout cl;
    public static final String PREFS = "PREFS";
    SharedPreferences sp;
    int cart_count;
    NetWorkInfoUtility netWorkInfoUtility;
    SearchAdapter searchAdapter;
    RecyclerView product_recyclerview;
    SwipeRefreshLayout swipeRefreshLayout;
    ConstraintLayout searchNoItem;
    String search_text;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_search);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        netWorkInfoUtility = new NetWorkInfoUtility();
        ll = findViewById(R.id.layout_search_list);
        searchNoItem = findViewById(R.id.layout_search_empty);
        product_recyclerview = findViewById(R.id.product_recyclerview);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayoutCart);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent
                , R.color.colorPrimaryDark);

        progressDialog = CommonUtils.showLoadingDialog(SearchActivity.this);
        searchData();
    }

    private void searchData() {
        Bundle bundle = getIntent().getExtras();
        search_text = bundle.getString("search_text");
        if (netWorkInfoUtility.isNetWorkAvailableNow(SearchActivity.this)) {
            Call<Search> call = APIClient.getNetInstance().searchData(search_text);
            call.enqueue(new Callback<Search>() {
                @Override
                public void onResponse(Call<Search> call, Response<Search> response) {
                    Log.v("res:", String.valueOf(response));
                    dismissDialog();
                    if (response.isSuccessful()) {
                       searchNoItem.setVisibility(View.GONE);
                        searchAdapter = new SearchAdapter(SearchActivity.this, response.body().getMessage());
                            product_recyclerview.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
                            product_recyclerview.setHasFixedSize(true);
                            product_recyclerview.setAdapter(searchAdapter);
                            searchAdapter.notifyDataSetChanged();
                            swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                                @Override
                                public void onRefresh() {
                                    //  shuffle(message);
                                    swipeRefreshLayout.setRefreshing(false);
                                }

                                private void shuffle(List<SearchData> message) {
                                    searchAdapter = new SearchAdapter(SearchActivity.this, response.body().getMessage());
                                    product_recyclerview.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
                                    product_recyclerview.setHasFixedSize(true);
                                    product_recyclerview.setAdapter(searchAdapter);
                                    searchAdapter.notifyDataSetChanged();
                                }
                            });


                    } else if (response.body().getStatus() == 0) {
                        dismissDialog();
                        ll.setVisibility(View.GONE);
                        searchNoItem.setVisibility(View.VISIBLE);
                        Toast.makeText(getApplicationContext(), (CharSequence) response.body().getMessage(), Toast.LENGTH_SHORT).show();

                    }
                    product_recyclerview.addOnItemTouchListener(new RecyclerTouchListener(SearchActivity.this,
                            product_recyclerview, new RecyclerTouchListener.ClickListener() {

                        @Override
                        public void onClick(View view, final int position) {
                            Log.e(TAG, "Short press on position :" + position);
                            String pid = String.valueOf(response.body().getMessage().get(position).getId());
                            //   Utility.setPid(pid);
                            //TODO create a visit from the data from webcall (in appObj) for info passed to email, text etc
                            Intent i = new Intent(SearchActivity.this, ProductDetail.class);
                            i.putExtra("pid", pid);
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_in_left);
                            startActivity(i);
                            finish();
                        }

                        @Override
                        public void onLongClick(View view, int position) {

                            Log.e(TAG, "Long press on position :" + position);
                        }

                    }));
                }

                @Override
                public void onFailure(Call<Search> call, Throwable t) {
                    Log.v("fail:", t.getMessage());
                    dismissDialog();
                    Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {

            showNetworkError();
        }
    }

    private void showNetworkError() {
        Toast.makeText(getApplicationContext(), "check internet", Toast.LENGTH_SHORT).show();
    }

    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

}

