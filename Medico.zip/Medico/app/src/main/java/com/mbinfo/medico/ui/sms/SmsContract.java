package com.mbinfo.medico.ui.sms;

import com.mbinfo.medico.ui.base.BasePresenter;
import com.mbinfo.medico.ui.base.BaseView;

public class SmsContract {
    interface View extends BaseView<Presenter> {
        void showSubmitProgress();

        void showSubmitSuccess(String message);

        void showSubmitError(String message);
    }

    interface Presenter extends BasePresenter {
        void onSubmit(String mobile);
    }
}
