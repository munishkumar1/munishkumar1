package com.mbinfo.medico.data.model.suppliermodel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TopSellData {
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("pid")
    @Expose
    private int pid;
    @SerializedName("stock")
    @Expose
    private int stock;
    @SerializedName("product_name")
    @Expose
    private String productName;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
