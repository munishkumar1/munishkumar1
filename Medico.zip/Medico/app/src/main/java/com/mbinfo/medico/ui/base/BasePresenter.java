package com.mbinfo.medico.ui.base;

public interface BasePresenter {
    void start();
    void stop();
}
