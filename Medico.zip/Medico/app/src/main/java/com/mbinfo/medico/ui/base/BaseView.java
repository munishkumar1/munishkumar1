package com.mbinfo.medico.ui.base;

/**
 * Created by varun on 1/6/17.
 */

public interface BaseView<T extends BasePresenter> extends ContextProvider {
    void showNetworkNotAvailableError();
    void initView();

}
