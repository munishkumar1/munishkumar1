package com.mbinfo.medico.ui.PictureUpload;

import com.mbinfo.medico.ui.sms.SmsActivity;

public class SmsPresenter implements SmsContract.Presenter {
    private SmsContract.View view;
    public SmsPresenter(SmsActivity smsActivity) {
    }

    @Override
    public void onSubmit(String registeras, String mobile) {

    }

    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }
}
