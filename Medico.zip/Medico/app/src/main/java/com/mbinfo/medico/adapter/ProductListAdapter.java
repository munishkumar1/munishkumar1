package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.product.ProductList;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.product.ByProductActivity;
import com.mbinfo.medico.utils.Utility;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class ProductListAdapter extends RecyclerView.Adapter<ProductListAdapter.ViewHolder> {
    public Context context;
    public List<ProductList> mData;
    Utility mUtil;
   static String pid;

    public ProductListAdapter(Context context, List<ProductList> mData) {
        this.context = context;
        this.mData = mData;
    }


    @NonNull
    @Override
    public ProductListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.power.setText(mData.get(position).getPower());
        holder.textViewSub1Title.setText(mData.get(position).getProductName());
        float mrp = mData.get(position).getPrice();
        holder.mrp.setText("MRP: \u20B9" + mData.get(position).getPrice());
        float discount_amount = mData.get(position).getDiscount();
       // holder.discount.setText(mData.get(position).getDiscount() + "off");
        if (discount_amount > 0) {
           holder.discount.setVisibility(View.VISIBLE);
            holder.discount.setText(mData.get(position).getDiscount() +"%" +"off");
            float amount = mrp - (mrp*discount_amount/100);
            holder.actulaprice.setText("\u20B9"+(int) amount);
        }else {
            holder.discount.setVisibility(View.INVISIBLE);
            holder.mrp.setVisibility(View.INVISIBLE);
            holder.actulaprice.setText("MRP: \u20B9" + mData.get(position).getPrice());

        }
        holder.textViewMed.setText("Mr." + mData.get(position).getSupplierName());
        pid = String.valueOf(mData.get(position).getId());
        SharedHelper.putKey(context,"pid",pid);
        String imgurl = mData.get(position).getImage();
        if(imgurl!=null) {
       /*    Glide.with(context).load(imgurl).
       into(holder.medicineview);*/
            Glide.with(context)
                    .load(imgurl)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.product_image);
        }else {
            Glide.with(context)
                    .load(R.drawable.med)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.product_image);
        }

  /*  holder.cardView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(context, ProductDetail.class);
            i.putExtra("pid",pid);
            context.startActivity(i);
        }
    });*/
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewSub1Title,textViewMed,power,mrp,actulaprice,discount;
        ImageView product_image;
        CardView cardView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewSub1Title = itemView.findViewById(R.id.textViewSub1Title);
            textViewMed = itemView.findViewById(R.id.textViewMed);
            actulaprice = itemView.findViewById(R.id.textViewPrice);
            product_image = itemView.findViewById(R.id.product_image);
            cardView = itemView.findViewById(R.id.cardviewone);
            mrp = itemView.findViewById(R.id.mrp);
            discount = itemView.findViewById(R.id.discount);
            power = itemView.findViewById(R.id.power);

        }
    }
}
