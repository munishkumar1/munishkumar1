package com.mbinfo.medico.ui.profile;

import com.mbinfo.medico.data.model.profilemodel.ProfileData;
import com.mbinfo.medico.ui.base.BasePresenter;
import com.mbinfo.medico.ui.base.BaseView;

public class ProfileContractor  {
    interface View extends BaseView<ProfileContractor.Presenter> {
        void showSubmitProgress();

        void showSubmitSuccess(ProfileData message);

        void showSubmitError(String message);
    }

    interface Presenter extends BasePresenter {
        void onSubmit();
    }
}
