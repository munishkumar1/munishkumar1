package com.mbinfo.medico.data.model;

public class SpinnerItem {
    String name;

    public SpinnerItem(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
