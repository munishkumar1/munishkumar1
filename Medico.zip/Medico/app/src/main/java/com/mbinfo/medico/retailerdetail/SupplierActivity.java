package com.mbinfo.medico.retailerdetail;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Column;
import com.anychart.enums.Anchor;
import com.anychart.enums.HoverMode;
import com.anychart.enums.Position;
import com.anychart.enums.TooltipPositionMode;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.gson.Gson;
import com.mbinfo.medico.R;

import com.mbinfo.medico.adapter.RecyclerViewAdapter;
import com.mbinfo.medico.adapter.RetailListAdapter;
import com.mbinfo.medico.adapter.SupAdapter;
import com.mbinfo.medico.data.model.product.Product;
import com.mbinfo.medico.data.model.retail.Retail;
import com.mbinfo.medico.data.model.suppliermodel.Supplier;
import com.mbinfo.medico.data.model.suppliermodel.SupplierData;
import com.mbinfo.medico.data.model.suppliermodel.TopSell;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;

import com.mbinfo.medico.ui.profile.ProfileActivity;
import com.mbinfo.medico.ui.profile.ProfileFragment;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.Utility;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SupplierActivity extends AppCompatActivity {
    List<DataEntry> data;
    String authkey;
    NetWorkInfoUtility netWorkInfoUtility;
    RecyclerView relone, reltwo;
    Button button;
    String name;
    int value;
    String[] names;
    List<SupplierData> namelist;
    Cartesian cartesian;
    AnyChartView anyChartView;
    BarChart barChart;
    ArrayList<BarEntry> entries;
    SupAdapter supAdapter;
    SupplyAdapter retailListAdapter;
    ImageView scart;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplier);
        netWorkInfoUtility = new NetWorkInfoUtility();
        relone = findViewById(R.id.rel_rtailer);
        reltwo = findViewById(R.id.rel_rat);
        barChart = (BarChart) findViewById(R.id.barChart);
        scart = findViewById(R.id.s_cart);
        data = new ArrayList<>();
        entries = new ArrayList<>();
        getTopSell();
        getChartData();
        getMyProduct();
        scart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Profile.class);
                startActivity(i);
            }
        });

    }

    private void getMyProduct() {
        int rid = Utility.getRatid();
        Log.v("tagid", String.valueOf(rid));
        if (netWorkInfoUtility.isNetWorkAvailableNow(SupplierActivity.this)) {
            //    progressDialog = CommonUtils.showLoadingDialog(getActivity());
            Call<Product> call = APIClient.getNetInstance().retailGet(rid);
            call.enqueue(new Callback<Product>() {
                @Override
                public void onResponse(Call<Product> call, Response<Product> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            String datamessage = String.valueOf(response.body().getMessage());
                            retailListAdapter = new SupplyAdapter(SupplierActivity.this, response.body().getMessage());
                            reltwo.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                            reltwo.setAdapter(retailListAdapter);
                            retailListAdapter.notifyDataSetChanged();

                        } else if (response.body().getStatus() == 0) {

                            Toast.makeText(getApplicationContext(), (CharSequence) response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        } else {
                            // Toast.makeText(getActivity(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Product> call, Throwable t) {

                    Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();

                }
            });
        } else {
            showNetworkNotAvailableError();
        }
    }

    private void showNetworkNotAvailableError() {
    }

    private void getTopSell() {
        String authkeyone = SharedHelper.getKey(this, "authkey");
        String authkey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjo2MSwibW9iaWxlIjoiNzAxMTc4Mjg3NCJ9LCJpYXQiOjE1OTUxNTc4MDF9.aOrctwDnfnIbe2sKaWJV1ytPDt_CI7S0Mdyp3-QUlhU";
        if (netWorkInfoUtility.isNetWorkAvailableNow(SupplierActivity.this)) {
            Call<TopSell> call = APIClient.getNetInstance().getTopSell(authkeyone);
            call.enqueue(new Callback<TopSell>() {
                @Override
                public void onResponse(Call<TopSell> call, Response<TopSell> response) {
                    Log.v("resp1:", String.valueOf(response));
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            int status = response.body().getStatus();
                            String message = String.valueOf(response.body().getMessage());
                            supAdapter = new SupAdapter(SupplierActivity.this, response.body().getMessage());
                            relone.setLayoutManager(new LinearLayoutManager(SupplierActivity.this, LinearLayoutManager.HORIZONTAL, false));
                            relone.setAdapter(supAdapter);
                            supAdapter.notifyDataSetChanged();

                        }
                    }
                }

                @Override
                public void onFailure(Call<TopSell> call, Throwable t) {
                    Log.v("fail", t.getMessage());
                }
            });

        }
    }

    private void getChartData() {
        authkey = SharedHelper.getKey(this, "authkey");
        Log.v("authkey", authkey);
        if (netWorkInfoUtility.isNetWorkAvailableNow(SupplierActivity.this)) {
            Call<Supplier> call = APIClient.getNetInstance().graphGet(authkey);
            call.enqueue(new Callback<Supplier>() {
                @Override
                public void onResponse(Call<Supplier> call, Response<Supplier> response) {
                    Log.v("resp", String.valueOf(response));
                    if (response.isSuccessful()) {
                        assert response.body() != null;
                        if (response.body().getStatus() == 1) {
                            Log.v("message", String.valueOf(response.body().getMessage()));
                            namelist = response.body().getMessage();
                            for (int i = 0; i < namelist.size(); i++) {
                                // data.add(new ValueDataEntry(namelist.get(i).getProductName(), namelist.get(i).getStock()));
                                entries.add(new BarEntry(namelist.get(i).getPid(), namelist.get(i).getStock()));
                                names = new String[]{namelist.get(i).getProductName()};
                            }
                            openChart();


                        }


                    } else if (response.body().getStatus() == 0) {
                        Toast.makeText(getApplicationContext(), (CharSequence) response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }


                @Override
                public void onFailure(Call<Supplier> call, Throwable t) {
                    Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_SHORT).show();
                    Log.e("check", t.toString());
                    Log.v("error", t.toString());
                    System.out.println(t.toString());

                }
            });
        }

    }

    private void openChart() {
        BarDataSet barDataSet = new BarDataSet(entries, "Medico");
        barDataSet.setBarBorderWidth(0.4f);
        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        BarData barData = new BarData(barDataSet);
        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        final String[] months = new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun"};
        IndexAxisValueFormatter formatter = new IndexAxisValueFormatter(names);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(formatter);
        barChart.setData(barData);
        barChart.setFitBars(true);
        barChart.animateXY(5000, 5000);
        barChart.invalidate();
    }

    private void loadFragment(Fragment fragment) {
        FrameLayout fl = findViewById(R.id.rootLayout);
        fl.removeAllViews();
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.rootLayout, fragment, "Test Fragment");
        // transaction.addToBackStack(null);
        transaction.commit();
    }

}


