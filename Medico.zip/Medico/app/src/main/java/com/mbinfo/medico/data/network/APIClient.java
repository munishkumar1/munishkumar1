package com.mbinfo.medico.data.network;

import com.mbinfo.medico.constant.ConstantValues;
import com.mbinfo.medico.utils.UnsafeOkHttpClient;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class APIClient {

    public static Retrofit retrofit = null;
    public static final String BASE_URL = ConstantValues.MEDICO_URL;
    public static ApiRequestNet apiRequestsNet;

    public static ApiRequestNet getNetInstance() {
        if (apiRequestsNet == null) {
            OkHttpClient okHttpClient = new OkHttpClient().newBuilder()
                    .connectTimeout(100, TimeUnit.SECONDS)
                    .readTimeout(100, TimeUnit.SECONDS)
                    .writeTimeout(100, TimeUnit.SECONDS)
                    .build();
          /*  OkHttpClient okHttpClient = UnsafeOkHttpClient.getUnsafeOkHttpClient();*/
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        apiRequestsNet = retrofit.create(ApiRequestNet.class);
        return apiRequestsNet;

    }
}
