package com.mbinfo.medico.ui.category;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.RecyclerViewAdapter;
import com.mbinfo.medico.data.model.catmodel.CatList;
import com.mbinfo.medico.data.model.catmodel.CategoryModel;
import com.mbinfo.medico.ui.mycart.MyCart;
import com.mbinfo.medico.ui.orderdetail.OrderDetailActivity;
import com.mbinfo.medico.ui.product.ProudctActivity;
import com.mbinfo.medico.ui.profile.ProfileActivity;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.RecyclerItemClickListener;
import com.mbinfo.medico.utils.Utility;

import java.util.ArrayList;
import java.util.List;

public  class Categtory extends AppCompatActivity implements CatContractor.View{
    Toolbar toolbar;
    ProgressDialog progressDialog;
    CatContractor.Presenter presenter;
    View backtohome;
    CoordinatorLayout coordinatorLayout;
    int duration = 5000;
    RecyclerView recyclerView;
    RecyclerViewAdapter adapter;
    SwipeRefreshLayout swipeRefreshLayout;
    public List<CatList> message;
    int catid;


    public static void start(Context context) {
        Intent i = new Intent(context, Categtory.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.toolbar);
        presenter = new CatPresenter(this);
        initView();
        initToolbar();
        presenter.onSubmit();
    }

    private void initToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public void showNetworkNotAvailableError() {
        Snackbar snackbar = Snackbar
                .make(coordinatorLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);
        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    public void initView() {
        recyclerView = findViewById(R.id.recl);
        coordinatorLayout =  findViewById(R.id.id_coordination);
         swipeRefreshLayout =  findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent
                ,R.color.colorPrimaryDark); recyclerView = findViewById(R.id.recl);
        coordinatorLayout =  findViewById(R.id.id_coordination);
         swipeRefreshLayout =  findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent
                ,R.color.colorPrimaryDark);

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchManager searchManager = (SearchManager) Categtory.this.getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(Categtory.this.getComponentName()));
        }
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.action_search:
                Toast.makeText(getApplicationContext(), "Item 1 Selected", Toast.LENGTH_LONG).show();
                return true;
            case R.id.profile:
               Intent i = new Intent(this, ProfileActivity.class);
               overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                startActivity(i);
                finish();
                return true;
            case R.id.id_basket:
                Intent intent = new Intent(this, MyCart.class);
                overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                startActivity(intent);
                finish();
                return true;
            case R.id.id_order:
                Intent myintnet = new Intent(this, OrderDetailActivity.class);
                overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                startActivity(myintnet);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void showSubmitProgress() {
        progressDialog = CommonUtils.showLoadingDialog(this);
    }

    @Override
    public void showSubmitSuccess(List<CatList> message, int status) {
        dismissDialog();
     /*   List<CategoryModel> al = new ArrayList<>();
        CategoryModel categoryModel = new CategoryModel();
        categoryModel.setId(message.get(0).getId());
        categoryModel.setTitle(message.get(0).getTitle());
        categoryModel.setDescription(message.get(0).getDescription());
        categoryModel.setImage(message.get(0).getImage());
        al.add(categoryModel);
        CategoryModel categoryModel1 = new CategoryModel();
        categoryModel1.setId(message.get(1).getId());
        categoryModel1.setTitle(message.get(1).getTitle());
        categoryModel1.setDescription(message.get(1).getDescription());
        categoryModel1.setImage(message.get(1).getImage());
        al.add(categoryModel1);
        CategoryModel categoryModel2 = new CategoryModel();
        categoryModel2.setId(message.get(2).getId());
        categoryModel2.setTitle(message.get(2).getTitle());
        categoryModel2.setDescription(message.get(2).getDescription());
        categoryModel2.setImage(message.get(2).getImage());
        al.add(categoryModel2);*/
       // adapter = new RecyclerViewAdapter(this,al);
        recyclerView.setLayoutManager(new GridLayoutManager(this,3));
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
/*
       swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                shuffle(message);
                swipeRefreshLayout.setRefreshing(false);
            }

           private void shuffle(List<CatList> message) {
                presenter.onSubmit();
               adapter = new RecyclerViewAdapter(Categtory.this,message);
               recyclerView.setLayoutManager(new GridLayoutManager(Categtory.this,3));
               recyclerView.setAdapter(adapter);
               adapter.notifyDataSetChanged();
           }
       });

              recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(Categtory.this,
                      new RecyclerItemClickListener.OnItemClickListener() {
                          @Override
                          public void onItemClick(View view, int position) {
                              catid = message.get(position).getId();
                              System.out.println(catid);
                              Utility.setCatid(catid);
                              Intent i = new Intent(getApplicationContext(), ProudctActivity.class);
                              overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                              startActivity(i);
                              finish();
                          }
                      }));
*/

    }

    @Override
    public void showEmptySuccess(String message, int status) {
        dismissDialog();
        if(status == 0){
            Toast.makeText(Categtory.this,message,Toast.LENGTH_SHORT).show();
        }

    }

    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    @Override
    public void showSubmitError(String message) {
          dismissDialog();
          Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();
    }

    @Override
    public Context getContext() {
        return this;
    }
}

