package com.mbinfo.medico.data.model.suppliermodel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Supplier {
    @SerializedName("status")
    @Expose
    private int status;
    @SerializedName("message")
    @Expose
    private List<SupplierData> message = null;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<SupplierData> getMessage() {
        return message;
    }

    public void setMessage(List<SupplierData> message) {
        this.message = message;
    }
}
