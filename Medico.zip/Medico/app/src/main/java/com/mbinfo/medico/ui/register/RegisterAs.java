package com.mbinfo.medico.ui.register;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;

import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.MySpinnerAdapter;
import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.model.SpinerMessage;
import com.mbinfo.medico.data.model.SpinnerDataModel;
import com.mbinfo.medico.data.model.SpinnerItem;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.ui.otp.OtpActivity;
import com.mbinfo.medico.utils.NetWorkInfoUtility;

import java.util.ArrayList;
import java.util.List;

public class RegisterAs extends AppCompatActivity {
    Button next;
    Spinner spinner;
    // Declaring the String Array with the Text Data for the Spinners
    public static final String[] titles = {"Register As", "Customer", "Retailer"};
    public List<SpinnerItem> rowItems;
    NetWorkInfoUtility netWorkInfoUtility;
    MySpinnerAdapter adapter;
    String regid;
    int rid ;

    public static void start(Context context) {
        Intent i = new Intent(context, RegisterAs.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_as);
        rowItems = new ArrayList<SpinnerItem>();
        netWorkInfoUtility = new NetWorkInfoUtility();
        initView();
    }

    private void initView() {
        spinner = findViewById(R.id.spinner);
        spinner = findViewById(R.id.spinner);
        for (int i = 0; i < titles.length; i++) {
            SpinnerItem item = new SpinnerItem(titles[i]);
            rowItems.add(item);
        }
        loadSpinnerData();
      /*  MySpinnerAdapter adapter = new MySpinnerAdapter(RegisterAs.this,
                R.layout.spinner_item, R.id.title, rowItems);
        spinner.setAdapter(adapter);*/
        next = findViewById(R.id.next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), RegisterActivity.class);
                i.putExtra("id",rid);
                startActivity(i);
                overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                finish();
            }
        });
    }

    private void loadSpinnerData() {
        if (netWorkInfoUtility.isNetWorkAvailableNow(RegisterAs.this)) {
            Call<SpinnerDataModel> call = APIClient.getNetInstance().loadSpinner();
              call.enqueue(new Callback<SpinnerDataModel>() {
                  @Override
                  public void onResponse(Call<SpinnerDataModel> call, Response<SpinnerDataModel> response) {
                      if(response.isSuccessful()){
                          if (response.body().getStatus() == 1){
                              adapter = new MySpinnerAdapter(RegisterAs.this,
                                      R.layout.spinner_item, R.id.title, response.body().getMessage());
                              spinner.setAdapter(adapter);
                              spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                  @Override
                                  public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                       SpinerMessage sm = response.body().getMessage().get(position);
                                       String titile = sm.getType();
                                       rid = sm.getId();

                                  }

                                  @Override
                                  public void onNothingSelected(AdapterView<?> parent) {

                                  }
                              });
                          }
                      }
                  }

                  @Override
                  public void onFailure(Call<SpinnerDataModel> call, Throwable t) {

                  }
              });

        }


    }
}
