package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.SpinerMessage;
import com.mbinfo.medico.data.model.SpinnerItem;
import com.mbinfo.medico.data.model.state.StateData;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.register.RegisterActivity;
import com.mbinfo.medico.ui.register.RegisterAs;
import com.mbinfo.medico.utils.Utility;

import java.util.List;

public class MySpinnerAdapter extends ArrayAdapter<SpinerMessage> {
    LayoutInflater layoutInflater;
  public int id;
   View view;
   Context context ;

    public MySpinnerAdapter(RegisterAs context, int spinner_item, int title, List<SpinerMessage> message) {
        super(context,spinner_item,title,message);
        layoutInflater = context.getLayoutInflater();

    }




    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        return rowview(convertView,position);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return rowview(convertView,position);
    }

    private View rowview(View convertView , int position){

        SpinerMessage rowItem = getItem(position);
        viewHolder holder ;
        View rowview = convertView;
        if (rowview==null) {

            holder = new viewHolder();
            layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowview = layoutInflater.inflate(R.layout.spinner_item, null, false);

            holder.txtTitle =  rowview.findViewById(R.id.title);
            holder.linearLayout = rowview.findViewById(R.id.spinner_id);
          //  holder.imageView = (ImageView) rowview.findViewById(R.id.icon);
            rowview.setTag(holder);
        }else{
            holder = (viewHolder) rowview.getTag();
        }
       // holder.imageView.setImageResource(rowItem.getImageId());
        holder.txtTitle.setText(rowItem.getType());
      /*  holder.txtTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = rowItem.getId();

            }
        });*/

        return rowview;
    }

    private class viewHolder{
        TextView txtTitle;
        LinearLayout linearLayout;
        ImageView imageView;
    }
}
