package com.mbinfo.medico.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.provider.Settings;

import java.util.Random;
import java.util.SplittableRandom;

/**
 * Created by Varun on 09-01-2018.
 */

public class Utility {
    private static final String USER_NAME = "user_name";
    private static final String USER_BIO= "bio";
    private static final String USER_FULL_NAME = "fullname";
    private static final String LOGIN = "login";
    private static final String USER_EMAIL = "user_email";
    public static final String USER_MOBILE_NUMBER = "user_mobile_number";
    private static final String USER_ADDRESS = "user_address";
    private static final String USER_UID = "user_uid";
    private static final String IMAGE_URL = "image_url";
    private static final String PID = "pid";
    private static final String CATID = "catid";
    private static final String RATID = "ratid";
    private static final String STATEID = "stateid";
    private static final String CITYID = "cityid";
    private static final String TESID = "tesid";
    private static final String UTYPE = "utype";
    private static final String UID = "uid";

    public static final String PREFS_NAME = "medico_app_pref";
    private Context mContext;
    private static SharedPreferences mPref;

    public Utility(Context mContext) {
        this.mContext = mContext;
        mPref = mContext.getApplicationContext().getSharedPreferences(PREFS_NAME, mContext.MODE_PRIVATE);
    }

    public static int getRandomColorCode() {
        Random rnd = new Random();
        int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
        return color;
    }

    public static boolean haveNetworkConnection(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo == null)
            return false;
        else {
            if (netInfo.isConnected())
                return true;
            else
                return false;
        }
    }



    public static int getUype(){
        return mPref.getInt(UTYPE, 0);
    }

    public static void setUtype(int id) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putInt(UTYPE, id);
        editor.commit();

    }

    public static void setUid(String uid) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(UID, uid);
        editor.commit();
    }
    public static String getUid(){
        return mPref.getString(UID,null);
    }

    public boolean IsLogin() {
        return mPref.getBoolean(LOGIN, false);
    }

    public void setLogin() {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putBoolean(LOGIN, true);
        editor.commit();
    }

    public static void setUserName(String userName) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(USER_NAME, userName);
        editor.commit();
    }

    public static String getUserName() {
        return mPref.getString(USER_NAME, null);
    }

    public static void setFullName(String fullName) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(USER_FULL_NAME, fullName);
        editor.commit();
    }

    public static String getFullName() {
        return mPref.getString(USER_FULL_NAME, null);
    }

    public static void setBio(String userName) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(USER_BIO, userName);
        editor.commit();
    }

    public static String getBio() {
        return mPref.getString(USER_BIO, null);
    }

    public static void setUserEmail(String email) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(USER_EMAIL, email);
        editor.commit();
    }

    public static String getUserEmail() {
        return mPref.getString(USER_EMAIL, null);
    }

    public static void setUserMobileNumber(String mobileNumber) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(USER_MOBILE_NUMBER, mobileNumber);
        editor.commit();
    }

    public static String getUserMobileNumber() {
        return mPref.getString(USER_MOBILE_NUMBER, null);
    }

    public static void setUserAddress(String address) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(USER_ADDRESS, address);
        editor.commit();
    }

    public static String getUserAddress() {
        return mPref.getString(USER_ADDRESS, null);
    }

    public static void setUserUid(String userName) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(USER_UID, userName);
        editor.commit();
    }

    public static String getUserUid() {
        return mPref.getString(USER_UID, null);
    }

    public static void setImageUrl(String imageUrl) {
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(IMAGE_URL, imageUrl);
        editor.commit();
    }

    public static String getImageUrl() {
        return mPref.getString(IMAGE_URL, null);
    }

    public static String getOs(Context context) {
        String release = Build.VERSION.RELEASE;
        int sdkVersion = Build.VERSION.SDK_INT;
        return "Android SDK: " + sdkVersion + " (" + release + ")";
    }

    public static String getDeviceID(Context context) {
        return Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ANDROID_ID);
    }

    public static String getDeviceModel(Context context) {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        return model;
    }

    public static String getDeviceName() {
        String deviceMan = Build.MANUFACTURER;
        return deviceMan;
    }

    public static String getPID() {
        return mPref.getString(PID,null);
    }
    public static void setPid (String pid){
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(PID, pid);
        editor.commit();

    }

    public static int getCatid() {
        return mPref.getInt(CATID,0);
    }
    public static  void setCatid(int catid){
        SharedPreferences.Editor editor = mPref.edit();
        editor.putInt(CATID,catid);
        editor.commit();

    }
    public static int getRatid() {
        return mPref.getInt(RATID,0);
    }
    public static  void setRatid(int ratid){
        SharedPreferences.Editor editor = mPref.edit();
        editor.putInt(RATID,ratid);
        editor.commit();
    }
    public static String getStateid() {
        return mPref.getString(STATEID,null);
    }
    public static void setStateid (String stateid){
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(STATEID, stateid);
        editor.commit();

    }
    public static String getCityid() {
        return mPref.getString(CITYID,null);
    }
    public static void setCityid (String cityid){
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(CITYID, cityid);
        editor.commit();

    }
    public static String getTesid() {
        return mPref.getString(TESID,null);
    }
    public static void setTesid (String tesid){
        SharedPreferences.Editor editor = mPref.edit();
        editor.putString(TESID, tesid);
        editor.commit();

    }
}
