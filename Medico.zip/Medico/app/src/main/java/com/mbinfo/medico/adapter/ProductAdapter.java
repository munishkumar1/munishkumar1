package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.product.ProductList;
import com.mbinfo.medico.data.model.retailer.RetailerDetail;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.MyViewHolder> {
    public Context context;
    public List<RetailerDetail> mData;
    public ProductAdapter(Context context, List<RetailerDetail> mData) {
        this.context =  context;
        this.mData = mData;
    }


    @NonNull
    @Override
    public ProductAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.retail_list, parent, false);
        ProductAdapter.MyViewHolder viewHolder = new ProductAdapter.MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
      holder.textViewSub1Title.setText(mData.get(position).getName());
      holder.textViewMed.setText("phone:" + mData.get(position).getMobile());
        holder.textViewPrice.setText("pin:" + mData.get(position).getPinCode());
        holder.Quantity.setText("village:" + mData.get(position).getVillage());


    }

    @Override
    public int getItemCount() {
        return mData.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textViewSub1Title,textViewMed,textViewPrice,Quantity;
        ImageView product_image;
        CardView cardView;

        public MyViewHolder(View view) {
            super(view);
            textViewSub1Title = view.findViewById(R.id.textViewSub1Title);
            textViewMed = view.findViewById(R.id.textViewMed);
            textViewPrice = view.findViewById(R.id.textViewPrice);
            Quantity = view.findViewById(R.id.quantiity);
            product_image = view.findViewById(R.id.product_image);


        }
    }
}
