package com.mbinfo.medico.ui.profile;

import android.content.Context;

import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.model.profilemodel.Profile;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.sms.SmsContract;
import com.mbinfo.medico.utils.NetWorkInfoUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfilePresenter implements ProfileContractor.Presenter {
    ProfileContractor.View view;
    NetWorkInfoUtility netWorkInfoUtility;
    String authkey;
    String data[];
    public ProfilePresenter(ProfileContractor.View view){
        this.view = view;
        netWorkInfoUtility = new NetWorkInfoUtility();
    }
    @Override
    public void onSubmit() {
        authkey = SharedHelper.getKey(view.getContext(),"authkey");
        if (netWorkInfoUtility.isNetWorkAvailableNow(view.getContext())) {
            view.showSubmitProgress();
            Call<Profile> call = APIClient.getNetInstance().profileGet(authkey);
            call.enqueue(new Callback<Profile>() {
                @Override
                public void onResponse(Call<Profile> call, Response<Profile> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            view.showSubmitSuccess(response.body().getMessage());
                        } else {
                            view.showSubmitError(String.valueOf(response.body().getMessage()));
                        }
                    }
                }

                @Override
                public void onFailure(Call<Profile> call, Throwable t) {

                }
            });
        } else {
            view.showNetworkNotAvailableError();
            // Toast.makeText(view.getContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }
}
