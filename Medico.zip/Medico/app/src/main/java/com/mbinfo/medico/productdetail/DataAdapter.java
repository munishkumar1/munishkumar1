package com.mbinfo.medico.productdetail;

import android.content.Context;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.product.ProductList;
import com.mbinfo.medico.retailerdetail.RetailAdapter;
import com.mbinfo.medico.utils.Utility;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder>{
    public Context context;
    public List<String> mData;
    Utility mUtil;
    static String pid;

    public DataAdapter(Context context, List<String> sideEffects) {
        this.context = context;
        this.mData = sideEffects;
    }


    @NonNull
    @Override
    public DataAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_sideefect, parent, false);
        DataAdapter.ViewHolder viewHolder = new DataAdapter.ViewHolder(view);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textsideeefect.setText("\u2022"+mData.get(position));
    }



    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textsideeefect;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textsideeefect = itemView.findViewById(R.id.textsafety);

        }
    }
}
