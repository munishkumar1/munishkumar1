package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.SpinerMessage;
import com.mbinfo.medico.data.model.state.StateData;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.register.RegisterActivity;
import com.mbinfo.medico.ui.register.RegisterAs;
import com.mbinfo.medico.utils.Utility;

import java.util.List;

public class StateAdapter extends ArrayAdapter<StateData> {
        LayoutInflater layoutInflater;
        public String id;
        View view;
        Context context ;

    public StateAdapter(RegisterActivity context, int spinner_item, int title, List<StateData> message) {
        super(context,spinner_item,title,message);
        layoutInflater = context.getLayoutInflater();

    }




        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

        return rowview(convertView,position);
    }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return rowview(convertView,position);
    }

        private View rowview(android.view.View convertView , int position){
        StateData rowItem = getItem(position);
        StateAdapter.viewHolder holder ;
        View rowview = convertView;
        if (rowview==null) {

            holder = new StateAdapter.viewHolder();
            layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowview = layoutInflater.inflate(R.layout.spinner_item, null, false);

            holder.txtTitle =  rowview.findViewById(R.id.title);
            holder.linearLayout =  rowview.findViewById(R.id.spinner_id);
            //  holder.imageView = (ImageView) rowview.findViewById(R.id.icon);
            rowview.setTag(holder);
        }else{
            holder = (StateAdapter.viewHolder) rowview.getTag();
        }
        // holder.imageView.setImageResource(rowItem.getImageId());
        holder.txtTitle.setText(rowItem.getState());
            id = String.valueOf(rowItem.getId());
            SharedHelper.putKey(getContext(),"id",id);
            Utility.setStateid(String.valueOf(rowItem.getId()));
   /*     holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = String.valueOf(rowItem.getId());
                SharedHelper.putKey(getContext(),"id",id);
                Utility.setStateid(String.valueOf(rowItem.getId()));
            }
        });*/

        return rowview;
    }

        private class viewHolder{
        LinearLayout linearLayout;
            TextView txtTitle;
            ImageView imageView;

        }
}
