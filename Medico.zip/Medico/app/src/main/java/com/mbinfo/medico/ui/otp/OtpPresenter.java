package com.mbinfo.medico.ui.otp;

import android.view.View;
import android.widget.Toast;

import com.mbinfo.medico.data.model.OtpModel;
import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.sms.SmsContract;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.Utility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OtpPresenter implements OtpContract.Presenter {
    private OtpContract.View view;
    NetWorkInfoUtility netWorkInfoUtility;
    String error;

    public OtpPresenter(OtpContract.View view) {
        this.view = view;
        netWorkInfoUtility = new NetWorkInfoUtility();

    }



    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }

    @Override
    public void onVerify(String mobile, String otp) {
        if (netWorkInfoUtility.isNetWorkAvailableNow(view.getContext())) {
            view.showSubmitProgress();
            Call<OtpModel> call = APIClient.getNetInstance().processVerify(mobile,otp);
            call.enqueue(new Callback<OtpModel>() {
                @Override
                public void onResponse(Call<OtpModel> call, Response<OtpModel> response) {
                    if (response.isSuccessful()) {
                            String authkey = response.body().getMessage();
                            SharedHelper.putKey(view.getContext(),"authkey",authkey);
                            System.out.println(authkey);
                            String utype = response.body().getUtype();
                            int rid = response.body().getRid();
                              Utility.setRatid(rid);

                          //  error= response.errorBody().toString();
                            view.showSubmitSuccess(response.body().getMessage(),utype);
                        } else {
                            view.showSubmitError(response.body().getMessage());
                        }
                    }

                    @Override
                public void onFailure(Call<OtpModel> call, Throwable t) {
                    Toast.makeText(view.getContext(),t.toString(), Toast.LENGTH_SHORT).show();

                }
            });
        } else {
            //Toast.makeText(view.getContext(),error,Toast.LENGTH_SHORT).show();
            view.showNetworkNotAvailableError();
            // Toast.makeText(view.getContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }


    }
}
