package com.mbinfo.medico.ui.register;

import com.mbinfo.medico.ui.base.BasePresenter;
import com.mbinfo.medico.ui.base.BaseView;
import com.mbinfo.medico.ui.sms.SmsContract;

public class RegisterContract {

     interface View extends BaseView<Presenter> {
         void showSubmitProgress();
         void showSubmitSuccess();

        void showSubmitError(String message);
    }
    interface Presenter extends BasePresenter {

        void onRegister(String username, String fathername,String business,String mobile,String utype,
                        String address,String village,String landmark,
                        String ward,String block,
                        String distict,String state,String pin,String adhar);
    }
}
