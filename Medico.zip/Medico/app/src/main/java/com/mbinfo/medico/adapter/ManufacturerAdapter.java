package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.ManModel;
import com.mbinfo.medico.data.model.Manufacture;
import com.mbinfo.medico.utils.Utility;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

public class ManufacturerAdapter extends RecyclerView.Adapter<ManufacturerAdapter.ViewHolder> {
    public Context context;
    public List<ManModel> mData;
    Utility mUtil;
    static String pid;

    public ManufacturerAdapter(Context context, List<ManModel> message) {
        this.context = context;
        this.mData = message;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textViewSub1Title.setText((mData.get(position).getName()).toLowerCase());

        }

  /*  holder.cardView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(context, ProductDetail.class);
            i.putExtra("pid",pid);
            context.startActivity(i);
        }
    });*/


    @Override
    public int getItemCount() {
        return mData.size();
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewSub1Title;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewSub1Title = itemView.findViewById(R.id.tagtext);

        }
    }



}
