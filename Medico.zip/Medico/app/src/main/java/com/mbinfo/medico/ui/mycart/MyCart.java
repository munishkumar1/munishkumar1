package com.mbinfo.medico.ui.mycart;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.CartViewAdapter;
import com.mbinfo.medico.data.model.cartmodel.CartShowData;
import com.mbinfo.medico.data.model.dataremove.RemoveItem;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.category.Categtory;
import com.mbinfo.medico.ui.checkout.CheckOut;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.utils.CommonUtils;

import java.util.List;

public class MyCart extends AppCompatActivity implements MyCartContractor.View{
    ProgressDialog progressDialog;
    MyCartContractor.Presenter presenter;
    View shopnow,deleteall,baddnew;
    ConstraintLayout constraintLayout;
    int duration = 5000;
    CircleImageView backarrow;
    RecyclerView recyclerView;
    CartViewAdapter adapter;
    SwipeRefreshLayout swipeRefreshLayout;
    LinearLayout layoutCartNoItems,layoutCartTwo,layoutCartList;
    public List<CartShowData> message;

    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_cart);
        presenter = new MyCartPresenter(this);
        initLayout();
        presenter.onSubmit();
    }

    private void initLayout() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);// add back arrow to toolbar
        }
        constraintLayout = findViewById(R.id.id_cartconst);
        recyclerView = findViewById(R.id.reclcart);
        backarrow = findViewById(R.id.profile_image);
        backarrow.setOnClickListener((View v) -> {
            Intent in = new Intent(getApplicationContext(), HomeActivity.class);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_in_left);
                startActivity(in);
                finish();
            });


        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayoutCart);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent
                , R.color.colorPrimaryDark);
        layoutCartNoItems = findViewById(R.id.layout_cart_empty);
        layoutCartTwo = findViewById(R.id.layout_cart_two);
        layoutCartList = findViewById(R.id.layout_cart_list);
        shopnow = findViewById(R.id.text_action_bottom2);
        deleteall = findViewById(R.id.text_action_bottom1);
        deleteall.setOnClickListener((View v) -> {
           String authkey = SharedHelper.getKey(getApplicationContext(),"authkey");
            //pid = Integer.parseInt(Utility.getPID());
            //pid = Integer.parseInt(getIntent().getStringExtra("pid"));
            Call<RemoveItem> call = APIClient.getNetInstance().removeCartAllItem(authkey);
            call.enqueue(new Callback<RemoveItem>() {
                @Override
                public void onResponse(Call<RemoveItem> call, Response<RemoveItem> response) {
                    if (response.isSuccessful()) {
                        if(response.body().getStatus() == 1) {
                            layoutCartNoItems.setVisibility(View.VISIBLE);
                            // constraintLayout.setVisibility(View.INVISIBLE);
                            layoutCartTwo.setVisibility(View.GONE);
                            layoutCartList.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                        else {
                            // Toast.makeText(getActivity(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<RemoveItem> call, Throwable t) {

                }
            });
        });
        shopnow.setOnClickListener((View v) ->{
            Intent i = new Intent(getApplicationContext(), CheckOut.class);
            overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
            startActivity(i);
            finish();
        });

    }



    @Override
    public void showSubmitProgress() {
        progressDialog = CommonUtils.showLoadingDialog(this);
    }

    @Override
    public void showSubmitSuccess(List<CartShowData> message, int status) {
        dismissDialog();
                adapter = new CartViewAdapter(this,message);
                recyclerView.setLayoutManager(new LinearLayoutManager(MyCart.this));
                recyclerView.setHasFixedSize(true);
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                      //  shuffle(message);
                        swipeRefreshLayout.setRefreshing(false);
                    }

                    private void shuffle(List<CartShowData> message) {
                        presenter.onSubmit();
                        adapter = new CartViewAdapter(MyCart.this,message);
                        recyclerView.setLayoutManager(new LinearLayoutManager(MyCart.this));
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                    }
                });
            }


    @Override
    public void showEmptySuccess(String message,int status) {
        dismissDialog();
        if(status == 0){
            layoutCartNoItems.setVisibility(View.VISIBLE);
           // constraintLayout.setVisibility(View.INVISIBLE);
            layoutCartTwo.setVisibility(View.GONE);
            layoutCartList.setVisibility(View.GONE);
            baddnew = findViewById(R.id.bAddNew);
            baddnew.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(MyCart.this, HomeActivity.class);
                    overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                    startActivity(i);
                    finish();
                }
            });


        }

        }







    @Override
    public void showSubmitError(String message) {

    }

    @Override
    public void showNetworkNotAvailableError() {
        Snackbar snackbar = Snackbar
                .make(constraintLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);
        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    @Override
    public void initView() {

    }

    @Override
    public Context getContext() {
        return this;
    }
    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(), HomeActivity.class);
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        startActivity(i);
        finish();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
