package com.mbinfo.medico.ui.base;

import android.content.Context;

/**
 * Created on 1/23/18.
 */

public interface ContextProvider {
    Context getContext();
}
