package com.mbinfo.medico.ui.register;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.room.Room;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.CityAdapter;
import com.mbinfo.medico.adapter.MySpinnerAdapter;
import com.mbinfo.medico.adapter.StateAdapter;
import com.mbinfo.medico.adapter.TehsilAdapter;
import com.mbinfo.medico.data.db.MedicoDatabse;
import com.mbinfo.medico.data.db.Register;
import com.mbinfo.medico.data.db.RegisterDao;
import com.mbinfo.medico.data.model.SpinnerDataModel;
import com.mbinfo.medico.data.model.SpinnerItem;
import com.mbinfo.medico.data.model.city.City;
import com.mbinfo.medico.data.model.state.StateData;
import com.mbinfo.medico.data.model.state.StateModel;
import com.mbinfo.medico.data.model.tehsil.Tehsil;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.PictureUpload.PictureActivity;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.ui.sms.SmsActivity;
import com.mbinfo.medico.ui.sms.SmsContract;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.Utility;

import java.util.ArrayList;
import java.util.List;


public class RegisterActivity extends AppCompatActivity implements RegisterContract.View, AdapterView.OnItemSelectedListener {
    Context context;
    ProgressDialog progressDialog;
    ConstraintLayout constraintLayout;
    int duration = 5000,id;
    String utype,mobile,business;
    EditText businesstext,username,fathername,address,village,landmark,ward,block,distict,state,pincode,adhar;
    String select_state,select_distict,select_teshil,device_id,device_model,device_name;
    Spinner selectstate,selectcity,selecttehsil;
    RegisterContract.Presenter presenter;
    View register;
    Utility utility;
    StateAdapter stateAdapter;
    CityAdapter cityAdapter;
    TehsilAdapter tehsilAdapter;
    String stateid, cityid,tesid;
    private RegisterDao mRegisterDAO;
    public static void start(Context context) {
        Intent i = new Intent(context, RegisterActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        presenter = new RegisterPresenter(this);
        utility = new Utility(this);
        mRegisterDAO = Room.databaseBuilder(this, MedicoDatabse.class, "db-register")
                .allowMainThreadQueries()   //Allows room to do operation on main thread
                .build()
                .getRegisterDao();
        initView();


    }

    @Override
    public void showSubmitProgress() {
        progressDialog = CommonUtils.showLoadingDialog(this);
    }

    @Override
    public void showSubmitSuccess() {
        dismissdialog();
        utility.setLogin();
        PictureActivity.start(getApplicationContext());
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        finish();
    }

    private void dismissdialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }
    @Override
    public void showSubmitError(String message) {
            dismissdialog();
    }

    @Override
    public void showNetworkNotAvailableError() {
        Snackbar snackbar = Snackbar
                .make(constraintLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);

        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    @Override
    public void initView() {
        mobile = SharedHelper.getKey(RegisterActivity.this, "mobile");
        utype = SharedHelper.getKey(RegisterActivity.this, "id");
        Intent i = getIntent();
        id = i.getIntExtra("id",0);
        businesstext = findViewById(R.id.business);
        if (id == 2) {
            businesstext.setVisibility(View.VISIBLE);
            business = businesstext.getText().toString();
     //       address.setVisibility(View.VISIBLE);
        }
        device_id = Utility.getDeviceID(this);
        device_model = Utility.getDeviceModel(this);
        device_name = Utility.getDeviceName();
        username = findViewById(R.id.usersname);
        fathername = findViewById(R.id.fathersname);
        address = findViewById(R.id.address);
        village = findViewById(R.id.village);
        landmark = findViewById(R.id.landmark);
        ward = findViewById(R.id.ward);
     /*   block = findViewById(R.id.block);
        distict = findViewById(R.id.district);
        state = findViewById(R.id.state);*/
        pincode = findViewById(R.id.Pincode);
        adhar = findViewById(R.id.adhar);
        register = findViewById(R.id.register);
        constraintLayout = findViewById(R.id.const_reg);
        selectstate = findViewById(R.id.state_spinner);
        selectcity  = findViewById(R.id.distict_spinner);
        selecttehsil = findViewById(R.id.tesil_spinner);
         selectstate.setOnItemSelectedListener(this);
         selectcity.setOnItemSelectedListener(this);
         loadSpinnerState();
    //     loadTehsil();
       // loadSpinnerCity();
        events();
    }
    private void loadSpinnerCity() {
         stateid = Utility.getStateid();
        Call<City> call = APIClient.getNetInstance().loadCity(stateid);
        call.enqueue(new Callback<City>() {
            @Override
            public void onResponse(Call<City> call, Response<City> response) {
                if(response.isSuccessful()){
                    if (response.body().getStatus() == 1){
                       Log.v("net", String.valueOf(response));
                        cityAdapter = new CityAdapter(RegisterActivity.this,
                                R.layout.spinner_item, R.id.title, response.body().getMessage());
                        selectcity.setAdapter(cityAdapter);

                    }
                }
            }

            @Override
            public void onFailure(Call<City> call, Throwable t) {

            }
        });

    }
    private void loadSpinnerState() {
        Call<StateModel> call = APIClient.getNetInstance().loadState();
        call.enqueue(new Callback<StateModel>() {
            @Override
            public void onResponse(Call<StateModel> call, Response<StateModel> response) {
                if(response.isSuccessful()){
                    if (response.body().getStatus() == 1){
                       // Log.d(TAG, "onResponse: response");
                        stateAdapter = new StateAdapter(RegisterActivity.this,
                                R.layout.spinner_item, R.id.title, response.body().getMessage());
                        selectstate.setAdapter(stateAdapter);

                    }
                }
            }

            @Override
            public void onFailure(Call<StateModel> call, Throwable t) {

            }
        });

    }

    private void loadTehsil() {
         cityid = Utility.getCityid();
        Call<Tehsil> call = APIClient.getNetInstance().loadTehsilData(Integer.parseInt(cityid));
        call.enqueue(new Callback<Tehsil>() {
            @Override
            public void onResponse(Call<Tehsil> call, Response<Tehsil> response) {
                if(response.isSuccessful()){
                    if (response.body().getStatus() == 1){
                        Log.v("net", String.valueOf(response));
                        tehsilAdapter = new TehsilAdapter(RegisterActivity.this,
                                R.layout.spinner_item, R.id.title, response.body().getMessage());
                        selecttehsil.setAdapter(tehsilAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<Tehsil> call, Throwable t) {

            }
        });
    }
    private void events() {
       register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()) {
                    registerdata();
                   // saveInDatbase();
                }
            }
        });

    }

    private boolean validate() {
        if(username.getText().toString().isEmpty()) {
            username.setError("UserName can not be empty");
            return false;
        }   if(fathername.getText().toString().isEmpty()) {
            fathername.setError("FatherName can not be empty");
            return false;
        }if(village.getText().toString().isEmpty()) {
            village.setError("Village can not be empty");
            return false;
        }if(ward.getText().toString().isEmpty()) {
            ward.setError("Ward can not be empty");
            return false;
   /*     }if(block.getText().toString().isEmpty()) {
            block.setError("Block can not be empty");
            return false;
        }if(distict.getText().toString().isEmpty()) {
            distict.setError("Distict can not be empty");
            return false;
        }if(state.getText().toString().isEmpty()) {
            state.setError("State can not be empty");
            return false;*/
        }if(pincode.getText().toString().isEmpty()) {
            pincode.setError("Pincode can not be empty");
            return false;

        }
        return true;
    }

    private void registerdata() {
       Utility.setUtype(id);
        String pin = pincode.getText().toString();
        tesid = Utility.getTesid();
        utype = String.valueOf(id);

        presenter.onRegister(username.getText().toString(), fathername.getText().toString(),business,mobile,utype,
                adhar.getText().toString(),address.getText().toString(), village.getText().toString(), landmark.getText().toString(),
                ward.getText().toString(),tesid,
                cityid, stateid, pin);
    }



    private void saveInDatbase() {
        String pin = pincode.getText().toString();
        Register register = new Register(username.getText().toString(), fathername.getText().toString(),
                address.getText().toString(), village.getText().toString(), landmark.getText().toString(),
                ward.getText().toString(),block.getText().toString(),
                distict.getText().toString(), state.getText().toString(), pin, adhar.getText().toString());
        //Insert to database
        try {
            mRegisterDAO.insert(register);
            setResult(RESULT_OK);
            finish();
        } catch (SQLiteConstraintException e) {
            Toast.makeText(RegisterActivity.this, "A cotnact with same phone number already exists.", Toast.LENGTH_SHORT).show();
        }
    }



    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        parent.getItemAtPosition(position);
        switch (parent.getId()){
            case R.id.state_spinner:
                select_state = selectstate.getSelectedItem().toString();
                loadSpinnerCity();
                break;
            case R.id.distict_spinner:
                select_distict = selectcity.getSelectedItem().toString();
               loadTehsil();
                break;
            case R.id.tesil_spinner:
                select_teshil = selecttehsil.getSelectedItem().toString();
                break;
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onBackPressed()
    {
        Intent intent = new Intent(this, RegisterAs.class);
        startActivity(intent);
        finish();
        // code here to show dialog
        super.onBackPressed();  // optional depending on your needs
    }
}
