package com.mbinfo.medico.data.model.suppliermodel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TopSell {
    @SerializedName("status")
    @Expose
    private int status;
    @SerializedName("message")
    @Expose
    private List<TopSellData> message = null;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<TopSellData> getMessage() {
        return message;
    }

    public void setMessage(List<TopSellData> message) {
        this.message = message;
    }
}
