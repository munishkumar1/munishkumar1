package com.mbinfo.medico.ui.mycart;

import com.mbinfo.medico.data.model.cartmodel.CartShowData;
import com.mbinfo.medico.ui.base.BasePresenter;
import com.mbinfo.medico.ui.base.BaseView;

import java.util.List;

public class MyCartContractor {
    interface View extends BaseView<MyCartContractor.Presenter> {
        void showSubmitProgress();

        void showSubmitSuccess(List<CartShowData> message, int status);
        void showEmptySuccess(String message,int status);

        void showSubmitError(String message);
    }

    interface Presenter extends BasePresenter {
        void onSubmit();
    }
}
