package com.mbinfo.medico.productdetail;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.Splash;

import com.mbinfo.medico.adapter.ProductListAdapter;
import com.mbinfo.medico.adapter.SlidingImage_Adapter;
import com.mbinfo.medico.data.model.cartmodel.CartModel;
import com.mbinfo.medico.data.model.product.Product;
import com.mbinfo.medico.data.model.productdetail.ProductDetails;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.retailerdetail.RetailAdapter;
import com.mbinfo.medico.retailerdetail.RetailerActivity_Detail;
import com.mbinfo.medico.ui.category.Categtory;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.ui.mycart.MyCart;
import com.mbinfo.medico.ui.product.ByProductActivity;
import com.mbinfo.medico.ui.product.ProudctActivity;
import com.mbinfo.medico.ui.sms.SmsFragment;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.MyNotificationPublisher;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.Utility;
import com.viewpagerindicator.CirclePageIndicator;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ProductDetail extends AppCompatActivity implements View.OnClickListener {
    public static final String NOTIFICATION_CHANNEL_ID = "10001";
    private final static String default_notification_channel_id = "default";
    private static ViewPager mPager;
    CirclePageIndicator indicator;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;
    static String genStr[] = new String[3];
    TextView medicine, supplier, price, mobile, buYnow, desc, descheading,
            safetycheading, safety, compsition, textcompsition, sideeffects, textsideeffects,
            quick_tips, how_to_use, how_it_works, texttips, textuse, twxtworks, mrp, discount, address, textcount;
    CircleImageView add, remove;
    CardView desccard, safetycard, compsitionccard, workscard, effectcard, tipscard, usecard;
    MaterialButton addTocart;
    private ImageView mImgae, mShare;
    private EditText quantitydetail;
    LinearLayout mLinearLayout, mPageLinear;
    LinearLayoutCompat linearLayoutCompat;
    private RelativeLayout mRelativeLayout;
    RecyclerView sideeefectdata, tipsdata, safetydata;
    NetWorkInfoUtility netWorkInfoUtility;
    Utility utility;
    Context context;
    DataAdapter dataAdapter;
    ProgressDialog progressDialog;
    ConstraintLayout constraintLayout;
    int duration = 5000, pid, quantity, count = 0;
    String authkey, message;
    Float mPrice;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        netWorkInfoUtility = new NetWorkInfoUtility();
        utility = new Utility(this);
        initLayout();
    }

    private void initLayout() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);// add back arrow to toolbar
        }
        //  mLinearLayout =  findViewById(R.id.layout_action1);
        linearLayoutCompat = findViewById(R.id.linearsideffect);
        mPageLinear = findViewById(R.id.pager_click);
        mRelativeLayout = findViewById(R.id.pager_relative);
        indicator = findViewById(R.id.indicator);
        medicine = findViewById(R.id.id_jeasns);
        price = findViewById(R.id.id_price);
        supplier = findViewById(R.id.id_fit);
        mobile = findViewById(R.id.id_mobile);
        desc = findViewById(R.id.textdesc);
        descheading = findViewById(R.id.desc);
        safetydata = findViewById(R.id.recycler_view_safty);
        safetycheading = findViewById(R.id.safety);
        compsition = findViewById(R.id.compsition);
        textcompsition = findViewById(R.id.textcompsition);
        sideeffects = findViewById(R.id.sideeffects);
        // textsideeffects = findViewById(R.id.textsideeffects);
        sideeefectdata = findViewById(R.id.recycler_view_sideeefect);
        quick_tips = findViewById(R.id.quick_tips);
        tipsdata = findViewById(R.id.recycler_view_tips);
        how_it_works = findViewById(R.id.how_it_works);
        twxtworks = findViewById(R.id.texthow_it_works);
        how_to_use = findViewById(R.id.how_to_use);
        textuse = findViewById(R.id.texthow_to_use);
        mrp = findViewById(R.id.id_mrp);
        discount = findViewById(R.id.id_discount);
        quantitydetail = findViewById(R.id.spinnerquantity);
        addTocart = findViewById(R.id.addtocart);
        address = findViewById(R.id.id_color);
        desccard = findViewById(R.id.desccard);
        safetycard = findViewById(R.id.safetycard);
        compsitionccard = findViewById(R.id.compsitionccard);
        workscard = findViewById(R.id.workscard);
        effectcard = findViewById(R.id.effectcard);
        tipscard = findViewById(R.id.tipscard);
        usecard = findViewById(R.id.usecard);
        // buYnow = findViewById(R.id.text_action_bottom2);
        textcount = findViewById(R.id.counter);
        add = findViewById(R.id.sum);
        remove = findViewById(R.id.remove);
        final int[] number = {1};
        textcount.setText("" + number[0]);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number[0] = number[0] + 1;
                textcount.setText("" + number[0]);

            }
        });

        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (number[0] == 1) {
                    textcount.setText("" + number[0]);
                }

                if (number[0] > 1) {

                    number[0] = number[0] - 1;
                    textcount.setText("" + number[0]);
                }

                }

        });


        addTocart.setOnClickListener(this);
        // buYnow.setOnClickListener(this);

        getProduct();
    }

    private void getProduct() {
        //authkey = SharedHelper.getKey(ProductDetail.this,"authkey");
        // int pid = Integer.parseInt(SharedHelper.getKey(ProductDetail.this,"pid"));
        pid = Integer.parseInt(getIntent().getStringExtra("pid"));
        if (netWorkInfoUtility.isNetWorkAvailableNow(ProductDetail.this)) {
            progressDialog = CommonUtils.showLoadingDialog(ProductDetail.this);
            Call<ProductDetails> call = APIClient.getNetInstance().productGetDetail(pid);
            call.enqueue(new Callback<ProductDetails>() {
                @Override
                public void onResponse(Call<ProductDetails> call1, Response<ProductDetails> response) {
                    if (response.isSuccessful()) {
                        dismissDialog();
                        if (response.body().getStatus() == 1) {
                            medicine.setText(response.body().getMessage().getProductName());
                            //  price.setText("Rs." + response.body().getMessage().getPrice());
                            float mrpamount = response.body().getMessage().getPrice();
                            float discount_amount = response.body().getMessage().getDiscount();
                            if (discount_amount > 0) {
                                discount.setVisibility(View.VISIBLE);
                                mrp.setText("MRP: \u20B9" + String.valueOf(mrpamount));
                                discount.setText(response.body().getMessage().getDiscount() + "%" + "off");
                                float amount = mrpamount - (mrpamount * discount_amount / 100);
                                price.setText("\u20B9" + (int) amount);

                            } else {
                                discount.setVisibility(View.INVISIBLE);
                                discount.setVisibility(View.INVISIBLE);
                                mrp.setVisibility(View.INVISIBLE);
                                price.setText("MRP: \u20B9" + mrpamount);

                            }
                            mPrice = Float.valueOf(response.body().getMessage().getPrice());
                            loadindicator(response.body().getMessage().getImages());
                            supplier.setText(response.body().getMessage().getSupplierName());
                            String unit = response.body().getMessage().getUnit();
                            mobile.setText(String.valueOf(response.body().getMessage().getQuantity() + unit));
                            if (response.body().getMessage().getDescription().equals("")) {
                                desccard.setVisibility(View.GONE);
                                descheading.setVisibility(View.GONE);
                                desc.setVisibility(View.GONE);
                            } else {
                                desc.setText(response.body().getMessage().getDescription());
                            }
                            if (response.body().getMessage().getSafetyAdvice() == null) {
                                safetycard.setVisibility(View.GONE);
                                safetycheading.setVisibility(View.GONE);
                                safetydata.setVisibility(View.GONE);
                            } else {
                                RecyclerView.LayoutManager manager = new LinearLayoutManager(getApplicationContext());
                                safetydata.setLayoutManager(manager);
                                dataAdapter = new DataAdapter(ProductDetail.this, response.body().getMessage().getSafetyAdvice());
                                safetydata.setAdapter(dataAdapter);

                            }
                            if (response.body().getMessage().getComposition().equals("")) {
                                compsitionccard.setVisibility(View.GONE);
                                compsition.setVisibility(View.GONE);
                                textcompsition.setVisibility(View.GONE);
                            } else {
                                textcompsition.setText(response.body().getMessage().getComposition());
                            }
                            if (response.body().getMessage().getSideEffects() == null || response.body().getMessage().getSideEffects().equals("")) {
                                effectcard.setVisibility(View.GONE);
                                sideeffects.setVisibility(View.GONE);
                                // textsideeffects.setVisibility(View.GONE);
                            } else {
                                RecyclerView.LayoutManager manager = new LinearLayoutManager(getApplicationContext());
                                sideeefectdata.setLayoutManager(manager);
                                dataAdapter = new DataAdapter(ProductDetail.this, response.body().getMessage().getSideEffects());
                                sideeefectdata.setAdapter(dataAdapter);
                            }
                            if (response.body().getMessage().getQuickTips() == null || response.body().getMessage().getQuickTips().equals("")) {
                                tipscard.setVisibility(View.GONE);
                                quick_tips.setVisibility(View.GONE);
                                // texttips.setVisibility(View.GONE);
                            } else {
                                RecyclerView.LayoutManager manager = new LinearLayoutManager(getApplicationContext());
                                tipsdata.setLayoutManager(manager);
                                dataAdapter = new DataAdapter(ProductDetail.this, response.body().getMessage().getQuickTips());
                                tipsdata.setAdapter(dataAdapter);
                            }
                           /* if(response.body().getMessage().getQuickTips() == null){
                                quick_tips.setVisibility(View.GONE);
                                texttips.setVisibility(View.GONE);
                            }else{
                                texttips.setText(response.body().getMessage().getQuickTips());
                            }*/

                            if (response.body().getMessage().getHowUse().equals("")) {
                                usecard.setVisibility(View.GONE);
                                how_to_use.setVisibility(View.GONE);
                                textuse.setVisibility(View.GONE);
                            } else {
                                textuse.setText(response.body().getMessage().getHowUse());
                            }
                            if (response.body().getMessage().getHowWorks().equals("")) {
                                workscard.setVisibility(View.GONE);
                                how_it_works.setVisibility(View.GONE);
                                twxtworks.setVisibility(View.GONE);
                            } else {
                                twxtworks.setText(response.body().getMessage().getHowWorks());
                            }
                            address.setText(response.body().getMessage().getVillage() +
                                    response.body().getMessage().getTehsil() + response.body().getMessage().getDistrict()
                                    + response.body().getMessage().getState());
                        } else {
                            // Toast.makeText(getActivity(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<ProductDetails> call, Throwable t) {
                    dismissDialog();

                }
            });
        } else {
            showNetworkError();
        }


    }

    private void loadindicator(List<String> images) {
        final String genreStr = "";
        int i = 0;
        for (String str : images) {
            genStr[i] = str;


            System.out.println("genStr[" + i + "]: " + genStr[i]);
            i++;
        }
        //      IMAGES = new String[genStr.length];
        final ArrayList<String> ImagesArray = new ArrayList<String>();
        // ImagesArray.add(genreStr);
        ImagesArray.addAll(Arrays.asList(genStr));
        System.out.println(ImagesArray.get(0));
        mPager = findViewById(R.id.pager);
        mPager.setAdapter(new SlidingImage_Adapter(ProductDetail.this, ImagesArray));
        indicator.setViewPager(mPager);
        final float density = getResources().getDisplayMetrics().density;
        indicator.setRadius(5 * density);
        NUM_PAGES = i;
        System.out.println("pages: " + NUM_PAGES);
        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                mPager.setCurrentItem(currentPage++, true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 4200, 4200);
        indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                currentPage = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }

        });


    }

    private void showNetworkError() {
        Snackbar snackbar = Snackbar
                .make(mLinearLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);
        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(), ByProductActivity.class);
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        startActivity(i);
        finish();
    }

    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.addtocart:
                if (utility.IsLogin()) {

                        // editText is empty
                        addtoCart();



                } else {
                    AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(ProductDetail.this);
                    myAlertDialog.setTitle("--- Alert ---");
                    myAlertDialog.setMessage("First login");
                    myAlertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface arg0, int arg1) {
                          /*  Intent mainIntent = new Intent(ProductDetail.this, HomeActivity.class);
                            startActivity(mainIntent);
                            finish();*/
                        }
                    });
                    myAlertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface arg0, int arg1) {
                            // do something when the Cancel button is clicked
                        }
                    });
                    myAlertDialog.show();


                    //  loadFragment(new SmsFragment());


                }
                break;
        /*    case R.id.text_action_bottom2:
                ByeNow();
                break;*/

        }

    }

    private void loadFragment(Fragment fragment) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.add(R.id.rootLayout, fragment, "Test Fragment");
        // transaction.addToBackStack(null);
        transaction.commit();
    }

    private void ByeNow() {
    }

    private void addtoCart() {
        if (netWorkInfoUtility.isNetWorkAvailableNow(getApplicationContext())) {
            authkey = SharedHelper.getKey(ProductDetail.this, "authkey");
            //int quantity = Integer.parseInt(quantitydetail.getText().toString());
            // int pid = Integer.parseInt(Utility.getPID());
            quantity = Integer.parseInt(textcount.getText().toString());
            Call<CartModel> call = APIClient.getNetInstance().addCartDetail(authkey, pid, quantity,
                    mPrice);
            call.enqueue(new Callback<CartModel>() {
                @Override
                public void onResponse(Call<CartModel> call, Response<CartModel> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            Utility.setPid(String.valueOf(pid));
                            message = response.body().getMessage();
                            scheduleNotification(getNotification(message));
                            Toast.makeText(ProductDetail.this, message, Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(getApplicationContext(), HomeActivity.class);
                            overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                            startActivity(i);
                            finish();

                        } else if (response.body().getStatus() == 0) {
                            String msg = response.body().getMessage();
                            Toast.makeText(ProductDetail.this, msg, Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<CartModel> call, Throwable t) {
                    Toast.makeText(ProductDetail.this, message, Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            showNetworkError();
            Toast.makeText(getApplicationContext(), "Network Error", Toast.LENGTH_SHORT).show();
        }
    }


    private void scheduleNotification(Notification notification) {
        Intent notificationIntent = new Intent(this, MyNotificationPublisher.class);
        notificationIntent.putExtra(MyNotificationPublisher.NOTIFICATION_ID, 1);
        notificationIntent.putExtra(MyNotificationPublisher.NOTIFICATION, notification);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        long futureInMillis = SystemClock.elapsedRealtime();
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        assert alarmManager != null;
        alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, futureInMillis, pendingIntent);
    }

    private Notification getNotification(String content) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, default_notification_channel_id);
        builder.setContentTitle("you have added product");
        builder.setContentText(content);
        builder.setSmallIcon(R.drawable.logo);
        builder.setAutoCancel(true);
        builder.setChannelId(NOTIFICATION_CHANNEL_ID);
        return builder.build();
    }
}
