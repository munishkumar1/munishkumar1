package com.mbinfo.medico.ui.profile;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.profilemodel.ProfileData;
import com.mbinfo.medico.retailerdetail.SupplierActivity;
import com.mbinfo.medico.ui.category.Categtory;
import com.mbinfo.medico.ui.otp.OtpActivity;
import com.mbinfo.medico.utils.CommonUtils;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity  extends AppCompatActivity implements ProfileContractor.View, View.OnClickListener {
    CircleImageView profile;
    TextView name,email,mName,mEmail,mobile,adress;
    ProgressDialog progressDialog;
    ProfileContractor.Presenter presenter;
    View backtohome;
    CoordinatorLayout coordinatorLayout;
    int duration = 5000;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        presenter = new ProfilePresenter(this);
       // getProfileData();
        presenter.onSubmit();
        initLayout();
    }
    private void initLayout() {
        name = findViewById(R.id.person);
        mName = findViewById(R.id.mName);
        email = findViewById(R.id.email);
        mobile = findViewById(R.id.phone);
        adress = findViewById(R.id.venue);
        backtohome = findViewById(R.id.bactohome);
        profile = findViewById(R.id.profile_image);
        coordinatorLayout = findViewById(R.id.mainlayout);
        backtohome.setOnClickListener(this);
    }

    @Override
    public void showSubmitProgress() {
        progressDialog = CommonUtils.showLoadingDialog(this);
    }

    @Override
    public void showSubmitSuccess(ProfileData message) {
        dismissDialog();
        name.setText(message.getName());
        mName.setText(message.getName());
        String phone = message.getMobile();
        System.out.println(phone);
        mobile.setText(phone);
        adress.setText(message.getVillage() + message.getDistrict());
//               adress.setText(message.getAddressId());
        String imgurl = message.getImage();
        if (imgurl != null) {
       /*    Glide.with(context).load(imgurl).
       into(holder.medicineview);*/
            Glide.with(ProfileActivity.this)
                    .load(imgurl)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(profile);
        } else {
            Glide.with(ProfileActivity.this)
                    .load(R.drawable.med)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(profile);

        }
    }
    @Override
    public void showSubmitError(String message) {

    }

    @Override
    public void showNetworkNotAvailableError() {
        Snackbar snackbar = Snackbar
                .make(coordinatorLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)

                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);

        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    @Override
     public void initView() {




    }

    private void getProfileData() {
        presenter.onSubmit();
    }

    @Override
    public Context getContext() {
        return this;
    }
    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    @Override
    public void onClick(View v) {
        Categtory.start(getApplicationContext());
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        finish();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(), SupplierActivity.class);
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        startActivity(i);
        finish();
    }

}
