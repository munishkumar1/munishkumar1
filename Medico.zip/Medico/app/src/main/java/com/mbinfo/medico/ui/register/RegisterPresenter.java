package com.mbinfo.medico.ui.register;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.ui.sms.SmsContract;
import com.mbinfo.medico.utils.NetWorkInfoUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterPresenter implements RegisterContract.Presenter {
    RegisterContract.View view;
    NetWorkInfoUtility netWorkInfoUtility;
    String business ="";
    Context context;

    public RegisterPresenter(RegisterActivity view) {
        this.view = view;
        netWorkInfoUtility = new NetWorkInfoUtility();
    }




    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }


    @Override
    public void onRegister(String username, String fathername, String business, final String mobile, String utype,String aadhaar,
                           String address, String village, String landmark,
                           String ward, String block, String distict, String state, String pin) {
        if (netWorkInfoUtility.isNetWorkAvailableNow(view.getContext())) {
            view.showSubmitProgress();
            Call<Sms> call = APIClient.getNetInstance().processReg(username,fathername,business,mobile,utype,aadhaar,address,
                    village,landmark,ward,block,distict,state,pin);
            call.enqueue(new Callback<Sms>() {
                @Override
                public void onResponse(Call<Sms> call, Response<Sms> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            String authkey = response.body().getMessage();
                            SharedHelper.putKey(view.getContext(),"authkey",authkey);
                            System.out.println(authkey);
                            view.showSubmitSuccess();

                        } else {
                            Toast.makeText(view.getContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            view.showSubmitError(response.body().getMessage());
                        }
                    }
                }

                @Override
                public void onFailure(Call<Sms> call, Throwable t) {
                    view.showSubmitError("check error");

                }
            });
        } else {
            view.showNetworkNotAvailableError();
            // Toast.makeText(view.getContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }


    }
}
