package com.mbinfo.medico.retailerdetail;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.ProductListAdapter;
import com.mbinfo.medico.adapter.RetailListAdapter;
import com.mbinfo.medico.data.model.product.Product;
import com.mbinfo.medico.data.model.product.ProductList;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.productdetail.ProductDetail;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.ui.product.ByProductActivity;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.RecyclerTouchListener;

import java.util.List;

import static androidx.constraintlayout.widget.Constraints.TAG;

public class RetailerActivity_Detail extends AppCompatActivity {
    RecyclerView recyclerView;
    View view;
    NetWorkInfoUtility netWorkInfoUtility;
    Context context;
    CircleImageView backarrow;
    ProgressDialog progressDialog;
    ConstraintLayout constraintLayout;
    LinearLayout NoItemLayout;
    int duration = 5000;
    String authkey, pid;
    int tab = 1, cat;
    Button bAddNew;
    RetailAdapter adapter;
    SwipeRefreshLayout swipeRefreshLayout;
    public List<ProductList> message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retailer__detail);
        initView();
    }

    private void initView() {
        netWorkInfoUtility = new NetWorkInfoUtility();
        recyclerView = findViewById(R.id.reclone);
        constraintLayout = findViewById(R.id.id_constp);
        NoItemLayout = findViewById(R.id.layout_cat_empty);
        bAddNew = findViewById(R.id.bAddNew);
        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent
                , R.color.colorPrimaryDark);
        backarrow = findViewById(R.id.profile_image);
        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getApplicationContext(), HomeActivity.class);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_in_left);
                startActivity(in);
                finish();
            }
        });
        bAddNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getApplicationContext(), HomeActivity.class);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_in_left);
                startActivity(in);
                finish();
            }
        });
        initLoadData();
    }
    private void initLoadData() {
        // cat = Utility.getCatid();
        Intent i = getIntent();
        int rid = i.getIntExtra("rid",0);
        System.out.println(rid);
        if (netWorkInfoUtility.isNetWorkAvailableNow(RetailerActivity_Detail.this)) {
            progressDialog = CommonUtils.showLoadingDialog(RetailerActivity_Detail.this);
            Call<Product> call = APIClient.getNetInstance().retailGet(rid);
            call.enqueue(new Callback<Product>() {
                @Override
                public void onResponse(Call<Product> call, Response<Product> response) {
                    if (response.isSuccessful()) {
                        dismissDialog();
                        if (response.body().getStatus() == 1) {
                            adapter = new RetailAdapter(RetailerActivity_Detail.this, response.body().getMessage());
                            recyclerView.setAdapter(adapter);
                            // adapter.notifyDataSetChanged();
                            message = response.body().getMessage();
                            swiipeData(response.body().getMessage());
                        } else if (response.body().getStatus() == 0) {
                            dismissDialog();
                            Toast.makeText(getApplicationContext(), (CharSequence) response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        } else {
                            // Toast.makeText(getActivity(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Product> call, Throwable t) {
                    dismissDialog();
                    Toast.makeText(getApplicationContext(), "no data", Toast.LENGTH_SHORT).show();
                    /*Categtory.start(getActivity());
                    getActivity().overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
                    getActivity().finish();*/
                    NoItemLayout.setVisibility(View.VISIBLE);
                    //  constraintLayout.setVisibility(View.GONE);
                }
            });
        } else {

            showNetworkError();
        }
    }
    private void swiipeData(List<ProductList> message) {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                suffle(message);
                swipeRefreshLayout.setRefreshing(false);
            }

            private void suffle(List<ProductList> message) {
                adapter = new RetailAdapter(RetailerActivity_Detail.this,message);
                StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
        });

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(this,
                recyclerView, new RecyclerTouchListener.ClickListener() {

            @Override
            public void onClick(View view, final int position) {
                Log.e(TAG, "Short press on position :" + position);
                String pid = String.valueOf(message.get(position).getId());
                //   Utility.setPid(pid);
                //TODO create a visit from the data from webcall (in appObj) for info passed to email, text etc
                Intent i = new Intent(RetailerActivity_Detail.this, ProductDetail.class);
                i.putExtra("pid",pid);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_in_left);
                startActivity(i);
                finish();
            }
            @Override
            public void onLongClick(View view, int position) {

                Log.e(TAG, "Long press on position :" + position);
            }

        }));
    }

    private void showNetworkError() {
        Snackbar snackbar = Snackbar
                .make(constraintLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);
        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }
    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }
    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        startActivity(new Intent(RetailerActivity_Detail.this, HomeActivity.class));
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_in_left);
        finish();

    }
}
