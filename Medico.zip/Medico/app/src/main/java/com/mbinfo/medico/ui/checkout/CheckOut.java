package com.mbinfo.medico.ui.checkout;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.CityAdapter;
import com.mbinfo.medico.adapter.StateAdapter;
import com.mbinfo.medico.adapter.TehsilAdapter;
import com.mbinfo.medico.data.model.CheckOutModel;
import com.mbinfo.medico.data.model.SpinnerItem;
import com.mbinfo.medico.data.model.city.City;
import com.mbinfo.medico.data.model.productdetail.ProductDetails;
import com.mbinfo.medico.data.model.state.StateModel;
import com.mbinfo.medico.data.model.tehsil.Tehsil;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.productdetail.ProductDetail;
import com.mbinfo.medico.ui.category.CatContractor;
import com.mbinfo.medico.ui.category.Categtory;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.ui.mycart.MyCart;
import com.mbinfo.medico.ui.register.RegisterActivity;
import com.mbinfo.medico.ui.thnaks.ThankYou;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.NetWorkInfoUtility;
import com.mbinfo.medico.utils.Utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckOut extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {
    ProgressDialog progressDialog;
    ConstraintLayout constraintLayout;
    NetWorkInfoUtility netWorkInfoUtility;
    int duration = 5000;
    EditText mVillage,mLandmark,mPanchyat,mPincode,mMobile;
    Spinner mState,mDistict,mTashil;
    String select_distict,select_teshil,select_state;
    CheckBox checkBox;
    Spinner mPaymode;
    Toolbar toolbar;
    CityAdop cityAdop;
    StateAdob stateAdob;
    TehsilAdop tehsilAdop;
    CircleImageView backarrow;
    public static final String[] titles = {"Online", "COD"};
    Button mPlaceOrder;
    String authkey,mode,old_addr;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);
        netWorkInfoUtility = new NetWorkInfoUtility();
        initLayout();
      loadTehsil();
      loadSpinnerCity();
    }

    private void initLayout() {
        backarrow = findViewById(R.id.profile_image);
        backarrow.setOnClickListener((View v) -> {
            Intent in = new Intent(getApplicationContext(), MyCart.class);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_in_left);
            startActivity(in);
            finish();
        });
        mVillage = findViewById(R.id.place_village);
        mLandmark = findViewById(R.id.id_landmark);
        mPanchyat = findViewById(R.id.address);
        mState = findViewById(R.id.state_spinner);
        mDistict = findViewById(R.id.distict_spinner);
        mTashil = findViewById(R.id.tesil_spinner);
        mState.setOnItemSelectedListener(this);
        mDistict.setOnItemSelectedListener(this);
        loadSpinnerState();
        mPincode = findViewById(R.id.pincode);
        mMobile = findViewById(R.id.adhar);
        mPaymode = findViewById(R.id.spinner_order);
        mPlaceOrder = findViewById(R.id.place_order);
        constraintLayout = findViewById(R.id.order_layout);
        checkBox = findViewById(R.id.checkView);
        checkBox.setOnClickListener(this);
        mPlaceOrder.setOnClickListener(this);
        loadSpinnerData();
        System.out.println(old_addr);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                if (isChecked) {
                    old_addr = "y";
                    mVillage.setVisibility(View.GONE);
                    mLandmark.setVisibility(View.GONE);
                    mPanchyat.setVisibility(View.GONE);
                    mTashil.setVisibility(View.GONE);
                    mDistict.setVisibility(View.GONE);
                    mState.setVisibility(View.GONE);
                    mPincode.setVisibility(View.GONE);
                    //Toast.makeText(getApplicationContext(),old_addr , Toast.LENGTH_LONG).show();
                    mPlaceOrder.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            PlaceOrder();
                        }
                    });
                }if(!isChecked){
                    mVillage.setVisibility(View.VISIBLE);
                    mLandmark.setVisibility(View.VISIBLE);
                    mPanchyat.setVisibility(View.VISIBLE);
                    mTashil.setVisibility(View.VISIBLE);
                    mDistict.setVisibility(View.VISIBLE);
                    mState.setVisibility(View.VISIBLE);
                    mPincode.setVisibility(View.VISIBLE);
                    PlaceOrder();
                }
            }
        });
    }

    private void loadSpinnerState() {
        Call<StateModel> call = APIClient.getNetInstance().loadState();
        call.enqueue(new Callback<StateModel>() {
            @Override
            public void onResponse(Call<StateModel> call, Response<StateModel> response) {
                if(response.isSuccessful()){
                    if (response.body().getStatus() == 1){
                        // Log.d(TAG, "onResponse: response");
                        stateAdob = new StateAdob(CheckOut.this,
                                R.layout.spinner_item, R.id.title, response.body().getMessage());
                        mState.setAdapter(stateAdob);

                    }
                }
            }

            @Override
            public void onFailure(Call<StateModel> call, Throwable t) {

            }
        });
    }


    private void openActivity() {
        Intent i = new Intent(getApplicationContext(), ThankYou.class);
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        startActivity(i);
        finish();
    }

    private void showNetworkError() {
        Snackbar snackbar = Snackbar
                .make(constraintLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);
        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    private void loadSpinnerData() {
        final List<String> plantsList = new ArrayList<>(Arrays.asList(titles));

        // Initializing an ArrayAdapter
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                this, R.layout.checkout_item, R.id.title, plantsList) {
          /*  @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if(position%2 == 1) {
                    // Set the item background color
                    tv.setBackgroundColor(Color.parseColor("#FFF9A600"));
                }
                else {
                    // Set the alternate item background color
                    tv.setBackgroundColor(Color.parseColor("#FFE49200"));
                }
                return view;
            }
        };*/

        /*
            public void setPrompt (CharSequence prompt)
                Sets the prompt to display when the dialog is shown.
         */
        };
        mPaymode.setPrompt("Select an item");

            // spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item);
        mPaymode.setAdapter(spinnerArrayAdapter);
        mPaymode.setOnItemSelectedListener(this);
        }



    private boolean validate() {
            if(mVillage.getText().toString().isEmpty()) {
                mVillage.setError("UserName can not be empty");
                return false;
            }   if(mLandmark.getText().toString().isEmpty()) {
                mLandmark.setError("FatherName can not be empty");
                return false;
            }if(mPanchyat.getText().toString().isEmpty()) {
                mPanchyat.setError("Village can not be empty");
                return false;
         /*   }if(mTashil.getText().toString().isEmpty()) {
                mTashil.setError("Ward can not be empty");
                return false;
            }if(mDistict.getText().toString().isEmpty()) {
                mDistict.setError("Block can not be empty");
                return false;
            }if(mState.getText().toString().isEmpty()) {
                mState.setError("Distict can not be empty");
                return false;*/
            }if(mPincode.getText().toString().isEmpty()) {
                mPincode.setError("Pincode can not be empty");
                return false;
            } if (mMobile.getText().toString().equals("") || (mMobile.getText().toString().length()!=10) ) {
                mMobile.setError(getString(R.string.empty_field_msg));
                mMobile.setError("Enter 10 digit Mobile Number");
                return false;
            }
            return true;
        }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.state_spinner:
               select_state  = mState.getSelectedItem().toString();
                loadSpinnerCity();
                break;
            case R.id.distict_spinner:
                select_distict = mDistict.getSelectedItem().toString();
                loadTehsil();
                break;
            case R.id.tesil_spinner:
                select_teshil = mTashil.getSelectedItem().toString();
                break;
                case R.id.spinner_order:
                    mode = parent.getItemAtPosition(position).toString();
                    // TypeSelected = position;
                    break;

        }
    }
    private void loadTehsil() {
        String cityid = Utility.getCityid();
        Call<Tehsil> call = APIClient.getNetInstance().loadTehsilData(122);
        call.enqueue(new Callback<Tehsil>() {
            @Override
            public void onResponse(Call<Tehsil> call, Response<Tehsil> response) {
                if(response.isSuccessful()){
                    if (response.body().getStatus() == 1){
                        Log.v("net", String.valueOf(response));
                        tehsilAdop = new TehsilAdop(CheckOut.this,
                                R.layout.spinner_item, R.id.title, response.body().getMessage());
                        mTashil.setAdapter(tehsilAdop);
                    }
                }
            }

            @Override
            public void onFailure(Call<Tehsil> call, Throwable t) {

            }
        });
    }

    private void loadSpinnerCity() {
        String stateid = Utility.getStateid();
        Call<City> call = APIClient.getNetInstance().loadCity(stateid);
        call.enqueue(new Callback<City>() {
            @Override
            public void onResponse(Call<City> call, Response<City> response) {
                if(response.isSuccessful()){
                    if (response.body().getStatus() == 1){
                        Log.v("net", String.valueOf(response));
                        cityAdop = new CityAdop(CheckOut.this,
                                R.layout.spinner_item, R.id.title, response.body().getMessage());
                        mDistict.setAdapter(cityAdop);

                    }
                }
            }

            @Override
            public void onFailure(Call<City> call, Throwable t) {

            }
        });

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(), MyCart.class);
        overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
        startActivity(i);
        finish();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }





    private void PlaceOrder() {
        String village = mVillage.getText().toString().trim();
        String landmark = mLandmark.getText().toString().trim();
        String panchyat = mPanchyat.getText().toString().trim();
    /*    String tashil = mTashil.getText().toString().trim();
        String distict = mDistict.getText().toString().trim();
        String state = mState.getText().toString().trim();*/
        String pincode = mPincode.getText().toString().trim();
        String mobile = mMobile.getText().toString().trim();
        authkey = SharedHelper.getKey(CheckOut.this,"authkey");
        if(netWorkInfoUtility.isNetWorkAvailableNow(CheckOut.this)){
            progressDialog = CommonUtils.showLoadingDialog(CheckOut.this);
            Call<CheckOutModel> call = APIClient.getNetInstance().OrderPlace(authkey,
                    village,landmark,panchyat,1,1,1,pincode,mobile,mode,old_addr);
            call.enqueue(new Callback<CheckOutModel>() {
                @Override
                public void onResponse(Call<CheckOutModel> call, Response<CheckOutModel> response) {
                    if (response.isSuccessful()) {
                        dismissDialog();
                        if(response.body().getStatus() == 1) {
                            openActivity();
                        }

                        else {
                            // Toast.makeText(getActivity(),response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<CheckOutModel> call, Throwable t) {
                    dismissDialog();

                }
            });
        }else {
            showNetworkError();
        }

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
         /*   case R.id.checkView:
               if(checkBox.isChecked()) {
                   old_addr="y";
                   mVillage.setVisibility(View.GONE);
                   mLandmark.setVisibility(View.GONE);
                   mPanchyat.setVisibility(View.GONE);
                   mTashil.setVisibility(View.GONE);
                   mDistict.setVisibility(View.GONE);
                   mState.setVisibility(View.GONE);
                   mPincode.setVisibility(View.GONE);
               }
               if(!checkBox.isChecked()){
                   old_addr ="n";
                   mVillage.setVisibility(View.VISIBLE);
                   mLandmark.setVisibility(View.VISIBLE);
                   mPanchyat.setVisibility(View.VISIBLE);
                   mTashil.setVisibility(View.VISIBLE);
                   mDistict.setVisibility(View.VISIBLE);
                   mState.setVisibility(View.VISIBLE);
                   mPincode.setVisibility(View.VISIBLE);
                   if(old_addr.equals("n") && validate()) {
                       PlaceOrder();
                   }
               }
                break;*/
            case R.id.place_order:
                if(validate()) {
                    PlaceOrder();
                }
                break;
    }
}
}

