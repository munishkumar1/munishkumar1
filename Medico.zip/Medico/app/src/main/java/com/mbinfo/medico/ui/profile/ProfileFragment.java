package com.mbinfo.medico.ui.profile;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.util.Rational;
import android.util.Size;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.profilemodel.ProfileData;
import com.mbinfo.medico.ui.sms.SmsPresenter;
import com.mbinfo.medico.utils.CameraUtil;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.Utility;

import java.io.File;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.camera.core.CameraX;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureConfig;
import androidx.camera.core.Preview;
import androidx.camera.core.PreviewConfig;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LifecycleOwner;
import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileFragment extends Fragment implements ProfileContractor.View, View.OnClickListener {
    CircleImageView profile;
    TextView name,email,mName,mEmail,mobile,adress;
    ProgressDialog progressDialog;
    ProfileContractor.Presenter presenter;
    View view ,backtohome;
    CoordinatorLayout coordinatorLayout;
    int duration = 5000;
    TextureView textureView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.activity_profile, null);
        presenter = new ProfilePresenter(this);
        // getProfileData();
        presenter.onSubmit();
        initLayout();
        return view;
    }

    private void initLayout() {
        name = view.findViewById(R.id.person);
        mName = view.findViewById(R.id.mName);
        email = view.findViewById(R.id.email);
        mobile = view.findViewById(R.id.phone);
        adress = view.findViewById(R.id.venue);
        backtohome =view.findViewById(R.id.bactohome);
        profile =view.findViewById(R.id.profile_image);
        textureView =view.findViewById(R.id.view_finder);
        coordinatorLayout = view.findViewById(R.id.mainlayout);
        backtohome.setOnClickListener(this);
        profile.setOnClickListener(this);
        openCamera();

    }

    @Override
    public void onClick(View v) {


    }

    private void openCamera() {
        if(CameraUtil.checkPermission(getActivity())){
            CameraX.unbindAll();
            Rational aspectRatio = new Rational (textureView.getWidth(), textureView.getHeight());
            Size screen = new Size(textureView.getWidth(), textureView.getHeight()); //size of the screen


            PreviewConfig pConfig = new PreviewConfig.Builder().setTargetAspectRatio(aspectRatio).setTargetResolution(screen).build();
            Preview preview = new Preview(pConfig);

            preview.setOnPreviewOutputUpdateListener(
                    new Preview.OnPreviewOutputUpdateListener() {
                        //to update the surface texture we  have to destroy it first then re-add it
                        @Override
                        public void onUpdated(Preview.PreviewOutput output){
                            ViewGroup parent = (ViewGroup) textureView.getParent();
                            parent.removeView(textureView);
                            parent.addView(textureView, 0);

                            textureView.setSurfaceTexture(output.getSurfaceTexture());
                            updateTransform();
                        }
                    });


            ImageCaptureConfig imageCaptureConfig = new ImageCaptureConfig.Builder().setCaptureMode(ImageCapture.CaptureMode.MIN_LATENCY)
                    .setTargetRotation(getActivity().getWindowManager().getDefaultDisplay().getRotation()).build();
            final ImageCapture imgCap = new ImageCapture(imageCaptureConfig);

            profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    File file = new File(Environment.getExternalStorageDirectory() + "/" + System.currentTimeMillis() + ".png");
                    imgCap.takePicture(file, new ImageCapture.OnImageSavedListener() {
                        @Override
                        public void onImageSaved(@NonNull File file) {
                            String msg = "Pic captured at " + file.getAbsolutePath();
                            Toast.makeText(getActivity(), msg,Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void onError(@NonNull ImageCapture.UseCaseError useCaseError, @NonNull String message, @Nullable Throwable cause) {
                            String msg = "Pic capture failed : " + message;
                            Toast.makeText(getActivity(), msg,Toast.LENGTH_LONG).show();
                            if(cause != null){
                                cause.printStackTrace();
                            }
                        }
                    });
                }
            });


            //bind to lifecycle:
            CameraX.bindToLifecycle((LifecycleOwner)this, preview, imgCap);
                }




        }

    private void updateTransform() {
        Matrix mx = new Matrix();
        float w = textureView.getMeasuredWidth();
        float h = textureView.getMeasuredHeight();

        float cX = w / 2f;
        float cY = h / 2f;

        int rotationDgr;
        int rotation = (int) textureView.getRotation();

        switch (rotation) {
            case Surface.ROTATION_0:
                rotationDgr = 0;
                break;
            case Surface.ROTATION_90:
                rotationDgr = 90;
                break;
            case Surface.ROTATION_180:
                rotationDgr = 180;
                break;
            case Surface.ROTATION_270:
                rotationDgr = 270;
                break;
            default:
                return;
        }
        mx.postRotate((float)rotationDgr, cX, cY);
        textureView.setTransform(mx);
    }


    @Override
    public void showSubmitProgress() {
        progressDialog = CommonUtils.showLoadingDialog(getActivity());
    }

    @Override
    public void showSubmitSuccess(ProfileData message) {
        dismissDialog();
        name.setText(message.getName());
        mName.setText(message.getName());
        Utility.setUserName(message.getName());
        String phone = message.getMobile();
        System.out.println(phone);
        mobile.setText(phone);
        Utility.setUserMobileNumber(message.getMobile());
     //   Utility.setUtype(message.getUtype());
        adress.setText(message.getVillage() + message.getDistrict());
//               adress.setText(message.getAddressId());
        String imgurl = message.getImage();
        if (imgurl != null) {
       /*    Glide.with(context).load(imgurl).
       into(holder.medicineview);*/
            Glide.with(getActivity())
                    .load(imgurl)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(profile);
        } else {
            Glide.with(getActivity())
                    .load(R.drawable.med)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(profile);

        }
    }

    @Override
    public void showSubmitError(String message) {

    }

    @Override
    public void showNetworkNotAvailableError() {
        Snackbar snackbar = Snackbar
                .make(coordinatorLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)

                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);

        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    @Override
    public void initView() {

    }
    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }
}
