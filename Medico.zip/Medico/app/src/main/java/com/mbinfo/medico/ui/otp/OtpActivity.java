package com.mbinfo.medico.ui.otp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import bov.vitali.smsinterceptor.OnMessageListener;
import bov.vitali.smsinterceptor.SmsInterceptor;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.prefs.SharedHelper;
import com.mbinfo.medico.retailerdetail.SupplierActivity;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.ui.register.RegisterAs;
import com.mbinfo.medico.utils.CommonUtils;
import com.mbinfo.medico.utils.Utility;

import java.util.ArrayList;
import java.util.List;

public class OtpActivity extends AppCompatActivity implements OtpContract.View, OnMessageListener {
    Context context;
    EditText mOtp;
    String otp,mobile;
    private ProgressDialog progressDialog;
    OtpContract.Presenter presenter;
    View verify;
    Sms sms;
    Utility utility;
    SmsInterceptor smsInterceptor;
    int duration = 5000,utype;
    String message,otpmessage;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    ConstraintLayout constraintLayout;
    public static void start(Context context) {
        Intent i = new Intent(context,OtpActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
           context.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp2);
        presenter = new OtpPresenter(this);
        utility = new Utility(this);
        initView();
        initSmsInterceptor();


        if (checkAndRequestPermissions()) {
            // carry on the normal flow, as the case of  permissions  granted.
        }

    }

    private boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS);
        int receiveSMS = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS);
        int readSMS = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (receiveSMS != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.RECEIVE_MMS);
        }
        if (readSMS != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_SMS);
        }
        if (permissionSendMessage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.SEND_SMS);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]),
                    REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }

     BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp")) {
                message = intent.getStringExtra("message");
/*
                TextView tv = (TextView) findViewById(R.id.txtview);
                tv.setText(message);*/
            }
        }
    };


    @Override
    public void showNetworkNotAvailableError() {
        Snackbar snackbar = Snackbar
                .make(constraintLayout, "No internet connection!", Snackbar.LENGTH_LONG).setDuration(duration)

                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });

        // Changing message text color
        snackbar.setActionTextColor(Color.WHITE);

        // Changing action button text color
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);

        snackbar.show();
    }

    public void initView() {
        constraintLayout = findViewById(R.id.otp_const);
        mOtp =  findViewById(R.id.otp);
        verify = findViewById(R.id.verify);
         sms = new Sms(OtpActivity.this);
        events();
    }

    private void events() {
        verify.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                otp =  mOtp.getText().toString();
                mobile = SharedHelper.getKey(OtpActivity.this,"mobile");
               if(validate()) {
                   verifyOtp();
               }else{
                   dismissDialog();
               }
            }
        });
    }

   private boolean validate() {
        //  mobile = mMobile.getText().toString().trim();
        //  password = mPassword.getText().toString().trim();
       boolean valid = true;
//        mOtp.setText(message);
//        mOtp.setError(null);
        //  mPassword.setError(null);
        if (otp.isEmpty()) {
            mOtp.setError(getString(R.string.empty_field_msg));
            valid = false;
        } else{
            mOtp.setError(null);
            }if (otp.length() != 6) {
           mOtp.setError("Enter 6 digit otp");
           valid = false;
       } else{
           mOtp.setError(null);
           }/*if(!message.equals(mOtp.getText().toString())) {
            mOtp.setError("error");
            valid = false;
        }else {
           mOtp.setError(null);*/

             return  valid;
    }
    private void verifyOtp() {
        presenter.onVerify(mobile,otp);
    }

  /*  @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i  = new Intent(this, SmsActivity.class);
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_in_left);
        startActivity(i);
        finish();

    }*/

    @Override
    public void showSubmitProgress() {

        progressDialog = CommonUtils.showLoadingDialog(this);
    }

    @Override
    public void showSubmitSuccess(String message, String uid) {
        System.out.println(uid);
       // SharedHelper.putKey(OtpActivity.this,"authkey",message);
        dismissDialog();
        if(message.equals("register")) {
            RegisterAs.start(getApplicationContext());
            overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
            finish();
        } if(uid.equals("1")){
            utility.setLogin();
            Utility.setUid(uid);
           // Categtory.start(getApplicationContext());
            HomeActivity.start(getApplicationContext());
            overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
            finish();
        } if(uid.equals("2")){
            utility.setLogin();
            Utility.setUid(uid);
            Intent i = new Intent(getApplicationContext(), SupplierActivity.class);
            startActivity(i);
            finish();
        }
    }

    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    @Override
    public void showSubmitError(String message) {
        dismissDialog();
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public Context getContext() {
        return this;
    }
    @Override
    public void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter("otp"));
        smsInterceptor.register();
    }

    @Override
    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
      smsInterceptor.unregister();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        smsInterceptor.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
    private void initSmsInterceptor() {
        smsInterceptor = new SmsInterceptor(this, this);
        // Not necessary

    }

    @Override
    public void messageReceived(String message) {
        otpmessage = message;
        String line = message;
        String regex = "[^\\d]+";

        String[] str = line.split(regex);

        System.out.println(str[1]);
        mOtp.setText(str[1]);
           mOtp.addTextChangedListener(new TextWatcher() {
               @Override
               public void beforeTextChanged(CharSequence s, int start, int count, int after) {

               }

               @Override
               public void onTextChanged(CharSequence s, int start, int before, int count) {

               }

               @Override
               public void afterTextChanged(Editable s) {
                   if(mOtp.getText().toString() != null) {
                       mOtp.setEnabled(true);
                       mOtp.setCursorVisible(true);
                   }
               }
           });
        }
    }

