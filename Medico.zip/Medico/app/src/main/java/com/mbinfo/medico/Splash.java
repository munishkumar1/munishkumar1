package com.mbinfo.medico;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mbinfo.medico.data.prefs.SessionManager;
import com.mbinfo.medico.ui.category.Categtory;
import com.mbinfo.medico.ui.home.HomeActivity;
import com.mbinfo.medico.ui.sms.SmsActivity;
import com.mbinfo.medico.utils.PermissionUtil;
import com.mbinfo.medico.utils.Utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Splash extends AppCompatActivity {
    private static final String TAG = Splash.class.getSimpleName();
    private static final int SPLASH_DISPLAY_LENGTH = 3000 ;
    String[] appPermission = {Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS, Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_EXTERNAL_STORAGE};
    private static final int PERMISSION_CODE = 1234;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    int deniedCount = 0;
    DialogInterface dialogInterface;
    SessionManager session;
    Utility utility;
     Animation animation;
     ImageView logo;
     TextView appTitle;
     TextView appSlogan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        session = new SessionManager(Splash.this);
        utility = new Utility(this);
//        session.checkLogin();
        init();
    }

    private void init() {
        logo = findViewById(R.id.logo);
        appTitle = findViewById(R.id.grocery);
        appSlogan = findViewById(R.id.slogan);
        try {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (utility.IsLogin()) {
                        Intent mainIntent = new Intent(Splash.this, HomeActivity.class);
                        Splash.this.startActivity(mainIntent);
                        Splash.this.finish();
                    } else {
                        Intent mainIntent = new Intent(Splash.this, HomeActivity.class);
                        Splash.this.startActivity(mainIntent);
                        Splash.this.finish();
                    }
                    /* Create an Intent that will start the Menu-Activity. */

                }
            }, SPLASH_DISPLAY_LENGTH);
        } catch (Exception e) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent newsIntent = new Intent(Splash.this, SmsActivity.class);
                    startActivity(newsIntent);
                    Splash.this.finish();
                }
            }, SPLASH_DISPLAY_LENGTH);
            e.printStackTrace();
        }
    }
        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == 1) {
                Intent newsIntent = new Intent(Splash.this, HomeActivity.class);
                startActivity(newsIntent);
                Splash.this.finish();
            }
    }




}
