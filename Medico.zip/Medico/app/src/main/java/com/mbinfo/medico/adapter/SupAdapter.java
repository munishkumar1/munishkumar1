package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.catmodel.CatList;
import com.mbinfo.medico.data.model.suppliermodel.TopSellData;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class SupAdapter extends RecyclerView.Adapter<SupAdapter.MyViewHolder> implements View.OnClickListener {
    public Context context;
    public List<TopSellData> mData;


    public SupAdapter(Context context, List<TopSellData> mData) {
        this.context = context;
        this.mData = mData;

    }


    @NonNull
    @Override
    public SupAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        view = layoutInflater.inflate(R.layout.sup_card_item, parent, false);
        return new SupAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SupAdapter.MyViewHolder holder, int position) {
        holder.medicine_title.setText(mData.get(position).getProductName());
//        int catid = mData.get(position).getId();
//        Utility.setCatid(catid);
        String imgurl = mData.get(position).getImage();
        if (imgurl != null) {
       /*    Glide.with(context).load(imgurl).
       into(holder.medicineview);*/
            Glide.with(context)
                    .load(imgurl)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.medicineview);
        } else {
            Glide.with(context)
                    .load(R.drawable.med)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.medicineview);
        }
      /* holder.cardView.setOnClickListener(this);
          Intent i = new Intent(context, ByProductActivity.class);
          context.startActivity(i);*/


    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    @Override
    public void onClick(View v) {

    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView medicine_title;
        ImageView medicineview;
        CardView cardView;

        public MyViewHolder(View view) {
            super(view);
            medicine_title = view.findViewById(R.id.med_title_sup);
            medicineview = view.findViewById(R.id.med_circle);
            cardView = view.findViewById(R.id.card);
        }
    }

    {
    }
}
