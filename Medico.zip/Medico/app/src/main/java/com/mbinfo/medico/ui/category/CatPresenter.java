package com.mbinfo.medico.ui.category;

import android.content.Context;
import android.widget.Toast;

import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.model.catmodel.CatList;
import com.mbinfo.medico.data.model.catmodel.CatModel;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.ui.sms.SmsContract;
import com.mbinfo.medico.utils.NetWorkInfoUtility;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static java.lang.String.valueOf;

public class CatPresenter implements CatContractor.Presenter {
    CatContractor.View view;
    NetWorkInfoUtility netWorkInfoUtility;
    Context context;
    List<CatList> message;
    int status;
    public CatPresenter(CatContractor.View view) {
        this.view = view;
        netWorkInfoUtility = new NetWorkInfoUtility();
    }
    @Override
    public void onSubmit() {
        if (netWorkInfoUtility.isNetWorkAvailableNow(view.getContext())) {
           view.showSubmitProgress();
            Call<CatModel> call = APIClient.getNetInstance().getCatData();
            call.enqueue(new Callback<CatModel>() {
                @Override
                public void onResponse(Call<CatModel> call, Response<CatModel> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus() == 1) {
                            status = response.body().getStatus();
                            message = response.body().getMessage();
                            view.showSubmitSuccess(response.body().getMessage(),response.body().getStatus());
                        } else {


                        }
                    }
                }

                @Override
                public void onFailure(Call<CatModel> call, Throwable t) {
                    view.showEmptySuccess(String.valueOf(message),status);
                }
            });
        } else {
            view.showNetworkNotAvailableError();
            Toast.makeText(view.getContext(),"Network Error",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }
}
