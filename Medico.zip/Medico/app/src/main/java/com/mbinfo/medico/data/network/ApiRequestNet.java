package com.mbinfo.medico.data.network;



import com.mbinfo.medico.data.model.CheckOutModel;
import com.mbinfo.medico.data.model.Manufacture;
import com.mbinfo.medico.data.model.OtpModel;
import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.model.SpinnerDataModel;
import com.mbinfo.medico.data.model.cartmodel.CartDataModel;
import com.mbinfo.medico.data.model.cartmodel.CartModel;
import com.mbinfo.medico.data.model.catmodel.CatModel;
import com.mbinfo.medico.data.model.city.City;
import com.mbinfo.medico.data.model.dataremove.RemoveItem;
import com.mbinfo.medico.data.model.ordermodel.OrderDetail;
import com.mbinfo.medico.data.model.product.Product;
import com.mbinfo.medico.data.model.productdetail.ProductDetails;
import com.mbinfo.medico.data.model.profilemodel.Profile;
import com.mbinfo.medico.data.model.retail.Retail;
import com.mbinfo.medico.data.model.retailer.RetailerModel;
import com.mbinfo.medico.data.model.search.Search;
import com.mbinfo.medico.data.model.state.StateModel;
import com.mbinfo.medico.data.model.suppliermodel.Supplier;
import com.mbinfo.medico.data.model.suppliermodel.TopSell;
import com.mbinfo.medico.data.model.tabmodel.TabProduct;
import com.mbinfo.medico.data.model.tehsil.Tehsil;
import com.mbinfo.medico.ui.checkout.CheckOut;

import java.util.SplittableRandom;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface ApiRequestNet {
    @FormUrlEncoded
    @POST("users/getotp")
    Call<Sms> processOtp(@Field("mobile") String mobile);

    @FormUrlEncoded
    @POST("users/verify")
    Call<OtpModel> processVerify(@Field("mobile") String mobile, @Field("otp") String otp);
    @GET("users/getusertype")
    Call<SpinnerDataModel> loadSpinner();
    @GET("users/getretailers")
    Call<Retail>loadRetail();
    @GET("users/getmanufacturers")
    Call<Manufacture>loadManfacture();
    @GET("users/getaddresslist")
    Call<StateModel> loadState();
    @FormUrlEncoded
    @POST("users/register")
    Call<Sms> processReg(@Field("name") String username, @Field("f_name") String fathername,
                            @Field("b_name")String businessname, @Field("mobile") String mobile,
                         @Field("utype") String utype,@Field("aadhaar")String adhar,
                        @Field("gstin") String gstin, @Field("village") String village,
                         @Field("landmark") String landmark,@Field("panchayat") String panchyat,
                         @Field("tehsil") String teshil, @Field("district") String district,
                         @Field("state") String state, @Field("pincode") String pincode);


    @Multipart
    @POST("users/upload/profilepic")
    Call<Sms> uploadImage(@Header("x-auth-token") String auth,@Part MultipartBody.Part file,
                          @Part("pic") RequestBody description);

     @GET("users/getuser")
     Call<Profile> profileGet(@Header("x-auth-token") String authkey);
    @GET("users/getcategory")
    Call<CatModel> getCatData();
    @GET("users/getlisttabs")
    Call<TabProduct>loadTabpinner();
    @FormUrlEncoded
    @POST("users/getproducts")
    Call<Product> productGet( @Field("cat") int cat);
    @FormUrlEncoded
    @POST("users/getproducts")
    Call<Product> retailGet( @Field("rid") int rid);
    @FormUrlEncoded
    @POST("users/getproducts")
    Call<Product> mnfGet( @Field("mfr") String mnf);
    @FormUrlEncoded
    @POST("users/getproducts")
    Call<RetailerModel> productGetTab(@Header("x-auth-token") String authkey, @Field("tab") int tab, @Field("cat")
            int cat);
    @FormUrlEncoded
    @POST("users/getproduct")
    Call<ProductDetails> productGetDetail(@Field("pid") int pid);
    @FormUrlEncoded
    @POST("users/addtocart")
    Call<CartModel> addCartDetail(@Header("x-auth-token") String authkey, @Field("pid") int pid, @Field("quantity") int
                                   quantiy, @Field("price") Float price);

    @GET("users/getcartitems")
    Call<CartDataModel> getCartData(@Header("x-auth-token") String authkey);
    @FormUrlEncoded
    @POST("users/deletecartitem")
    Call<RemoveItem> removeCartItem(@Header("x-auth-token") String authkey, @Field("pid") int pid);
    @POST("users/emptycart")
    Call<RemoveItem> removeCartAllItem(@Header("x-auth-token") String authkey);
    @FormUrlEncoded
    @POST("users/placeorder")
    Call<CheckOutModel> OrderPlace(@Header("x-auth-token") String authkey,
                                   @Field("village") String village, @Field("landmark") String landmark,
                                   @Field("panchayat") String panchyat, @Field("tehsil") int tehsil,
                                   @Field("district") int distict,
                                   @Field("state") int state, @Field("pincode") String pincode,
                                   @Field("alt_mobile") String mobile, @Field("pay_mode") String mode, @Field("old_addr") String old_addr);
    @GET("users/orders")
    Call<OrderDetail> OrderGet(@Header("x-auth-token") String authkey);
    @FormUrlEncoded
    @POST("users/getaddresslist")
    Call<City> loadCity(@Field("stateid") String stateid);
    @FormUrlEncoded
    @POST("users/getaddresslist")
    Call<Tehsil> loadTehsilData(@Field("cityid") int cityid);
    @GET("users/getchart")
    Call<Supplier> graphGet(@Header("x-auth-token") String authkey);
    @GET("users/gettopselling")
    Call<TopSell> getTopSell(@Header("x-auth-token") String authkey);
    @FormUrlEncoded
    @POST("users/searchproducts")
    Call<Search> searchData(@Field("query") String search_text);
}
