package com.mbinfo.medico.ui.home;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.Sms;
import com.mbinfo.medico.data.model.ordermodel.OrderDetail;
import com.mbinfo.medico.ui.category.Categtory;
import com.mbinfo.medico.ui.fragment.HomeFragment;
import com.mbinfo.medico.ui.mycart.MyCart;
import com.mbinfo.medico.ui.orderdetail.OrderDetailActivity;
import com.mbinfo.medico.ui.profile.ProfileActivity;
import com.mbinfo.medico.ui.profile.ProfileFragment;
import com.mbinfo.medico.ui.sms.SmsActivity;
import com.mbinfo.medico.ui.sms.SmsFragment;
import com.mbinfo.medico.utils.Utility;

import java.util.Locale;


public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    Utility utility;
    TextView mName, mEmail;
    Locale myLocale;

    public static void start(Context context) {
        Intent i = new Intent(context, HomeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }

    private BottomNavigationView bottomNavigationView;
    Fragment fragment;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigationMyProfile:
                    if (utility.IsLogin()) {
                        loadFragment(new ProfileFragment());
                    } else {
                        loadFragment(new SmsFragment());
                    }
                  /*  Intent i = new Intent(HomeActivity.this, SmsActivity.class);
                    startActivity(i);*/
                    return true;
                case R.id.navigationMyCourses:
                    return true;
                case R.id.navigationHome:
                    loadFragment(new HomeFragment());
                    return true;
                case R.id.navigationSearch:
                    return true;
                case R.id.navigationMenu:
                    DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                    drawer.openDrawer(GravityCompat.START);
                    return true;
            }
            return false;
        }
    };

    private void loadFragment(Fragment fragment) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.add(R.id.rootLayout, fragment, "Test Fragment");
        // transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        utility = new Utility(HomeActivity.this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        // navigationView.setBackgroundColor(Color.WHITE);
        navigationView.setNavigationItemSelectedListener(this);
        mName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.id_name);
        mEmail = (TextView) navigationView.getHeaderView(0).findViewById(R.id.textView);
        mName.setText(utility.getUserName());
        mEmail.setText(utility.getUserMobileNumber());

        bottomNavigationView = findViewById(R.id.navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
//
        CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) bottomNavigationView.getLayoutParams();
        layoutParams.setBehavior(new BottomNavigationBehavior());

        bottomNavigationView.setSelectedItemId(R.id.navigationHome);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_camera) {
            loadFragment(new HomeFragment());
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {
            loadFragment(new ProfileFragment());

        } else if (id == R.id.nav_slideshow) {
            Intent i = new Intent(getApplicationContext(), MyCart.class);
            overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
            startActivity(i);
        } else if (id == R.id.nav_manage) {
            //changeLanguge("hi");
            Intent i = new Intent(getApplicationContext(), OrderDetailActivity.class);
            overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
            startActivity(i);
        } else if (id == R.id.nav_share) {
            openShare();

        } else if (id == R.id.nav_dark_mode) {
            rateus();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void rateus() {
        try {
            Uri marketUri = Uri.parse("market://details?id=" + getPackageName());
            Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
            overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
            startActivity(marketIntent);
        }catch(ActivityNotFoundException e) {
            Uri marketUri = Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName());
            Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
            overridePendingTransition(R.anim.animatoin_right, R.anim.animation_left);
            startActivity(marketIntent);
        }
    }

    private void changeLanguge(String lang) {
        myLocale = new Locale(lang);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.updateConfiguration(conf, dm);
     /*   Intent refresh = new Intent(this, AndroidLocalize.class);
        startActivity(refresh);*/
    }

    private void openShare() {
        int applicationNameId = this.getApplicationInfo().labelRes;
        final String appPackageName = this.getPackageName();
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, this.getString(applicationNameId));
        String text = "Install this application: ";
        String link = "https://play.google.com/store/apps/details?id=" + appPackageName;
        i.putExtra(Intent.EXTRA_TEXT, text + " " + link);
        startActivity(Intent.createChooser(i, "Share link:"));
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
