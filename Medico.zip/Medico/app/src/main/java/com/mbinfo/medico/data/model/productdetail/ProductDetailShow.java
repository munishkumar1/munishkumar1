package com.mbinfo.medico.data.model.productdetail;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ProductDetailShow {
    @SerializedName("product_name")
    @Expose
    private String productName;
    @SerializedName("price")
    @Expose
    private float price;
    @SerializedName("images")
    @Expose
    private List<String> images = null;
    @SerializedName("power")
    @Expose
    private String power;
    @SerializedName("discount")
    @Expose
    private float discount;
    @SerializedName("presc")
    @Expose
    private String presc;
    @SerializedName("form")
    @Expose
    private String form;
    @SerializedName("quantity")
    @Expose
    private int quantity;
    @SerializedName("unit")
    @Expose
    private String unit;
    @SerializedName("manufacturer")
    @Expose
    private String manufacturer;
    @SerializedName("supplier_name")
    @Expose
    private String supplierName;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("village")
    @Expose
    private String village;
    @SerializedName("landmark")
    @Expose
    private String landmark;
    @SerializedName("panchayat")
    @Expose
    private String panchayat;
    @SerializedName("tehsil")
    @Expose
    private String tehsil;
    @SerializedName("district")
    @Expose
    private String district;
    @SerializedName("state")
    @Expose
    private String state;
    @SerializedName("pin_code")
    @Expose
    private String pinCode;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("composition")
    @Expose
    private String composition;
    @SerializedName("side_effects")
    @Expose
    private List<String> sideEffects = null;
    @SerializedName("quick_tips")
    @Expose
    private List<String> quickTips = null;
    @SerializedName("safety_advice")
    @Expose
    private List<String> safetyAdvice = null;
    @SerializedName("how_use")
    @Expose
    private String howUse;
    @SerializedName("how_works")
    @Expose
    private String howWorks;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public float getDiscount() {
        return discount;
    }

    public void setDiscount(float discount) {
        this.discount = discount;
    }

    public String getPresc() {
        return presc;
    }

    public void setPresc(String presc) {
        this.presc = presc;
    }

    public String getForm() {
        return form;
    }

    public void setForm(String form) {
        this.form = form;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getPanchayat() {
        return panchayat;
    }

    public void setPanchayat(String panchayat) {
        this.panchayat = panchayat;
    }

    public String getTehsil() {
        return tehsil;
    }

    public void setTehsil(String tehsil) {
        this.tehsil = tehsil;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }



    public String getComposition() {
        return composition;
    }

    public void setComposition(String composition) {
        this.composition = composition;
    }

    public List<String> getSideEffects() {
        return sideEffects;
    }

    public void setSideEffects(List<String> sideEffects) {
        this.sideEffects = sideEffects;
    }

    public List<String> getQuickTips() {
        return quickTips;
    }

    public void setQuickTips(List<String> quickTips) {
        this.quickTips = quickTips;
    }

    public List<String> getSafetyAdvice() {
        return safetyAdvice;
    }

    public void setSafetyAdvice(List<String> safetyAdvice) {
        this.safetyAdvice = safetyAdvice;
    }

    public String getHowUse() {
        return howUse;
    }

    public void setHowUse(String howUse) {
        this.howUse = howUse;
    }

    public String getHowWorks() {
        return howWorks;
    }

    public void setHowWorks(String howWorks) {
        this.howWorks = howWorks;
    }
}
