package com.mbinfo.medico.ui.checkout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.mbinfo.medico.R;
import com.mbinfo.medico.adapter.CityAdapter;
import com.mbinfo.medico.data.model.city.CityData;
import com.mbinfo.medico.ui.register.RegisterActivity;
import com.mbinfo.medico.utils.Utility;

import java.util.List;

public class CityAdop extends ArrayAdapter<CityData> {
    LayoutInflater layoutInflater;
    public String cityid;
    View view;
    Context context;

    public CityAdop(CheckOut context, int spinner_item, int title, List<CityData> message) {
        super(context, spinner_item, title, message);
        layoutInflater = context.getLayoutInflater();

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return rowview(convertView, position);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return rowview(convertView, position);
    }

    private View rowview(View convertView, int position) {

        CityData rowItem = getItem(position);
        CityAdop.viewHolder holder;
        View rowview = convertView;
        if (rowview == null) {

            holder = new CityAdop.viewHolder();
            layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowview = layoutInflater.inflate(R.layout.spinner_item, null, false);

            holder.txtTitle = rowview.findViewById(R.id.title);
            //  holder.imageView = (ImageView) rowview.findViewById(R.id.icon);
            rowview.setTag(holder);
        } else {
            holder = (CityAdop.viewHolder) rowview.getTag();
        }
        // holder.imageView.setImageResource(rowItem.getImageId());
        holder.txtTitle.setText(rowItem.getCity());
        cityid = String.valueOf(rowItem.getId());
        Utility.setCityid(cityid);
        // SharedHelper.putKey(getContext(), "id", id);
        return rowview;
    }

    private class viewHolder {
        TextView txtTitle;
        ImageView imageView;
    }

    {
    }
}
