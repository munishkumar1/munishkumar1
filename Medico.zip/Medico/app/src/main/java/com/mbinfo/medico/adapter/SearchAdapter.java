package com.mbinfo.medico.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.mbinfo.medico.R;
import com.mbinfo.medico.data.model.cartmodel.CartShowData;
import com.mbinfo.medico.data.model.dataremove.RemoveItem;
import com.mbinfo.medico.data.model.search.SearchData;
import com.mbinfo.medico.data.network.APIClient;
import com.mbinfo.medico.data.prefs.SharedHelper;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.MyViewHolder> {
    public Context context;
    public List<SearchData> mData;
    double mPrice, cast, quant;
    String authkey;
    int pid;

    public SearchAdapter(Context context, List<SearchData> mData) {
        this.context = context;
        this.mData = mData;
    }

    @NonNull
    @Override
    public SearchAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        view = layoutInflater.inflate(R.layout.search_list, parent, false);
        return new SearchAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchAdapter.MyViewHolder holder, int position) {
        pid = mData.get(position).getId();
        holder.name.setText(mData.get(position).getProductName());
        holder.price.setText("Price" + ":" + "Rs." + mData.get(position).getPrice());
        mPrice = Double.parseDouble(mData.get(position).getPrice());
        quant = mData.get(position).getQuantity();
        holder.calculatedprice.setText("Discount" + ":" + "Rs." + mData.get(position).getDiscount());
        System.out.println(cast);
        holder.quantity.setText("Quantity:" + Integer.toString(mData.get(position).getQuantity()));
        String imgurl = mData.get(position).getImage();
        if (imgurl != null) {
       /*    Glide.with(context).load(imgurl).
       into(holder.medicineview);*/
            Glide.with(context)
                    .load(imgurl)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.medimage);
        } else {
            Glide.with(context)
                    .load(R.drawable.med)
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(holder.medimage);
        }


    }


    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name, price, quantity, totalprice, date, calculatedprice;
        ImageView medimage, remove;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.cart_name);
            date = itemView.findViewById(R.id.id_date);
            price = itemView.findViewById(R.id.id_price);
            quantity = itemView.findViewById(R.id.qauantity);
            totalprice = itemView.findViewById(R.id.text_action1);
            medimage = itemView.findViewById(R.id.image_cartlist);
            calculatedprice = itemView.findViewById(R.id.delfree);
            //  remove = itemView.findViewById(R.id.ic_wishlist);


        }
    }
}


