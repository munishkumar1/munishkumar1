package com.mbinfo.medico.adapter

import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import java.util.*

class PageAdapter(fm: FragmentManager?, mFragmentList: List<Fragment>?, mFragmentTitleList: List<String>) : FragmentPagerAdapter(fm!!) {
    private var mFragmentList: List<Fragment>? = ArrayList()
    private var mFragmentTitleList: List<String> = ArrayList()
    override fun getCount(): Int {
        return mFragmentList?.size ?: 0
    }

    override fun getItem(position: Int): Fragment {
        return mFragmentList!![position]
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return mFragmentTitleList[position]
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return false
    }

    init {
        this.mFragmentList = mFragmentList
        this.mFragmentTitleList = mFragmentTitleList
    }
}