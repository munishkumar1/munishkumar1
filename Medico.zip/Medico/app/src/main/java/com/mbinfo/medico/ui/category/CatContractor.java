package com.mbinfo.medico.ui.category;

import com.mbinfo.medico.data.model.catmodel.CatList;
import com.mbinfo.medico.ui.base.BasePresenter;
import com.mbinfo.medico.ui.base.BaseView;

import java.util.List;

public class CatContractor {
    public interface View extends BaseView<CatContractor.Presenter> {
        void showSubmitProgress();

        void showSubmitSuccess(List<CatList> message , int status);
        void showEmptySuccess(String message,int status);
        void showSubmitError(String message);
    }

    public interface Presenter extends BasePresenter {
        void onSubmit();
    }
}
