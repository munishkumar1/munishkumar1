package com.seatech.hrm.adapter;

import junit.framework.TestCase;

public class ManageableAdpterTest extends TestCase {

}