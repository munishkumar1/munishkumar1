package com.seatech.hrm.adapter;

import junit.framework.TestCase;

public class ManageliveAdpterTest extends TestCase {

}