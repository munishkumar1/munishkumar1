package com.seatech.hrm.util;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    Context context;

    public PrefManager (Context context) {
        this.context = context;
    }

    public void saveUserDetails (String userid) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("LoginDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("userid", userid);
        editor.commit ();
    }

    public String getUserId () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("LoginDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("userid", "");
    }




    public void savepostDetails (String post) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("PostDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("Post", post);
        editor.commit ();
    }

    public String getpost () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("PostDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("Post", "");
    }
    public void savenameDetails (String name) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("nameDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("Name", name);
        editor.commit ();
    }

    public String getname () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("nameDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("Name", "");
    }


    public void saveemp_codeDetails (String emp_code) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("Emp_codeDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("Emp_code", emp_code);
        editor.commit ();
    }

    public String getemp_code () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("Emp_codeDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("Emp_code", "");
    }
    public void saveemailDetails (String email) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("EmailDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("Email", email);
        editor.commit ();
    }

    public String getemail () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("EmailDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("Email", "");
    }

    public void savecontactDetails (String contact) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("ContactDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("Contact", contact);
        editor.commit ();
    }

    public String getcontact () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("ContactDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("Contact", "");
    }




    public String getPunchStatus () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("PunchStatus", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("punchStatus", "");
    }

    public void savePunchStatusDetails (String  puchstatus) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("PunchStatus", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("punchStatus", puchstatus);
        editor.commit ();
    }
}
