package com.seatech.hrm.data;

import com.seatech.hrm.attendance.AttendanceinfoResponse;
import com.seatech.hrm.employeee.EmployeeResponse;
import com.seatech.hrm.employeee.EmployeeResponseDitail;
import com.seatech.hrm.holiday.HolidayResponse;
import com.seatech.hrm.leave.ApplyleaveResponse;
import com.seatech.hrm.leave.ManageleaveResponse;
import com.seatech.hrm.login.MainResponse;
import com.seatech.hrm.punchinandout.LogoutResponse;
import com.seatech.hrm.punchinandout.PunchinResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {

    @FormUrlEncoded
    @POST("LoginApi")
     Call< MainResponse > login (
            @Field("email") String user_email,
            @Field("password") String user_pass);



    @POST("EmployeeApi")
    Call< EmployeeResponse > employee ();


    @FormUrlEncoded
    @POST("EmployeeInfo")
    Call< EmployeeResponseDitail > employeeDiteal (
            @Field("id") String user_id);

    @POST("CalenderApi")
    Call< HolidayResponse > getholiday ();


    @FormUrlEncoded
    @POST("ApplyLeaveAPI")
    Call< ApplyleaveResponse > getapplyleave (
            @Field("empId") String user_id,
            @Field("type") String user_type,
            @Field("fromDate") String user_date,
            @Field("toDate") String user_todate,
            @Field("comment") String user_comment);


    @FormUrlEncoded
    @POST("ManageLeaveApi")
    Call< ManageleaveResponse > getmanageleave (
            @Field ("empId") String user_empId);


    @FormUrlEncoded
    @POST("PersonalInfoApi")
    Call< AttendanceinfoResponse > getattendace (
            @Field("fromDate") String user_fromDate,
            @Field("toDate") String user_toDate,
            @Field ("empId") String user_empId);


    @FormUrlEncoded
    @POST("PunchInOutApi")
    Call< PunchinResponse > getpunchin (
            @Field("empId") String user_empid);

    @FormUrlEncoded
    @POST("PunchCompleteApi")
    Call< LogoutResponse > getComplete (
            @Field("empId") String user_empid,
            @Field("punchStatus") String user_punchstastus,
            @Field ("comment") String user_comment);

}
