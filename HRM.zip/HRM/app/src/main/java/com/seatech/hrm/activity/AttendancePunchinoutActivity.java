package com.seatech.hrm.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.seatech.hrm.R;
import com.seatech.hrm.data.ApiClient;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.punchinandout.LogoutResponse;
import com.seatech.hrm.punchinandout.PunchinResponse;
import com.seatech.hrm.util.PrefManager;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

@RequiresApi(api = Build.VERSION_CODES.N)
public class AttendancePunchinoutActivity extends AppCompatActivity implements View.OnClickListener {
    TextView datetime, _tvTime;
    EditText comment;
    ApiInterface apiInterface;
    Button punchin, punchout;
    String eid,punchstatus;
    PrefManager prefManager;
    private long mLastCLickTime = 0;
    DateFormat dateFormat;
    String time;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_attendance_punchinout);
        initToolbar ();
        ActionBar actionBar = getSupportActionBar ();
        actionBar.setDisplayHomeAsUpEnabled (true);
        prefManager = new PrefManager (AttendancePunchinoutActivity.this);
        eid =  prefManager.getUserId ();
        checkStatus ();
        String punchstatus = prefManager.getPunchStatus ();
        System.out.println ("puchsttttttt:" + punchstatus);

        datetime = findViewById (R.id.dates);
        comment = findViewById (R.id.feedback_longdes);
        _tvTime = findViewById (R.id.curenttime);
        punchin = findViewById (R.id.puchin);
        punchout = findViewById (R.id.puchout);
        punchin.setOnClickListener (this);
        punchout.setOnClickListener (this);
        dateFormat = new SimpleDateFormat ("yyyy-mm-dd hh:mm:ss");

    }

    private void checkStatus () {

         apiInterface = ApiClient.getClient (AttendancePunchinoutActivity.this).create (ApiInterface.class);
                Call< PunchinResponse > call = apiInterface.getpunchin (eid);

                call.enqueue (new Callback< PunchinResponse > () {
                    @Override
                    public void onResponse (Call< PunchinResponse > call, Response< PunchinResponse > response) {
                        System.out.println ("punchiOUTTTTTTTTTTT:" + response);
                        if (response.body ().getStatusCode () == 201) {
                          Toast.makeText (getApplicationContext (),response.body ().getMessage (),Toast.LENGTH_LONG).show ();

                        }else if(response.body ().getStatusCode () == 200){

                            punchstatus = response.body ().getResult ().getPunchStatus ();
                            Toast.makeText (getApplicationContext (),response.body ().getMessage (),Toast.LENGTH_LONG).show ();
                            if(response.body ().getResult ().getPunchStatus ().equals ("1")){
                                punchout.setVisibility (View.VISIBLE);
                                punchin.setVisibility (View.GONE);

                            }else if(response.body ().getResult ().getPunchStatus ().equals ("0")){
                                punchin.setVisibility (View.VISIBLE);
                                punchout.setVisibility (View.GONE);
                            }
                        }
                    }

                    @Override
                    public void onFailure (Call< PunchinResponse > call, Throwable t) {
                       Toast.makeText (getApplicationContext (),t.getMessage (),Toast.LENGTH_LONG).show ();
                    }
                });
            }





    private void initToolbar () {

        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Attendance");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);

    }

    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item) {
        switch (item.getItemId ()) {
            case android.R.id.home:
                Intent i = new Intent (AttendancePunchinoutActivity.this, MainActivity.class);
                startActivity (i);
                this.finish ();
                return true;
        }
        return super.onOptionsItemSelected (item);
    }

    @Override

    public void onBackPressed () {
        super.onBackPressed ();
        Intent i = new Intent (AttendancePunchinoutActivity.this, MainActivity.class);
        startActivity (i);
        finish ();


    }


    @Override
    public void onClick (View v) {
        switch(v.getId ()){
            case R.id.puchin:
                PuchinCompleteApi();
                break;
            case R.id.puchout:
                PuchoutCompleteApi();
                break;

        }


    }


    private void PuchinCompleteApi () {
        apiInterface = ApiClient.getClient (AttendancePunchinoutActivity.this).create (ApiInterface.class);
        Call< LogoutResponse > call = apiInterface.getComplete (prefManager.getUserId (), "1", comment.getText ().toString ());

        call.enqueue (new Callback< LogoutResponse > () {
            @Override
            public void onResponse (Call< LogoutResponse > call, Response< LogoutResponse > response) {
                System.out.println ("punchinnnn:"+ response);
                if(response.isSuccessful ()){
                    punchin.setVisibility (View.GONE);
                    punchout.setVisibility (View.VISIBLE);
                }
                Date date = Calendar.getInstance ().getTime ();
                String strDate = dateFormat.format (date);
                time = response.body ().getPunchTime ();

                try {

                    Date date1 = dateFormat.parse (strDate);
                    Date date2 = dateFormat.parse (time);
                    Timer timer = new Timer ();
                    timer.schedule (new TimerTask () {
                        @Override
                        public void run () {
                            long diff = date1.getTime () - date2.getTime ();
                           /* long diff_in_seconds= TimeUnit.MILLISECONDS.toSeconds (diff)% 60;
                            long  diff_in_Minutew =  TimeUnit.MILLISECONDS.toMinutes (diff)%60;
                            long  diff_in_Hour   =  TimeUnit.MILLISECONDS.toMinutes (diff)%24;*/
                           /* System.out.println ("time diff:" + "hours" + diff_in_Hour + "min" + diff_in_Minutew
                                                        + "second" +diff_in_seconds );*/
                            int hours = Math.toIntExact (diff / ( 1000 * 60 * 60 ));
                            int mins = Math.toIntExact (diff/(1000*60)) *60;
                            String dff = hours + ":"+mins;
                            System.out.println ("asdddd:" + dff);

                        }
                    },0,1000);



                } catch (Exception e) {
                    e.printStackTrace ();
                }

            }

            @Override
            public void onFailure (Call< LogoutResponse > call, Throwable t) {
                System.out.println ("punchinnnnfaillllllllll:"+ t.getMessage ());

            }
        });



    }

private  void  PuchoutCompleteApi(){


    apiInterface = ApiClient.getClient (AttendancePunchinoutActivity.this).create (ApiInterface.class);
    Call< LogoutResponse > call = apiInterface.getComplete (prefManager.getUserId (), "0", comment.getText ().toString ());

    call.enqueue (new Callback< LogoutResponse > () {
        @Override
        public void onResponse (Call< LogoutResponse > call, Response< LogoutResponse > response) {
            System.out.println ("punchouttttttt:"+ response);
            if(response.isSuccessful ()){
                punchout.setVisibility (View.GONE);
                punchin.setVisibility (View.VISIBLE);
            }

        }

        @Override
        public void onFailure (Call< LogoutResponse > call, Throwable t) {
            System.out.println ("punchouttttfaillllllllll:"+ t.getMessage ());

        }
    });
}
}



