package com.seatech.hrm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.seatech.hrm.R;
import com.seatech.hrm.data.ApiClient;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.employeee.EmployeeResponse;
import com.seatech.hrm.employeee.EmployeeResponseDitail;
import com.seatech.hrm.util.PrefManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EmployeeDetail_Activity extends AppCompatActivity {
    ApiInterface apiInterface;
    PrefManager prefManager;
     String id;
     TextView tvemp,email,post,name2,email2,dob,gender,phone,alternateno,department,designation,dateofjoing,avaikability;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_employee_detail);
        initView();
        Intent i = getIntent ();
          id = i.getStringExtra ("empid");
        apiInterface = ApiClient.getClient (EmployeeDetail_Activity.this).create (ApiInterface.class);
        employeedata ();
        initToolbar ();
        ActionBar actionBar = getSupportActionBar ();

        actionBar.setDisplayHomeAsUpEnabled (true);

    }

    private void initView () {
        tvemp =  findViewById (R.id.idTVEmplyeeName);
        email =  findViewById (R.id.idTVEmplyeeEmail);
        post =  findViewById (R.id.idTVEmplyeepost);
        name2 =  findViewById (R.id.idTVpost);
        email2 =  findViewById (R.id.idemail1);
        dob =  findViewById (R.id.iddob1);
        phone =  findViewById (R.id.idphone1);
        alternateno =  findViewById (R.id.idAlternateNo1);
        department =  findViewById (R.id.it);
        designation =  findViewById (R.id.iddesignation1);
        dateofjoing =  findViewById (R.id.idDateOfJoining1);
        avaikability =  findViewById (R.id.idavailability1);


    }


    private void initToolbar () {


        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Employee Detail");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);

    }

    private void employeedata () {
        Call< EmployeeResponseDitail > call = apiInterface.employeeDiteal (id);
        System.out.println (" iddddd:" + id);
        call.enqueue (new Callback< EmployeeResponseDitail > () {
            @Override
            public void onResponse (Call< EmployeeResponseDitail > call, Response< EmployeeResponseDitail > response) {
                System.out.println (" employee:" + response);
                tvemp.setText (response.body ().getResult ().getName ());
                email.setText (response.body ().getResult ().getEmail ());
                post.setText (response.body ().getResult ().getPost ());
                name2.setText (response.body ().getResult ().getName ());
                email2.setText (response.body ().getResult ().getEmail ());
                dob.setText (response.body ().getResult ().getDob ());
                phone.setText (response.body ().getResult ().getPhone ());
                alternateno.setText (response.body ().getResult ().getAltPhone ());
                System.out.println (" PHONE:" + response.body ().getResult ().getAltPhone ());
                department.setText (response.body ().getResult ().getDepartment ());
                designation.setText (response.body ().getResult ().getRole ());
                dateofjoing.setText (response.body ().getResult ().getDoj ());
                avaikability.setText (response.body ().getResult ().getAvailability ());
                tvemp.setText (response.body ().getResult ().getName ());

            }

            @Override
            public void onFailure (Call< EmployeeResponseDitail > call, Throwable t) {
                System.out.println ("employeefaillllll:" + t.getMessage ());
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item) {
        switch (item.getItemId ()) {
            case android.R.id.home:
                Intent i = new Intent (EmployeeDetail_Activity.this, Employee_Activity.class);
                startActivity (i);
                this.finish ();
                return true;
        }
        return super.onOptionsItemSelected (item);
    }

    @Override

    public void onBackPressed () {
        super.onBackPressed ();
        Intent i = new Intent (EmployeeDetail_Activity.this, Employee_Activity.class);
        startActivity (i);
        finish ();
    }
}