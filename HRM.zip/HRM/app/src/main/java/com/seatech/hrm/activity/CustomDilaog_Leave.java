package com.seatech.hrm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.seatech.hrm.R;

public class CustomDilaog_Leave extends Activity {
    private Dialog dialog;
    TextView applyleave,manageleave,cancel;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        //setContentView (R.layout.activity_custom_dilaog_leave);
          //  loadDailog ();
        this.setFinishOnTouchOutside (false);

    }


    @Override
    protected void onResume () {
        super.onResume ();
        loadDailog1 ();
    }

    private void loadDailog1 () {
        dialog = new Dialog (this);
        dialog.setContentView (R.layout.demo);
        cancel = dialog.findViewById (R.id.Cancelleave);
        applyleave = dialog.findViewById (R.id.applyleave);
        manageleave = dialog.findViewById (R.id.managelive);
            manageleave.setOnClickListener ((View v)->{
            Intent intent = new Intent (CustomDilaog_Leave.this,ManageleaveActivity.class);
            intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK);
            getApplicationContext ().startActivity (intent);

                                       });
        applyleave.setOnClickListener((View v)->{
            Intent intent = new Intent (CustomDilaog_Leave.this,ApplyLeaveActivity2.class);
            intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
            getApplicationContext ().startActivity (intent);

                                      });
        
        cancel.setOnClickListener ((View v)->{
           // Toast.makeText (getApplicationContext (),"click",Toast.LENGTH_LONG).show ();
            Intent intent = new Intent (CustomDilaog_Leave.this,MainActivity.class);
            intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK| Intent.FLAG_ACTIVITY_CLEAR_TASK);
            getApplicationContext ().startActivity (intent);
            finish ();




        });

        dialog.show ();

    }
    @Override
    public void onBackPressed() {
        dialog.dismiss();
        finish();
    }

}