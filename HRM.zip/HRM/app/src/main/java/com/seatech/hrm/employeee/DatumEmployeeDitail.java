package com.seatech.hrm.employeee;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumEmployeeDitail {

    @SerializedName("Role")
    @Expose
    private String role;
    @SerializedName("Availability")
    @Expose
    private String availability;
    @SerializedName("AltPhone")
    @Expose
    private String altPhone;
    @SerializedName("Department")
    @Expose
    private String department;
    @SerializedName("Email")
    @Expose
    private String email;
    @SerializedName("DOB")
    @Expose
    private String dob;
    @SerializedName("Phone")
    @Expose
    private String phone;
    @SerializedName("Post")
    @Expose
    private String post;
    @SerializedName("Photo")
    @Expose
    private String photo;
    @SerializedName("Gender")
    @Expose
    private String gender;
    @SerializedName("DOJ")
    @Expose
    private String doj;
    @SerializedName("Name")
    @Expose
    private String name;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    public String getAltPhone() {
        return altPhone;
    }

    public void setAltPhone(String altPhone) {
        this.altPhone = altPhone;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDoj() {
        return doj;
    }

    public void setDoj(String doj) {
        this.doj = doj;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
