package com.seatech.hrm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.seatech.hrm.R;

public class AttendanceSelectDilaog extends AppCompatActivity {
    private Dialog dialog;
    TextView personalinfo,punchinout ,cancelattendance;
    @Override
    protected void onCreate (Bundle savedInstanceState) {

        super.onCreate (savedInstanceState);
       // setContentView (R.layout.activity_attendance_sclect);

        this.setFinishOnTouchOutside (false);

    }


    @Override
    protected void onResume () {
        super.onResume ();
        loadDailog ();
    }

    private void loadDailog () {

        dialog = new Dialog (this);
        dialog.setContentView (R.layout.activity_attendance_sclect);

        cancelattendance = dialog.findViewById (R.id.cancel);
        punchinout = dialog.findViewById (R.id.punchinout);
        personalinfo = dialog.findViewById (R.id.personalinfo);
        punchinout.setOnClickListener ((View v)->{
            Intent intent = new Intent (AttendanceSelectDilaog.this,AttendancePunchinoutActivity.class);
            intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK);
            getApplicationContext ().startActivity (intent);

        });
        personalinfo.setOnClickListener((View v)->{
            Intent intent = new Intent (AttendanceSelectDilaog.this,AttendancePersonalActivity.class);
            intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
            getApplicationContext ().startActivity (intent);

        });

        cancelattendance.setOnClickListener ((View v)->{
            // Toast.makeText (getApplicationContext (),"click",Toast.LENGTH_LONG).show ();
            Intent intent = new Intent (AttendanceSelectDilaog.this,MainActivity.class);
            intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK| Intent.FLAG_ACTIVITY_CLEAR_TASK);
            getApplicationContext ().startActivity (intent);
            finish ();



        });

        dialog.show ();

    }

}




