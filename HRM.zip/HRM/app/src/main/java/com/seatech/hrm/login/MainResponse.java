package com.seatech.hrm.login;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MainResponse {

    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("Status_code")
    @Expose
    private Integer statusCode;
    @SerializedName("Result")
    @Expose
    private DatumLogin result;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public DatumLogin getResult() {
        return result;
    }

    public void setResult(DatumLogin result) {
        this.result = result;
    }


}
