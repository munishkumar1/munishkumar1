package com.seatech.hrm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.seatech.hrm.R;
import com.seatech.hrm.adapter.HolidayAdpter;
import com.seatech.hrm.adapter.ManageableAdpter;
import com.seatech.hrm.data.ApiClient;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.leave.ApplyleaveResponse;
import com.seatech.hrm.leave.DatumManageleave;
import com.seatech.hrm.leave.ManageleaveResponse;
import com.seatech.hrm.login.MainResponse;
import com.seatech.hrm.util.NetWorkInfoUtility;
import com.seatech.hrm.util.PrefManager;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ManageleaveActivity extends AppCompatActivity {
    ApiInterface apiInterface;
    TextView  total,remaning,takin;
    PrefManager prefManager;
    ManageableAdpter manageableAdpter;

    String id;

    RecyclerView recyclerView;
    private DrawerLayout drawerLayout;
    NetWorkInfoUtility netWorkInfoUtility;
    private LinearLayout linearLayout;
    SwipeRefreshLayout swipeRefreshLayout;

    LinearLayoutManager linearLayoutManager;
    List< DatumManageleave > mData;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_manageleave);
        total = findViewById (R.id.total);
        recyclerView = findViewById (R.id.recycle);
        remaning = findViewById (R.id.remaing1);
        takin = findViewById (R.id.taken);

        prefManager = new PrefManager (ManageleaveActivity.this);
        apiInterface = ApiClient.getClient (ManageleaveActivity.this).create (ApiInterface.class);
        manageleavedata ();
        initToolbar ();
        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);

    }

    private void initToolbar ( ) {


        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Manage leave");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);

    }



    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent i = new Intent (ManageleaveActivity.this,MainActivity.class);
                i.setFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity (i);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override

    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent (ManageleaveActivity.this,MainActivity.class);
        i.setFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity (i);
        finish ();

    }
    private void manageleavedata () {


        Call< ManageleaveResponse > call = apiInterface.getmanageleave (prefManager.getUserId ());
        System.out.println ("empcodeeeeee:" + prefManager.getemp_code ());
        call.enqueue (new Callback< ManageleaveResponse > () {
            @Override
            public void onResponse (Call< ManageleaveResponse > call, Response< ManageleaveResponse > response) {
                if (response.isSuccessful ()) {
                    if (response.body ().getStatusCode () == 200) {
                        total.setText (String.valueOf (response.body ().getTotalLeave ()));
                        System.out.println ("totalleaveeeee:" + response.body ().getTotalLeave ());
                        remaning.setText (String.valueOf (response.body ().getRemainingLeave ()));
                        System.out.println ("remaingleaveeeee:" + response.body ().getRemainingLeave ());
                        takin.setText (String.valueOf (response.body ().getLeaveTaken ()));
                        System.out.println ("takenleaveeeeeee:" + response.body ().getLeaveTaken ());
                        mData = response.body ().getData ();
                        ManageableAdpter manageableAdpter = new ManageableAdpter (ManageleaveActivity.this, response.body ().getData ());
                        linearLayoutManager = new LinearLayoutManager (ManageleaveActivity.this, LinearLayoutManager.VERTICAL, false);
                        recyclerView.setLayoutManager (linearLayoutManager);
                        recyclerView.setAdapter (manageableAdpter);


                        Toast.makeText (ManageleaveActivity.this, response.body ().getMessage (),
                                        Toast.LENGTH_LONG).show ();


                    }


                }
            }
            @Override
            public void onFailure (Call< ManageleaveResponse > call, Throwable t) {

                Toast.makeText (ManageleaveActivity.this, t.getMessage (),
                                Toast.LENGTH_LONG).show ();


            }
        });
    }
    }




