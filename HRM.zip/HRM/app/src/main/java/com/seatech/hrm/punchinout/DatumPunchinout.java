package com.seatech.hrm.punchinout;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumPunchinout {

    @SerializedName("punchStatus")
    @Expose
    private String punchStatus;
    @SerializedName("PunchIn")
    @Expose
    private String punchIn;

    public String getPunchStatus() {
        return punchStatus;
    }

    public void setPunchStatus(String punchStatus) {
        this.punchStatus = punchStatus;
    }

    public String getPunchIn() {
        return punchIn;
    }

    public void setPunchIn(String punchIn) {
        this.punchIn = punchIn;
    }
}
