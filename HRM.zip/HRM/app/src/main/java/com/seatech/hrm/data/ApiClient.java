package com.seatech.hrm.data;
import android.content.Context;


import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;

import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    public static final String BASE_URL = "http://14.97.59.83:8091/SeaTHRMAPI/";
    // public static final String BASE_URL = "http://booking.sudrive.in/OutStationApi/";
    private static Retrofit retrofit = null;
    public static ApiClient apiClient;
    public static ApiClient getInstance() {
        if (apiClient == null) {
            apiClient = new ApiClient();
        }
        return apiClient;
    }
    public static Retrofit getClient () {
        return getClient(null);
    }

    public static Retrofit getClient(final Context context) {
        if (retrofit == null) {
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.readTimeout(100, TimeUnit.SECONDS);
            client.writeTimeout(100, TimeUnit.SECONDS);
            client.connectTimeout(100, TimeUnit.SECONDS);
            client.addInterceptor(interceptor);
            client.addInterceptor(new Interceptor () {
                @Override
                public okhttp3.Response intercept(Chain chain) throws IOException {
                    Request request = chain.request();

                    return chain.proceed(request);
                }
            });
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client (client.build ())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
