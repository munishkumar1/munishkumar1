package com.seatech.hrm.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.seatech.hrm.R;

public class AttendanceSclectActivity extends DialogFragment {

    TextView personalinfo,punchinout ,cancelattendance;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootsView = inflater.inflate (R.layout.activity_attendance_sclect, container, false);
        getDialog ().setCanceledOnTouchOutside (false);
        personalinfo = rootsView.findViewById (R.id.personalinfo);
        cancelattendance = rootsView.findViewById (R.id.cancel);
        cancelattendance.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (getActivity (),MainActivity.class);
                intent.addFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity (intent);
                getActivity ().finish ();
            }
        });
        personalinfo.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (getActivity (), AttendancePersonalActivity.class);
                intent.addFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity (intent);
                getActivity ().finish ();
            }
        });

        punchinout = rootsView.findViewById (R.id.punchinout);
        punchinout.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (getActivity (), AttendancePunchinoutActivity.class);
                intent.addFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity (intent);
                getActivity ().finish ();
            }
        });

        return rootsView;
    }
}
