package com.seatech.hrm.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.kaopiz.kprogresshud.KProgressHUD;
import com.seatech.hrm.data.ApiClient;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.util.NetWorkInfoUtility;
import com.seatech.hrm.R;
import com.seatech.hrm.login.MainResponse;
import com.seatech.hrm.util.PrefManager;
import com.seatech.hrm.util.Validation;

import java.util.jar.Attributes;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static java.util.jar.Attributes.*;

public class Login extends AppCompatActivity {
    AppCompatEditText email, password;
    Button login;
    ApiInterface apiInterface;
    PrefManager prefManager;
    NetWorkInfoUtility netWorkInfoUtility;
    String Name;
    private KProgressHUD hud;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_login);
        email = findViewById (R.id.username);
        password = findViewById (R.id.password);
        prefManager = new PrefManager (Login.this);
        netWorkInfoUtility = new NetWorkInfoUtility ();
        apiInterface = ApiClient.getClient (Login.this).create (ApiInterface.class);
        login = findViewById (R.id.login);
        login.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View view) {
                if (validate ()) {
                    if (netWorkInfoUtility.isNetWorkAvailableNow (Login.this)) {
                        hud = KProgressHUD.create(Login.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE);
                          login ();

                    }else {
                        LayoutInflater inflater = getLayoutInflater();
                        View layout = inflater.inflate(R.layout.costom_toast, (ViewGroup)
                                findViewById(R.id.custom_toast_container));
                        TextView tv = (TextView) layout.findViewById(R.id.txtvw);
                        tv.setText("You are offline");
                        Toast toast = new Toast(getApplicationContext());
                        toast.setGravity(Gravity.BOTTOM, 0, 100);
                        toast.setDuration(Toast.LENGTH_LONG);
                        toast.setView(layout);
                        toast.show();
                    }
                }
            }
        });
    }
    private boolean validate () {

        boolean valid = true;
        String name = email.getText ().toString ().trim ();
        String Password = password.getText ().toString ().trim ();
        if (name.isEmpty ()) {
            email.setError ("enter a valid UserName");
            valid = false;
        } else {
            email.setError (null);
        }
        if((!Validation.validEmail(name))){
            email.setError ("enter a valid Email");
            valid = false;
        } else {
            email.setError (null);
        }
        if (Password.isEmpty ()) {
            password.setError ("enter a valid Password");
            valid = false;
        } else {
            password.setError (null);
        }

        return valid;
    }


    private void login () {

        Call< MainResponse > call = apiInterface.login (email.getText ().toString (), password.getText ().toString ());
        call.enqueue (new Callback< MainResponse > () {
            @Override
            public void onResponse (Call< MainResponse > call, Response< MainResponse > response) {
                System.out.println ("responseeeeee:" + response);
                hud.dismiss ();
                  if(response.isSuccessful ()) {
                      if (response.body ().getStatusCode () == 200) {
                          String name = response.body ().getResult ().getName ();

                         // Boolean isLogin = response.body ().getData ().getIsLoggedIn ();
                          prefManager.savePunchStatusDetails (response.body ().getResult ().getPunchStatus ());
                          prefManager.saveUserDetails (response.body ().getResult ().getEmpId ());
                          prefManager.savenameDetails (response.body ().getResult ().getName ());
                          prefManager.savepostDetails  (response.body ().getResult ().getPost ());
                          prefManager.saveemp_codeDetails (response.body ().getResult ().getEmpCode ());
                          prefManager.saveemailDetails (response.body ().getResult ().getEmail ());
                          prefManager.savecontactDetails (response.body ().getResult ().getContact ());
                         // prefManager.IsLogin (isLogin);
                          Intent i = new Intent (Login.this, MainActivity.class);
                          i.putExtra ("name",response.body ().getResult ().getName ());
                          i.putExtra ("post",response.body ().getResult ().getPost ());
                          i.putExtra ("empcode",response.body ().getResult ().getEmpCode ());
                          i.putExtra ("punchStatus",response.body ().getResult ().getPunchStatus ());
                          i.putExtra ("email",response.body ().getResult ().getEmail ());
                          i.putExtra ("mobile",response.body ().getResult ().getContact ());
                          i.putExtra ("poto",response.body ().getResult ().getPhoto ());
                          i.putExtra ("id",response.body ().getResult ().getEmpId ());

                          startActivity (i);
                          System.out.println ("idddddddd:" + response.body ().getResult ().getEmpId ());



                          finish ();


                      } else if (response.body ().getStatusCode () == 201) {
                          Toast.makeText (getApplicationContext (), response.body ().getMessage (), Toast.LENGTH_SHORT).show ();


                      }
                  }
            }

            @Override
            public void onFailure (Call< MainResponse > call, Throwable t) {
                System.out.println ("faillllllll:" + t.getMessage ());
                hud.dismiss ();

            }
        });

    }

}



