package com.seatech.hrm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.seatech.hrm.R;
import com.seatech.hrm.adapter.EmployeeAdpter;
import com.seatech.hrm.data.ApiClient;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.databinding.ActivityEmployeeBinding;
import com.seatech.hrm.employeee.DatumEmployee;
import com.seatech.hrm.employeee.EmployeeResponse;
import com.seatech.hrm.util.NetWorkInfoUtility;

import java.util.Collections;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Employee_Activity extends AppCompatActivity {
    SwipeRefreshLayout swipeRefreshLayout;
    RecyclerView recyclerView;
    ActivityEmployeeBinding activityEmployeeBinding;
    NetWorkInfoUtility netWorkInfoUtility;
    ApiInterface apiInterface;
    EmployeeAdpter  employeeAdpter;
    List< DatumEmployee > mData;
    


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        //setContentView (R.layout.activity_employee);







        activityEmployeeBinding =  ActivityEmployeeBinding.inflate (getLayoutInflater ());
        View view = activityEmployeeBinding.getRoot ();
        setContentView (view);


        initToolbar ();
        ActionBar actionBar = getSupportActionBar ();

        actionBar.setDisplayHomeAsUpEnabled (true);

    }

    private void initToolbar () {


        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("All Empolyee");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);


        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager (this);
        activityEmployeeBinding.idemployee.setLayoutManager (layoutManager);
        netWorkInfoUtility= new NetWorkInfoUtility();
        apiInterface = ApiClient.getClient (Employee_Activity.this).create (ApiInterface.class);
        loadEmployeeData();
    }

    private void loadEmployeeData () {
        if (netWorkInfoUtility.isNetWorkAvailableNow (Employee_Activity.this)) {
            Call< EmployeeResponse > call = apiInterface.employee ();
            call.enqueue (new Callback< EmployeeResponse > () {
                @Override
                public void onResponse (Call< EmployeeResponse > call, Response< EmployeeResponse > response) {
                    System.out.println ("cancleteeeeeeee:" + response);
                    if (response.isSuccessful ()) {
                        if (response.body ().getStatusCode () == 201) {
                            Toast.makeText (Employee_Activity.this, response.body ().getMessage (),
                                            Toast.LENGTH_LONG).show ();


                        } else {
                            mData = response.body ().getData ();
                            employeeAdpter = new EmployeeAdpter (Employee_Activity.this, response.body ().getData ());
                            activityEmployeeBinding.idemployee.setAdapter (employeeAdpter);


                            //recyclerView.addOnScrollListener (endlessScrollEventListener);


                        }
                       /* activityEmployeeBinding.swipe.setOnRefreshListener (new SwipeRefreshLayout.OnRefreshListener () {
                            @Override
                            public void onRefresh () {
                                activityEmployeeBinding.swipe.setRefreshing (false);
                                // shuffleItems ();
                            }
                        });

                    }*/
                    }
                }


                @Override
                public void onFailure (Call< EmployeeResponse > call, Throwable t) {
                    System.out.println ("canclefailllllll:" + t.getMessage ());
                }
            });

        }else {
            LayoutInflater inflater = getLayoutInflater();
            View layout = inflater.inflate(R.layout.costom_toast, (ViewGroup)
                    findViewById(R.id.custom_toast_container));
            TextView tv = (TextView) layout.findViewById(R.id.txtvw);
            tv.setText("You are offline");
            Toast toast = new Toast(getApplicationContext());
            toast.setGravity(Gravity.BOTTOM, 0, 100);
            toast.setDuration(Toast.LENGTH_LONG);
            toast.setView(layout);
            toast.show();
        }

        }

    private void shuffleItems () {
        Collections.shuffle (mData, new Random (System.currentTimeMillis ()));
        employeeAdpter = new EmployeeAdpter (Employee_Activity.this,mData);
        recyclerView.setAdapter (employeeAdpter);

    }

    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item) {
        switch (item.getItemId ()) {
            case android.R.id.home:
                Intent i = new Intent (Employee_Activity.this, MainActivity.class);
                startActivity (i);
                this.finish ();
                return true;
        }
        return super.onOptionsItemSelected (item);
    }

    @Override

    public void onBackPressed () {
        super.onBackPressed ();
        Intent i = new Intent (Employee_Activity.this, MainActivity.class);
        startActivity (i);
        finish ();
    }

    }
