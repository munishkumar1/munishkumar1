package com.seatech.hrm.login;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumLogin {

    @SerializedName("Role")
    @Expose
    private String role;
    @SerializedName("empId")
    @Expose
    private String empId;
    @SerializedName("Email")
    @Expose
    private String email;
    @SerializedName("Emp_code")
    @Expose
    private String empCode;
    @SerializedName("punchStatus")
    @Expose
    private String punchStatus;
    @SerializedName("Post")
    @Expose
    private String post;
    @SerializedName("punchInTime")
    @Expose
    private String punchInTime;
    @SerializedName("Photo")
    @Expose
    private String photo;
    @SerializedName("logedIn")
    @Expose
    private Boolean logedIn;
    @SerializedName("Name")
    @Expose
    private String name;
    @SerializedName("Contact")
    @Expose
    private String contact;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public String getPunchStatus() {
        return punchStatus;
    }

    public void setPunchStatus(String punchStatus) {
        this.punchStatus = punchStatus;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getPunchInTime() {
        return punchInTime;
    }

    public void setPunchInTime(String punchInTime) {
        this.punchInTime = punchInTime;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Boolean getLogedIn() {
        return logedIn;
    }

    public void setLogedIn(Boolean logedIn) {
        this.logedIn = logedIn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

}
