package com.seatech.hrm.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.seatech.hrm.R;
import com.seatech.hrm.activity.EmployeeDetail_Activity;
import com.seatech.hrm.data.ApiClient;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.employeee.DatumEmployee;
import com.seatech.hrm.util.PrefManager;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class EmployeeAdpter extends RecyclerView.Adapter<EmployeeAdpter.ViewHodler> {
    private List< DatumEmployee > mData;
    Context mContext;
    ApiInterface apiInterface;
    String id;
    PrefManager prefManager;

    public EmployeeAdpter (Context mContext, List< DatumEmployee > data) {
        this.mContext = mContext;
        this.mData = data;
        prefManager = new PrefManager (mContext);
    }


    @NonNull
    @NotNull
    @Override
    public EmployeeAdpter.ViewHodler onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.employee_item, parent, false);
        // View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.canclefull, parent, false);
        return new EmployeeAdpter .ViewHodler (view);
    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull EmployeeAdpter.ViewHodler holder, int position) {
        holder.name.setText (mData.get (position).getName ());
        id = mData.get (position).getEmpId ();
       // prefManager.saveUserDetails (id);

    }

    @Override
    public int getItemCount () {
        return mData.size ();
    }

    public class ViewHodler extends RecyclerView.ViewHolder {
        TextView name, email, post,role;
        CircleImageView circleImageView;
        CardView cardView;


        public ViewHodler (@NonNull @NotNull View itemView) {
            super (itemView);


            name = itemView.findViewById (R.id.idTVEmplyeeName);
            email = itemView.findViewById (R.id.idTVEmplyeeEmail);
            post = itemView.findViewById (R.id.idTVEmplyeepost);
            role = itemView.findViewById (R.id.idTVCourseName);
           // apiInterface = ApiClient.getClient (itemView.getContext ().createContext (apiInterface.getClass ());
            cardView = itemView.findViewById (R.id.cardview);
             cardView.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Intent myIntent = new Intent(itemView.getContext(), EmployeeDetail_Activity.class);
                    myIntent.putExtra("empid", id);

                    itemView.getContext().startActivity(myIntent);


                }
            });



        }
    }
}
