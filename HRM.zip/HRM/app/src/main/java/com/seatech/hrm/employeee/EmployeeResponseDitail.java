package com.seatech.hrm.employeee;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EmployeeResponseDitail {

    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("Status_code")
    @Expose
    private int statusCode;
    @SerializedName("Result")
    @Expose
    private DatumEmployeeDitail result;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatusCode () {
        return statusCode;
    }

    public void setStatusCode (int statusCode) {
        this.statusCode = statusCode;
    }

    public DatumEmployeeDitail getResult() {
        return result;
    }

    public void setResult(DatumEmployeeDitail result) {
        this.result = result;
    }



}
