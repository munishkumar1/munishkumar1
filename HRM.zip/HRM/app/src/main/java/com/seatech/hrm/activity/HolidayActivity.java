package com.seatech.hrm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.seatech.hrm.R;
import com.seatech.hrm.adapter.EmployeeAdpter;
import com.seatech.hrm.adapter.HolidayAdpter;
import com.seatech.hrm.data.ApiClient;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.databinding.ActivityEmployeeBinding;
import com.seatech.hrm.databinding.ActivityHolidayBinding;
import com.seatech.hrm.employeee.DatumEmployee;
import com.seatech.hrm.employeee.EmployeeResponse;
import com.seatech.hrm.holiday.DatumHoliday;
import com.seatech.hrm.holiday.HolidayResponse;
import com.seatech.hrm.util.NetWorkInfoUtility;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HolidayActivity extends AppCompatActivity {


    ActivityHolidayBinding activityHolidayBinding;
    NetWorkInfoUtility netWorkInfoUtility;
    ApiInterface apiInterface;
    TableRow tableRow;
    HolidayAdpter holidayAdpter;
    List< DatumHoliday > mData;




    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        //setContentView (R.layout.activity_holiday);

        activityHolidayBinding =  ActivityHolidayBinding.inflate (getLayoutInflater ());
        View view = activityHolidayBinding.getRoot ();
        setContentView (view);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager (this);
        activityHolidayBinding.recyclerview.setLayoutManager (layoutManager);





        initToolbar ();
        ActionBar actionBar = getSupportActionBar ();

        actionBar.setDisplayHomeAsUpEnabled (true);

    }

    private void initToolbar () {


        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Manage Holiday");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);


        netWorkInfoUtility= new NetWorkInfoUtility();
        apiInterface = ApiClient.getClient (HolidayActivity.this).create (ApiInterface.class);
        hlidayData ();

    }

    private void hlidayData () {

        if (netWorkInfoUtility.isNetWorkAvailableNow (HolidayActivity.this)) {
            Call<HolidayResponse> call = apiInterface.getholiday ();
            call.enqueue (new Callback< HolidayResponse > () {
                @Override
                public void onResponse (Call< HolidayResponse > call, Response< HolidayResponse > response) {
                    System.out.println (" Holidayyyyy:" + response);

                    if (response.body ().getStatusCode () == 201) {
                        Toast.makeText (HolidayActivity.this, response.body ().getMessage (),
                                        Toast.LENGTH_LONG).show ();


                    } else {
                        mData = response.body ().getData ();
                        HolidayAdpter holidayAdpter = new HolidayAdpter (HolidayActivity.this,response.body ().getData ());
                        activityHolidayBinding.recyclerview.setAdapter (holidayAdpter);

                    }
                }

                @Override
                public void onFailure (Call< HolidayResponse > call, Throwable t) {

                }
            });


        }
    }
    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item) {
        switch (item.getItemId ()) {
            case android.R.id.home:
                Intent i = new Intent (HolidayActivity.this, MainActivity.class);
                startActivity (i);
                this.finish ();
                return true;
        }
        return super.onOptionsItemSelected (item);
    }

    @Override

    public void onBackPressed () {
        super.onBackPressed ();
        Intent i = new Intent (HolidayActivity.this, MainActivity.class);
        startActivity (i);
        finish ();


    }

}


