package com.seatech.hrm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.seatech.hrm.R;

public class PersonlInfoDetail extends AppCompatActivity {
    TextView date, punchinnote, punchin, punchout, punchoutnote, total;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_personl_info_detail);
        date = findViewById (R.id.date);
        punchinnote = findViewById (R.id.punchinnote);
        punchin = findViewById (R.id.punchin);
        punchout = findViewById (R.id.punchout);
        punchoutnote = findViewById (R.id.punchoutnote);
        total = findViewById (R.id.total);

        initToolbar ();
        ActionBar actionBar = getSupportActionBar ();
        actionBar.setDisplayHomeAsUpEnabled (true);

    }

    private void initToolbar () {

        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Personal Info Detail");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);

    }


    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item) {
        switch (item.getItemId ()) {
            case android.R.id.home:
                Intent i = new Intent (PersonlInfoDetail.this, MainActivity.class);
                startActivity (i);
                this.finish ();
                return true;
        }
        return super.onOptionsItemSelected (item);
    }

    @Override

    public void onBackPressed () {
        super.onBackPressed ();
        Intent i = new Intent (PersonlInfoDetail.this, MainActivity.class);
        startActivity (i);
        finish ();


    }
}





