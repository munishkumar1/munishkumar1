package com.seatech.hrm.holiday;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumHoliday {

    @SerializedName("DATE")
    @Expose
    private String date;
    @SerializedName("flag")
    @Expose
    private Boolean flag;
    @SerializedName("HOLIDAY")
    @Expose
    private String holiday;
    @SerializedName("TYPE")
    @Expose
    private String type;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Boolean getFlag() {
        return flag;
    }

    public void setFlag(Boolean flag) {
        this.flag = flag;
    }

    public String getHoliday() {
        return holiday;
    }

    public void setHoliday(String holiday) {
        this.holiday = holiday;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
