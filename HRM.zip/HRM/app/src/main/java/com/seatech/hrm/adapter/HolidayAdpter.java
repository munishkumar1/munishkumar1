package com.seatech.hrm.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.seatech.hrm.R;
import com.seatech.hrm.activity.EmployeeDetail_Activity;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.employeee.DatumEmployee;
import com.seatech.hrm.holiday.DatumHoliday;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class HolidayAdpter extends RecyclerView.Adapter<HolidayAdpter.ViewHodler> {

    private List< DatumHoliday > mData;
    Context mContext;
    String id;

    public HolidayAdpter (Context mContext, List< DatumHoliday > mData) {
        this.mContext = mContext;
        this.mData = mData;
    }


    @NonNull
    @NotNull
    @Override
    public HolidayAdpter.ViewHodler onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.recycler_item_regular_row, parent, false);
        // View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.canclefull, parent, false);
        return new HolidayAdpter.ViewHodler (view);
    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull HolidayAdpter.ViewHodler holder, int position) {
        holder.date.setText (mData.get (position).getDate ());
        holder.holiday.setText (mData.get (position).getHoliday ());
        holder.type.setText (mData.get (position).getType ());
        id = mData.get (position).getDate ();

    }

    @Override
    public int getItemCount () {
        return mData.size ();
    }

    public class ViewHodler extends RecyclerView.ViewHolder {
        TextView date, holiday, type;
        CircleImageView circleImageView;
        CardView cardView;


        public ViewHodler (@NonNull @NotNull View itemView) {
            super (itemView);


            date = itemView.findViewById (R.id.date1);
            holiday = itemView.findViewById (R.id.holiday1);
            type = itemView.findViewById (R.id.type1);

            // apiInterface = ApiClient.getClient (itemView.getContext ().createContext (apiInterface.getClass ());






        }
    }
}



