package com.seatech.hrm.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.seatech.hrm.R;

public class LeaveSclectActivity extends DialogFragment {
TextView applyleave,manageleave,cancel;






    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate (R.layout.demo, container, false);
        getDialog ().setCanceledOnTouchOutside (false);
        cancel = rootView.findViewById (R.id.Cancelleave);
        cancel.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (getActivity (),MainActivity.class);
               // intent.addFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity (intent);
                getActivity ().finish ();
            }
        });
        applyleave = rootView.findViewById(R.id.applyleave);
        manageleave = rootView.findViewById (R.id.managelive);
        manageleave.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (getActivity (),ManageleaveActivity.class);
               // intent.addFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity (intent);

            }
        });
        applyleave.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent i = new Intent (getActivity (),ApplyLeaveActivity2.class);
               // i.addFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity (i);
                getActivity ().finish ();

            }
        });

        manageleave = rootView.findViewById (R.id.idmanageleave);
        return  rootView;
    }
}