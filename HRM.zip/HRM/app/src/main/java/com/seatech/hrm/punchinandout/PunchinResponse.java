package com.seatech.hrm.punchinandout;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import javax.xml.transform.Result;

public class PunchinResponse {
    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("Status_code")
    @Expose
    private int statusCode;
    @SerializedName("Result")
    @Expose
    private DatumPunchinin result;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public DatumPunchinin getResult () {
        return result;
    }

    public void setResult (DatumPunchinin result) {
        this.result = result;
    }
}


