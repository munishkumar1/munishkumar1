package com.seatech.hrm.attendance;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumAttendance {

    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("total")
    @Expose
    private String total;
    @SerializedName("punchOutTime")
    @Expose
    private String punchOutTime;
    @SerializedName("punchOutNote")
    @Expose
    private String punchOutNote;
    @SerializedName("punchInTime")
    @Expose
    private String punchInTime;
    @SerializedName("punchInNote")
    @Expose
    private String punchInNote;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getPunchOutTime() {
        return punchOutTime;
    }

    public void setPunchOutTime(String punchOutTime) {
        this.punchOutTime = punchOutTime;
    }

    public String getPunchOutNote() {
        return punchOutNote;
    }

    public void setPunchOutNote(String punchOutNote) {
        this.punchOutNote = punchOutNote;
    }

    public String getPunchInTime() {
        return punchInTime;
    }

    public void setPunchInTime(String punchInTime) {
        this.punchInTime = punchInTime;
    }

    public String getPunchInNote() {
        return punchInNote;
    }

    public void setPunchInNote(String punchInNote) {
        this.punchInNote = punchInNote;
    }

}
