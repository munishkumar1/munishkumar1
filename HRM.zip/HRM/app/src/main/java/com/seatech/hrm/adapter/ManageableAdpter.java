package com.seatech.hrm.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.seatech.hrm.R;
import com.seatech.hrm.activity.ManageleaveActivity;
import com.seatech.hrm.holiday.DatumHoliday;
import com.seatech.hrm.leave.DatumManageleave;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ManageableAdpter extends RecyclerView.Adapter< ManageableAdpter.ViewHodler> {

    private List< DatumManageleave > mData;
    Context mContext;
    String id;

    public ManageableAdpter (Context mContext, List< DatumManageleave> data) {
        this.mContext = mContext;
        this.mData = data;
    }

    @NonNull
    @NotNull
    @Override
    public ManageableAdpter.ViewHodler onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.manageleavedeatails, parent, false);
        // View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.canclefull, parent, false);
        return new ManageableAdpter.ViewHodler (view);
    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull ManageableAdpter.ViewHodler holder, int position) {
       holder.emp_id.setText (String.valueOf (mData.get (position).getEmpId ()));
     holder.name.setText (mData.get (position).getName ());
      holder.frome.setText (mData.get (position).getFrom ());
        holder.to.setText (mData.get (position).getTo ());
        holder.reson.setText (mData.get (position).getReason ());
       holder.status.setText (mData.get (position).getApproval ());
       // = mData.get (position).getEmpId ();

    }

    @Override
    public int getItemCount () {
        return mData.size ();
    }

    public class ViewHodler extends RecyclerView.ViewHolder {
        TextView emp_id,name,frome,to,reson,status;
        CircleImageView circleImageView;
        CardView cardView;


        public ViewHodler (@NonNull @NotNull View itemView) {
            super (itemView);


            emp_id = itemView.findViewById (R.id.emp_id);
            name = itemView.findViewById (R.id.name);
            frome = itemView.findViewById (R.id.frome);
            to = itemView.findViewById (R.id.to);
            reson = itemView.findViewById (R.id.reson);
            status = itemView.findViewById (R.id.status);

            // apiInterface = ApiClient.getClient (itemView.getContext ().createContext (apiInterface.getClass ());






        }
    }
}



