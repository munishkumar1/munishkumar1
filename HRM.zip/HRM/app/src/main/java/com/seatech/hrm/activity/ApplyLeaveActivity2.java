package com.seatech.hrm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.seatech.hrm.R;
import com.seatech.hrm.data.ApiClient;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.leave.ApplyleaveResponse;
import com.seatech.hrm.login.MainResponse;
import com.seatech.hrm.util.PrefManager;

import java.util.Calendar;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApplyLeaveActivity2 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner Leavetype, Spinneremployee;
    String leaverType;
    TextView date, todaydate;
    EditText editText;
    Button saveleave;
    private int mYear, mMonth, mDay;
    ApiInterface apiInterface;
    FragmentTransaction fragmentTransaction;
    PrefManager prefManager;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_apply_leave3);
        date = findViewById (R.id.calander_home);
        editText = findViewById (R.id.feedback_longdes);
        saveleave = findViewById (R.id.saveleave);
        prefManager = new PrefManager (ApplyLeaveActivity2.this);
        apiInterface = ApiClient.getClient (ApplyLeaveActivity2.this).create (ApiInterface.class);
        saveleave.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                saveleave ();
            }
        });
        todaydate = findViewById (R.id.todaydate);
        Spinneremployee = findViewById (R.id.spinneremployee);
        FragmentManager fragmentManager = getSupportFragmentManager ();
        fragmentTransaction = fragmentManager.beginTransaction ();
        initToolbar ();
        ActionBar actionBar = getSupportActionBar ();
        actionBar.setDisplayHomeAsUpEnabled (true);


        String[] valuesone =
                {"Self", "Rahul"};
        ArrayAdapter< String > arrayAdapter = new ArrayAdapter< String > (this.Spinneremployee.getContext (), android.R.layout.simple_spinner_item, valuesone);
        arrayAdapter.setDropDownViewResource (android.R.layout.simple_dropdown_item_1line);
        Spinneremployee.setAdapter (arrayAdapter);
        Spinneremployee.setOnItemSelectedListener (this);
        todaydate.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                final Calendar c = Calendar.getInstance ();
                mYear = c.get (Calendar.YEAR);
                mMonth = c.get (Calendar.MONTH);
                mDay = c.get (Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog (ApplyLeaveActivity2.this,
                                                                          new DatePickerDialog.OnDateSetListener () {


                                                                              @Override
                                                                              public void onDateSet (DatePicker view, int year,
                                                                                                     int monthOfYear, int dayOfMonth) {

                                                                                  todaydate.setText (dayOfMonth + "-" + ( monthOfYear + 1 ) + "-" + year);

                                                                              }
                                                                          }, mYear, mMonth, mDay);
                datePickerDialog.show ();
            }


        });
        date.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                final Calendar c = Calendar.getInstance ();
                mYear = c.get (Calendar.YEAR);
                mMonth = c.get (Calendar.MONTH);
                mDay = c.get (Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog (ApplyLeaveActivity2.this,
                                                                          new DatePickerDialog.OnDateSetListener () {


                                                                              @Override
                                                                              public void onDateSet (DatePicker view, int year,
                                                                                                     int monthOfYear, int dayOfMonth) {

                                                                                  date.setText (dayOfMonth + "-" + ( monthOfYear + 1 ) + "-" + year);

                                                                              }
                                                                          }, mYear, mMonth, mDay);
                datePickerDialog.show ();
            }
        });

        String[] values =
                {"Sick", "Hospitalisation", "Maternity", "Maternity", "Paternity", "LOP", "Casual Leave"};
        Leavetype = findViewById (R.id.Spinnera);
        ArrayAdapter< String > adapter = new ArrayAdapter< String > (this.Leavetype.getContext (), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource (android.R.layout.simple_dropdown_item_1line);
        Leavetype.setAdapter (adapter);
        Leavetype.setOnItemSelectedListener (this);
    }


   /* @Override
    public void onItemSelected (AdapterView< ? > parent, View view, int position, long id) {

    }


    @Override
    public void onNothingSelected (AdapterView< ? > parent) {

    }

    String[] values =
            {"Salf", "Employee name"};*/


    private void initToolbar () {


        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Apply Leave");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);
    }


    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item) {
        switch (item.getItemId ()) {
            case android.R.id.home:
                Intent i = new Intent (ApplyLeaveActivity2.this, MainActivity.class);
                startActivity (i);
                return true;
        }
        return super.onOptionsItemSelected (item);
    }


    @Override
    public void onItemSelected (AdapterView< ? > parent, View view, int position, long id) {
         leaverType = Leavetype.getSelectedItem().toString();
    }


    @Override
    public void onNothingSelected (AdapterView< ? > parent) {

    }

    @Override
    public void onBackPressed () {
        Intent i = new Intent (ApplyLeaveActivity2.this, MainActivity.class);
        // Intent i = new Intent (Intent.ACTION_MAIN);
        i.addFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.addFlags (Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity (i);


    }

    private void saveleave () {
        Call< ApplyleaveResponse > call = apiInterface.getapplyleave (prefManager.getUserId (), String.valueOf(leaverType), date.getText ().toString (), todaydate.getText ().toString (),
                                                                      editText.getText ().toString ());
        call.enqueue (new Callback< ApplyleaveResponse > () {
            @Override
            public void onResponse (Call< ApplyleaveResponse > call, Response< ApplyleaveResponse > response) {
                System.out.println ("saveeeeeeee:" + response);

                if (response.body ().getStatusCode () == 200) {



                    Intent i = new Intent (ApplyLeaveActivity2.this, MainActivity.class);
                    startActivity (i);
                    finish ();
                } else if (response.body ().getStatusCode () == 201) {
                    Toast.makeText (getApplicationContext (), response.body ().getMessage (), Toast.LENGTH_SHORT).show ();

                }

            }






            @Override
            public void onFailure (Call< ApplyleaveResponse > call, Throwable t) {
                System.out.println ("employeefaillllll:" + t.getMessage ());

            }
        });


    }
}