package com.seatech.hrm.leave;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ManageleaveResponse {
    @SerializedName("Remaining Leave")
    @Expose
    private Integer remainingLeave;
    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private List<DatumManageleave> data = null;
    @SerializedName("Status_code")
    @Expose
    private Integer statusCode;
    @SerializedName("Total Leave")
    @Expose
    private Integer totalLeave;
    @SerializedName("Leave Taken")
    @Expose
    private Integer leaveTaken;
    @SerializedName("Success")
    @Expose
    private Boolean success;

    public Integer getRemainingLeave() {
        return remainingLeave;
    }

    public void setRemainingLeave(Integer remainingLeave) {
        this.remainingLeave = remainingLeave;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<DatumManageleave> getData() {
        return data;
    }

    public void setData(List<DatumManageleave> data) {
        this.data = data;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Integer getTotalLeave() {
        return totalLeave;
    }

    public void setTotalLeave(Integer totalLeave) {
        this.totalLeave = totalLeave;
    }

    public Integer getLeaveTaken() {
        return leaveTaken;
    }

    public void setLeaveTaken(Integer leaveTaken) {
        this.leaveTaken = leaveTaken;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }}