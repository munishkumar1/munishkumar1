package com.seatech.hrm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.seatech.hrm.R;
import com.seatech.hrm.util.PrefManager;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    Toolbar toolbar;
    TextView empname,emppost,empcode,empemail,empmobile;
   ImageView emppick;
    NavigationView navigationView;
    public DrawerLayout drawerLayout;
    PrefManager prefManager;
    CardView cardView ,leavecardView,attendanceview,holdaycard;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);
        prefManager = new PrefManager (MainActivity.this);
        empname = findViewById (R.id.empname);
        String name = prefManager.getname ();
        String Post = prefManager.getpost ();
        String Emp_code = prefManager.getemp_code ();
        String Email = prefManager.getemail ();
        String Contact = prefManager.getcontact ();

        Intent i = getIntent ();
        System.out.println ("nameeeeee:"+i.getStringExtra ("name"));
        empname.setText (name);
        emppost = findViewById (R.id.emppost);
        emppost.setText (Post);
        System.out.println ("posttttt:"+i.getStringExtra ("post"));
        empcode = findViewById (R.id.empcode);
        empcode.setText (Emp_code);
        empemail = findViewById (R.id.empeamil);
        empemail.setText (Email);
        empmobile = findViewById (R.id.empmobile);
        empmobile.setText (Contact);
        emppick = findViewById (R.id.profile_image);
        initView ();

       // emppick.setImageDrawable (i.getStringExtra ("poto"));





         holdaycard = findViewById (R.id.Holiday);
         holdaycard.setOnClickListener (new View.OnClickListener () {
             @Override
             public void onClick (View v) {
                 Intent intent = new Intent (MainActivity.this,HolidayActivity.class);
                 intent.addFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                 startActivity (intent);
                 finish ();

             }
         });
         cardView = findViewById (R.id.card);
        leavecardView = findViewById (R.id.cardtwo);
        attendanceview = findViewById (R.id.cardomr);

        attendanceview.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (MainActivity.this,AttendanceSelectDilaog.class);
                intent.setFlags (Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity (intent);


            }
        });
        leavecardView.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (MainActivity.this,CustomDilaog_Leave.class);
                intent.setFlags (Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity (intent);




            }
        });
         cardView.setOnClickListener (new View.OnClickListener () {
             public void onClick (View v) {
                 Intent intent = new Intent(MainActivity.this, Employee_Activity.class);
                 intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK| Intent.FLAG_ACTIVITY_CLEAR_TASK);
                 startActivity(intent);
                 finish ();

             }
         });
        navigationView = findViewById (R.id.nav_view);
        navigationView.setNavigationItemSelectedListener (this);


    }

    private void initView() {
        // Replace the default action bar with a Toolbar so the navigation drawer appears above it
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);



        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle (this, drawerLayout, toolbar, R.string.nav_open, R.string.nav_close);
        drawerLayout.addDrawerListener (toggle);
        toggle.syncState ();


//       navigationView.setCheckedItem (R.id.nav_empolyee);

    }



    @Override
    public boolean onNavigationItemSelected (@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId ()) {
            case R.id.nav_empolyee:
                Intent intent = new Intent (MainActivity.this,EmployeeDetail_Activity.class);
                intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK| Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity (intent);
                finish();
                break;
            case R.id.nav_leave:
                FragmentManager fragmentManager = getSupportFragmentManager ();
                //getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                LeaveSclectActivity resourse_share=new LeaveSclectActivity ();
                resourse_share.show(fragmentManager, "Dialog Fragment");
                break;
            case R.id.nav_attendance:
                FragmentManager fM = getSupportFragmentManager ();
               // getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                AttendanceSclectActivity resourse_share_one=new AttendanceSclectActivity ();
                resourse_share_one.show(fM, "Att Fragment");

                break;
           /*case R.id.nav_create:
               intent = new Intent (SecondActivity.this,CreateActivity.class);
                startActivity (intent);
                break;*/
            case R.id.nav_holiday:
                Intent intent1 = new Intent (MainActivity.this,HolidayActivity.class);
                intent1.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK| Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity (intent1);
                finish();
                break;

            case R.id.nav_logout:
                //prefManager.Logout ();
               // exit ();
                // intent = new Intent (SecondActivity.this, MainActivity.class);
                //  startActivity (intent);
                finishAffinity ();
                break;



        }
        drawerLayout.closeDrawer (GravityCompat.START);
        return true;
    }
}

