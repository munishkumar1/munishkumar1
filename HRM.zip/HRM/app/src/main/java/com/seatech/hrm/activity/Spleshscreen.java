package com.seatech.hrm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.seatech.hrm.R;

public class Spleshscreen extends AppCompatActivity {
    private static int SPLASH_SCREEN_TIME_OUT=2000;
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_spleshscreen);

        Thread timer = new Thread () {
            @Override
            public void run () {

                try {
                    sleep (2000);


                    Intent i = new Intent (Spleshscreen.this, Login.class);
                    startActivity (i);
                    finish ();

                    super.run ();
                } catch (InterruptedException e) {
                    e.printStackTrace ();
                }
            }

        };
        timer.start ();
    }




    }



