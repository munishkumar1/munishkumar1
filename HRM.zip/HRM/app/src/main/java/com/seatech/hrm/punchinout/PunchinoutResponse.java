package com.seatech.hrm.punchinout;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import javax.xml.transform.Result;

public class PunchinoutResponse {

    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("Status_code")
    @Expose
    private Integer statusCode;
    @SerializedName("Success")
    @Expose
    private Boolean success;
    @SerializedName("Result")
    @Expose
    private Result result;

    public String getMessage () {
        return message;
    }

    public void setMessage (String message) {
        this.message = message;
    }

    public Integer getStatusCode () {
        return statusCode;
    }

    public void setStatusCode (Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Boolean getSuccess () {
        return success;
    }

    public void setSuccess (Boolean success) {
        this.success = success;
    }

    public Result getResult () {
        return result;
    }

    public void setResult (Result result) {
        this.result = result;
    }
}