package com.seatech.hrm.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.seatech.hrm.R;
import com.seatech.hrm.attendance.DatumAttendance;
import com.seatech.hrm.holiday.DatumHoliday;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PersonalinfoAdpter extends RecyclerView.Adapter< PersonalinfoAdpter.ViewHodler> {

    private List< DatumAttendance > pData;
    Context mContext;
    String id;

    public PersonalinfoAdpter (Context mContext, List< DatumAttendance > pData) {
        this.mContext = mContext;
        this.pData = pData;
    }


    @NonNull
    @NotNull
    @Override
    public PersonalinfoAdpter.ViewHodler onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.personalitemdetial, parent, false);
        // View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.canclefull, parent, false);
        return new PersonalinfoAdpter.ViewHodler (view);
    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull PersonalinfoAdpter.ViewHodler holder, int position) {
        holder.date.setText (pData.get (position).getDate ());
        holder.punchinfo.setText (pData.get (position).getPunchInNote ());
        holder. outinfo.setText (pData.get (position).getPunchOutTime ());
        holder. outnote.setText (pData.get (position).getPunchOutNote ());
       holder.punchinifo.setText (pData.get (position).getPunchInTime ());
        holder.  toolinfo.setText (pData.get (position).getTotal ());
       //   id = pData.get (position).getDate ();*/

    }

    @Override
    public int getItemCount () {
        return pData.size ();
    }

    public class ViewHodler extends RecyclerView.ViewHolder {
        TextView date, punchinfo,punchinifo,outinfo,outnote,toolinfo;
        CircleImageView circleImageView;
        CardView cardView;


        public ViewHodler (@NonNull @NotNull View itemView) {
            super (itemView);


            date = itemView.findViewById (R.id.date);
            punchinfo = itemView.findViewById (R.id.punchinnote);
            punchinifo = itemView.findViewById (R.id.punchin);
            outinfo = itemView.findViewById (R.id.punchout);
           outnote = itemView.findViewById (R.id.punchoutnote);
           toolinfo = itemView.findViewById (R.id.total);
           // toolinfo = itemView.findViewById (R.id.punchinifo);

            // apiInterface = ApiClient.getClient (itemView.getContext ().createContext (apiInterface.getClass ());






        }
    }
}



