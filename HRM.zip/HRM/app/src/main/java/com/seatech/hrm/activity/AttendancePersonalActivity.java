package com.seatech.hrm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.seatech.hrm.R;
import com.seatech.hrm.adapter.PersonalinfoAdpter;
import com.seatech.hrm.attendance.AttendanceinfoResponse;
import com.seatech.hrm.attendance.DatumAttendance;
import com.seatech.hrm.data.ApiClient;
import com.seatech.hrm.data.ApiInterface;
import com.seatech.hrm.util.NetWorkInfoUtility;
import com.seatech.hrm.util.PrefManager;

import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AttendancePersonalActivity extends AppCompatActivity {
    TextView fromedate, todaydate;
    RecyclerView recyclerView;
    Button search;
    PrefManager prefManager;
    private int mYear, mMonth, mDay;
    ApiInterface apiInterface;
    LinearLayoutManager linearLayoutManager;
    TableRow tableRow;
   PersonalinfoAdpter personalinfoAdpter;
    List< DatumAttendance > pData;

    NetWorkInfoUtility netWorkInfoUtility;
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_attendance_personal);
        recyclerView = findViewById (R.id.recycler);
        fromedate = findViewById (R.id.calander_fromeattendance);
        search = findViewById (R.id.search);
        prefManager = new PrefManager (AttendancePersonalActivity.this);

        apiInterface = ApiClient.getClient (AttendancePersonalActivity.this).create (ApiInterface.class);
        search.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                personalinfo ();
            }
        });
        fromedate.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                final Calendar c = Calendar.getInstance ();
                mYear = c.get (Calendar.YEAR);
                mMonth = c.get (Calendar.MONTH);
                mDay = c.get (Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog (AttendancePersonalActivity.this,
                                                                          new DatePickerDialog.OnDateSetListener () {


                                                                              @Override
                                                                              public void onDateSet (DatePicker view, int year,
                                                                                                     int monthOfYear, int dayOfMonth) {

                                                                                  fromedate.setText (dayOfMonth + "-" + ( monthOfYear + 1 ) + "-" + year);

                                                                              }
                                                                          }, mYear, mMonth, mDay);
                datePickerDialog.show ();
            }


        });
        todaydate = findViewById (R.id.attendancepersonal);
        todaydate.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                final Calendar c = Calendar.getInstance ();
                mYear = c.get (Calendar.YEAR);
                mMonth = c.get (Calendar.MONTH);
                mDay = c.get (Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog (AttendancePersonalActivity.this,
                                                                          new DatePickerDialog.OnDateSetListener () {


                                                                              @Override
                                                                              public void onDateSet (DatePicker view, int year,
                                                                                                     int monthOfYear, int dayOfMonth) {

                                                                                  todaydate.setText (dayOfMonth + "-" + ( monthOfYear + 1 ) + "-" + year);

                                                                              }
                                                                          }, mYear, mMonth, mDay);
                datePickerDialog.show ();
            }


        });
        initToolbar ();
        ActionBar actionBar = getSupportActionBar ();

        actionBar.setDisplayHomeAsUpEnabled (true);

    }

    private void initToolbar () {


        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Personal info");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);

    }


    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item) {
        switch (item.getItemId ()) {
            case android.R.id.home:
                Intent i = new Intent (AttendancePersonalActivity.this, MainActivity.class);
                i.setFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity (i);
                return true;
        }
        return super.onOptionsItemSelected (item);
    }

    @Override

    public void onBackPressed () {
        super.onBackPressed ();
        Intent i = new Intent (AttendancePersonalActivity.this, MainActivity.class);
        i.setFlags (Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity (i);
        finish ();


    }
    private void personalinfo () {
        Call< AttendanceinfoResponse > call = apiInterface.getattendace(fromedate.getText ().toString (), todaydate.getText ().toString (), prefManager.getUserId ());
        call.enqueue (new Callback< AttendanceinfoResponse > () {
            @Override
            public void onResponse (Call< AttendanceinfoResponse > call, Response< AttendanceinfoResponse > response) {
                System.out.println ("INFORRRRRRRR:" + response);
               /* if (response.body ().getStatusCode () == 200) {


                    Intent i = new Intent (AttendancePersonalActivity.this, PersonlInfoDetail.class);
                    startActivity (i);
                    finish ();
                } else*/
                if (response.body ().getStatusCode () == 201) {
                    Toast.makeText (getApplicationContext (), response.body ().getMessage (), Toast.LENGTH_SHORT).show ();

                } else {
                    pData = response.body ().getData ();
                    personalinfoAdpter = new PersonalinfoAdpter (AttendancePersonalActivity.this, response.body ().getData ());
                    linearLayoutManager = new LinearLayoutManager (AttendancePersonalActivity.this, LinearLayoutManager.VERTICAL, false);
                    recyclerView.setLayoutManager (linearLayoutManager);
                    recyclerView.setAdapter (personalinfoAdpter);

                }
            }





            @Override
            public void onFailure (Call< AttendanceinfoResponse > call, Throwable t) {

            }
        });
    }

}




