package com.seatech.hrm.attendance;

public class AttendancePuchin {


}
