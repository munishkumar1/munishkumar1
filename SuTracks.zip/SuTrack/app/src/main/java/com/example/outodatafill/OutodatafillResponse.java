package com.example.outodatafill;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OutodatafillResponse {

    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private DatumOutodatafill data;
    @SerializedName("Status_code")
    @Expose
    private Integer statusCode;
    @SerializedName("Success")
    @Expose
    private Boolean success;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DatumOutodatafill getData() {
        return data;
    }

    public void setData(DatumOutodatafill data) {
        this.data = data;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

}
