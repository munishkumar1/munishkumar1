package com.example.activity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.adapter.OrderAdapter;
import com.example.data.APIInterface;
import com.example.data.ApiClient;
import com.example.orderlist.DatumOrderlist;
import com.example.orderlist.OrderlistResponse;
import com.example.sutrack.R;
import com.utility.PrefManager;

import java.util.Collections;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment_Orders extends Fragment {

    APIInterface apiInterface;
    RecyclerView recyclerView;
    PrefManager prefManager;
    private DrawerLayout drawerLayout;
    //NetWorkInfoUtility netWorkInfoUtility;
    private LinearLayout linearLayout;
    SwipeRefreshLayout swipeRefreshLayout;
    OrderAdapter orderAdapter;
    List< DatumOrderlist > mData;
    LinearLayoutManager linearLayoutManager;


    @Nullable
    @Override
    public View onCreateView (LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate (R.layout.homefragmentod, container, false);
        prefManager = new PrefManager (getActivity ());
        apiInterface = ApiClient.getClient (getActivity ()).create (APIInterface.class);
        recyclerView = view.findViewById (R.id.idRun);
        linearLayout = view.findViewById (R.id.empty);
        linearLayout = view.findViewById (R.id.empty_run);
        swipeRefreshLayout = view.findViewById (R.id.swipe);

        Call< OrderlistResponse > call = apiInterface.getOrderhistery (prefManager.getUserId ());
        call.enqueue (new Callback< OrderlistResponse > () {
            @Override
            public void onResponse (Call< OrderlistResponse > call, Response< OrderlistResponse > response) {


                if (response.isSuccessful ()) {
                    if (response.body ().getStatusCode () == 201) {
                        Toast.makeText (getActivity (), response.body ().getMessage (),
                                        Toast.LENGTH_LONG).show ();
                        linearLayout.setVisibility (View.VISIBLE);
                        swipeRefreshLayout.setVisibility (View.GONE);


                    } else {
                        mData = response.body ().getData ();
                        //int pageNum = mData.size ();
                        orderAdapter = new  OrderAdapter (getActivity (), mData);
                        linearLayoutManager = new LinearLayoutManager (getActivity (), LinearLayoutManager.VERTICAL, false);
                        recyclerView.setLayoutManager (linearLayoutManager);
                        orderAdapter.notifyDataSetChanged ();

                        recyclerView.setAdapter (orderAdapter);
                        //upcomingAdapter.updateData (response.body ().getData ());
                        // upcomingAdapter.updateData (response.body ().getData ());



                          /*  endlessScrollEventListener = new EndlessScrollEventListener (linearLayoutManager) {
                                @Override
                                public void onLoadMore (int pageNum, RecyclerView recyclerView) {
                                    upCommingData ();

                                }
                            };*/
                        // recyclerView.addOnScrollListener (endlessScrollEventListener);
                    }
                    swipeRefreshLayout.setOnRefreshListener (new SwipeRefreshLayout.OnRefreshListener () {
                        @Override
                        public void onRefresh () {
                            swipeRefreshLayout.setRefreshing (false);
                            // upcomingAdapter.notifyDataSetChanged ();
                            shuffleItems ();


                        }
                    });
                }
            }

            @Override
            public void onFailure (Call< OrderlistResponse > call, Throwable t) {

            }
        });

        return view;

    }

    private void shuffleItems () {

        Collections.shuffle (mData, new Random (System.currentTimeMillis ()));
        orderAdapter = new OrderAdapter (getActivity (), mData);
        recyclerView.setAdapter (orderAdapter);
    }
}









