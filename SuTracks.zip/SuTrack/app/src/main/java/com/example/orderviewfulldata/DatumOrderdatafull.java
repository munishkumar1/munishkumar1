package com.example.orderviewfulldata;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumOrderdatafull {


    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("moving_from")
    @Expose
    private String movingFrom;
    @SerializedName("driver_id")
    @Expose
    private String driverId;
    @SerializedName("amount")
    @Expose
    private String amount;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("leadb_api")
    @Expose
    private Integer leadbApi;
    @SerializedName("remaining")
    @Expose
    private String remaining;
    @SerializedName("advance")
    @Expose
    private String advance;
    @SerializedName("contact")
    @Expose
    private String contact;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("moving_to")
    @Expose
    private String movingTo;
    @SerializedName("uniqueLeadId")
    @Expose
    private String uniqueLeadId;
    @SerializedName("lead_api")
    @Expose
    private Integer leadApi;
    @SerializedName("status")
    @Expose
    private Integer status;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMovingFrom() {
        return movingFrom;
    }

    public void setMovingFrom(String movingFrom) {
        this.movingFrom = movingFrom;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Integer getLeadbApi() {
        return leadbApi;
    }

    public void setLeadbApi(Integer leadbApi) {
        this.leadbApi = leadbApi;
    }

    public String getRemaining() {
        return remaining;
    }

    public void setRemaining(String remaining) {
        this.remaining = remaining;
    }

    public String getAdvance() {
        return advance;
    }

    public void setAdvance(String advance) {
        this.advance = advance;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMovingTo() {
        return movingTo;
    }

    public void setMovingTo(String movingTo) {
        this.movingTo = movingTo;
    }

    public String getUniqueLeadId() {
        return uniqueLeadId;
    }

    public void setUniqueLeadId(String uniqueLeadId) {
        this.uniqueLeadId = uniqueLeadId;
    }

    public Integer getLeadApi() {
        return leadApi;
    }

    public void setLeadApi(Integer leadApi) {
        this.leadApi = leadApi;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

}
