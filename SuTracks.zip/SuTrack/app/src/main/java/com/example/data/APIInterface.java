package com.example.data;

import com.example.booknow.BooknowResponse;
import com.example.manageotp.OtpResponse;
import com.example.mobile.MobileResponse;
import com.example.orderlist.OrderlistResponse;
import com.example.orderviewfulldata.OrderdatafullResponse;
import com.example.outodatafill.OutodatafillResponse;
import com.example.trucktype.TrucktypeResponse;
import com.example.useredit.EditResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface APIInterface {

    @FormUrlEncoded
    @POST("LoginContactApi")
    Call< MobileResponse > getmobile (

            @Field("Mobile") String Mobile);



    @FormUrlEncoded
    @POST("OtpCheck")
    Call< OtpResponse > getOtp (
            @Field("Mobile") String Mobile,
            @Field("OTP") String OTP);

    @FormUrlEncoded
    @POST("EditUserList")
    Call< EditResponse > getEdit (
            @Field("Name") String cust_name,
            @Field("Email") String cust_email,
            @Field("Contact") String cust_contact,
            @Field("City") String cust_city,
            @Field("Edit_api") String Edit_api,
            @Field("DOB") String Dob,
            @Field("id") String id);




    @FormUrlEncoded
    @POST("AddLeadServlet")
    Call< BooknowResponse > getbooknow (
            @Field("Name") String cust_name,
            @Field("City") String cust_city,
            @Field("Contact") String cust_contact,
            @Field("Moving_from") String cust_place,
            @Field("Moving_to") String cust_placen,
            @Field("Date") String Edit_date,
            @Field("Weight") String weight,
            @Field("Unit") String unit,
            @Field("NoOfPackage") String no_of_Packege,
            @Field("TruckType") int truck_type,  @Field("good_type") String good_type,@Field("leadb_api") String s1);


    @FormUrlEncoded
    @POST("OrderHistory")
    Call< OrderlistResponse > getOrderhistery (
            @Field("Contact") String cust_contect);




    @FormUrlEncoded
    @POST("FetchUserData")
    Call< OutodatafillResponse > getOutodatafill (
            @Field("Contact") String cust_contect);



    @FormUrlEncoded
    @POST("ViewOrderApi")
    Call< OrderdatafullResponse > getviewfulldata (
            @Field("id") String cust_id);



    @POST("TruckType")
    Call< TrucktypeResponse > getTruckTypedata ();



    @POST("TruckType")
    Call< TrucktypeResponse > getTruckTypedata ();

}
