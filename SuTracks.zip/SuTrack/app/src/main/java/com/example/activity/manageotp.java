package com.example.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.data.APIInterface;
import com.example.data.ApiClient;
import com.example.manageotp.OtpResponse;
import com.example.mobile.MobileResponse;
import com.example.sutrack.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class manageotp extends AppCompatActivity {

    EditText t2;
    Button b2;
    private APIInterface apiInterface;
    private String TAG = "manageotp.class";

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_manageotp);
        t2 = (EditText) findViewById (R.id.t2);
        b2 = (Button) findViewById (R.id.b2);
        b2.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                otp ();


            }
        });
        apiInterface = ApiClient.getClient (manageotp.this).create (APIInterface.class);
    }

    private void otp () {
        Call< OtpResponse > call = apiInterface.getOtp (getIntent().getExtras().getString("Mobile"),t2.getText ().toString ());
        call.enqueue (new Callback< OtpResponse > () {
            @Override
            public void onResponse (Call< OtpResponse > call, Response< OtpResponse > response) {

                if (response.isSuccessful ()) {
                    //  t1.setVisibility (View.GONE);
                    if (response.body ().getStatusCode () == 200) {
                       // String userid = response.body ().getData ().getId ();
                        //   Boolean isLogin = response.body ().getData ().getIsLoggedIn ();
                        //  prefManager.saveUserDetails (userid);
                        // prefManager.IsLogin (isLogin);
                        Intent i = new Intent (manageotp.this, HomeActivity.class);
                        startActivity (i);
                        finish ();
                    } else if (response.body ().getStatusCode () == 201) {

                        Toast.makeText (getApplicationContext (), response.body ().getMessage (), Toast.LENGTH_SHORT).show ();

                    }

                }

            }




            @Override
            public void onFailure (Call< OtpResponse > call, Throwable t) {

                System.out.println ("Failleeeefaillllllll:" + t.getMessage ());
                t2.setVisibility (View.GONE);
            }
        });

    }
}