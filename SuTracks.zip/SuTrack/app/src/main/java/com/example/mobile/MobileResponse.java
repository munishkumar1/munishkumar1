package com.example.mobile;

import android.provider.ContactsContract;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MobileResponse {
    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private DatumMobile data;
    @SerializedName("Status_code")
    @Expose
    private Integer statusCode;
    @SerializedName("Success")
    @Expose
    private Boolean success;

    public String getMessage () {
        return message;
    }

    public void setMessage (String message) {
        this.message = message;
    }

    public DatumMobile getData () {
        return data;
    }

    public void setData (DatumMobile data) {
        this.data = data;
    }

    public Integer getStatusCode () {
        return statusCode;
    }

    public void setStatusCode (Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Boolean getSuccess () {
        return success;
    }

    public void setSuccess (Boolean success) {
        this.success = success;
    }
}