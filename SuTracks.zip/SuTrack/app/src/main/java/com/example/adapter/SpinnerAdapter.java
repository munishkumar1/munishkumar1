package com.example.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import com.example.activity.HomeFragment;
import com.example.sutrack.R;
import com.example.trucktype.DatumTrucktype;

import java.util.List;

public class SpinnerAdapter extends ArrayAdapter< DatumTrucktype > {
    LayoutInflater layoutInflater;
    public String id;
    View view;
    Context context ;

    public SpinnerAdapter (FragmentActivity context, int row, int title, List< DatumTrucktype> data) {
        super (context,row,title,data);
        layoutInflater = context.getLayoutInflater();

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        return rowview(convertView,position);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return rowview(convertView,position);
    }

    private View rowview(android.view.View convertView , int position){
        DatumTrucktype rowItem = getItem(position);
        SpinnerAdapter.viewHolder holder ;
        View rowview = convertView;
        if (rowview==null) {

            holder = new SpinnerAdapter.viewHolder();
            layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowview = layoutInflater.inflate(R.layout.row, null, false);

            holder.txtTitle =  rowview.findViewById(R.id.title);
            holder.linearLayout =  rowview.findViewById(R.id.spinner_id);
            //  holder.imageView = (ImageView) rowview.findViewById(R.id.icon);
            rowview.setTag(holder);
        }else{
            holder = (SpinnerAdapter.viewHolder) rowview.getTag();
        }
        // holder.imageView.setImageResource(rowItem.getImageId());
        holder.txtTitle.setText(rowItem.getTruckType ());
/*
       holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = String.valueOf (rowItem.getId ());
                System.out.println ("idddddd:"+ id);
               // SharedHelper.putKey(getContext(),"id",id);
                //Utility.setStateid(String.valueOf(rowItem.getId()));
            }
        });*/

        return rowview;
    }

    private class viewHolder{
        LinearLayout linearLayout;
        TextView txtTitle;
        //ImageView imageView;

    }
}
