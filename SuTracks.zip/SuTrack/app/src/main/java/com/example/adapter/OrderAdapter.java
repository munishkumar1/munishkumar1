package com.example.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.activity.HomeActivity;
import com.example.activity.Orderviewfulldata;
import com.example.activity.manageotp;
import com.example.data.APIInterface;
import com.example.orderlist.DatumOrderlist;
import com.example.sutrack.R;
import com.utility.PrefManager;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {
    private List< DatumOrderlist > mData;
    private Context mContext;
    private APIInterface apiInterface;
    String id;
    PrefManager prefManager;



    public OrderAdapter (Context mContext, List< DatumOrderlist > data) {
        this.mContext = mContext;
        this.mData = data;
    }


    @NonNull
    @Override
    public OrderAdapter.ViewHolder onCreateViewHolder ( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.orderlist, parent, false);
        return new OrderAdapter .ViewHolder (view);
    }



    @Override
    public void onBindViewHolder (OrderAdapter.ViewHolder holder, int position) {
        holder.orderid.setText (String.valueOf (mData.get (position).getId ()));
          String oid = holder.orderid.getText ().toString ();
        holder.button1.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                Intent i = new Intent (mContext, Orderviewfulldata.class);
                i.putExtra ("id",oid);
                mContext.startActivity (i);

            }
        });
        holder.date.setText (mData.get (position).getDate ());
        holder.moving_frome.setText (mData.get (position).getMovingFrom ());
        holder.moving_to.setText (mData.get (position).getMovingTo ());
       // holder.status.setText (mData.get (position).getStatus ());
        System.out.println ("status:" + holder.status);
       // prefManager.savestatusetails (prefManager.getstatus ());
       // prefManager.getstatus ();
        if (mData.get (position).getStatus () == 0) {
            holder.status.setText ("Pending");
        } else if (mData.get (position).getStatus () == 1) {
            holder.status.setText ("Process");
        } else if (mData.get (position).getStatus () == 2) {
            holder.status.setText ("Processing");

        } else if (mData.get (position).getStatus () == 3) {
            holder.status.setText ("Complete");
        }else if(mData.get (position).getStatus () == 4) {
            holder.status.setText ("Cancel");

        }else {
            holder.status.setVisibility (View.GONE);

        }

    }
            @Override
            public int getItemCount ( ) {
                return mData.size ();
            }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView orderid, date, moving_frome, moving_to,status;
        Button button1;

        public ViewHolder ( View itemView) {
            super (itemView);
            orderid = itemView.findViewById (R.id.orderidview1);
            date = itemView.findViewById (R.id.dateview1);
            moving_frome = itemView.findViewById (R.id.moving_from1);
            moving_to = itemView.findViewById (R.id.moving_to1);
            status = itemView.findViewById (R.id.oderstatus1);
            button1 = itemView.findViewById (R.id.orderbutton);

        }
    }
}
