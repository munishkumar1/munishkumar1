package com.example.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.data.APIInterface;
import com.example.data.ApiClient;
import com.example.mobile.MobileResponse;
import com.example.sutrack.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.hbb20.CountryCodePicker;
import com.utility.PrefManager;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Mobilevarification extends AppCompatActivity {
    CountryCodePicker ccp;
    EditText t1;
    Button b1;
    private APIInterface apiInterface;
    PrefManager prefManager;
    NetWorkInfoUtility netWorkInfoUtility;
    String tokennew;

    private String TAG = "Mobilevarification.class";

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_mobilevarification);
        //   prefManager = new PrefManager (Mobilevarification.this);
        t1 = (EditText) findViewById (R.id.t1);
        ccp = (CountryCodePicker) findViewById (R.id.ccp);
        ccp.registerCarrierNumberEditText (t1);
        b1 = (Button) findViewById (R.id.b1);
        b1.getSolidColor ();

        prefManager = new PrefManager (Mobilevarification.this);
        checkSession ();
        netWorkInfoUtility = new NetWorkInfoUtility ();
        FirebaseMessaging.getInstance ().getToken ()
                .addOnCompleteListener (new OnCompleteListener< String > () {
                    @Override
                    public void onComplete (@NonNull @NotNull Task< String > task) {
                        if (!task.isSuccessful ()) {
                            Log.w (TAG, "FCM token Failed", task.getException ());
                            return;
                        }
                        tokennew = task.getResult ();
                        // Toast.makeText (MainActivity.this,tokennew,Toast.LENGTH_SHORT).show ();
                        System.out.println ("firebasetokennnnn:" + tokennew);
                    }
                });

        apiInterface = ApiClient.getClient (Mobilevarification.this).create (APIInterface.class);

        b1.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View view) {
           //     if (validate ()) {
                    login ();
                }

           // }
        });
    }

    private void checkSession () {
        boolean login = prefManager.getLogin ();
        if (login) {
            Intent i = new Intent (Mobilevarification.this, HomeActivity.class);
            startActivity (i);
            finish ();
        }

    }


    private void login () {
        Call< MobileResponse > call = apiInterface.getmobile (t1.getText ().toString ());
        call.enqueue (new Callback< MobileResponse > () {
            @Override
            public void onResponse (Call< MobileResponse > call, Response< MobileResponse > response) {
                System.out.println ("responseeeeee:" + response);
                if (response.isSuccessful ()) {
                    //  t1.setVisibility (View.GONE);
                    if (response.body ().getStatusCode () == 200) {
                        String userid = response.body ().getData ().getContact ();
                        Boolean isLogin = response.body ().getData ().getIsLoggedIn ();
                        prefManager.saveUserDetails (userid);
                        prefManager.IsLogin (isLogin);
                        String EMAIL = response.body ().getData ().getEmail ();
                        String DOB = response.body ().getData ().getDob ();
                        String City = response.body ().getData ().getCity ();
                        String Name = response.body ().getData ().getName ();
                        String id = response.body ().getData ().getId ();
                        System.out.println ("countect:" + id);

                        //Boolean isLogin = response.body ().getData ().getIsLoggedIn ();
                        prefManager.saveUserDetails (userid);
                        prefManager.saveEmailDetails (EMAIL);
                        prefManager.saveDOBDetails (DOB);
                        prefManager.saveCityDetails (City);
                        prefManager.saveNameDetails (Name);
                        prefManager.saveId (id);


                        // prefManager.IsLogin (isLogin);
                        Intent i = new Intent (Mobilevarification.this, manageotp.class);
                        i.putExtra ("Mobile", t1.getText ().toString ());
                        startActivity (i);
                        finish ();
                    } else if (response.body ().getStatusCode () == 201) {

                        Toast.makeText (getApplicationContext (), response.body ().getMessage (), Toast.LENGTH_SHORT).show ();

                    }

                }

            }


            @Override
            public void onFailure (Call< MobileResponse > call, Throwable t) {
                System.out.println ("Failleeeefaillllllll:" + t.getMessage ());
                t1.setVisibility (View.GONE);

            }
        });


    }


    public boolean validate () {
        boolean valid = true;

        String name = t1.getText ().toString ();
        // String password = Password.getText ().toString ();
        if (name.isEmpty ()) {
            t1.setError ("enter a valid  Mobile ");
            valid = false;
        } else {
            t1.setError (null);
        }
        // if (password.isEmpty ()) {
        //   Password.setError ("enter a valid Password");
        valid = false;
        //  } else {
        //    Password.setError (null);
        //   }

        return valid;
    }
}