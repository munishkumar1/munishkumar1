package com.example.goodtype;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumGoodtype {

    @SerializedName("good_type")
    @Expose
    private String goodType;
    @SerializedName("leadb_api")
    @Expose
    private Integer leadbApi;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("lead_api")
    @Expose
    private Integer leadApi;

    public String getGoodType() {
        return goodType;
    }

    public void setGoodType(String goodType) {
        this.goodType = goodType;
    }

    public Integer getLeadbApi() {
        return leadbApi;
    }

    public void setLeadbApi(Integer leadbApi) {
        this.leadbApi = leadbApi;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getLeadApi() {
        return leadApi;
    }

    public void setLeadApi(Integer leadApi) {
        this.leadApi = leadApi;
    }
}
