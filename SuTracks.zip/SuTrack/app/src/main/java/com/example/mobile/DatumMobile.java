package com.example.mobile;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumMobile {
    @SerializedName("Email")
    @Expose
    private String email;
    @SerializedName("DOB")
    @Expose
    private String dob;
    @SerializedName("isLoggedIn")
    @Expose
    private Boolean isLoggedIn;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("City")
    @Expose
    private String city;
    @SerializedName("Name")
    @Expose
    private String name;
    @SerializedName("Contact")
    @Expose
    private String contact;

    public String getEmail () {
        return email;
    }

    public void setEmail (String email) {
        this.email = email;
    }

    public String getDob () {
        return dob;
    }

    public void setDob (String dob) {
        this.dob = dob;
    }

    public Boolean getIsLoggedIn () {
        return isLoggedIn;
    }

    public void setIsLoggedIn (Boolean isLoggedIn) {
        this.isLoggedIn = isLoggedIn;
    }

    public String getId () {
        return id;
    }

    public void setId (String id) {
        this.id = id;
    }

    public String getCity () {
        return city;
    }

    public void setCity (String city) {
        this.city = city;
    }

    public String getName () {
        return name;
    }

    public void setName (String name) {
        this.name = name;
    }

    public String getContact () {
        return contact;
    }

    public void setContact (String contact) {
        this.contact = contact;
    }
}