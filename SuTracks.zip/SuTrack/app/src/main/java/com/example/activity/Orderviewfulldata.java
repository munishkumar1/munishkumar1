package com.example.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.data.APIInterface;
import com.example.data.ApiClient;
import com.example.orderviewfulldata.DatumOrderdatafull;
import com.example.orderviewfulldata.OrderdatafullResponse;
import com.example.sutrack.R;
import com.utility.PrefManager;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Orderviewfulldata extends AppCompatActivity {
    private APIInterface apiInterface;
    String orderid;
    List< DatumOrderdatafull > mData;
    PrefManager prefManager;
    TextView name,contact,city,date,Drivername,amount,remaining,advance,Id1,moving_from,moving_to,uniqueleadid,status;
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_orderviewfulldata);
        name = findViewById (R.id.namefull1);

        contact =findViewById (R.id.contentfull1);
        city = findViewById (R.id.cityfull2);
        date =findViewById (R.id.displydateput);
        Drivername = findViewById (R.id.driverfulldata);
        amount = findViewById (R.id.amountfull1);
        remaining = findViewById (R.id.remainingfull1);
        advance = findViewById (R.id.advancefull1);
        Id1 = findViewById (R.id.idfull2);
        moving_from = findViewById (R.id.moving_fromfull1);
        moving_to = findViewById (R.id.moving_tofull1);
        uniqueleadid = findViewById (R.id.uniqueLeadId1);
        status = findViewById (R.id.statusfull1);



        apiInterface = ApiClient.getClient (Orderviewfulldata.this).create (APIInterface.class);
        Orderviewfull ();

        prefManager = new PrefManager (Orderviewfulldata.this);

    }

    private void Orderviewfull () {
        Intent intent = getIntent();
         orderid = intent.getStringExtra("id");
         System.out.println ("orderrrrrrrrrr:"+ orderid);

        Call< OrderdatafullResponse > call = apiInterface.getviewfulldata (orderid);
        call.enqueue (new Callback< OrderdatafullResponse > () {
            @Override
            public void onResponse (Call< OrderdatafullResponse > call, Response< OrderdatafullResponse > response) {
                System.out.println ("resssssss:"+ response);
                if (response.isSuccessful ()) {
                    if (response.body ().getStatusCode () == 200) {
                        Toast.makeText (Orderviewfulldata.this, response.body ().getMessage (), Toast.LENGTH_SHORT).show ();
                        mData = response.body ().getData ();
                        for(DatumOrderdatafull p : mData){
                            name.setText(p.getName ()) ;
                            contact.setText(p.getContact ()) ;
                            contact.setText(p.getContact ()) ;
                            city.setText(p.getCity ()) ;
                            Drivername.setText(p.getDriverId ()) ;
                            amount.setText(p.getAmount ()) ;
                            remaining.setText(p.getRemaining ()) ;
                            advance.setText(p.getAdvance ()) ;
                       //     Id1.setText(p.getId ()) ;
                            date.setText(p.getDate ()) ;
                            moving_from.setText(p.getMovingFrom ()) ;
                           moving_to.setText(p.getMovingTo ()) ;
                            uniqueleadid.setText(p.getUniqueLeadId ()) ;
                           // status.setText(p.getStatus ()) ;
                            if (p.getStatus () == 0) {
                                status.setText ("Pending");
                            } else if (p.getStatus () == 1) {
                                status.setText ("Process");
                            } else if (p.getStatus () == 2) {
                                status.setText ("Processing");

                            } else if (p.getStatus () == 3) {
                                status.setText ("Complete");
                            }else if(p.getStatus () == 4) {
                                status.setText ("Cancel");

                            }else {
                                status.setVisibility (View.GONE);

                            }

                        }
                        }


                    }


                }









            @Override
            public void onFailure (Call< OrderdatafullResponse > call, Throwable t) {

            }
        });

    }
}