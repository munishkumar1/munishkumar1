package com.example.trucktype;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumTrucktype {

    @SerializedName("truck_type")
    @Expose
    private String truckType;
    @SerializedName("leadb_api")
    @Expose
    private Integer leadbApi;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("noOfPackage")
    @Expose
    private Integer noOfPackage;
    @SerializedName("lead_api")
    @Expose
    private Integer leadApi;
    @SerializedName("status")
    @Expose
    private Integer status;

    public String getTruckType() {
        return truckType;
    }

    public void setTruckType(String truckType) {
        this.truckType = truckType;
    }

    public Integer getLeadbApi() {
        return leadbApi;
    }

    public void setLeadbApi(Integer leadbApi) {
        this.leadbApi = leadbApi;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNoOfPackage() {
        return noOfPackage;
    }

    public void setNoOfPackage(Integer noOfPackage) {
        this.noOfPackage = noOfPackage;
    }

    public Integer getLeadApi() {
        return leadApi;
    }

    public void setLeadApi(Integer leadApi) {
        this.leadApi = leadApi;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
