package com.example.booknow;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumBooknow {

    @SerializedName("Moving_from")
    @Expose
    private String movingFrom;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("City")
    @Expose
    private String city;
    @SerializedName("Moving_to")
    @Expose
    private String movingTo;
    @SerializedName("Date")
    @Expose
    private String date;
    @SerializedName("Name")
    @Expose
    private String name;
    @SerializedName("Contact")
    @Expose
    private String contact;

    public String getMovingFrom() {
        return movingFrom;
    }

    public void setMovingFrom(String movingFrom) {
        this.movingFrom = movingFrom;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getMovingTo() {
        return movingTo;
    }

    public void setMovingTo(String movingTo) {
        this.movingTo = movingTo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

}
