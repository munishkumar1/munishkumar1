package com.example.utilservice;

public class MyInstnaceIDLIstner extends MyFirebaseMessagingService {

}
