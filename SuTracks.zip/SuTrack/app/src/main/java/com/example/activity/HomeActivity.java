package com.example.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.DatePicker;
import android.widget.EditText;

import com.example.sutrack.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.utility.PrefManager;

public class HomeActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {
    EditText editText;
    PrefManager prefManager;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_home);

        prefManager = new PrefManager (HomeActivity.this);
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        editText =findViewById (R.id.calander_home);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                                                   new HomeFragment ()).commit();
        }
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;

                    switch (item.getItemId()) {
                        case R.id.BookNow:
                           selectedFragment = new HomeFragment();
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                                                                   selectedFragment).commit();
                            break;
                        case R.id.account:
                           selectedFragment = new HomeFragment_Account ();
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                                                                   selectedFragment).commit();
                            break;
                        case R.id.Orders:
                           selectedFragment = new HomeFragment_Orders ();
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                                                                   selectedFragment).commit();
                            break;

                        case R.id.logout:

                            prefManager.Logout ();
                              Intent intent = new Intent (HomeActivity.this, Mobilevarification.class);
                            startActivity (intent);
                            finish ();
                            break;
                    }



                    return true;
                }
            };


    @Override
    public void onDateSet (DatePicker view, int year, int month, int dayOfMonth) {


    }


    public static class MainActivity extends AppCompatActivity {



        @Override
        protected void onCreate (Bundle savedInstanceState) {
            super.onCreate (savedInstanceState);
            setContentView (R.layout.activity_main);

            Thread timer = new Thread (){
                @Override
                public void run() {

                    try {
                        sleep (800);
                        Intent intent = new Intent (getApplicationContext (),Mobilevarification .class);
                        startActivity (intent);
                        finish ();
                        super.run ();
                    }catch (InterruptedException e){
                        e.printStackTrace ();
                    }
                }

            };
            timer.start ();
        }

    }

}

