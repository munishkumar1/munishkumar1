package com.example.activity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.adapter.OrderAdapter;
import com.example.data.APIInterface;
import com.example.data.ApiClient;
import com.example.manageotp.OtpResponse;
import com.example.outodatafill.DatumOutodatafill;
import com.example.outodatafill.OutodatafillResponse;
import com.example.sutrack.R;
import com.example.useredit.EditResponse;
import com.utility.PrefManager;

import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment_Account extends Fragment {
    PrefManager prefManager;
    AppCompatEditText name,  city, email;
    TextView dob;
    Button button;
    private APIInterface apiInterface1;

    SwipeRefreshLayout swipeRefreshLayout;

    LinearLayoutManager linearLayoutManager;
    String id;
    List< DatumOutodatafill > mData;
    private String TAG = "HomeFragment_Account.class";
    private int mYear, mMonth, mDay;

    @Nullable
    @Override
    public View onCreateView (LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate (R.layout.homefragment_orders, container, false);
        prefManager = new PrefManager (getActivity ());
        id = prefManager.getUserId ();
        name = view.findViewById (R.id.name);
        name.setText (prefManager.getname ());

        dob = view.findViewById (R.id.birth);
        dob.setText (prefManager.getDOB ());

         dob.setOnClickListener (new View.OnClickListener () {
             @Override
             public void onClick (View v) {
                 final Calendar c = Calendar.getInstance();
                 mYear = c.get(Calendar.YEAR);
                 mMonth = c.get(Calendar.MONTH);
                 mDay = c.get(Calendar.DAY_OF_MONTH);


                 DatePickerDialog datePickerDialog = new DatePickerDialog (getActivity (),
                                                                           new DatePickerDialog.OnDateSetListener() {


                                                                              @Override
                                                                              public void onDateSet(DatePicker view, int year,
                                                                                                    int monthOfYear, int dayOfMonth) {

                                                                                  dob.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                                                                              }
                                                                          }, mYear, mMonth, mDay);
                 datePickerDialog.show();
             }
         });
        city = view.findViewById (R.id.city);
        city.setText (prefManager.getCity ());

        email = view.findViewById (R.id.email);
        email.setText (prefManager.getEmail ());
        apiInterface1 = ApiClient.getClient (getActivity ()).create (APIInterface.class);

        System.out.println ("idddddddd:" + prefManager.getid ());
        Outofilldata ();
        initView (view);
        return view;


    }

    private void initView (View view) {
        button = view.findViewById (R.id.id_save_account);
        button.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                edituser ();

            }
        });


    }

    private void edituser () {

        Call< EditResponse > call = apiInterface1.getEdit (name.getText ().toString (),
                                                           email.getText ().toString (), prefManager.getUserId (),
                                                           city.getText ().toString (), "1", dob.getText ().toString (), prefManager.getid ());

        call.enqueue (new Callback< EditResponse > () {
            @Override
            public void onResponse (Call< EditResponse > call, Response< EditResponse > response) {

                Toast.makeText (getActivity (),"Successfully",Toast.LENGTH_SHORT).show ();

                //Boolean saveDOBDetails = response.body ().getData ().getDob ();
                prefManager.saveDOBDetails (prefManager.getDOB ());
              //  prefManager.IsLogin (saveDOBDetails);
            /*    if(response.body ().getStatusCode () ==200){

                }*/


            }

            @Override
            public void onFailure (Call< EditResponse > call, Throwable t) {
                System.out.println ("Failleeeefaillllllll:" + t.getMessage ());
                Toast.makeText (getActivity (), t.getMessage (), Toast.LENGTH_LONG).show ();

            }
        });

    }

    private void Outofilldata () {
        Call< OutodatafillResponse > call = apiInterface1.getOutodatafill (id);
        call.enqueue (new Callback< OutodatafillResponse > () {
            @Override
            public void onResponse (Call< OutodatafillResponse > call, Response< OutodatafillResponse > response) {


                if (response.isSuccessful ()) {
                    if (response.body ().getStatusCode () == 200) {
                        Toast.makeText (getActivity (), response.body ().getMessage (), Toast.LENGTH_SHORT).show ();
                        System.out.println ("nameeeeeeee: " + response.body ().getData ().getName ());
                        name.setText (response.body ().getData ().getName ());
                        city.setText (response.body ().getData ().getCity ());
                        email.setText (response.body ().getData ().getEmail ());
                        dob.setText (response.body ().getData ().getDob ());


                    }


                }
            }





            @Override
            public void onFailure (Call< OutodatafillResponse > call, Throwable t) {

                System.out.println ("apieeeefaillllllll:" + t.getMessage ());
                Toast.makeText (getActivity (), t.getMessage (), Toast.LENGTH_LONG).show ();

            }
        });


}}




