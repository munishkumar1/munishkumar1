package com.example.account;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class AccountResponse {

        @SerializedName("Data")
        @Expose
        private List<DatumAccount> data = null;

        public List<DatumAccount> getData() {
            return data;
        }

        public void setData(List<DatumAccount> data) {
            this.data = data;
        }
}
