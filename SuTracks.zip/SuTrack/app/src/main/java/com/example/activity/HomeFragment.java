package com.example.activity;

import android.app.DatePickerDialog;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.fragment.app.Fragment;

import com.example.adapter.SpinnerAdapter;
import com.example.booknow.BooknowResponse;
import com.example.data.APIInterface;
import com.example.data.ApiClient;
import com.example.sutrack.R;
import com.example.trucktype.DatumTrucktype;
import com.example.trucktype.TrucktypeResponse;
import com.example.useredit.EditResponse;
import com.google.gson.JsonObject;
import com.utility.PrefManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment implements AdapterView.OnItemSelectedListener {

    //PrefManager prefManager;
    AppCompatEditText name;
    AppCompatEditText city;
    AppCompatEditText contact;
    AppCompatEditText moving_from;
    AppCompatEditText moving_to;
    AppCompatEditText date;
    AppCompatEditText weith;
    AppCompatEditText Unites;
    AppCompatEditText nopackage;
    AppCompatEditText trucktype;
    AppCompatEditText good_type;
    Spinner mTruckType;
    Button button_home;
    ArrayList<String> TruckName;
    private APIInterface apiInterface1;
    private APIInterface apiInterface2;
    private String TAG = "HomeFragment_Orders.class";
    private int mYear, mMonth, mDay;
    List< DatumTrucktype > mData;
    int id;
    List<String> lmt = new ArrayList<> ();
    SpinnerAdapter stateAdapter;

    @Nullable
    @Override
    public View onCreateView (LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate (R.layout.homefragment, container, false);
        name = view.findViewById (R.id.name_home);
        city = view.findViewById (R.id.city_home);
        contact = view.findViewById (R.id.mobile_home);
        moving_from = view.findViewById (R.id.frome_home);
        moving_to = view.findViewById (R.id.to_home);
        date = view.findViewById (R.id.calander_home);
        weith = view.findViewById (R.id.wight_home);
        Unites = view.findViewById (R.id.unites_home);
        nopackage = view.findViewById (R.id.package_home);
        //trucktype = view.findViewById (R.id.TruckType_home);
        mTruckType = view.findViewById (R.id.spCountry);










        good_type = view.findViewById (R.id.good_home);
        date.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                final Calendar c = Calendar.getInstance ();
                mYear = c.get (Calendar.YEAR);
                mMonth = c.get (Calendar.MONTH);
                mDay = c.get (Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog (getActivity (),
                                                                          new DatePickerDialog.OnDateSetListener () {


                                                                              @Override
                                                                              public void onDateSet (DatePicker view, int year,
                                                                                                     int monthOfYear, int dayOfMonth) {

                                                                                  date.setText (dayOfMonth + "-" + ( monthOfYear + 1 ) + "-" + year);

                                                                              }
                                                                          }, mYear, mMonth, mDay);
                datePickerDialog.show ();
            }
        });
        apiInterface1 = ApiClient.getClient (getActivity ()).create (APIInterface.class);

        button_home = view.findViewById (R.id.save_home);
        button_home.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                booknowuser ();
            }
        });

     /*   apiInterface1 = ApiClient.getClient (getActivity ()).create (APIInterface.class);*/

           // initView (view);
             Trucktype ();
            return view;

    }

    private void  Trucktype () {
        Call< TrucktypeResponse > call = apiInterface1.getTruckTypedata ();
        call.enqueue (new Callback< TrucktypeResponse > () {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onResponse (Call< TrucktypeResponse > call, Response< TrucktypeResponse > response) {
                System.out.println ("respppppp:" + response);

                if(response.isSuccessful ()){

                        mData = response.body ().getData ();
                    stateAdapter = new SpinnerAdapter (getActivity (),
                                                    R.layout.row, R.id.title, response.body().getData ());
                    mTruckType.setAdapter(stateAdapter);

                    mTruckType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                             id = mData.get (position).getId ();
                            System.out.println ("truckiddddd:"+ id);


                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {

                        }
                    });

                        //mTruckType.setAdapter (new SpinnerAdapter (getActivity (), R.layout.row, (String[]) lmt.toArray ()));

                    }
                }




            @Override
            public void onFailure (Call< TrucktypeResponse > call, Throwable t) {

            }
        });
    }

    private void spnJson (String jsonResponce) {
        try {
            JSONObject jsonObject = new JSONObject (jsonResponce);
            JSONArray jsonArray = jsonObject.getJSONArray ("data");
            for(int i =0;i<jsonArray.length ();i++){
                JSONObject dataobj = jsonArray.getJSONObject (i);
                String type = dataobj.getString ("truck_type");
                System.out.println ("typeeeeeeeee"+ type);
            }
        }catch (Exception e){
            e.printStackTrace ();
        }
    }

    private void booknowuser () {

        Call< BooknowResponse > call = apiInterface1.getbooknow (name.getText ().toString (),city.getText ().toString (),contact.getText ().toString (),moving_from.getText ().toString (),
                                                                 moving_to.getText ().toString (),date.getText ().toString (), weith.getText ().toString (),Unites.getText ().toString (),nopackage.getText ().toString (),id ,good_type.getText ().toString (),"1");
        call.enqueue (new Callback< BooknowResponse > () {
            @Override
            public void onResponse (Call< BooknowResponse > call, Response< BooknowResponse > response) {

                Toast.makeText (getActivity (),"Successfully",Toast.LENGTH_SHORT).show ();
            }

            @Override
            public void onFailure (Call< BooknowResponse > call, Throwable t) {

            }
        });

    }


    @Override
    public void onItemSelected (AdapterView< ? > parent, View view, int position, long id) {

    }


    @Override
    public void onNothingSelected (AdapterView< ? > parent) {

    }
}

