package com.utility;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.activity.HomeFragment_Account;

public class PrefManager {

    Context context;

    public PrefManager (Context context) {
        this.context = context;
    }

    public void saveUserDetails (String userid) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("LoginDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("userid", userid);
        editor.commit ();
    }

    public String getUserId () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("LoginDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("userid", "");
    }

    public void saveEmailDetails (String email) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("EmailDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("Email", email);
        editor.commit ();
    }

    public String getEmail () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("EmailDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("Email", "");
    }

    public void saveDOBDetails (String dob) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("DobDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("DOB", dob);
        editor.commit ();
    }

    public String getDOB () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("DobDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("DOB", "");
    }

    public void saveCityDetails (String city) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("CityDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("City", city);
        editor.commit ();
    }

    public String getCity () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("CityDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("City", "");
    }

    public void saveNameDetails (String name) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("NameDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("Name", name);
        editor.commit ();
    }

    public String getname () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("NameDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("name", "");
    }


    public void saveId (String id) {

        SharedPreferences sharedPreferences = context.getSharedPreferences ("Id", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("Id", id);
        editor.commit ();
    }

    public String getid () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("Id", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("Id", "");


    }

    public void IsLogin (Boolean isLogin) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("RidDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putBoolean ("islogin", isLogin);
        editor.commit ();
    }

    public boolean getLogin () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("RidDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean ("islogin", false);
    }

    public void Logout () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("RidDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.remove ("islogin");
        editor.commit ();
    }

    public void savestatusetails (String status) {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("StatusDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit ();
        editor.putString ("status", getstatus ());
        editor.commit ();
    }

    public String getstatus () {
        SharedPreferences sharedPreferences = context.getSharedPreferences ("StatusDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString ("status", "");
    }


}

