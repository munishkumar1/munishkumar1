package com.example.outstation.cancle;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumCancle {

    @SerializedName("user_email")
    @Expose
    private String userEmail;
    @SerializedName("total_price")
    @Expose
    private String totalPrice;
    @SerializedName("mcdtaxe")
    @Expose
    private String mcdtaxe;
    @SerializedName("couponapplied")
    @Expose
    private String couponapplied;
    @SerializedName("destination")
    @Expose
    private String destination;
    @SerializedName("basicprice")
    @Expose
    private String basicprice;
    @SerializedName("source")
    @Expose
    private String source;
    @SerializedName("driver_price")
    @Expose
    private String driverPrice;
    @SerializedName("user_number")
    @Expose
    private String userNumber;
    @SerializedName("car_type")
    @Expose
    private String carType;
    @SerializedName("driver_name")
    @Expose
    private String driverName;
    @SerializedName("create_by")
    @Expose
    private String createBy;
    @SerializedName("roundtrip")
    @Expose
    private String roundtrip;
    @SerializedName("ride_date")
    @Expose
    private String rideDate;
    @SerializedName("advance_price")
    @Expose
    private String advancePrice;
    @SerializedName("cust_name")
    @Expose
    private String custName;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("create_date")
    @Expose
    private String createDate;
    @SerializedName("assignto")
    @Expose
    private String assignto;
    @SerializedName("status")
    @Expose
    private String status;

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getMcdtaxe() {
        return mcdtaxe;
    }

    public void setMcdtaxe(String mcdtaxe) {
        this.mcdtaxe = mcdtaxe;
    }

    public String getCouponapplied() {
        return couponapplied;
    }

    public void setCouponapplied(String couponapplied) {
        this.couponapplied = couponapplied;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getBasicprice() {
        return basicprice;
    }

    public void setBasicprice(String basicprice) {
        this.basicprice = basicprice;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDriverPrice() {
        return driverPrice;
    }

    public void setDriverPrice(String driverPrice) {
        this.driverPrice = driverPrice;
    }

    public String getUserNumber() {
        return userNumber;
    }

    public void setUserNumber(String userNumber) {
        this.userNumber = userNumber;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getRoundtrip() {
        return roundtrip;
    }

    public void setRoundtrip(String roundtrip) {
        this.roundtrip = roundtrip;
    }

    public String getRideDate() {
        return rideDate;
    }

    public void setRideDate(String rideDate) {
        this.rideDate = rideDate;
    }

    public String getAdvancePrice() {
        return advancePrice;
    }

    public void setAdvancePrice(String advancePrice) {
        this.advancePrice = advancePrice;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getAssignto() {
        return assignto;
    }

    public void setAssignto(String assignto) {
        this.assignto = assignto;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}

