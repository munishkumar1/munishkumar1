package com.example.outstation;

public class model {
    private String contact;
    String name,contactm,email;
    public model (String string1, String s, String cursorString, String string, String name, String contactm, String email) {
        this.name = name;
        this.contactm = contactm;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contactm;
    }

    public void setContact(String contact) {
        this.contactm = contactm;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
