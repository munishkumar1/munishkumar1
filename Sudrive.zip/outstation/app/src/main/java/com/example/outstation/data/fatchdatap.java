package com.example.outstation.data;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.database.dbmanagerp;
import com.example.outstation.modelp;
import com.example.outstation.myadapterp;

import java.util.ArrayList;

public class fatchdatap extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList< modelp > dataholderp;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_fatchdatap);
        setContentView (R.layout.activity_fetechdata);

        recyclerView = (RecyclerView) findViewById (R.id.recviewp);
        recyclerView.setLayoutManager (new LinearLayoutManager (this));
        Cursor cursor = new dbmanagerp (this).readalldata ();
        dataholderp = new ArrayList< modelp > ();

        while (cursor.moveToNext ()) {
            modelp obj = new modelp (cursor.getString (1), cursor.getString (2), cursor.getString (3), cursor.getString (4), cursor.getString (5), cursor.getString (6), cursor.getString (7));
            dataholderp.add (obj);
        }

        myadapterp adapter = new myadapterp (dataholderp);
        recyclerView.setAdapter (adapter);

    }




}

