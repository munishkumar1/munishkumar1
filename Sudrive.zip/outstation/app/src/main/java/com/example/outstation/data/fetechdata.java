package com.example.outstation.data;

import androidx.appcompat.app.AppCompatActivity;

public class fetechdata extends AppCompatActivity {
   /* RecyclerView recyclerView;
    ArrayList< model > dataholder;*/
/*
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_fetechdata);
        setContentView (R.layout.activity_fetechdata);
        {

            recyclerView = (RecyclerView) findViewById (R.id.recview);
            recyclerView.setLayoutManager (new LinearLayoutManager (this));

            Cursor cursor = new dbmanager (this).readalldata ();
            dataholder = new ArrayList< model > ();

            while (cursor.moveToNext ()) {
                model obj = new model (cursor.getString (1), cursor.getString (2), cursor.getString (3), cursor.getString (4), cursor.getString (1), cursor.getString (2), cursor.getString (3));
                getDataholder ().add (obj);
            }

            myadapter adapter;
            adapter = getMyadapter ();
            recyclerView.setAdapter ((RecyclerView.Adapter) adapter);
        }
    }

    private myadapter getMyadapter () {
        myadapter adapter = new myadapter (getDataholder ());
        return adapter;
    }

    private ArrayList< model > getDataholder () {
        return dataholder;
    }
}*/
}