package com.example.outstation.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.activity.UpcomingView;
import com.example.outstation.complete.DatumComplete;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class CompleteAdapter extends RecyclerView.Adapter<CompleteAdapter.ViewHolder> {
    private List<DatumComplete> mData;
    private Context mContext;

    public CompleteAdapter (Context mContext, List< DatumComplete > data) {
        this.mData = data;
        this.mContext = mContext;
    }


    @NonNull
    @NotNull
    @Override
    public CompleteAdapter.ViewHolder onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.completeu, parent, false);
        return new CompleteAdapter .ViewHolder (view);

    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull CompleteAdapter.ViewHolder holder, int position) {
        holder.bookida.setText (mData.get (position).getId ());
        String id = mData.get (position).getId ();
        holder.partnera.setText (mData.get (position).getDriverName ());
        holder.customera.setText (mData.get (position).getCustName ());
        holder.customernumbera.setText (mData.get (position).getUserNumber ());
        holder.view.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent i = new Intent (mContext, UpcomingView.class);
                i.putExtra ("id",id);
                mContext.startActivity (i);
            }
        });






    }


    @Override
    public int getItemCount () {



        return mData.size ();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView bookida ,customernumbera,customera,partnera;
        Button view , starta,completea;


        public ViewHolder (@NonNull @NotNull View itemView) {

            super (itemView);

            bookida =itemView.findViewById (R.id.bookidnamea);
            customernumbera =itemView.findViewById (R.id.costomarnumbera);
            customera =itemView.findViewById (R.id.customera);
            partnera =itemView.findViewById (R.id.partnernamea);
            view =itemView.findViewById (R.id.button1a);
            starta =itemView.findViewById (R.id.button2a);
            completea =itemView.findViewById (R.id.button3a);


        }





    }
}
