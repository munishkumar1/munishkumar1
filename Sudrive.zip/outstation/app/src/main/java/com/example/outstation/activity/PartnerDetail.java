package com.example.outstation.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.outstation.R;
import com.example.outstation.adapter.PartnerAdapter;
import com.example.outstation.adapter.RunningAdapter;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.partner.DatumPatner;
import com.example.outstation.partner.PartnerResponse;
import com.example.outstation.utility.EndlessScrollEventListener;
import com.example.outstation.utility.RecyclerTouchListener;

import java.util.Collections;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PartnerDetail extends AppCompatActivity {
    APIInterface apiInterface;
    private RecyclerView recyclerView;
    private ProgressBar bar;
    TextView adduser;
    List< DatumPatner > mData;
    SwipeRefreshLayout swipeRefreshLayout;
    PartnerAdapter partnerAdapter;
    LinearLayoutManager linearLayoutManager;
    private EndlessScrollEventListener endlessScrollEventListener;
    int page = 0,limit;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_partner_detail);
        apiInterface = ApiClient.getClient (PartnerDetail.this).create (APIInterface.class);
        recyclerView = findViewById (R.id.idPartner);
        swipeRefreshLayout=findViewById (R.id.swipe);
        bar = findViewById (R.id.progressBarPat);
        adduser = findViewById (R.id.adduser);
        partnerData ();
        initToolbar ();
        // calling the action bar
        ActionBar actionBar = getSupportActionBar();

        // showing the back button in action bar
        actionBar.setDisplayHomeAsUpEnabled(true);

    }

    private void initToolbar () {
        // assigning ID of the toolbar to a variable
        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Partner");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);
    }


    private void partnerData () {
        String name = "Superadmin";
        String pwd = "superadmin@123";
        bar.setVisibility (View.VISIBLE);
        Call< PartnerResponse > call = apiInterface.getsinglerowp (name, pwd);
        call.enqueue (new Callback< PartnerResponse > () {
            @Override
            public void onResponse (Call< PartnerResponse > call, Response< PartnerResponse > response) {
                System.out.println ("resppppppp:" + response);
                if (response.isSuccessful ()) {
                    bar.setVisibility (View.GONE);
                    if (response.body ().getStatusCode () == 200) {
                        mData = response.body ().getData ();
                         partnerAdapter = new PartnerAdapter (PartnerDetail.this, response.body ().getData ());
                         linearLayoutManager = new LinearLayoutManager (PartnerDetail.this, LinearLayoutManager.VERTICAL, false);
                        recyclerView.setLayoutManager (linearLayoutManager);
                        recyclerView.setAdapter (partnerAdapter);
                        endlessScrollEventListener = new EndlessScrollEventListener (linearLayoutManager) {
                            @Override
                            public void onLoadMore (int pageNum, RecyclerView recyclerView) {
                                partnerData ();
                            }
                        };
                        //recyclerView.addOnScrollListener (endlessScrollEventListener);
                        recyclerView.addOnItemTouchListener (new RecyclerTouchListener (getApplicationContext (), recyclerView, new RecyclerTouchListener.ClickListener () {
                            @Override
                            public void onClick (View view, int position) {

                                DatumPatner datumPatner = mData.get (position);
                                Intent i = new Intent (PartnerDetail.this, PartnerEdit.class);
                                i.putExtra ("id", datumPatner.getId ());
                                i.putExtra ("name", datumPatner.getName ());
                                i.putExtra ("email", datumPatner.getEmail ());
                                i.putExtra ("mobile", datumPatner.getContactNo ());
                                startActivity (i);


                            }


                            @Override
                            public void onLongClick (View view, int position) {

                            }

                        }));

                    }swipeRefreshLayout.setOnRefreshListener (new SwipeRefreshLayout.OnRefreshListener () {
                        @Override
                        public void onRefresh () {
                            swipeRefreshLayout.setRefreshing (false);
                            shuffleItems ();
                        }
                    });
                }
            }

            @Override
            public void onFailure (Call< PartnerResponse > call, Throwable t) {
                System.out.println ("faildddddddd:" + t.getMessage ());
                bar.setVisibility (View.GONE);
            }
        });
    }

    private void shuffleItems () {
        Collections.shuffle (mData, new Random (System.currentTimeMillis ()));
        partnerAdapter = new PartnerAdapter (PartnerDetail.this, mData);
        recyclerView.setAdapter (partnerAdapter);

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}