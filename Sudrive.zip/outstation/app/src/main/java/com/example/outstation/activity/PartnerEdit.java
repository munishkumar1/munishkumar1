package com.example.outstation.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.outstation.R;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.partner.PatnerEdit;
import com.google.android.material.textfield.TextInputEditText;

import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PartnerEdit extends AppCompatActivity {
    TextInputEditText name, email, mobile, carno, carname;
    Button save;
    String id;
    private APIInterface apiInterface;
    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_partner_edit_two);
        id = getIntent ().getStringExtra ("id");
        apiInterface = ApiClient.getClient (PartnerEdit.this).create (APIInterface.class);
        initView ();
    }

    private void initView () {
        name = findViewById (R.id.nametext);
        name.setText (getIntent ().getStringExtra ("name"));
        email = findViewById (R.id.emailtext);
        email.setText (getIntent ().getStringExtra ("email"));
        mobile = findViewById (R.id.contacttextmobile);
        mobile.setText (getIntent ().getStringExtra ("mobile"));
        carno = findViewById (R.id.vechicleNo);
        carname = findViewById (R.id.Carname);
        save = findViewById (R.id.sbmt_add);
        save.setOnClickListener (new View.OnClickListener () {

            @Override
            public void onClick (View v) {
                if (validate ()) {
                    savePartner ();

            }
        }
        });

    }

    private void savePartner () {



        Call< PatnerEdit > call = apiInterface.partnerEdit (name.getText ().toString (), email.getText ().toString (),
                                                            mobile.getText ().toString (), id);
        call.enqueue (new Callback< PatnerEdit > () {


            @Override
            public void onResponse (Call< PatnerEdit > call, Response< PatnerEdit > response) {

                System.out.println ("editresppppppp:" + response);
                if (response.isSuccessful ()) {
                    //bar.setVisibility (View.GONE);
                    if (response.body ().getStatusCode () == 200) {

                        Intent i = new Intent (PartnerEdit.this, PartnerDetail.class);
                        startActivity (i);
                        finish ();

                    }
                }
            }

            @Override
            public void onFailure (Call< PatnerEdit > call, Throwable t) {
                System.out.println ("faildddddddd:" + t.getMessage ());
                //bar.setVisibility (View.GONE);
            }
        });
    }

    @Override
    public void onBackPressed () {
        super.onBackPressed ();
        }

    public boolean validate () {
        boolean valid = true;
        String username = name.getText ().toString ();
        String usermobile = mobile.getText ().toString ();
        String useremail = email.getText ().toString ();

        if (username.isEmpty ()) {
            name.setError ("enter a valid Name");
            valid = false;
        } else {
            name.setError (null);
        }

        if (usermobile.isEmpty ()) {
            mobile.setError ("enter a valid Mobile");
            valid = false;
        } else {
            mobile.setError (null);
        }
        if(useremail.isEmpty () ){
            email.setError ("enter a valid email");
            valid = false;
        }else {
            email.setError (null);
        }

        return valid;
    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                                       + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                                       + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                                       + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                                       + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                                       + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }
}

