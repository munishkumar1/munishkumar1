package com.example.outstation.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.outstation.R;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.modeldata.MainResponse;
import com.example.outstation.utility.NetWorkInfoUtility;
import com.example.outstation.utility.PrefManager;
import com.example.outstation.utility.Utility;
import com.example.outstation.utilservice.MyFirebaseMessagingService;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.messaging.FirebaseMessaging;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private TextInputEditText Name, Password;
    TelephonyManager telephonyManager;
    private TextView Info;
    private Button Login;
    APIInterface apiInterface;
    private int counter = 5;
    ProgressBar bar;
    private String android_id, device_id;
    private String TAG = "MainActivity.class";
    String device_unique_id, IMEI;
    String tokennew;
    NetWorkInfoUtility netWorkInfoUtility;
    PrefManager prefManager;
    private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 1;
    private static final int REQUEST_PERMISSION = 0;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);
        Name = findViewById (R.id.etName);
        Password = findViewById (R.id.etPassword);
        Info = findViewById (R.id.btnLogin);
        Login = findViewById (R.id.btnLogin);
        bar = findViewById (R.id.progressBar);
        requestRead ();
        prefManager = new PrefManager (MainActivity.this);
        checkSession ();
        netWorkInfoUtility = new NetWorkInfoUtility ();

        FirebaseMessaging.getInstance ().getToken ()
                .addOnCompleteListener (new OnCompleteListener< String > () {
                    @Override
                    public void onComplete (@NonNull @NotNull Task< String > task) {
                        if (!task.isSuccessful ()) {
                            Log.w (TAG, "FCM token Failed", task.getException ());
                            return;
                        }
                        tokennew = task.getResult ();
                        // Toast.makeText (MainActivity.this,tokennew,Toast.LENGTH_SHORT).show ();
                        System.out.println ("firebasetokennnnn:" + tokennew);
                    }
                });


        apiInterface = ApiClient.getClient (MainActivity.this).create (APIInterface.class);
        // Info.setText ("No of attempts remaing: 5");

        Login.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                //  validate (Name.getText ().toString (), Password.getText ().toString ());
                System.out.println ("nameeeeeeeee:" + Name.getText ().toString ());
                if (validate ()) {
                    login ();
                }

            }
        });
    }

    private void checkSession () {
        boolean login = prefManager.getLogin ();
        if (login) {
            Intent i = new Intent (MainActivity.this, SecondActivity.class);
            startActivity (i);
            finish ();
        }

    }


    private void login () {
        if (netWorkInfoUtility.isNetWorkAvailableNow (MainActivity.this)) {

            Call< MainResponse > call = apiInterface.login (Name.getText ().toString (), Password.getText ().toString (), tokennew);
            call.enqueue (new Callback< MainResponse > () {
                @Override
                public void onResponse (Call< MainResponse > call, Response< MainResponse > response) {
                    System.out.println ("responseeeeee:" + response);
                    if (response.isSuccessful ()) {
                        bar.setVisibility (View.GONE);
                        if (response.body ().getStatusCode () == 200) {
                            String userid = response.body ().getData ().getId ();
                            Boolean isLogin = response.body ().getData ().getIsLoggedIn ();
                            prefManager.saveUserDetails (userid);
                            prefManager.IsLogin (isLogin);
                            Intent i = new Intent (MainActivity.this, SecondActivity.class);
                            startActivity (i);
                            finish ();
                        } else if (response.body ().getStatusCode () == 201) {
                            Toast.makeText (getApplicationContext (), response.body ().getMessage (), Toast.LENGTH_SHORT).show ();

                        }
                       /* if (response.body ().getStatusCode () == 200) {
                            Intent i = new Intent (MainActivity.this, SecondActivity.class);
                            startActivity (i);
                            finish ();

                        }*/
                    }

                }

                @Override
                public void onFailure (Call< MainResponse > call, Throwable t) {
                    System.out.println ("responseeeeeefail:" + t.getMessage ());

                    bar.setVisibility (View.GONE);

                }
            });


        } else {
            Toast.makeText (MainActivity.this, "You are offline",
                            Toast.LENGTH_SHORT).show ();
        }
    }


    public void requestRead () {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            int hasWritePermission = checkSelfPermission (Manifest.permission.WRITE_EXTERNAL_STORAGE);
            int hasReadPermission = checkSelfPermission (Manifest.permission.READ_EXTERNAL_STORAGE);

            List< String > permissions = new ArrayList< String > ();
            if (hasWritePermission != PackageManager.PERMISSION_GRANTED) {
                permissions.add (Manifest.permission.WRITE_EXTERNAL_STORAGE);
            } else {
//              preferencesUtility.setString("storage", "true");
            }

            if (hasReadPermission != PackageManager.PERMISSION_GRANTED) {
                permissions.add (Manifest.permission.READ_EXTERNAL_STORAGE);

            } else {
//              preferencesUtility.setString("storage", "true");
            }

            if (!permissions.isEmpty ()) {
//              requestPermissions(permissions.toArray(new String[permissions.size()]), REQUEST_CODE_SOME_FEATURES_PERMISSIONS);

                ActivityCompat.requestPermissions (this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE},
                                                   REQUEST_PERMISSION);
            }
        }
    }

    public boolean validate () {
        boolean valid = true;

        String name = Name.getText ().toString ();
        String password = Password.getText ().toString ();
        if (name.isEmpty ()) {
            Name.setError ("enter a valid UserName");
            valid = false;
        } else {
            Name.setError (null);
        }
        if (password.isEmpty ()) {
            Password.setError ("enter a valid Password");
            valid = false;
        } else {
            Password.setError (null);
        }

        return valid;
    }
   /* public void loadIMEI() {
        // Check if the READ_PHONE_STATE permission is already available.
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                                                                    Manifest.permission.READ_PHONE_STATE)) {
//                get_imei_data();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE},
                                                  MY_PERMISSIONS_REQUEST_READ_PHONE_STATE);
            }
        } else {

            TelephonyManager mngr = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
            IMEI = mngr.getDeviceId();
            device_unique_id = Settings.Secure.getString(this.getContentResolver(),
                                                         Settings.Secure.ANDROID_ID);
           // textView.setText(device_unique_id+"----"+mngr.getDeviceId());
            System.out.println (device_unique_id+"----"+mngr.getDeviceId());
            // READ_PHONE_STATE permission is already been granted.
            Toast.makeText(this,"Alredy granted",Toast.LENGTH_SHORT).show();
        }
    }*/

    @Override
    public void onRequestPermissionsResult (int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_PERMISSION: {
                for (int i = 0; i < permissions.length; i++) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {


                        System.out.println ("Permissions --> " + "Permission Granted: " + permissions[i]);
                    } else if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                        System.out.println ("Permissions --> " + "Permission Denied: " + permissions[i]);
                    }
                }
            }
            break;
            default: {
                super.onRequestPermissionsResult (requestCode, permissions, grantResults);
            }
        }
    }

    private void readFile () {
    }
 /*   public static String getDeviceId(Context context) {

        String deviceId;

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            deviceId = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            System.out.println ("deviceeee:"+ deviceId);
        } else {
            final TelephonyManager mTelephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (mTelephony.getDeviceId() != null) {
                deviceId = mTelephony.getDeviceId();
                System.out.println ("deviceeee:"+ deviceId);
            } else {
                deviceId = Settings.Secure.getString(
                        context.getContentResolver(),
                        Settings.Secure.ANDROID_ID);
                System.out.println ("deviceeee:"+ deviceId);
            }
        }

        return deviceId;
    }*/

    @Override
    public void onBackPressed () {
        Intent intent = new Intent (Intent.ACTION_MAIN);
        intent.addCategory (Intent.CATEGORY_HOME);
        intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity (intent);
    }
}