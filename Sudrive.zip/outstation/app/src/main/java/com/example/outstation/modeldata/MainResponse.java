package com.example.outstation.modeldata;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MainResponse {

    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private ResultResponse data;
    @SerializedName("Status_code")
    @Expose
    private Integer statusCode;
    @SerializedName("Success")
    @Expose
    private Boolean success;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }



    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public ResultResponse getData () {
        return data;
    }

    public void setData (ResultResponse data) {
        this.data = data;
    }
}
