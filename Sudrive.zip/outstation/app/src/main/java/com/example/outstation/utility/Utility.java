package com.example.outstation.utility;

import android.content.Context;
import android.content.SharedPreferences;

public class Utility {
    private static final String RID = "rid";
    private static final String UID = "uid";
    public static final String PREFS_NAME = "suout_app_pref";
    Context mContext;
     static SharedPreferences mPref;

    public Utility (Context mContext) {
        this.mContext = mContext;
        mPref = mContext.getApplicationContext ().getSharedPreferences (PREFS_NAME, mContext.MODE_PRIVATE);
    }



}
