package com.example.outstation.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.activity.PartnerEdit;
import com.example.outstation.partner.DatumPatner;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class PartnerAdapter extends RecyclerView.Adapter<PartnerAdapter.ViewHolder>{
    private List< DatumPatner > mData;
    private Context mContext;
    String id;


    public PartnerAdapter (Context mContext,List<DatumPatner> data) {
        this.mContext = mContext;
        this.mData = data;
    }



    @NonNull
    @NotNull
    @Override
    public PartnerAdapter.ViewHolder onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        // to inflate the layout for each item of recycler view.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.partner, parent, false);
        return new PartnerAdapter.ViewHolder (view);
    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull PartnerAdapter.ViewHolder holder, int position) {
        holder.name.setText (mData.get (position).getName ());
        id = mData.get (position).getId ();
        holder.email.setText (mData.get (position).getEmail ());
        holder.mobile.setText (mData.get (position).getContactNo ());


    }


    @Override
    public int getItemCount () {
        return mData.size ();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name , email , mobile,edit;
        public ViewHolder (@NonNull @NotNull View itemView) {
            super (itemView);
            name = itemView.findViewById (R.id.patname);
            email = itemView.findViewById (R.id.patemail);
            mobile = itemView.findViewById (R.id.patmobile);
            edit = itemView.findViewById (R.id.useredit);
            edit.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Intent i = new Intent (mContext, PartnerEdit.class);
                    i.putExtra ("id",id);
                    mContext.startActivity (i);
                }
            });


        }
    }
}
