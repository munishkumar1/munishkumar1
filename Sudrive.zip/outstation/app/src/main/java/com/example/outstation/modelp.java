package com.example.outstation;

public class modelp {
    String name,contact,email,vechicle,carname,carType,location;

    public modelp (String name, String contact, String email, String vechicle, String carname, String carType, String location) {
        this.name = name;
        this.contact = contact;
        this.email = email;
        this.vechicle = vechicle;
        this.carname = carname;
        this.carType = carType;
        this.location = location;
    }

    public String getName () {
        return name;
    }

    public void setName (String name) {
        this.name = name;
    }

    public String getContactm () {
        return contact;
    }

    public void setContactm (String contact) {
        this.contact = contact;
    }

    public String getEmail () {
        return email;
    }

    public void setEmail (String email) {
        this.email = email;
    }

    public String getVechicle () {
        return vechicle;
    }

    public void setVechicle (String vechicle) {
        this.vechicle = vechicle;
    }

    public String getCarname () {
        return carname;
    }

    public void setCarname (String carname) {
        this.carname = carname;
    }

    public String getCarType () {
        return carType;
    }

    public void setCarType (String carType) {
        this.carType = carType;
    }

    public String getLocation () {
        return location;
    }

    public void setLocation (String location) {
        this.location = location;
    }
}
