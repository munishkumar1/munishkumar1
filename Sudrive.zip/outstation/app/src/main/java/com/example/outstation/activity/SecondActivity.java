package com.example.outstation.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.adapter.DashBoardAdapter;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.modeldata.dashbordmodel.DashboardResponse;
import com.example.outstation.utility.NetWorkInfoUtility;
import com.example.outstation.utility.PrefManager;
import com.example.outstation.utilservice.MyFirebaseMessagingService;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.messaging.FirebaseMessaging;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SecondActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout;
    RecyclerView recyclerView;
    NavigationView navigationView;
    APIInterface apiInterface;
    Toolbar toolbar;
    private ProgressBar bar;
    private String TAG = "SecondActivity.class";
    String token;
    NetWorkInfoUtility netWorkInfoUtility;
    PrefManager prefManager;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.dashboard);
        drawerLayout = findViewById (R.id.drawer_layout);
        navigationView = findViewById (R.id.nav_view);
        toolbar = findViewById (R.id.toolbar);
        bar = findViewById (R.id.progressBar);
        netWorkInfoUtility =new  NetWorkInfoUtility();
        prefManager = new PrefManager (SecondActivity.this);
        token = MyFirebaseMessagingService.getToken (SecondActivity.this);


        setSupportActionBar (toolbar);
        recyclerView = findViewById (R.id.recyclerview);
        apiInterface = ApiClient.getClient (SecondActivity.this).create (APIInterface.class);
        dasborddata ();

       Menu menu = navigationView.getMenu ();
        navigationView.bringToFront ();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle (this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener (toggle);
        toggle.syncState ();
        navigationView.setNavigationItemSelectedListener (this);

        navigationView.setCheckedItem (R.id.nav_home);
    }
      private  void dasborddata() {
          if (netWorkInfoUtility.isNetWorkAvailableNow (SecondActivity.this)) {
              String name = "Superadmin";
              String pwd = "superadmin@123";
              bar.setVisibility (View.VISIBLE);
              Call< DashboardResponse > call = apiInterface.getDashboard (name, pwd);
              call.enqueue (new Callback< DashboardResponse > () {
                  @Override
                  public void onResponse (Call< DashboardResponse > call, Response< DashboardResponse > response) {
                      System.out.println ("respppp:" + response);


                      if (response.isSuccessful ()) {
                          bar.setVisibility (View.GONE);
                          if (response.body ().getStatusCode () == 200) {

                              DashBoardAdapter dashBoardAdapter = new DashBoardAdapter (response.body ().getData (), SecondActivity.this);
                              GridLayoutManager gridLayoutManager = new GridLayoutManager (SecondActivity.this, 2);
                              recyclerView.setLayoutManager (gridLayoutManager);
                              recyclerView.setAdapter (dashBoardAdapter);
                          }
                      }

                  }


                  @Override
                  public void onFailure (Call< DashboardResponse > call, Throwable t) {
                      System.out.println ("resfsillll:" + t.getMessage ());
                      bar.setVisibility (View.GONE);

                  }
              });

          }else {
              Toast.makeText (SecondActivity.this,"You are offline",Toast.LENGTH_SHORT).show ();
          }


      }
    @Override
    public boolean onNavigationItemSelected (@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId ()) {
            case R.id.nav_home:
                break;
            case R.id.nav_bus:
                Intent intent = new Intent (SecondActivity.this, PartnerDetail.class);
                startActivity (intent);
                break;
            case R.id.nav_plane:
               Intent intent1 = new Intent (SecondActivity.this, SingleActivity.class);
                startActivity (intent1);
                break;
           /*case R.id.nav_create:
               intent = new Intent (SecondActivity.this,CreateActivity.class);
                startActivity (intent);
                break;*/
            case R.id.nav_running2:
                intent = new Intent (SecondActivity.this, RunningActivity1.class);
                startActivity (intent);
                break;
            case R.id.nav_complete:
                intent = new Intent (SecondActivity.this, CompleteActivity1.class);
                startActivity (intent);
                break;
            case R.id.nav_upcoming:
                intent = new Intent (SecondActivity.this, UpcomingActivity1.class);
                startActivity (intent);
                break;

            case R.id.nav_cancle:
                intent = new Intent (SecondActivity.this, CancelActivity.class);
                startActivity (intent);
                break;
            case R.id.nav_reject:
                intent = new Intent (SecondActivity.this, RejectActivity1.class);
                startActivity (intent);
                break;

            case R.id.nav_logout:
                prefManager.Logout ();
                intent = new Intent (SecondActivity.this, MainActivity.class);
                startActivity (intent);
                break;




        }
        drawerLayout.closeDrawer (GravityCompat.START);
        return true;
    }
}

