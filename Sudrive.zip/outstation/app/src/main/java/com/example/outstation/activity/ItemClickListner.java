package com.example.outstation.activity;

import android.view.View;

public interface ItemClickListner {
    void onClick (View view, int positon);
}
