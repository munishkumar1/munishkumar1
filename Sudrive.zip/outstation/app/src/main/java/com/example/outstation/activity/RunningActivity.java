package com.example.outstation.activity;

/*public class RunningActivity extends AppCompatActivity {

    TextInputLayout name, contact, email, vehicle, carnage,carType,location;
    FloatingActionButton fb;
    Button sbmt;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_running);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        name = (TextInputLayout) findViewById(R.id.nametext);
        contact = (TextInputLayout) findViewById(R.id.contacttext);
        email = (TextInputLayout) findViewById(R.id.emailtext);
        vehicle =(TextInputLayout) findViewById (R.id.vechicleNo);
        carnage =(TextInputLayout) findViewById (R.id.Carname);
        carType =(TextInputLayout) findViewById (R.id.CarType);
        location =(TextInputLayout) findViewById (R.id.location);


        fb = (FloatingActionButton) findViewById(R.id.fbtn);
        sbmt = (Button) findViewById(R.id.sbmt_add);

        fb = (FloatingActionButton) findViewById(R.id.fbtn);
        sbmt = (Button) findViewById(R.id.sbmt_add);



        sbmt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                processinsert(name.getEditText().getText().toString(), contact.getEditText().getText().toString(), email.getEditText().getText().toString(),
                              vehicle.getEditText().getText().toString(), carnage.getEditText().getText().toString(), carType.getEditText().getText().toString(),
                              location.getEditText().getText().toString());
            }
        });


        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // startActivity(new Intent (getApplicationContext(), fatchdatap.class));
            }
        });


    }



    private void processinsert (String a, String b, String c, String d, String e, String f, String g)
    {
        String res=new dbmanagerp (this).addrecordp (a, b, c, d, e, f, g);
        name.getEditText().setText("");
        contact.getEditText().setText("");
        email.getEditText().setText("");
        vehicle.getEditText().setText("");
        carnage.getEditText().setText("");
        carType.getEditText().setText("");
        location.getEditText().setText("");
        Toast.makeText(getApplicationContext(), res, Toast.LENGTH_SHORT).show();
    }


}

      */
