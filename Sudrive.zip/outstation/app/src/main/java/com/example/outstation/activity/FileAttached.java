package com.example.outstation.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.outstation.R;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.fileupload.Fileuplode;
import com.example.outstation.utility.PrefManager;

import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FileAttached  extends AppCompatActivity {

    private APIInterface apiInterface;
    TextView textView, textView1;
    Button fileatteched;
    EditText mEdittext;
    int SELECT_PICTURE = 200;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    ImageView imageView;
    Uri selectedImageUri;
    Bitmap thumbnail;
    File finalFile, upload;
    String picturePath, rid, userid, part_image;
    PrefManager prefManager;
    ProgressDialog progressDoalog;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_fileatteched);
        apiInterface = ApiClient.getClient (FileAttached.this).create (APIInterface.class);
        //textView = findViewById (R.id.Feedback_LongDes);
        textView1 = findViewById (R.id.Feedback_Attach);
        imageView = findViewById (R.id.imageupload);
        mEdittext = findViewById (R.id.feedback_longdes);
        initToolbar ();

        ActionBar actionBar = getSupportActionBar ();

        actionBar.setDisplayHomeAsUpEnabled (true);
        progressDoalog = new ProgressDialog (FileAttached.this);

        prefManager = new PrefManager (FileAttached.this);
        userid = prefManager.getUserId ();
        System.out.println ("userrrr:" + userid);
        rid = prefManager.getRId ();
        System.out.println ("ridddd:" + rid);
        // String id = getIntent ().getStringExtra ("id");

        textView1.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                //selectImage ();
                if (isPermissionGRanted ()) {
                    selectImage ();
                } else {
                    takePermission ();
                }
            }
        });
        fileatteched = findViewById (R.id.attachbutton);
        fileatteched.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                if(validate ()){
                progressDoalog.setMax (100);
                progressDoalog.setMessage ("Image is  Uploading....");
                progressDoalog.setTitle ("File Uploading");
                progressDoalog.setProgressStyle (ProgressDialog.STYLE_HORIZONTAL);
                progressDoalog.show ();
                new Thread (new Runnable () {
                    @Override
                    public void run () {
                        try {
                            while (progressDoalog.getProgress () <= progressDoalog
                                    .getMax ()) {
                                Thread.sleep (200);
                                handle.sendMessage (handle.obtainMessage ());
                                if (progressDoalog.getProgress () == progressDoalog
                                        .getMax ()) {
                                    progressDoalog.dismiss ();
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace ();
                        }
                    }
                }).start ();


                System.out.println ("filenameeeee:" + finalFile.getName ());
                RequestBody requestFile = RequestBody.create (MediaType.parse ("image/jpeg"), finalFile);
                // MultipartBody.Part is used to send also the actual filename
                MultipartBody.Part body = MultipartBody.Part.createFormData ("file_name", finalFile.getName (), requestFile);
                // RequestBody fbody = RequestBody.create (MediaType.parse ("image/*"),file);
                RequestBody ridrid = RequestBody.create (MediaType.parse ("text/plain"), rid);
                RequestBody remark = RequestBody.create (MediaType.parse ("text/plain"), mEdittext.getText ().toString ());
                RequestBody creatby = RequestBody.create (MediaType.parse ("text/plain"), userid);

                Call< Fileuplode > call = apiInterface.getfileuplod (ridrid, body, remark, creatby);
                call.enqueue (new Callback< Fileuplode > () {
                    @Override
                    public void onResponse (Call< Fileuplode > call, Response< Fileuplode > response) {
                        System.out.println ("fileuploadddddd:" + response);
                        progressDoalog.dismiss ();
                        imageView.setImageDrawable (null);
                        Toast.makeText (getApplicationContext (), response.body ().getMessage (), Toast.LENGTH_LONG).show ();
                        Intent i = new Intent (FileAttached.this, SecondActivity.class);
                        startActivity (i);
                        finish ();

                    }

                    @Override
                    public void onFailure (Call< Fileuplode > call, Throwable t) {
                        System.out.println ("fileuploadfailllll:" + t.getMessage ());
                        progressDoalog.dismiss ();
                        Toast.makeText (getApplicationContext (), t.getMessage (), Toast.LENGTH_LONG).show ();

                    }
                });

            }
        }
                                         });
    }

      /*  initToolbar ();
        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);
*/


    private void selectImage () {
        if (Build.VERSION.SDK_INT < 19) {
            Intent i = new Intent (Intent.ACTION_GET_CONTENT);
            i.setType ("image/*");
            i.setFlags (Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult (i, 102);
        } else {
            Intent i = new Intent (Intent.ACTION_GET_CONTENT);
            i.addCategory (Intent.CATEGORY_OPENABLE);
            i.putExtra (Intent.EXTRA_MIME_TYPES, new String[]{"image/*"});
            i.setType ("image/*");
            i.setFlags (Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult (i, 102);
        }
    }

    public void onActivityResult (int requestCode, int resultCode, Intent data) {
        super.onActivityResult (requestCode, resultCode, data);
        if (resultCode == 100) {
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageLegacy ()) {
                    selectImage ();

                    // compare the resultCode with the
                    // SELECT_PICTURE constant


                }
            }
        } else if (requestCode == 102) {
            if (data != null) {
                Uri uri = data.getData ();
                //  imageView.setImageURI (mediapth);
                // onSelectFromGalleryResult (data);

                String[] imageProjection = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver ().query (uri, imageProjection, null, null, null);
                if (cursor != null) {
                    cursor.moveToFirst ();
                    int indexImage = cursor.getColumnIndex (imageProjection[0]);
                    part_image = cursor.getString (indexImage);
                    // imgPath.setText(part_image);                                                        // Get the image file absolute path
                    Bitmap bitmap = null;
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap (this.getContentResolver (), uri);
                    } catch (IOException e) {
                        e.printStackTrace ();
                    }
                    imageView.setImageBitmap (bitmap);
                    Uri tempUri = getImageUri (getApplicationContext (), bitmap);
                    String realpath = getPath (FileAttached.this, tempUri);
                    System.out.println ("uriiiiiii:" + realpath);
                    finalFile = new File (realpath);
                    //String relpath = getRealPathFromURI (tempUri);
                    //upload = new File (relpath);
                    ////String name = upload.getName ();
                    //System.out.println ("newimageeeeeeeeeee:" + name);*/
//onSelectFromGalleryResult (data);

                }


            } else {
                return;
            }
        }


    }

    public static String getPath (Context context, Uri uri) {
        String result = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = context.getContentResolver ().query (uri, proj, null, null, null);
        if (cursor != null) {
            if (cursor.moveToFirst ()) {
                int column_index = cursor.getColumnIndexOrThrow (proj[0]);
                result = cursor.getString (column_index);
            }
            cursor.close ();
        }
        if (result == null) {
            result = "Not found";
        }
        return result;
    }

    /*  private void onSelectFromGalleryResult (Intent data) {
          thumbnail = null;
          if (data != null) {
              try {
                  thumbnail = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
                  Uri selectedImage = data.getData();
                  String[] filePathColumn = { MediaStore.Images.Media.DATA };

                  Cursor cursor = getContentResolver().query(selectedImage,
                                                             filePathColumn, null, null, null);
                  cursor.moveToFirst();

                  int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                  picturePath = cursor.getString(columnIndex);
                  cursor.close();
              } catch (IOException e) {
                  e.printStackTrace();
              }
          }

          //imageView.setImageBitmap(thumbnail);
          // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
          Uri tempUri = getImageUri(getApplicationContext(), thumbnail);

          // CALL THIS METHOD TO GET THE ACTUAL PATH
          finalFile = new File(getRealPathFromURI(tempUri));
      }*/
    private String getRealPathFromURI (Uri tempUri) {
        String path = "";
        if (getContentResolver () != null) {
            Cursor cursor = getContentResolver ().query (tempUri, null, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst ();
                int idx = cursor.getColumnIndex (MediaStore.Images.ImageColumns.DATA);
                path = cursor.getString (idx);
                cursor.close ();
            }
        }
        if (path == null) {
            path = "not found";
        }
        return path;
    }

    public static Uri getImageUri (Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream ();
        inImage.compress (Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage (inContext.getContentResolver (), inImage, "IMG_" + Calendar.getInstance ().getTime (), null);
        return Uri.parse (path);
    }

    private boolean isPermissionGRanted () {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.R) {
            return Environment.isExternalStorageEmulated ();
        } else {
            int readExternalStroage = ContextCompat.checkSelfPermission (this, Manifest.permission.READ_EXTERNAL_STORAGE);
            return readExternalStroage == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void takePermission () {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.R) {
            try {
                Intent i = new Intent (Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.addCategory ("android.intent.categroy,DEFAULT");
                i.setData (Uri.parse (String.format ("packges", getApplicationContext ().getPackageName ())));
                startActivityForResult (i, 100);
            } catch (Exception e) {
                Intent i = new Intent ();
                i.setAction (Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                startActivityForResult (i, 100);
            }
        } else {
            ActivityCompat.requestPermissions (this, new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE
            }, 101);
        }
    }

    @Override
    public void onRequestPermissionsResult (int requestCode, @NonNull @NotNull String[] permissions, @NonNull @NotNull int[] grantResults) {
        super.onRequestPermissionsResult (requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            if (requestCode == 101) {
                boolean readExternalStroage = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                if (readExternalStroage) {
                    selectImage ();
                } else {
                    takePermission ();
                }

            }
        }
    }

    Handler handle = new Handler () {
        @Override
        public void handleMessage (Message msg) {
            super.handleMessage (msg);
            progressDoalog.incrementProgressBy (1);
        }
    };

    private void initToolbar () {
        // assigning ID of the toolbar to a variable
        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("File Upload");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);

    }
/*
    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        startActivity(new Intent (FileAttached.this, SecondActivity.class));
        finish();

    }*/

    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item) {
        switch (item.getItemId ()) {
            case android.R.id.home:
                this.finish ();
                return true;
        }
        return super.onOptionsItemSelected (item);
    }

    public boolean validate () {
        boolean valid = true;

        String editText = mEdittext.getText ().toString ();
        if (editText.isEmpty ()) {
            mEdittext.setError ("enter a valid valid text here");
            valid = false;
        } else {
            mEdittext.setError (null);
        }
        return valid;
    }
}



