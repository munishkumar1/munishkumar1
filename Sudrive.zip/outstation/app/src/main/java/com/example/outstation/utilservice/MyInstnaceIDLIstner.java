package com.example.outstation.utilservice;

import com.google.firebase.iid.FirebaseInstanceIdReceiver;

public class MyInstnaceIDLIstner extends MyFirebaseMessagingService {

}
