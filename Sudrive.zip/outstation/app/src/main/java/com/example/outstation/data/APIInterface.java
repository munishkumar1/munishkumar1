package com.example.outstation.data;

import com.example.outstation.cancle.CancleResponse;
import com.example.outstation.complete.CompleteResponse;
import com.example.outstation.fileupload.Fileuplode;
import com.example.outstation.modeldata.MainResponse;
import com.example.outstation.modeldata.dashbordmodel.DashboardResponse;
import com.example.outstation.partner.PartnerResponse;
import com.example.outstation.partner.PatnerEdit;
import com.example.outstation.rejected.Reject;
import com.example.outstation.rejectedm.RejectedResponse;
import com.example.outstation.running.CompleteRide;
import com.example.outstation.running.RunningCancle;
import com.example.outstation.running.RunningResponse;
import com.example.outstation.running.StartRide;
import com.example.outstation.upcomming.UpcommingResponse;
import com.example.outstation.upcomming.ViewResponse;
import com.example.outstation.user.InsertResponse;
import com.example.outstation.user.UserResponse;
import com.example.outstation.user.UserSave;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface APIInterface {
    @FormUrlEncoded    // annotation that used with POST type request
    @POST("ApiLogin") // specify the sub url for our base url
     Call< MainResponse > login(
            @Field("Email") String user_email,
            @Field("Password") String user_pass,
            @Field ("device_id") String deviceid);

    @FormUrlEncoded    // annotation that used with POST type request
    @POST("ApiDashbord") // specify the sub url for our base url
    Call< DashboardResponse > getDashboard(
            @Field("Email") String user_email,
            @Field("Password") String user_pass);

    @FormUrlEncoded
    @POST("UserDetailsApi")
    Call< UserResponse > getsinglerow (
            @Field("Email") String user_email,
            @Field("Password") String user_pass);



             @FormUrlEncoded
            @POST("PartnerDetailsApi")
                    Call< PartnerResponse > getsinglerowp (
                    @Field("Email") String user_email,
            @Field("Password") String user_pass);


    @FormUrlEncoded
    @POST("RunningApi")
    Call< RunningResponse > getrunning (
             @Field("Email") String user_email,
            @Field("Password") String user_pass);



    @FormUrlEncoded
    @POST("CompleteApi")
    Call< CompleteResponse > getcomplete (
            @Field("Email") String user_email,
            @Field("Password") String user_pass);


    @FormUrlEncoded
    @POST("UpComingApi")
    Call< UpcommingResponse > getupcoming (
            @Field("Email") String user_email,
            @Field("Password") String user_pass);
    @FormUrlEncoded
    @POST("RejectRideApi")
   Call< Reject > getReject(@Field ("id") String id);



    @POST("RejectApi")
    Call< RejectedResponse > getrejected ();


    @FormUrlEncoded
    @POST("UserEditApi")
    Call< UserSave > getsave (
            @Field("cust_name") String cust_name,
            @Field("cust_email") String cust_email,
           @Field("cust_mobile") String cust_mobile,
           @Field("id") String id);

    @FormUrlEncoded
    @POST("ViewRideApi")
    Call< ViewResponse > getView(@Field ("id") String id);


    @POST("CancelApi")
    Call< CancleResponse > getrecancle ();

    @FormUrlEncoded
    @POST("CompleteRideApi")
    Call< CompleteRide > completed (@Field ("id") String id);


    @FormUrlEncoded
    @POST("StartRideApi")
    Call< StartRide > StartRide (@Field ("id") String id);


    @FormUrlEncoded
    @POST("UserInsertApi")
    Call<InsertResponse> getinsert (
            @Field("cust_name") String cust_name,
            @Field("cust_email") String cust_email,
            @Field("cust_mobile") String cust_mobile);


    @FormUrlEncoded
    @POST("UpdateCancelRide")
    Call<RunningCancle> getRunningcancal (
            @Field("id") String id);





    @FormUrlEncoded
    @POST("PartnerEditApi")
    Call< PatnerEdit > partnerEdit (
            @Field("name") String cust_name,
            @Field("email") String cust_email,
            @Field("contact_no") String cust_mobile,
            @Field ("id") String id);



    @Multipart
    @POST("FileAttach")
                    Call< Fileuplode > getfileuplod (
            @Part("ride_id")RequestBody rideid,
            @Part MultipartBody.Part file_name,
            @Part("remark") RequestBody remark,
            @Part("create_by") RequestBody createdby);





}
