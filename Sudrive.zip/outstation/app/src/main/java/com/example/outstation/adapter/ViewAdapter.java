package com.example.outstation.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.activity.CompleteActivity1;
import com.example.outstation.activity.FileAttached;
import com.example.outstation.activity.SecondActivity;
import com.example.outstation.upcomming.DatumView;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class ViewAdapter extends RecyclerView.Adapter<ViewAdapter.ViewHolder>{
    List< DatumView > mData;
    private Context mContext;
    String id;

    public ViewAdapter (Context mContext, List<DatumView> data,String id) {
        this.mContext = mContext;
        this.mData = data;
        this.id = id;
    }

    @NonNull
    @NotNull
    @Override
    public ViewAdapter.ViewHolder onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.upcomingviewfull, parent, false);
        return new ViewAdapter .ViewHolder (view);
    }

    @Override
    public void onBindViewHolder (@NonNull @NotNull ViewAdapter.ViewHolder holder, int position) {



            holder.customer.setText (mData.get (position).getCustName ());
            holder.customernumber.setText (mData.get (position).getUserNumber ());

            if(mData.get (position).getDriverName ().equals ("NA")){
                 holder.prtnername.setText ("NA");
            }else{
                holder.prtnername.setText (mData.get (position).getDriverName ());
            }
               holder.RideDate.setText (mData.get (position).getRideDate ());
               holder.CreateDate.setText (mData.get (position).getCreateDate ());
        holder.CreateBY.setText (mData.get (position).getCreateBy ());
        holder.Assignto.setText (mData.get (position).getAssignto ());
        holder.Source.setText (mData.get (position).getSource ());
        holder.Destination.setText (mData.get (position).getDestination ());
        holder.Coupon.setText (mData.get (position).getCouponapplied ());
        holder.RoundTrip.setText (mData.get (position).getRoundtrip ());
        holder.CarType.setText (mData.get (position).getCarType ());
        holder.TotalPrice.setText (mData.get (position).getTotalPrice ());
        holder.AdvancePrice.setText (mData.get (position).getAdvancePrice ());
        holder.BasePrice.setText (mData.get (position).getBasicprice ());
        holder.PartnerPrice.setText (mData.get (position).getDriverPrice ());



    }

    @Override
    public int getItemCount () {
        return mData.size ();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView  customernumber, customer, prtnername,RideDate,CreateDate,CreateBY,Assignto,Source,Destination,
                Coupon,RoundTrip,CarType,TotalPrice,BasePrice,PartnerPrice,AdvancePrice,MCDtax,attechedfile;
        public ViewHolder (@NonNull @NotNull View itemView) {
            super (itemView);
            customer = itemView.findViewById (R.id.customerview);
            customernumber = itemView.findViewById (R.id.costomarnumberu);
            prtnername = itemView.findViewById (R.id.partnernameup);
            RideDate = itemView.findViewById (R.id.displydateput);
            CreateDate = itemView.findViewById (R.id.createdateput);
            CreateBY = itemView.findViewById (R.id.createbyput);
            Assignto = itemView.findViewById (R.id.assigntoput);
            Destination = itemView.findViewById (R.id.destinationput);
            Source = itemView.findViewById (R.id.sourceput);
            Coupon = itemView.findViewById (R.id.couponput);
            RoundTrip = itemView.findViewById (R.id.roundtripput);
            CarType = itemView.findViewById (R.id.cartypeput);
            TotalPrice = itemView.findViewById (R.id.totalpriceput);
            BasePrice = itemView.findViewById (R.id.basepriceput);
            PartnerPrice = itemView.findViewById (R.id.partnerpriceput);
            AdvancePrice = itemView.findViewById (R.id.advancepriceput);
            attechedfile=itemView.findViewById (R.id.upcommingfile);
            attechedfile.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Intent intent = new Intent (mContext, FileAttached.class);
                       intent.putExtra ("id",id);
                    mContext.startActivity (intent);


                }
            });



        }
    }
}
