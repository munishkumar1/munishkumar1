package com.example.outstation.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.activity.CompleteActivity1;
import com.example.outstation.activity.RunningActivity1;
import com.example.outstation.activity.UpcomingActivity1;
import com.example.outstation.modeldata.dashbordmodel.Datum;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class DashBoardAdapter extends RecyclerView.Adapter<DashBoardAdapter.ReViewHodler> {
    private List<Datum> mData;
    private Context mContext;

    public DashBoardAdapter (List< Datum> data, Context mContext) {
        this.mData = data;
        this.mContext =  mContext;


    }


    @NonNull
    @NotNull
    @Override
    public ReViewHodler onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.dashboard_data,parent,false);
        return new ReViewHodler (view);
    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull DashBoardAdapter.ReViewHodler holder, int position) {
        holder.name.setText (mData.get (position).getName ());
        holder.value.setText (Integer.toString(mData.get (position).getValue ()));
        holder.cardView.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                if (mData.get (position).getName ().equals ("Running")) {
                    Intent i = new Intent (mContext, RunningActivity1.class);
                    mContext.startActivity (i);
                }
                if (mData.get (position).getName ().equals ("UpComing")) {
                    Intent i = new Intent (mContext, UpcomingActivity1.class);
                    mContext.startActivity (i);
                }
                if (mData.get (position).getName ().equals ("Complete")) {
                    Intent i = new Intent (mContext, CompleteActivity1.class);
                    mContext.startActivity (i);
                }
                if (mData.get (position).getName ().equals ("Todat Earning")) {
                    Intent i = new Intent (mContext, CompleteActivity1.class);
                    mContext.startActivity (i);
                }
                if (mData.get (position).getName ().equals ("Monthly Earning")) {
                    Intent i = new Intent (mContext, CompleteActivity1.class);
                    mContext.startActivity (i);
                }
                if (mData.get (position).getName ().equals ("Yearly Sum")) {
                    Intent i = new Intent (mContext, CompleteActivity1.class);
                    mContext.startActivity (i);
                }
            }


        });


    }


    @Override
    public int getItemCount () {
        return mData.size ();
    }


    public class ReViewHodler extends RecyclerView.ViewHolder {
        TextView name ,value;
       CardView cardView;

        public ReViewHodler (@NonNull @NotNull View itemView) {
            super (itemView);
            name = itemView.findViewById (R.id.runname);
            value = itemView.findViewById (R.id.runvalue);
            cardView = itemView.findViewById (R.id.card_data);

        }
    }
}
