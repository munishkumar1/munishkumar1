package com.example.outstation.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.outstation.R;
import com.example.outstation.adapter.UserAdapter;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.user.Datum;
import com.example.outstation.user.UserResponse;
import com.example.outstation.utility.EndlessScrollEventListener;
import com.example.outstation.utility.RecyclerTouchListener;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SingleActivity extends AppCompatActivity  {
    APIInterface apiInterface;
    private RecyclerView recyclerView;
    List<Datum> mData;
   TextView textView;
    SwipeRefreshLayout swipeRefreshLayout;
    UserAdapter courseAdapter;
    LinearLayoutManager linearLayoutManager;
    private EndlessScrollEventListener endlessScrollEventListener;
    int page = 0,limit;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_singlerow);
        recyclerView = findViewById (R.id.idRVCourse);
        textView = findViewById (R.id.adduser);
        swipeRefreshLayout =  findViewById (R.id.swipe);



        textView.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (SingleActivity.this,InsertActivity.class);
                startActivity (intent);
                finish ();
            }
        });


        apiInterface = ApiClient.getClient (SingleActivity.this).create (APIInterface.class);
        userData ();
        initToolbar ();
    }
    private void initToolbar () {
        // assigning ID of the toolbar to a variable
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("User");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    }


    private void userData () {
        String name = "Superadmin";
        String pwd = "superadmin@123";
        Call< UserResponse > call = apiInterface.getsinglerow (name, pwd);
        call.enqueue (new Callback< UserResponse > () {
            @Override
            public void onResponse (Call< UserResponse > call, Response< UserResponse > response) {
                System.out.println ("responseuderrrrrrrrr:" + response);
                if (response.isSuccessful ()) {
                    if (response.body ().getStatusCode () == 200) {
                        mData = response.body ().getData ();
                        courseAdapter = new UserAdapter (SingleActivity.this, mData);
                         linearLayoutManager = new LinearLayoutManager (SingleActivity.this, LinearLayoutManager.VERTICAL, false);
                        recyclerView.setLayoutManager (linearLayoutManager);
                        recyclerView.setAdapter (courseAdapter);
                       /* endlessScrollEventListener = new EndlessScrollEventListener (linearLayoutManager) {
                            @Override
                            public void onLoadMore (int pageNum, RecyclerView recyclerView) {
                                userData ();

                            }
                        };*/
                        //recyclerView.addOnScrollListener (endlessScrollEventListener);
                        recyclerView.addOnItemTouchListener(new RecyclerTouchListener (getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
                            @Override
                            public void onClick(View view, int position) {

                               // Toast.makeText (getApplicationContext (),"reclclik",Toast.LENGTH_LONG).show ();
                                     Datum datum = mData.get (position);
                                Intent i = new Intent (SingleActivity.this, PartnerActivity.class);
                                i.putExtra ("name", datum.getCustName ());
                                i.putExtra ("email", datum.getCustEmail ());
                                i.putExtra ("mobile", datum.getCustMobile ());
                                i.putExtra ("id", datum.getId ());
                                Log.i ("hello", mData.get (position).getCustName ());
                                startActivity (i);



                            }

                            @Override
                            public void onLongClick(View view, int position) {

                            }
                        }));


                    }
                }
                swipeRefreshLayout.setOnRefreshListener (new SwipeRefreshLayout.OnRefreshListener () {
                    @Override
                    public void onRefresh () {
                        swipeRefreshLayout.setRefreshing (false);
                        shuffleItems ();

                    }
                });

            }

            @Override
            public void onFailure (Call< UserResponse > call, Throwable t) {
                System.out.println ("responseuserrrrrrrrrrfail:" + t.getMessage ());

            }
        });

    }

   /* @Override
    public void onClick (View view, int positon) {
        try {
            final Datum datum = mData.get (positon);
            Intent i = new Intent (this, PartnerActivity.class);
            i.putExtra ("name", datum.getCustName ());
            i.putExtra ("email", datum.getCustEmail ());
            i.putExtra ("mobule", datum.getCustMobile ());
            Log.i ("hello", datum.getCustName ());
            startActivity (i);

        } catch (Exception e) {
            e.printStackTrace ();
        }
    }*/
   @Override
   public void onBackPressed()
   {
       super.onBackPressed();
       startActivity(new Intent(SingleActivity.this, SecondActivity.class));
       finish();

   }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void shuffleItems(){
        Collections.shuffle (mData,new Random (System.currentTimeMillis ()));
        courseAdapter = new UserAdapter (SingleActivity.this, mData);
        recyclerView.setAdapter (courseAdapter);

    }
}