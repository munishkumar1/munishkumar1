package com.example.outstation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RunningDetail extends AppCompatActivity {

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
       // setContentView (R.layout.activity_running_detail);



    }
}