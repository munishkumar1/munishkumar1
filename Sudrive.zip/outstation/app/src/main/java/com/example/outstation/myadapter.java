package com.example.outstation;

public interface myadapter {
}
