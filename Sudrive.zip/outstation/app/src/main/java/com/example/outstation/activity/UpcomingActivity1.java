package com.example.outstation.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.outstation.R;
import com.example.outstation.adapter.CompleteAdapter;
import com.example.outstation.adapter.UpcomingAdapter;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.upcomming.DatumUpcomming;
import com.example.outstation.upcomming.UpcommingResponse;
import com.example.outstation.utility.EndlessScrollEventListener;
import com.example.outstation.utility.NetWorkInfoUtility;

import java.util.Collections;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpcomingActivity1 extends AppCompatActivity {
    APIInterface apiInterface;
    RecyclerView recyclerView;
    NetWorkInfoUtility netWorkInfoUtility;
    private LinearLayout linearLayout;
    SwipeRefreshLayout swipeRefreshLayout;
    UpcomingAdapter upcomingAdapter;
    LinearLayoutManager linearLayoutManager;
    List< DatumUpcomming > mData;
    private boolean isLastPage = false;
    private int totalPage = 10;
    private boolean isLoading = false;
    int itemCount = 0;
    private EndlessScrollEventListener endlessScrollEventListener;
    int page = 0,limit;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_upcoming1);
        apiInterface = ApiClient.getClient (UpcomingActivity1.this).create (APIInterface.class);
        recyclerView = findViewById (R.id.idupcom);
        linearLayout = findViewById (R.id.empty);
        linearLayout = findViewById (R.id.empty_run);
        swipeRefreshLayout = findViewById (R.id.swipe);
        netWorkInfoUtility = new NetWorkInfoUtility ();
       // limit = mData.size ();
        //getDataFromAPI (page, limit);

        upCommingData ();

        initToolbar ();
        ActionBar actionBar = getSupportActionBar ();
        actionBar.setDisplayHomeAsUpEnabled (true);
    }





    private void initToolbar () {
        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Upcoming");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);
    }

    private void upCommingData () {


        if (netWorkInfoUtility.isNetWorkAvailableNow (UpcomingActivity1.this)) {

            String name = "Superadmin";
            String pwd = "superadmin@123";
            Call< UpcommingResponse > call = apiInterface.getupcoming (name, pwd);
            call.enqueue (new Callback< UpcommingResponse > () {
                @Override
                public void onResponse (Call< UpcommingResponse > call, Response< UpcommingResponse > response) {
                    System.out.println ("upcomingteeeeeeee:" + response);
                    if (response.isSuccessful ()) {
                        if (response.body ().getStatusCode () == 201) {
                            Toast.makeText (UpcomingActivity1.this, response.body ().getMessage (),
                                            Toast.LENGTH_LONG).show ();
                            linearLayout.setVisibility (View.VISIBLE);


                        } else {
                            mData = response.body ().getData ();
                            //int pageNum = mData.size ();
                            upcomingAdapter = new  UpcomingAdapter (UpcomingActivity1.this, mData);
                            linearLayoutManager = new LinearLayoutManager (UpcomingActivity1.this, LinearLayoutManager.VERTICAL, false);
                            recyclerView.setLayoutManager (linearLayoutManager);
                            recyclerView.setAdapter (upcomingAdapter);

                          /*  endlessScrollEventListener = new EndlessScrollEventListener (linearLayoutManager) {
                                @Override
                                public void onLoadMore (int pageNum, RecyclerView recyclerView) {
                                    upCommingData ();

                                }
                            };*/
                           // recyclerView.addOnScrollListener (endlessScrollEventListener);
                        }
                        swipeRefreshLayout.setOnRefreshListener (new SwipeRefreshLayout.OnRefreshListener () {
                            @Override
                            public void onRefresh () {
                                swipeRefreshLayout.setRefreshing (false);
                                shuffleItems ();

                            }
                        });
                    }
                }

                @Override
                public void onFailure (Call< UpcommingResponse > call, Throwable t) {
                    System.out.println ("completeeeefaillllllll:" + t.getMessage ());

                }
            });


        } else {
            Toast.makeText (UpcomingActivity1.this, "You are offline", Toast.LENGTH_SHORT).show ();
        }
    } private void shuffleItems () {
        Collections.shuffle (mData, new Random (System.currentTimeMillis ()));
        upcomingAdapter = new UpcomingAdapter (UpcomingActivity1.this, mData);
        recyclerView.setAdapter (upcomingAdapter);
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        startActivity(new Intent (UpcomingActivity1.this, SecondActivity.class));
        finish();

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}


