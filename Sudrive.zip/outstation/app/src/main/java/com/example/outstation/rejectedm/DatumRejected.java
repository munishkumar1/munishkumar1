package com.example.outstation.rejectedm;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumRejected {
    @SerializedName("driver_name")
    @Expose
    private String driverName;
    @SerializedName("create_by")
    @Expose
    private String createBy;
    @SerializedName("user_email")
    @Expose
    private String userEmail;
    @SerializedName("couponapplied")
    @Expose
    private String couponapplied;
    @SerializedName("destination")
    @Expose
    private String destination;
    @SerializedName("cust_name")
    @Expose
    private String custName;
    @SerializedName("source")
    @Expose
    private String source;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("user_number")
    @Expose
    private String userNumber;
    @SerializedName("car_type")
    @Expose
    private String carType;
    @SerializedName("status")
    @Expose
    private String status;

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getCouponapplied() {
        return couponapplied;
    }

    public void setCouponapplied(String couponapplied) {
        this.couponapplied = couponapplied;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserNumber() {
        return userNumber;
    }

    public void setUserNumber(String userNumber) {
        this.userNumber = userNumber;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}

