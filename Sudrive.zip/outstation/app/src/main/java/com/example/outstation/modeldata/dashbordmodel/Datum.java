package com.example.outstation.modeldata.dashbordmodel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datum {
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("Id")
    @Expose
    private int id;
    @SerializedName("value")
    @Expose
    private int value;

    public String getName () {
        return name;
    }

    public void setName (String name) {
        this.name = name;
    }

    public int getId () {
        return id;
    }

    public void setId (int id) {
        this.id = id;
    }

    public int getValue () {
        return value;
    }

    public void setValue (int value) {
        this.value = value;
    }
}
