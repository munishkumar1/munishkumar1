package com.example.outstation.upcomming;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ViewResponse {

    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private List< DatumView > data = null;
    @SerializedName("Sucess")
    @Expose
    private Boolean sucess;
    @SerializedName("Status_code")
    @Expose
    private Integer statusCode;

    public String getMessage () {
        return message;
    }

    public void setMessage (String message) {
        this.message = message;
    }

    public List< DatumView > getData () {
        return data;
    }

    public void setData (List< DatumView > data) {
        this.data = data;
    }

    public Boolean getSucess () {
        return sucess;
    }

    public void setSucess (Boolean sucess) {
        this.sucess = sucess;
    }

    public Integer getStatusCode () {
        return statusCode;
    }

    public void setStatusCode (Integer statusCode) {
        this.statusCode = statusCode;

    }
}