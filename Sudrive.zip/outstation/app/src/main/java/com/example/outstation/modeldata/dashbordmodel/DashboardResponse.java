package com.example.outstation.modeldata.dashbordmodel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DashboardResponse {
    @SerializedName("data")
    @Expose
    private List< Datum > data = null;
    @SerializedName("Status_code")
    @Expose
    private int statusCode;

    public List< Datum > getData () {
        return data;
    }

    public void setData (List< Datum > data) {
        this.data = data;
    }

    public int getStatusCode () {
        return statusCode;
    }

    public void setStatusCode (int statusCode) {
        this.statusCode = statusCode;
    }
}
