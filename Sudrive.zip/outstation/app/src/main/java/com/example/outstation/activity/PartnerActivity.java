package com.example.outstation.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.outstation.R;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.user.UserSave;
import com.example.outstation.utility.NetWorkInfoUtility;
import com.google.android.material.textfield.TextInputEditText;

import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PartnerActivity extends AppCompatActivity {
    APIInterface apiInterface;


    String custname, custemail, custmobile, id;
    private DrawerLayout drawerLayout;
    NetWorkInfoUtility netWorkInfoUtility;




    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        //setContentView (R.layout.activity_partner);
        getWindow ().setFlags (WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        openDialog ();

        apiInterface = ApiClient.getClient (PartnerActivity.this).create (APIInterface.class);





        /*fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  startActivity(new Intent(getApplicationContext(), fetechdata.class));
            }
        });*/


    }


    public void openDialog () {
        final Dialog dialog = new Dialog (PartnerActivity.this); // Context, this, etc.
        dialog.setContentView (R.layout.activity_partner);
        Button view = dialog.findViewById (R.id.sbmt_save);
        Button close = dialog.findViewById (R.id.btnClose);
        TextInputEditText name = dialog.findViewById (R.id.edt_name);
        TextInputEditText mobile = dialog.findViewById (R.id.mobile);
        TextInputEditText email = dialog.findViewById (R.id.email);
        custname = getIntent ().getStringExtra ("name");
        custemail = getIntent ().getStringExtra ("email");
        netWorkInfoUtility= new NetWorkInfoUtility ();
        custmobile = getIntent ().getStringExtra ("mobile");
        id = getIntent ().getStringExtra ("id");
        name.setText (custname);
        mobile.setText (custmobile);
        email.setText (custemail);
        close.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent (PartnerActivity.this, SingleActivity.class);
                startActivity (intent);
                finish ();
            }
        });
        view.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                if (netWorkInfoUtility.isNetWorkAvailableNow (PartnerActivity.this)) {


                    Call< UserSave > call = apiInterface.getsave (name.getText ().toString ()
                            , email.getText ().toString (), mobile.getText ().toString (), id);
                    call.enqueue (new Callback< UserSave > () {
                        @Override
                        public void onResponse (Call< UserSave > call, Response< UserSave > response) {
                            System.out.println ("saveinresppppp:" + response);
                            if (response.isSuccessful ()) {
                                if (response.body ().getStatusCode () == 200) {
                                    Toast.makeText (getApplicationContext (), response.body ().getMessage (), Toast.LENGTH_LONG).show ();
                                    Intent intent = new Intent (PartnerActivity.this, SingleActivity.class);
                                    startActivity (intent);
                                    finish ();
                                }
                            }

                        }

                        @Override
                        public void onFailure (Call< UserSave > call, Throwable t) {
                            System.out.println ("saveingfailllllll:" + t.getMessage ());


                        }
                    });


                }else {
                    Toast.makeText (PartnerActivity.this,"You are offline",Toast.LENGTH_SHORT).show ();
                }
            }
        });


        dialog.setTitle (R.string.app_name);
        dialog.show ();

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}