package com.example.outstation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.activity.ItemClickListner;
import com.example.outstation.data.APIInterface;
import com.example.outstation.running.DatumRunning;
import com.example.outstation.user.Datum;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {
    APIInterface apiInterface;
    private List< Datum> mData;
    private Context mContext;
    String mName,mMobile,mEmail;
    private ItemClickListner itemClickListner;




    public UserAdapter (Context mContext, List< Datum > data) {
        this.mContext = mContext;
        this.mData = data;
    }

    @NonNull
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        // to inflate the layout for each item of recycler view.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_data, parent, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull UserAdapter.ViewHolder holder, int position) {
        holder.name.setText (mData.get (position).getCustName ());
        mName = mData.get (position).getCustName ();
        holder.email.setText (mData.get (position).getCustEmail ());
        mEmail = mData.get (position).getCustEmail ();
        holder.mobile.setText (mData.get (position).getCustMobile ());
        mName = mData.get (position).getCustMobile ();



    }


    @Override
    public int getItemCount () {

        return mData.size ();

    }
    public void setClickListener(ItemClickListner itemClickListener) {
        this.itemClickListner = itemClickListener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView name,mobile, email,useredit;


        public ViewHolder (@NonNull @NotNull View itemView) {
            super (itemView);
            name = itemView.findViewById (R.id.username);
            mobile =itemView.findViewById (R.id.usermobile);
            email = itemView.findViewById (R.id.useremail);
            useredit = itemView.findViewById (R.id.useredit);
          /*  itemView.setTag(itemView);
            itemView.setOnClickListener(this);*/

        /*    mName = name.getText ().toString ();
            mMobile = mobile.getText ().toString ();
            mEmail = email.getText ().toString ();*/

         /*   useredit.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Intent i = new Intent (mContext, PartnerActivity.class);
                    i.putExtra ("name",mName);
                    i.putExtra ("mobile",mMobile);
                    i.putExtra ("email",mEmail);
                    mContext.startActivity (i);

                }
            });*/



        }



        @Override
        public void onClick (View v) {
            if (itemClickListner != null) itemClickListner.onClick(v, getPosition ());

        }
    }
}
