package com.example.outstation.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.activity.UpcomingView;
import com.example.outstation.cancle.DatumCancle;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class CancelAdapter extends RecyclerView.Adapter<CancelAdapter.ReViewHodler> {
    private List< DatumCancle > mData;
    private Context mContext;

    public CancelAdapter (Context mContext, List< DatumCancle> data) {
        this.mContext=mContext;
        this.mData=data;
    }

    @NonNull
    @Override
    public CancelAdapter.ReViewHodler onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.cancleview, parent, false);
        return new CancelAdapter .ReViewHodler (view);
    }

    @Override
    public void onBindViewHolder (@NonNull @NotNull CancelAdapter.ReViewHodler holder, int position) {
        holder.customerc.setText (mData.get (position).getCustName ());
        holder.customernumberc.setText (mData.get (position).getUserNumber ());
        holder.bookidc.setText (mData.get (position).getId ());
        String id = mData.get (position).getId ();
        holder.partnerc.setText (mData.get (position).getDriverName ());
        holder.view.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent i = new Intent (mContext, UpcomingView.class);
                i.putExtra ("id",id);
                mContext.startActivity (i);
            }
        });

    }




    @Override
    public int getItemCount () {
        return mData.size ();
    }

    public class ReViewHodler extends RecyclerView.ViewHolder {
        TextView bookidc, customernumberc, customerc, partnerc;
        Button view;
        public ReViewHodler (@NonNull @NotNull View itemView) {
            super (itemView);
            bookidc = itemView.findViewById (R.id.cancallayoutbooking);
            partnerc = itemView.findViewById (R.id.cancelelayoutput);
            customerc = itemView.findViewById (R.id.canclelayoutcostomarput);
            customernumberc = itemView.findViewById (R.id.canclelayoutmobileput);
            view =itemView.findViewById (R.id.canclelayoutbutton1);

        }
    }
}
