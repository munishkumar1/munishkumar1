package com.example.outstation.partner;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DatumPatner {

    @SerializedName("id")
    @Expose
    private String id;

    @SerializedName("car_name")
    @Expose
    private String carName;
    @SerializedName("contact_no")
    @Expose
    private String contactNo;
    @SerializedName("car_no")
    @Expose
    private String carNo;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("email")
    @Expose
    private String email;

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getCarNo() {
        return carNo;
    }

    public void setCarNo(String carNo) {
        this.carNo = carNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getId () {
        return id;
    }

    public void setId (String id) {
        this.id = id;
    }
}

