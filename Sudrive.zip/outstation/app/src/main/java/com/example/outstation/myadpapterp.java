package com.example.outstation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;


public class myadpapterp extends RecyclerView.Adapter<myadpapterp.myviewholderp>
{
    ArrayList<modelp> dataholder;

    public myadpapterp (ArrayList< modelp > dataholder) {
        this.dataholder = dataholder;
    }


    @NonNull
    @NotNull
    @Override
    public myviewholderp onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.singlerowp,parent,false);
        return new myviewholderp (view);
    }


    @Override
    public void onBindViewHolder ( @NotNull myviewholderp holder, int position)
    {
        holder.dname.setText (dataholder.get (position).getName ());
        holder.dcontact.setText(dataholder.get(position).getContactm ());
        holder.demail.setText(dataholder.get(position).getEmail());
        holder.dvechicle.setText(dataholder.get(position).getVechicle());
        holder.dcarname.setText(dataholder.get(position).getCarname());
        holder.dcarType.setText(dataholder.get(position).getCarType());
        holder.dlocation.setText(dataholder.get(position).getLocation ());
    }


    @Override
    public int getItemCount () {
        return dataholder.size ();
    }

    class myviewholderp extends RecyclerView.ViewHolder

    {
        TextView dname,dcontact,demail,dvechicle,dcarname,dcarType,dlocation;
        public myviewholderp (@NonNull @NotNull View itemView) {
            super (itemView);

            dname=(TextView)itemView.findViewById (R.id.name);
            dcontact=(TextView)itemView.findViewById (R.id.number);
            demail=(TextView)itemView.findViewById (R.id.displayemail);
            dvechicle=(TextView)itemView.findViewById (R.id.VechicleNo);
            dcarname=(TextView)itemView.findViewById (R.id.Carname);
            dcarType=(TextView)itemView.findViewById (R.id.CarType);
            dlocation=(TextView)itemView.findViewById (R.id.Location);


        }
    }
}
