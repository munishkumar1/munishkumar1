package com.example.outstation.utility;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    Context context;

    public PrefManager (Context context) {
        this.context = context;
    }
    public void saveUserDetails(String userid) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("LoginDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("userid", userid);
        editor.commit();
    }

    public String getUserId() {
        SharedPreferences sharedPreferences = context.getSharedPreferences("LoginDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString("userid", "");
    }
    public void saveRidDetails(String rid){
        SharedPreferences sharedPreferences = context.getSharedPreferences("RidDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("rid", rid);
        editor.commit();
    }
    public String getRId() {
        SharedPreferences sharedPreferences = context.getSharedPreferences("RidDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getString("rid", "");
    }
    public void IsLogin (Boolean isLogin){
        SharedPreferences sharedPreferences = context.getSharedPreferences("RidDetails", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean ("islogin",isLogin);
        editor.commit();
    }
    public boolean getLogin(){
        SharedPreferences sharedPreferences = context.getSharedPreferences("RidDetails", Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean ("islogin", false);
    }
     public  void  Logout(){
    SharedPreferences sharedPreferences = context.getSharedPreferences("RidDetails", Context.MODE_PRIVATE);
    SharedPreferences.Editor editor = sharedPreferences.edit();
    editor.remove ("islogin");
    editor.commit();
}

}
