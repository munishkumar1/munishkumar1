package com.example.outstation.user;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datum {
        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("cust_email")
        @Expose
        private String custEmail;
        @SerializedName("cust_name")
        @Expose
        private String custName;
        @SerializedName("cust_mobile")
        @Expose
        private String custMobile;
        @SerializedName("create_date")
        @Expose
        private String createDate;

        public String getCustEmail () {
                return custEmail;
        }

        public void setCustEmail (String custEmail) {
                this.custEmail = custEmail;
        }

        public String getCustName () {
                return custName;
        }

        public void setCustName (String custName) {
                this.custName = custName;
        }

        public String getCustMobile () {
                return custMobile;
        }

        public void setCustMobile (String custMobile) {
                this.custMobile = custMobile;
        }

        public String getCreateDate () {
                return createDate;
        }

        public void setCreateDate (String createDate) {
                this.createDate = createDate;
        }

        public String getId () {
                return id;
        }

        public void setId (String id) {
                this.id = id;
        }
}
