package com.example.outstation.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.outstation.R;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.user.InsertResponse;
import com.google.android.material.textfield.TextInputEditText;

import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class  InsertActivity  extends AppCompatActivity implements View.OnClickListener {
    private APIInterface apiInterface;
    private Button AddUser, Close;
    TextInputEditText name, mobile, email;
    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.insert);
        apiInterface = ApiClient.getClient (InsertActivity.this).create (APIInterface.class);
        initView ();
        initToolbar ();
        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);


    }

    private void initToolbar () {

            Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
            // using toolbar as ActionBar
            toolbar.setTitle ("Add user");
            toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
            setSupportActionBar (toolbar);
            getSupportActionBar ().setDisplayShowHomeEnabled (true);
    }

    private void initView () {
        AddUser = findViewById (R.id.sbmt_save);
        Close = findViewById (R.id.btnClose);
        name = findViewById (R.id.edt_name);
        mobile = findViewById (R.id.mobile);
        email = findViewById (R.id.emailuser);


        AddUser.setOnClickListener (this);

        Close.setOnClickListener (this);


    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick (View v) {

        switch (v.getId ()) {
            case R.id.sbmt_save:
                if (validate ()) {

                    Call< InsertResponse > call = apiInterface.getinsert (name.getText ().toString ().trim (), email.getText ().toString ().trim ()
                            , mobile.getText ().toString ().trim ());
                    call.enqueue (new Callback< InsertResponse > () {
                        @Override
                        public void onResponse (Call< InsertResponse > call, Response< InsertResponse > response) {
                            System.out.println ("insereeeeeeee:" + response);
                            Intent i = new Intent (getApplicationContext (), SingleActivity.class);
                            startActivity (i);
                            finish ();

                        }

                        @Override
                        public void onFailure (Call< InsertResponse > call, Throwable t) {
                            System.out.println ("inserteeeefaillllllll:" + t.getMessage ());

                        }
                    });
                }
                break;
            case R.id.btnClose:
                Intent i = new Intent (getApplicationContext (), SingleActivity.class);
                startActivity (i);
                finish ();
                break;
        }
    }

    private void InsertUser () {

    }

  // @Override
    //public void onBackPressed () {
        //super.onBackPressed ();
       // Intent i = new Intent (getApplicationContext (), SingleActivity.class);
       // startActivity (i);
       // finish ();

   // }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public boolean validate () {
        boolean valid = true;

        String username = name.getText ().toString ();
        String usermobile = mobile.getText ().toString ();
        String useremail = email.getText ().toString ();

        if (username.isEmpty ()) {
            name.setError ("enter a valid Name");
            valid = false;
        } else {
            name.setError (null);
        }

        if (usermobile.isEmpty ()) {
            mobile.setError ("enter a valid Mobile");
            valid = false;
        } else {
            mobile.setError (null);
        }
        if(useremail.isEmpty () ){
            email.setError ("enter a valid email");
            valid = false;
        }else {
            email.setError (null);
        }

        return valid;
    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                                       + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                                       + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                                       + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                                       + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                                       + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }
}