package com.example.outstation.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.outstation.R;
import com.example.outstation.adapter.RunningAdapter;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.running.DatumRunning;
import com.example.outstation.running.RunningResponse;
import com.example.outstation.utility.EndlessScrollEventListener;
import com.example.outstation.utility.NetWorkInfoUtility;

import java.util.Collections;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RunningActivity1 extends AppCompatActivity {
    APIInterface apiInterface;
    RecyclerView recyclerView;
    private DrawerLayout drawerLayout;
    private LinearLayout linearLayout;
    private List< DatumRunning > mData;
    NetWorkInfoUtility netWorkInfoUtility;
    LinearLayoutManager linearLayoutManager;
    SwipeRefreshLayout swipeRefreshLayout;
    private ProgressBar loadingPB;
    private NestedScrollView nestedSV;
    RunningAdapter runningAdapter;
    private EndlessScrollEventListener endlessScrollEventListener;
    int page = 0,limit=10;



    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_running1);
        apiInterface = ApiClient.getClient (RunningActivity1.this).create (APIInterface.class);
        recyclerView = findViewById (R.id.idRun);
        linearLayout = findViewById (R.id.empty);
        linearLayout = findViewById (R.id.empty_run);
        swipeRefreshLayout = findViewById (R.id.swipe);
        netWorkInfoUtility = new NetWorkInfoUtility ();
        userDataSet (page, limit);
         loadingPB = findViewById(R.id.idPBLoading);
        nestedSV = findViewById (R.id.idNestedSV);
        nestedSV.setOnScrollChangeListener (new NestedScrollView.OnScrollChangeListener () {
            @Override
            public void onScrollChange (NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (scrollY == v.getChildAt (0).getMeasuredHeight () - v.getMeasuredHeight ()) {
                    // in this method we are incrementing page number,
                    // making progress bar visible and calling get data method.
                    page++;
                    loadingPB.setVisibility (View.VISIBLE);
                    userDataSet (page, limit);

                }
            }
        });



        initToolbar ();
        ActionBar actionBar = getSupportActionBar ();

        // showing the back button in action bar
        actionBar.setDisplayHomeAsUpEnabled (true);


    }

    private void initToolbar () {
        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("Running");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar (toolbar);
        getSupportActionBar ().setDisplayShowHomeEnabled (true);
    }


    private void userDataSet (int page, int limit) {
        if (page > limit) {
            // checking if the page number is greater than limit.
            // displaying toast message in this case when page>limit.
            Toast.makeText (this, "That's all the data..", Toast.LENGTH_SHORT).show ();

            // hiding our progress bar.
            loadingPB.setVisibility (View.GONE);
            return;
        }
        if (netWorkInfoUtility.isNetWorkAvailableNow (RunningActivity1.this)) {
            String name = "Superadmin";
            String pwd = "superadmin@123";
            Call< RunningResponse > call = apiInterface.getrunning (name, pwd);
            call.enqueue (new Callback< RunningResponse > () {
                @Override
                public void onResponse (Call< RunningResponse > call, Response< RunningResponse > response) {
                    System.out.println ("runninresppppp:" + response);
                    if (response.isSuccessful ()) {
                        if (response.body ().getStatusCode () == 201) {
                        //    Toast.makeText (RunningActivity1.this, response.body ().getMessage (),
                                          //  Toast.LENGTH_LONG).show ();
                            linearLayout.setVisibility (View.VISIBLE);
                            //recyclerView.setVisibility (View.GONE);
                            swipeRefreshLayout.setVisibility (View.GONE);

                        } else {

                            mData = response.body ().getData ();
                             runningAdapter = new RunningAdapter (RunningActivity1.this, response.body ().getData ());
                             linearLayoutManager = new LinearLayoutManager (RunningActivity1.this, LinearLayoutManager.VERTICAL, false);
                            recyclerView.setLayoutManager (linearLayoutManager);
                            recyclerView.setAdapter (runningAdapter);
                           // Toast.makeText (RunningActivity1.this, response.body ().getMessage (),
                                         //   Toast.LENGTH_LONG).show ();
                            endlessScrollEventListener = new EndlessScrollEventListener (linearLayoutManager) {
                                @Override
                                public void onLoadMore (int pageNum, RecyclerView recyclerView) {
                                   // userDataSet (page, limit);


                                }
                            };
                           // recyclerView.addOnScrollListener (endlessScrollEventListener);
                        }



                    }swipeRefreshLayout.setOnRefreshListener (new SwipeRefreshLayout.OnRefreshListener () {
                        @Override
                        public void onRefresh () {
                            swipeRefreshLayout.setRefreshing (false);
                            shuffleItems ();
                        }
                    });
                }

                @Override
                public void onFailure (Call< RunningResponse > call, Throwable t) {
                    System.out.println ("runningfailllllll:" + t.getMessage ());
                }
            });

        } else {
            Toast.makeText (RunningActivity1.this, "You are offline", Toast.LENGTH_SHORT).show ();
        }
    }


    @Override
    public void onBackPressed () {
        super.onBackPressed ();
        startActivity (new Intent (RunningActivity1.this, SecondActivity.class));
        finish ();

    }

    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item) {
        switch (item.getItemId ()) {
            case android.R.id.home:
                this.finish ();
                return true;
        }
        return super.onOptionsItemSelected (item);
    }

    public void shuffleItems () {
        Collections.shuffle (mData,new Random (System.currentTimeMillis ()));
        runningAdapter = new RunningAdapter (RunningActivity1.this, mData);
        recyclerView.setAdapter (runningAdapter);

    }
}
