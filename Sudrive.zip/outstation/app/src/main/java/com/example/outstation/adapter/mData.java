package com.example.outstation.adapter;

public class mData {
}
