//////////////////UpcomingAdapter////////////



package com.example.outstation.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.activity.CancelActivity;
import com.example.outstation.activity.UpcomingView;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.rejected.Reject;
import com.example.outstation.running.RunningCancle;
import com.example.outstation.upcomming.DatumUpcomming;
import com.example.outstation.utility.PrefManager;
import com.example.outstation.utility.Utility;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class

UpcomingAdapter extends RecyclerView.Adapter<UpcomingAdapter.ViewHolder> {
    private List< DatumUpcomming > mData;
    private Context mContextl;
    APIInterface apiInterface;
    String id;
    int itemPosition;



    public UpcomingAdapter (Context mContextl, List< DatumUpcomming > data) {
        this.mContextl = mContextl;
        this.mData = data;
    }

    @NonNull
    @NotNull
    @Override
    public UpcomingAdapter.ViewHolder onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        // to inflate the layout for each item of recycler view.
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.upcomingu, parent, false);
        return new UpcomingAdapter.ViewHolder (view);
    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull UpcomingAdapter.ViewHolder holder, int position) {

        holder.customer.setText (mData.get (position).getCustName ());
        holder.customernumber.setText (mData.get (position).getUserNumber ());
        holder.bookid.setText (mData.get (position).getId ());
        id = mData.get (position).getId ();
        holder.prtnername.setText (mData.get (position).getDriverName ());
        itemPosition = holder.getAdapterPosition ();
        holder.view.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {

                Toast.makeText (mContextl,"cliclupcomin",Toast.LENGTH_SHORT).show ();
                Intent intent = new Intent (mContextl, UpcomingView.class);
                intent.putExtra ("id", holder.bookid.getText ().toString ());
                mContextl.startActivity (intent);


            }
        });

           /* holder.reject.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Toast.makeText (mContextl,"reject",Toast.LENGTH_SHORT).show ();

                        apiInterface = ApiClient.getClient ().create (APIInterface.class);
                        Call< Reject > call = apiInterface.getReject (id);
                        call.enqueue (new Callback< Reject > () {
                            @Override
                            public void onResponse (Call< Reject > call, Response< Reject > response) {
                                System.out.println ("rejectresppppp:" + response);
                                if (response.isSuccessful ()) {
                                    if (response.body ().getStatusCode () == 200) {
                                        Toast.makeText (mContextl, response.body ().getMessage (), Toast.LENGTH_LONG).show ();
                                        // reject.setVisibility (View.GONE);
                                        removeItem (itemPosition);

                                    }
                                }
                            }

                            @Override
                            public void onFailure (Call< Reject > call, Throwable t) {
                                System.out.println ("rejectfailllllll:" + t.getMessage ());
                            }
                        });



                    }


            });
        } catch (Exception e) {
            e.printStackTrace ();
        }*/


    }

    @Override
    public int getItemCount () {
        return mData.size ();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView bookid, customernumber, customer, prtnername;
        Button reject, view, cancle;

        public ViewHolder (@NonNull @NotNull View itemView) {
            super (itemView);
            bookid = itemView.findViewById (R.id.bookidnameu);
            customernumber = itemView.findViewById (R.id.costomarnumberu);
            customer = itemView.findViewById (R.id.customeru);
            prtnername = itemView.findViewById (R.id.partnernameup);
            cancle = itemView.findViewById (R.id.button4u);
            cancle.setBackgroundColor (Color.RED);
            reject = itemView.findViewById (R.id.button2u);
            view = itemView.findViewById (R.id.button1u);
            cancle.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Toast.makeText (mContextl, "cancelclick", Toast.LENGTH_LONG).show ();
                    apiInterface = ApiClient.getClient (mContextl).create (APIInterface.class);
                    Call< RunningCancle > call = apiInterface.getRunningcancal (id);
                    call.enqueue (new Callback< RunningCancle > () {
                        @Override
                        public void onResponse (Call< RunningCancle > call, Response< RunningCancle > response) {
                            System.out.println ("cancledddddd:" + response);
                            Toast.makeText (mContextl, response.body ().getMessage (), Toast.LENGTH_SHORT).show ();
                            Intent mIntent = new Intent (mContextl, CancelActivity.class);
                            mContextl.startActivity (mIntent);


                        }

                        @Override
                        public void onFailure (Call< RunningCancle > call, Throwable t) {
                            System.out.println ("canclefailllllllll:" + t.getMessage ());

                        }


                    });

                }
            });

            reject.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    try {
                        apiInterface = ApiClient.getClient (mContextl).create (APIInterface.class);
                        Call< Reject > call = apiInterface.getReject (id);
                        call.enqueue (new Callback< Reject > () {
                            @Override
                            public void onResponse (Call< Reject > call, Response< Reject > response) {
                                System.out.println ("rejectresppppp:" + response);
                                if (response.isSuccessful ()) {
                                    if (response.body ().getStatusCode () == 200) {
                                        Toast.makeText (mContextl, response.body ().getMessage (), Toast.LENGTH_LONG).show ();
                                        // reject.setVisibility (View.GONE);
                                        removeItem (itemPosition);
                                    }
                                }
                            }

                            @Override
                            public void onFailure (Call< Reject > call, Throwable t) {
                                System.out.println ("rejectfailllllll:" + t.getMessage ());
                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace ();
                    }
                }

            });


        }


        private void startActivity () {
        }

        private void removeItem (int itemPosition) {
            mData.remove (itemPosition);
            notifyItemRemoved (itemPosition);
            notifyItemRangeChanged (itemPosition, mData.size ());
        }

        private void rejectApi () {
            try {
                apiInterface = ApiClient.getClient (mContextl).create (APIInterface.class);
                Call< Reject > call = apiInterface.getReject (id);
                call.enqueue (new Callback< Reject > () {
                    @Override
                    public void onResponse (Call< Reject > call, Response< Reject > response) {
                        System.out.println ("rejectresppppp:" + response);
                        if (response.isSuccessful ()) {
                            if (response.body ().getStatusCode () == 200) {
                                Toast.makeText (mContextl, response.body ().getMessage (), Toast.LENGTH_LONG).show ();


                            }
                        }
                    }

                    @Override
                    public void onFailure (Call< Reject > call, Throwable t) {
                        System.out.println ("rejectfailllllll:" + t.getMessage ());
                    }
                });


            } catch (Exception e) {
                e.printStackTrace ();
            }
        }
    }
}