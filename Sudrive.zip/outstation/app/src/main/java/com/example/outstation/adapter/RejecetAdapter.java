package com.example.outstation.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.activity.UpcomingView;
import com.example.outstation.rejectedm.DatumRejected;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class RejecetAdapter extends RecyclerView.Adapter<RejecetAdapter.ViewHolder> {
    private List< DatumRejected > mData;
    private Context mContext;


    public RejecetAdapter (Context mContext,List<DatumRejected> data) {
        this.mContext = mContext;
        this.mData = data;
    }

    @NonNull
    @NotNull
    @Override
    public RejecetAdapter.ViewHolder onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rejecet, parent, false);
        return new RejecetAdapter.ViewHolder (view);
    }



    @Override
    public void onBindViewHolder (@NonNull @NotNull RejecetAdapter.ViewHolder holder, int position) {
        holder.customer.setText (mData.get (position).getCustName ());
        holder.customernumber.setText (mData.get (position).getUserNumber ());
        holder.bookid.setText (mData.get (position).getId ());
        String id = mData.get (position).getId ();
        holder.partner.setText (mData.get (position).getDriverName ());
       holder.view.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                //Toast.makeText (mContext,"rejectttt",Toast.LENGTH_SHORT).show ();
                Intent i = new Intent (mContext, UpcomingView.class);
                i.putExtra ("id",holder.bookid.getText ().toString ());
                mContext.startActivity (i);
            }
        });




    }


    @Override
    public int getItemCount () {
        return mData.size ();
    }

    public class ViewHolder extends RecyclerView.ViewHolder  {

        TextView bookid, customernumber, customer, partner;
        Button view;

        public ViewHolder (@NonNull @NotNull View itemView) {
            super (itemView);
            bookid = itemView.findViewById (R.id.bookidnameu);
            partner = itemView.findViewById (R.id.partnernameu);
            customer = itemView.findViewById (R.id.customeru);
            customernumber = itemView.findViewById (R.id.costomarnumberu);
            view = itemView.findViewById (R.id.button1u2);
/*
            view.setOnClickListener(v -> {
                Toast.makeText (mContext,"rejectttt",Toast.LENGTH_LONG).show ();
            });*/

        }


    }
}
