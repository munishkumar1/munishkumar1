package com.example.outstation.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.example.outstation.R;
import com.example.outstation.adapter.ViewAdapter;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.upcomming.ViewResponse;
import com.example.outstation.utility.PrefManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpcomingView extends AppCompatActivity {

    APIInterface apiInterface;
    RecyclerView recyclerView;
    String id;
    PrefManager prefManager;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_upcoming_view);
        apiInterface = ApiClient.getClient (UpcomingView.this).create (APIInterface.class);
        recyclerView = findViewById (R.id.upcomingview);
        prefManager = new PrefManager (UpcomingView.this);
        id = getIntent ().getStringExtra ("id");
        System.out.println ("viddddddddd:"+ id);
        prefManager.saveRidDetails (id);
        viewride();
        initToolbar();
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    private void initToolbar () {
        // assigning ID of the toolbar to a variable
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        // using toolbar as ActionBar
        toolbar.setTitle ("View");
        toolbar.setTitleTextColor (getResources ().getColor (android.R.color.white));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    }

    private void viewride (){
        try{
        Call< ViewResponse> call = apiInterface.getView (id);
        call.enqueue (new Callback< ViewResponse > () {
            @Override
            public void onResponse (Call< ViewResponse > call, Response< ViewResponse > response) {
                System.out.println ("viewteeeeeeee:"+response);

                if(response.isSuccessful ()){
                    if(response.body ().getStatusCode () == 200){
                        Log.v ("viewdataaaaa",response.body ().getData ().toString ());
                        ViewAdapter viewAdapter = new ViewAdapter (UpcomingView.this, response.body ().getData (),id);
                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager (UpcomingView.this, LinearLayoutManager.VERTICAL, false);
                        recyclerView.setLayoutManager (linearLayoutManager);
                        recyclerView.setAdapter (viewAdapter);

                    }
                }
            }




            @Override
            public void onFailure (Call< ViewResponse > call, Throwable t) {
                System.out.println ("viewteeeefaillllllll:"+t.getMessage ());

            }
        });

    }catch (Exception e) {
            e.printStackTrace ();
        }
        }
    @Override
    public void onBackPressed() {
        Log.d("CDA", "onBackPressed Called");
        Intent setIntent = new Intent(getApplicationContext (),UpcomingActivity1.class);
        startActivity(setIntent);
        finish ();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}