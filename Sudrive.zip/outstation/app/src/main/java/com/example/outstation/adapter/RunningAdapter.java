package com.example.outstation.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.outstation.R;
import com.example.outstation.activity.CancelActivity;
import com.example.outstation.activity.RunningActivity1;
import com.example.outstation.activity.SecondActivity;
import com.example.outstation.activity.UpcomingView;
import com.example.outstation.data.APIInterface;
import com.example.outstation.data.ApiClient;
import com.example.outstation.running.CompleteRide;
import com.example.outstation.running.DatumRunning;
import com.example.outstation.running.RunningCancle;
import com.example.outstation.running.StartRide;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RunningAdapter extends RecyclerView.Adapter<RunningAdapter.ViewHolder> {
    private List< DatumRunning > mData;
    private Context mContext;
    private APIInterface apiInterface;
    String id;


    public RunningAdapter (Context mContext, List< DatumRunning > data) {
        this.mContext = mContext;
        this.mData = data;
    }


    @NonNull
    @NotNull
    @Override
    public RunningAdapter.ViewHolder onCreateViewHolder (@NonNull @NotNull ViewGroup parent, int viewType) {
        // to inflate the layout for each item of recycler view.
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.runningu, parent, false);
        return new RunningAdapter.ViewHolder (view);
    }


    @Override
    public void onBindViewHolder (@NonNull @NotNull RunningAdapter.ViewHolder holder, int position) {
        // holder.bookid.setText (mData.get (position).);

        holder.customer.setText (mData.get (position).getCustName ());
        holder.customernumber.setText (mData.get (position).getUserNumber ());
        holder.bookid.setText (mData.get (position).getId ());
        id = mData.get (position).getId ();
        holder.partner.setText (mData.get (position).getDriverName ());
        if (mData.get (position).getStatus () == 4) {
            holder.start.setVisibility (View.VISIBLE);
            holder.start.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Toast.makeText (mContext, "Ride has Start", Toast.LENGTH_SHORT).show ();
                    apiInterface = ApiClient.getClient (mContext).create (APIInterface.class);
                    Call< StartRide > call = apiInterface.StartRide (id);
                    call.enqueue (new Callback< StartRide > () {
                        @Override
                        public void onResponse (Call< StartRide > call, Response< StartRide > response) {
                            System.out.println ("startdddddd:" + response);
                            holder.start.setVisibility (View.GONE);
                            holder.complete.setVisibility (View.GONE);

                        }

                        @Override
                        public void onFailure (Call< StartRide > call, Throwable t) {
                            System.out.println ("startfailllllllll:" + t.getMessage ());
                        }
                    });

                }
            });
        } else if (mData.get (position).getStatus () == 1) {
            holder.complete.setVisibility (View.VISIBLE);
            holder.complete.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Toast.makeText (mContext, "Ride has Complete", Toast.LENGTH_SHORT).show ();
                    apiInterface = ApiClient.getClient (mContext).create (APIInterface.class);
                    Call< CompleteRide > call = apiInterface.completed (id);
                    call.enqueue (new Callback< CompleteRide > () {
                        @Override
                        public void onResponse (Call< CompleteRide > call, Response< CompleteRide > response) {
                            System.out.println ("copletedddddd:" + response);
                            removeItem (position);
                        }

                        @Override
                        public void onFailure (Call< CompleteRide > call, Throwable t) {
                            System.out.println ("copletedfailllllllll:" + t.getMessage ());

                        }
                    });


                }
            });
        }

        holder.view.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent i = new Intent (mContext, UpcomingView.class);
                i.putExtra ("id", id);
                mContext.startActivity (i);
            }
        });


    }


    private void removeItem (int itemPosition) {
        mData.remove (itemPosition);
        notifyItemRemoved (itemPosition);
        notifyItemRangeChanged (itemPosition, mData.size ());
    }

    @Override
    public  int getItemCount () {

        return mData.size ();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView bookid, customernumber, customer, partner;
        Button view, start, complete, cancle;

        // LinearLayout linearLayout;
        public ViewHolder (@NonNull @NotNull View itemView) {
            super (itemView);
            bookid = itemView.findViewById (R.id.bookidname);
            partner = itemView.findViewById (R.id.partnername);
            customer = itemView.findViewById (R.id.customer);
            customernumber = itemView.findViewById (R.id.costomarnumber1);
            view = itemView.findViewById (R.id.button1);
            cancle = itemView.findViewById (R.id.button4);
            cancle.setBackgroundColor (Color.RED);
            start = itemView.findViewById (R.id.button2);
            //linearLayout = itemView.findViewById (R.id.empty_run);
            complete = itemView.findViewById (R.id.button3);

            view.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {

                }
            });
            cancle.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {

                    apiInterface = ApiClient.getClient (mContext).create (APIInterface.class);
                    Call< RunningCancle > call = apiInterface.getRunningcancal (id);
                    call.enqueue (new Callback< RunningCancle > () {
                        @Override
                        public void onResponse (Call< RunningCancle > call, Response< RunningCancle > response) {
                            System.out.println ("cancledddddd:" + response);
                            Toast.makeText (mContext, response.body ().getMessage (), Toast.LENGTH_SHORT).show ();
                            Intent intent = new Intent (mContext, SecondActivity.class);
                            startActivity (intent);




                        }

                        @Override
                        public void onFailure (Call< RunningCancle > call, Throwable t) {
                            System.out.println ("canclefailllllllll:" + t.getMessage ());

                        }


                    });


                }
            });
        }
    }

    private void startActivity (Intent intent) {
    }

}


