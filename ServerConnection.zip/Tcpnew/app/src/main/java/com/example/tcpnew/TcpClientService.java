package com.example.tcpnew;


import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

public class TcpClientService extends Service {

    private AtomicBoolean working = new AtomicBoolean(true);
    private Socket socket;
    private DataInputStream dataInputStream;
    private DataOutputStream dataOutputStream;
    private String message = "Hello Server";
    private static final String TAG = "MyActivity";
    String encode = "Rover";

    byte[] dataa = encode.getBytes(StandardCharsets.UTF_8);
    boolean isFirstTime = false;

    private String IP = "120.138.10.146";
    private int PORT = 8077;

    String base64 = Base64.encodeToString(dataa, Base64.DEFAULT);
  /*  var data = """
        GET / HTTP/1.0
        User-Agent: NTRIP RTKLIB/2.4.2
        Authorization: Basic $base64
        """.trimIndent()*/

//    var data = "\nGET / HTTP/1.0\n"+
//        "User-Agent: NTRIP ApogeeGnss\n"+
//        "Accept: */*\n"+
//        "Connection: close\r\n\r\n"

    String data = "\nGET / HTTP/1.0\n"+
            "User-Agent: NTRIP ApogeeGnss\n"+
            "Accept: */*\n"+
            "Connection: close\r\n\r\n";

    Runnable runnable = new Runnable(){
        public void run() {
            //some code here


            try {
                InetAddress ip = InetAddress.getByName(IP);
                socket = new Socket(ip, PORT);
                dataInputStream = new DataInputStream(socket.getInputStream());
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                while (working.get()) {
                    try {
                        Log.i(TAG, "Received: " + socket.isConnected());
                        dataOutputStream.write(data.getBytes(StandardCharsets.UTF_8));
                        byte[] buffer = new byte[2000];
                        if(isFirstTime){
                            int avai = dataInputStream.available();
                            if(avai > 0){
                                int reaf =  dataInputStream.read(buffer);

                                String str = new String(buffer, StandardCharsets.UTF_8);
                                Log.i(TAG, "Received: " + str);
                            }

                        }
                        isFirstTime = true;
                        Log.i(TAG, "Received: " + socket.isConnected());
                        Thread.sleep(2000L);
                    }catch (Exception exception){
                        try {
                            dataInputStream.close();
                            dataOutputStream.close();
                        } catch ( IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }catch (Exception ex){
                try {
                    dataInputStream.close();
                    dataOutputStream.close();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
        }
    };

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startMeForeground();
        new Thread(runnable).start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        working.set(false);
    }

    private void startMeForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String NOTIFICATION_CHANNEL_ID = getPackageName();
            String channelName = "Tcp Client Background Service";
            NotificationChannel chan = new NotificationChannel(NOTIFICATION_CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_NONE);
            chan.setLightColor(Color.BLUE);
            Log.i(TAG,"MyActivity" +channelName);
            chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            manager.createNotificationChannel(chan);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);
            Notification notification = notificationBuilder.setOngoing(true)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("Tcp Client is running in background")
                    .setPriority(NotificationManager.IMPORTANCE_MIN)
                    .setCategory(Notification.CATEGORY_SERVICE)
                    .build();
            startForeground(2, notification);
        } else {
            startForeground(1, new Notification());
        }
    }
}

